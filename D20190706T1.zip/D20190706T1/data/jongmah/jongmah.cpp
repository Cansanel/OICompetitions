# include <bits/stdc++.h>
using namespace std;
namespace Base{
	# define mr make_pair
	typedef long long ll;
	typedef double db;
	const int inf = 0x3f3f3f3f, INF = 0x7fffffff;
	const ll  infll = 0x3f3f3f3f3f3f3f3fll, INFll = 0x7fffffffffffffffll;
	template<typename T> void read(T &x){
    	x = 0; int fh = 1; double num = 1.0; char ch = getchar();
		while (!isdigit(ch)){ if (ch == '-') fh = -1; ch = getchar(); }
		while (isdigit(ch)){ x = x * 10 + ch - '0'; ch = getchar(); }
	    if (ch == '.'){
	    	ch = getchar();
	    	while (isdigit(ch)){num /= 10; x = x + num * (ch - '0'); ch = getchar();}
		}
		x = x * fh;
	}
	template<typename T> void chmax(T &x, T y){x = x < y ? y : x;}
	template<typename T> void chmin(T &x, T y){x = x > y ? y : x;}
}
using namespace Base;

const int N = 1000010;
int n, m;
int f[N][3][3], cnt[N];
void upd(int &x, int y){
	x = max(x, y);
}
int main(){
	read(n), read(m);
	for (int i = 1; i <= n; i++){
		int x; read(x);
		cnt[x]++;
	}
	for (int i = 0; i <= m; i++)
		for (int j = 0; j <= 2; j++) 
			for (int k = 0; k <= 2; k++)
				f[i][j][k] = -inf;
	f[0][0][0] = 0;
	for (int i = 1; i <= m; i++){
		for (int j = 0; j <= 2; j++)
			for (int k = 0; k <= 2; k++){
				if (f[i - 1][j][k] == -inf) continue;
				int tmp = f[i - 1][j][k], les = cnt[i];
				if (les < j + k) continue;
				tmp += j; les -= j + k;
				for (int t = 0; t <= 2; t++){
					if (t > les) continue;
					upd(f[i][k][t], tmp + (les - t) / 3);
				}	
			}
	}
	printf("%d\n", f[m][0][0]);
	return 0;
}
