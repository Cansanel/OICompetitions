# include <bits/stdc++.h>
using namespace std; 
namespace Base{
	# define mr make_pair
	typedef long long ll;
	typedef double db;
	const int inf = 0x3f3f3f3f, INF = 0x7fffffff;
	const ll  infll = 0x3f3f3f3f3f3f3f3fll, INFll = 0x7fffffffffffffffll;
	template<typename T> void read(T &x){
    	x = 0; int fh = 1; double num = 1.0; char ch = getchar();
		while (!isdigit(ch)){ if (ch == '-') fh = -1; ch = getchar(); }
		while (isdigit(ch)){ x = x * 10 + ch - '0'; ch = getchar(); }
	    if (ch == '.'){
	    	ch = getchar();
	    	while (isdigit(ch)){num /= 10; x = x + num * (ch - '0'); ch = getchar();}
		}
		x = x * fh;
	}
	template<typename T> void chmax(T &x, T y){x = x < y ? y : x;}
	template<typename T> void chmin(T &x, T y){x = x > y ? y : x;}
}
using namespace Base;

void maker();
int worker();
void cleaner();

namespace Make{
	char prob[101]; int op; 
	void addid(char *s, int id){
		if (id == 0){s[0] = 0; return;}
		int tmp = 0;
		while (id > 0) s[tmp++] = id % 10 + '0', id /= 10;
		for (int i = 0, j = tmp - 1; i < j; i++, j--) std :: swap(s[i], s[j]);
		s[tmp] = 0;
	}
	void addout(char *s){s[0] = '.'; s[1] = 'o'; s[2] = 'u'; s[3] = 't'; s[4] = 0;}
	void addin(char *s){s[0] = '.'; s[1] = 'i'; s[2] = 'n'; s[3] = 0;}
	void prints(char *s){
		int tmp = strlen(s);
		for (int i = 0; i < tmp; i++) std :: cerr << s[i];
		std :: cerr << '\n';
	}
	int random(int l, int r){
		int size = r - l + 1;
		return l + abs(((rand() << 16) + rand())) % size;
	}
	void runMake(){
		scanf("\n%s", prob);
		int l, r, len = strlen(prob);
		read(l), read(r); 
		for (op = l; op <= r; op++){
			addid(prob + len, op); 
			addin(prob + strlen(prob));
			prints(prob);
			freopen(prob, "w", stdout);
			maker();
			fclose(stdout);
			freopen(prob, "r", stdin);
			addout(prob + strlen(prob) - 3);
			freopen(prob, "w", stdout);
			int tmp = worker();
			if (tmp != 0) cerr << "Error" << "\n";
				else cerr << "Success" << "\n";
			fclose(stdin);
			fclose(stdout);
			cleaner();
			freopen("CON", "r", stdin);
			freopen("CON", "w", stdout);
		}
	}
}

int main(){
	Make :: runMake();
	return 0;
}

void maker(){
	srand((int)time(0) + Make :: op);
	int n, typ;
	read(n); read(typ);
	if (typ == 0){
		printf("%d\n", n);
		for (int i = 1; i <= n; i++)
			printf("%d %d\n", Make :: random(1, 1e6), Make :: random(1, 1e6));
	}
	else {
		printf("%d\n", n);
		for (int i = 1; i <= n; i++)
			printf("%d %d\n", 0, Make :: random(1, 1e6));
	}
}

const int N = 1000100;
struct Node{
	int a, b;
}p[N];
int n;
bool cmp(Node x, Node y){
	return x.a - x.b > y.a - y.b;
}
int worker(){
//	freopen("queue.in", "r", stdin);
//	freopen("queue.out", "w", stdout);
	read(n);
	for (int i = 1; i <= n; i++){
		read(p[i].a), read(p[i].b);
	}
	sort(p + 1, p + n + 1, cmp);
	ll sum = 0;
	for (int i = 1; i <= n; i++)
		sum = sum + 1ll * (i - 1) * p[i].a + 1ll * (n - i) * p[i].b;
	cout << sum << endl;
	return 0;
}

void cleaner(){
	
}
