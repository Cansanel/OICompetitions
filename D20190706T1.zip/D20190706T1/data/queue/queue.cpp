# include <bits/stdc++.h>
using namespace std;
namespace Base{
	# define mr make_pair
	typedef long long ll;
	typedef double db;
	const int inf = 0x3f3f3f3f, INF = 0x7fffffff;
	const ll  infll = 0x3f3f3f3f3f3f3f3fll, INFll = 0x7fffffffffffffffll;
	template<typename T> void read(T &x){
    	x = 0; int fh = 1; double num = 1.0; char ch = getchar();
		while (!isdigit(ch)){ if (ch == '-') fh = -1; ch = getchar(); }
		while (isdigit(ch)){ x = x * 10 + ch - '0'; ch = getchar(); }
	    if (ch == '.'){
	    	ch = getchar();
	    	while (isdigit(ch)){num /= 10; x = x + num * (ch - '0'); ch = getchar();}
		}
		x = x * fh;
	}
	template<typename T> void chmax(T &x, T y){x = x < y ? y : x;}
	template<typename T> void chmin(T &x, T y){x = x > y ? y : x;}
}
using namespace Base;

const int N = 1000100;
struct Node{
	int a, b;
}p[N];
int n;
bool cmp(Node x, Node y){
	return x.a - x.b > y.a - y.b;
}
int main(){
	freopen("queue.in", "r", stdin);
	freopen("queue.out", "w", stdout);
	read(n);
	for (int i = 1; i <= n; i++){
		read(p[i].a), read(p[i].b);
	}
	sort(p + 1, p + n + 1, cmp);
	ll sum = 0;
	for (int i = 1; i <= n; i++)
		sum = sum + 1ll * (i - 1) * p[i].a + 1ll * (n - i) * p[i].b;
	cout << sum << endl;
	return 0;
}


