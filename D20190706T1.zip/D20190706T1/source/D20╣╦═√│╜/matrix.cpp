#include<iostream>
#include<stdio.h>
using namespace std;
int n,m,count[300][300][30];
long long res;
char a[300][300];
bool BT(int x,int yu,int yd)
{
	int i=yu,j=yd;
	while(i<j)
	{
		if(a[i][x]!=a[j][x]) return false;
		i++;
		j--;
	}
	return true;
}
bool good(int xl,int xr,int yu,int yd)
{
	for(int i=xl;i<=xr;i++)
		if(!BT(i,yu,yd)) return false;
	return true;
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
			count[i][j][a[i][j]-96]=count[i][j-1][a[i][j]-96]+1;
			for(int k=1;k<=26;k++)
			{
				count[i][j][k]=count[i][j-1][k];
				if(k==a[i][j]-96) count[i][j][k]++;
			}
		}
	}
	int ok=2;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++) 
		{
			for(int k=j;k<=m;k++)
			{
				for(int l=i;l<=n;l++)
				{
					ok=2;
					for(int p=1;p<=26;p++)
					{
						if((count[l][k][p]-count[l][j-1][p])&1) ok--;
						if(!ok) break;
					}
					if(!ok) break;
					if(good(j,k,i,l)) cout<<i<<' '<<l<<' '<<j<<' '<<k<<' '<<ok<<endl,res++;
				}
			}
		}
	}
	cout<<res<<endl;
	return 0;
}

//���� 
