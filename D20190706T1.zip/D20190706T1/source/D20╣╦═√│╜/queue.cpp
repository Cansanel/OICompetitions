#include<cstdio>
#include<algorithm>
#include<ctype.h>
int n;
long long res;
struct D
{
	int A,B;
}q[500010];
bool cmp(D X,D Y)
{
	return X.A-Y.A>X.B-Y.B;
}
void qread(int& x)
{
	x=0;
	int f=1;
	char c=getchar();
	for(;!isdigit(c);c=getchar())
		if(c=='-') f=-1;
	for(;isdigit(c);c=getchar()) x=x*10+c-48;
	x*=f;
	return ;
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	qread(n);
	for(int i=0;i<n;i++)
	{
		qread(q[i].A);
		qread(q[i].B);
	}
	std::sort(q,q+n,cmp);
	for(int i=0;i<n;i++) res+=i*q[i].A+(n-i-1)*q[i].B;
	printf("%lld\n",res);
	return 0;
}
