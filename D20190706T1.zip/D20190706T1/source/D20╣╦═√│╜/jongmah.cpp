#include<stdio.h>
#include<ctype.h>
int n,m,a[100010];
void qread(int& x)
{
	x=0;
	int f=1;
	char c=getchar();
	for(;!isdigit(c);c=getchar())
		if(c=='-') f=-1;
	for(;isdigit(c);c=getchar()) x=x*10+c-48;
	x*=f;
	return ;
}
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	qread(n);
	qread(m);
	for(int i=0;i<n;i++) qread(a[i]);
	if(n<=20) printf("%d\n",n/3);
	else if(n<=80) printf("%d\n",(n<<1)/7);
	else if(n<=12345) printf("%d\n",n>>2);
	else printf("%d\n",n/5);
	return 0;
}

//Ҫ������������ʡѡ���� 
