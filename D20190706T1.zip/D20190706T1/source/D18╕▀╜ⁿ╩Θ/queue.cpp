#include<bits/stdc++.h>
using namespace std;
int n;
long long ans;
struct node
{
	int l,r,dat;
}a[500010];
bool cmp(node q,node w)
{
	return q.dat>w.dat;
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	cin>>n;
	for (int i=1;i<=n;i++)
	{
		cin>>a[i].l>>a[i].r;
		a[i].dat=a[i].l-a[i].r;
	}
	sort(a+1,a+1+n,cmp);
	for (int i=1;i<=n;i++) ans+=(long long)(a[i].l*(i-1)+a[i].r*(n-i));
	cout<<ans<<endl;
}
