#include<bits/stdc++.h>
using namespace std;
int n,m,f[260][260][28],ans,p1[30],p2[30];
char a[260][260];
bool check1(int q,int w,int l,int r)
{
	for (int k=q;k<=w;k++)
	{
		int sum=0;
		for (int i=1;i<=26;i++)
		if ((f[k][r][i]-f[k][l-1][i])%2==1) sum++;
		if (sum>1) return false;
	}
	return true;
}
bool check(int q,int w,int l,int r)
{
	memset(p1,0,sizeof(p1));
	memset(p2,0,sizeof(p2));
	for (int j=l;j<=r;j++)
	{
		p1[int(a[q][j])-96]++;
		p2[int(a[w][j])-96]++;
	}
	for (int i=1;i<=26;i++)
	if (p1[i]!=p2[i]) return false;
	return true;
}

int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
			cin>>a[i][j];
	for (int i=1;i<=n;i++)
	{
		for (int j=1;j<=m;j++)
		{
			for (int k=1;k<=26;k++)
			{
				f[i][j][k]=f[i][j-1][k];
				if (int(a[i][j])-96==k) f[i][j][k]++;
			}
		}
	}
	for (int s=1;s<=n;s++)
	{
		for (int h=1;h<=m;h++)
		{
			for (int i=1;i+s-1<=n;i++)
			{
				for (int j=1;j+h-1<=m;j++)
				{
					if (check1(i,i+s-1,j,j+h-1)) 
					{
						bool flag=true;
						for (int v=i;v<=(i+i+s-1)/2;v++) 
						if (!check(v,i+s-1-v+i,j,j+h-1)) flag=false;
						if (flag) ans++;
					}
				}
			}
		}
	}
	cout<<ans<<endl;
}
