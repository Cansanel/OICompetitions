#include<bits/stdc++.h>
using namespace std;
int n,m,a[200010],t[200010],ans;
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=n;i++)
	{
		cin>>a[i];
		t[a[i]]++;
	}
	for (int i=1;i<=m;i++)
		if (t[i]>3)
		{
			ans+=t[i]/3;
			t[i]%=3;
		}
	for (int i=1;i<=m;i++)
	{
		if (t[i+1]==3&&t[i+2]==2&&t[i+3]==2)
		{
			t[i+1]=1;t[i+2]=0;t[i+3]=0;
			ans+=2;
		}
		if (t[i]==2&&t[i+1]==2&&t[i+2]==3)
		{
			t[i]=0;t[i+1]=0;t[i+2]=1;
			ans+=2;
		}
		else if (t[i]==1&&t[i+1]==3&&t[i+2]==3&&t[i+3]==2)
		{
			t[i]=0;t[i+1]=0;t[i+2]=0;t[i+3]=0;
			ans+=3;
		}
		else if (t[i]==2&&t[i+1]==3&&t[i+2]==3)
		{
			t[i]=0;t[i+1]=1;t[i+2]=1;
			ans+=2;
		}
		else if (t[i]==3&&t[i+1]==3&&t[i+2]==2)
		{
			t[i]=1;t[i+1]=1;t[i+2]=0;
			ans+=2;
		}
		else if (t[i]==3&&t[i+1]==2&&t[i+2]==3)
		{
			t[i]=1;t[i+1]=0;t[i+2]=1;
			ans+=2;
		}
		else if (t[i]>0&&t[i]<3&&t[i+1]>0&&t[i+1]<3&&t[i+2]&&t[i+2]<3)
		{
			while(t[i]&&t[i+1]&&t[i+2])
			{
				t[i]--;t[i+1]--;t[i+2]--;
				ans++;
			}
		}
		else if (t[i]==3)
		{
			t[i]=0;
			ans++;
		}
	}
	cout<<ans<<endl;
}
