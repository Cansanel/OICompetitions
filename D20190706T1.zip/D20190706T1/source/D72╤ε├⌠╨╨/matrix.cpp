#include<bits/stdc++.h>
using namespace std;
int n,m,s[251][251][26],a[251][251],ans;
bool pa[251][251][251];
int gt(){
	char c=getchar();
	while(c==' '||c=='\n')c=getchar();
	return c-'a';
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(register int i=1;i<=n;i++)for(register int j=1;j<=m;j++){
		a[i][j]=gt();
		for(int k=0;k<26;k++)s[i][j][k]=s[i][j-1][k]+(a[i][j]==k);
	}
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=m;j++)for(register int k=j;k<=m;k++){
			int tot=0;
			for(register int h=0;h<26;h++)tot+=(s[i][k][h]-s[i][j-1][h])&1;
			pa[i][j][k]=(tot<=1);
		}
	}
	for(register int i=1;i<=m;i++)for(register int j=i;j<=m;j++){
		for(register int k=1;k<=n;k++){
			if(!pa[k][i][j])continue;
			ans++;
			int t=1;
			while(k+t<=n&&k-t){
				if(!pa[k+t][i][j]||!pa[k-t][i][j])break;
				bool che=false;
				for(register int l=0;l<26;l++)if(s[k+t][j][l]-s[k+t][i-1][l]!=s[k-t][j][l]-s[k-t][i-1][l]){che=true;break;}
				if(che)break;
				ans++,t++/*,printf("(%d,%d),(%d,%d)\n",i,j,k-t,k+t)*/;
			}
		}
		for(register int k=1;k<n;k++){
			int t=0;
			while(k+t+1<=n&&k-t){
				if(!pa[k+t+1][i][j]||!pa[k-t][i][j])break;
				bool che=false;
				for(register int l=0;l<26;l++)if(s[k+t+1][j][l]-s[k+t+1][i-1][l]!=s[k-t][j][l]-s[k-t][i-1][l]){che=true;break;}
				if(che)break;
				ans++,t++/*,printf("(%d,%d),(%d,%d)\n",i,j,k-t,k+t+1)*/;
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}
/*
3 5
accac
aaaba
cccaa
*/
