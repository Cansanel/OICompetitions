#include<bits/stdc++.h>
using namespace std;
int n,m,t,tot,ans;
map<int,int>mp;
pair<int,int>p[100001];
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%d",&t),mp[t]++;
	for(map<int,int>::iterator i=mp.begin();i!=mp.end();i++)p[++tot]=make_pair(i->first,i->second)/*,printf("(%d,%d)\n",i->first,i->second)*/;
	for(int i=1;i<=tot;i++){
		if(i+2>tot)continue;
		if(!p[i].second||!p[i+1].second||!p[i+2].second){
			while(p[i].second>=3)p[i].second-=3,ans++;
			continue;
		}
		if(p[i].first+1!=p[i+1].first||p[i+1].first+1!=p[i+2].first){
			while(p[i].second>=3)p[i].second-=3,ans++;
			continue;
		}
		while(p[i].second&&p[i+1].second&&p[i+2].second)p[i].second--,p[i+1].second--,p[i+2].second--,ans++/*,printf("(%d,%d,%d)\n",p[i].first,p[i+1].first,p[i+2].first)*/;
	}
	printf("%d\n",ans);
	return 0;
}
/*
10 6
2 2 3 3 4 4 5 5 6 6

16 7
1 1 2 3 5 5 6 8 8 9 10 10 11 14 14 15
*/
