#include<bits/stdc++.h>
using namespace std;
int n,tot;
pair<int,int>p[500001];
bool cmp(pair<int,int>i,pair<int,int>j){
	return i.first-i.second>j.first-j.second;
}
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d%d",&p[i].first,&p[i].second);
	sort(p+1,p+n+1,cmp);
	for(int i=1;i<=n;i++)tot+=p[i].first*(i-1)+p[i].second*(n-i);
	printf("%d\n",tot);
	return 0;
}
