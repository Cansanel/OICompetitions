#include<bits/stdc++.h>
using namespace std;
int n,m,ans,a[1000],num[30];
char ch;
bool check1(int l,int r)
{
	bool flag=true;
	for(int k=0;k<=r-l;k++)
		if(a[l+k]!=a[r-k]) flag=false;
	return flag;
}
bool check2(int l,int r)
{
	int t;
	memset(num,0,sizeof(num));
	for(int i=l;i<=r;i++) num[a[i]]++;
	if((r-l+1)%2) t=1;
	for(int i=1;i<=26;i++)
		if(num[i]%2) t--;
	if(t) return false;
	else return true;
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n==1)
	{
		int k=0;
		while(k<m)
		{
			scanf("%c",&ch);
			if(ch>='a'&&ch<='z') a[++k]=ch-'a'+1;
		}
		for(int i=1;i<=m;i++)
			for(int j=1;j<=i;j++)
				if(check1(j,i)) ans++;
	}
	if(m==1)
	{
		int k=0;
		while(k<n)
		{
			scanf("%c",&ch);
			if(ch>='a'&&ch<='z') a[++k]=ch-'a'+1;
		}
		for(int i=1;i<=n;i++)
			for(int j=1;j<=i;j++)
				if(check2(j,i)) ans++;
	}
	printf("%d",ans);
	fclose(stdin); fclose(stdout);
	return 0;
}
