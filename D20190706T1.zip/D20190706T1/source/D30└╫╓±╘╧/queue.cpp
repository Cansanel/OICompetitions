#include<bits/stdc++.h>
using namespace std;
int n,ans;
struct node
{
	int a,b,c;
}x[1000005];
bool cmp(node p,node q)
{
	return p.c>q.c;
}
int main()
{
	
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&x[i].a,&x[i].b);
		x[i].c=x[i].a-x[i].b;
	}
	sort(x+1,x+n+1,cmp);
	for(int i=1;i<=n;i++)
	{
		ans+=x[i].a*(i-1)+x[i].b*(n-i);
	}
	printf("%d",ans);
	fclose(stdin); fclose(stdout);
	return 0;
}
