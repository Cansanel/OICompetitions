#include<bits/stdc++.h>
using namespace std;
int n,m,ans,x;
struct node
{
	int nu,data;
}num[1000005];
bool cmp(node p,node q)
{
	return p.nu<q.nu;
}
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&x);
		num[x].nu++;
		num[x].data=x;
	}
	sort(num+1,num+m+1,cmp);
	for(int i=1;i<=m;i++)
	{
		while(num[i].nu>0&&num[num[i].data-1].nu>0&&
			num[num[i].data+1].nu>0)
		{
			ans++;
			num[i].nu--;
			num[num[i].data-1].nu--;
			num[num[i].data+1].nu--;
		}
	}
	for(int i=1;i<=m;i++)
		while(num[i].nu>=3)
		{
			ans++;
			num[i].nu-=3;
		}
	printf("%d\n",ans);
	fclose(stdin); fclose(stdout);
	return 0;
}
