#include<bits/stdc++.h>
using namespace std;

int n,m,ans;
int a[255][255];

int read(){
	int x=0,f=1;char c;
	c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<3)+(x<<1)+c-'0';c=getchar();}
	return x*f;
}

bool check(int x1,int y1,int x2,int y2){
	int num[x2-x1+1][26];
	memset(num,0,sizeof(num));
	if((y2-y1+1)&1){
		
		for(int i=x1;i<=x2;i++){
			int cnt=0;
			for(int j=y1;j<=y2;j++){
				num[i-x1][a[i][j]]++;
			}
			for(int j=0;j<26;j++){
				cnt+=(num[i-x1][j]&1);
			}
			if(cnt>1) return false;
		}
	}
	else {
		for(int i=x1;i<=x2;i++){
			for(int j=y1;j<=y2;j++){
				num[i-x1][a[i][j]]++;
			}
			for(int j=0;j<26;j++){
				if(num[i-x1][j]&1) return false;
			}
		}
	}
	
	for(int i=x1;i<=(x1+x2)/2;i++){
		for(int j=0;j<26;j++){
			if(num[i-x1][j]!=num[x2-i][j]) return false;
		}
	}
	return true;
}

int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++){
		char c;
		for(int j=1;j<=m;j++){
			cin>>c;
			a[i][j]=c-'a';
		}
	}
	for(int i1=1;i1<=n;i1++){
		for(int j1=1;j1<=m;j1++){
			for(int i2=1;i2<=n;i2++){
				for(int j2=1;j2<=m;j2++){
					if(i2>=i1&&j2>=j1){
						if(check(i1,j1,i2,j2)) ans++;
					}
				}
			}
		}
	}
	cout<<ans;
	return 0;
}


