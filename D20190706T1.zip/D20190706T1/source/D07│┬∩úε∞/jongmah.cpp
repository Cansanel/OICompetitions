#include<bits/stdc++.h>
using namespace std;

int n,m,ans;
int a[100010];

int read(){
	int x=0,f=1;char c;
	c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<3)+(x<<1)+c-'0';c=getchar();}
	return x*f;
}


int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	ans=n/3;
	cout<<ans;
	return 0;
}

