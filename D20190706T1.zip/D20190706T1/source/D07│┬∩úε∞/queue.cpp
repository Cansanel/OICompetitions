#include<bits/stdc++.h>
using namespace std;

int n;
long long ans;

struct p{
	int a,b,c;
} p0[100010];

bool cmp(p p1,p p2){
	if(p1.c<p2.c) return true;
	return false;
}

int read(){
	int x=0,f=1;char c;
	c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<3)+(x<<1)+c-'0';c=getchar();}
	return x*f;
}

int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++){
		p0[i].a=read();p0[i].b=read();
		p0[i].c=p0[i].b-p0[i].a;
	}
	sort(p0+1,p0+n+1,cmp);
	
	for(int i=1;i<=n;i++){
		ans+=(i-1)*p0[i].a+(n-i)*p0[i].b;
	}
	
	cout<<ans;
	
	return 0;
}
