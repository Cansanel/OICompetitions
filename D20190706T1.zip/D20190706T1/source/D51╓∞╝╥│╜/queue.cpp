#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define ll long long
#define mod 1000000007
#define maxn 500010
using namespace std;
int n;
ll ans;
struct node{
	ll x,y;
	int num;
};
node a[maxn];
ll calc(node x1,int r1,node x2,int r2)
{
	return (ll)x1.x*(r1-1)+x1.y*(n-r1)+x2.x*(r2-1)+x2.y*(n-r2);
}
bool cmp(node x1,node x2)
{
	if(calc(x1,x1.num,x2,x2.num)>calc(x1,x2.num,x2,x1.num)) return true;
	return false;
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.txt","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	scanf("%lld%lld",&a[i].x,&a[i].y),a[i].num=i;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
	ans+=(ll)a[i].x*(i-1)+a[i].y*(n-i);
	printf("%lld",ans);
}

