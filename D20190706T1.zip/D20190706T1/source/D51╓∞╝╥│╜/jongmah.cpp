#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define ll long long
#define mod 1000000007
#define maxn 110
using namespace std;
int n,m,ans;
int a[maxn];
int f[maxn][maxn][maxn];
void fread(int &x)
{
	x=0;
	char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9')
	{
		x=x*10+c-48;
		c=getchar();
	}
}
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.txt","w",stdout);
	fread(n),fread(m);
	for(int i=1;i<=n;i++)
	{
		int x;
		fread(x);
		a[x]++;
	}
	for(int i=1;i<=m;i++)
	{
		for(int j=0;j<=a[i];j++)
		{
			for(int k=0;k*3<=j;k++)
			{
				f[i][j][k]=f[i][j-3*k][0]+k;
				if(k==0&&j<=a[i-1]&&j<=a[i-2]&&i-3>=0)
				{
					for(int l1=0;j+l1<=a[i-1];l1++)
					{
						for(int l2=0;l2*3<=l1;l2++)
						{
							if(j+l1-3*l2<=a[i-2])
							f[i][j][0]=max(f[i][j][0],f[i-1][l1][l2]+j);
						}
					}
					for(int l1=0;j+l1<=a[i-2];l1++)
					{
						for(int l2=0;l2*3<=l1;l2++)
							f[i][j][0]=max(f[i][j][0],f[i-2][l1][l2]+j);
					}
				}
			}
		}
	}
	for(int i=0;i<=a[m];i++)
	{
		for(int j=0;j*3<=i;j++)
		ans=max(f[m][i][j],ans);
	}
	printf("%d",ans);
}

