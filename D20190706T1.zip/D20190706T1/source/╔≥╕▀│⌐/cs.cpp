#include<bits/stdc++.h>
using namespace std;
void dfs(int n,int c[])
{
	cout<<n<<endl;
	for(int i=1;i<=12398;i++) c[min(10000,i+n)]=i;
	dfs(n+1,c);
}
int main()
{
int c[100000];
	dfs(1,c);
	return 0;
}

