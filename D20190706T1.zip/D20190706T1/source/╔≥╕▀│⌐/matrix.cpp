#include<bits/stdc++.h>
using namespace std;
inline char readchar()
{
	char ch=getchar();
	int p=0;
	while(ch<'a'||ch>'z') ch=getchar();
	return ch;
}
inline void read(int &x)
{
	char ch=getchar();
	int p=0;
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) p=p*10+ch-48,ch=getchar();
	x=p;
}
char a[255][255];
bool pre[26];
int jsgs[255][255];
int jsgsl[255][255];
bool can[255][255][255];
bool canl[255][255][255];
int ph[255][255][255];
int n,m;
void print()
{
	for(int  i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
			{
				for(int k=1;k<=m;k++)
				{
					cout<<can[i][j][k]<<" ";
				} 
				cout<<endl;
			}
			
		cout<<endl;
	}
	cout<<endl;
	for(int  i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
			{
				for(int k=1;k<=n;k++)
				{
					cout<<canl[i][j][k]<<" ";
				} 
				cout<<endl;
			}
			
		cout<<endl;
	}
	system("pause");
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	read(n);
	read(m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			{
				char ch=readchar();
				a[i][j]=ch;
			}
	for(int i=1;i<=n;i++)
		{
			
			for(int j=1;j<=m;j++)
				{
					memset(pre,0,sizeof(pre));
					int fuck_ccf=0;
					for(int k=j;k<=m;k++)
						{
							int ZYMAKIOI=a[i][k]-'a';
							if(pre[ZYMAKIOI]) fuck_ccf--;
							else fuck_ccf++;
							pre[ZYMAKIOI]=!pre[ZYMAKIOI];
							if(fuck_ccf==1||fuck_ccf==0) can[i][j][k]=1;
						}
					
				}
		}
	for(int i=1;i<=m;i++)
		{
			
			for(int j=1;j<=n;j++)
				{
					memset(pre,0,sizeof(pre));
					int fuck_ccf=0;
					for(int k=j;k<=n;k++)
						{
							int ZYMAKIOI=a[k][i]-'a';
							if(pre[ZYMAKIOI]) fuck_ccf--;
							else fuck_ccf++;
							pre[ZYMAKIOI]=!pre[ZYMAKIOI];
							if(fuck_ccf==1||fuck_ccf==0) canl[j][i][k]=1;
						}
					
				}
		}
//	print();
	int ans=0;
	for(int i=1;i<=n;i++)
		{
			for(int j=i;j<=n;j++)
				{
					for(int k=1;k<=m;k++)
						{
							ph[i][j][k]=ph[i][j][k-1]+(can[i][1][k]&&can[j][1][k]&&canl[i][k][j]);
						}
				}
		}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			for(int k=1;k<=n;k++)
				{
					ans+=ph[i][k][m]-ph[i][k][j-1];
				}
	cout<<ans<<endl;
	return 0;
}

