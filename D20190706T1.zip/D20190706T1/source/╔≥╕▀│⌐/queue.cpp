#include<bits/stdc++.h>
using namespace std;
struct node{
	int a,b,c;
};
node a[500005];
bool cmp(node a,node b)
{
	return a.c>b.c;
}
inline void read(int &x)
{
	char ch=getchar();
	int p=0;
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) p=p*10+ch-48,ch=getchar();
	x=p;
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	int n;
	read(n);
	for(int i=1;i<=n;i++)
		{
			read(a[i].a);
			read(a[i].b);
			a[i].c=a[i].a-a[i].b;
		}
	sort(a+1,a+n+1,cmp);
	int ans=0;
	for(int i=1;i<=n;i++)
		{
			ans+=(i-1)*a[i].c+(n-1)*a[i].b;
		}
	cout<<ans<<endl;
	return 0;
}

