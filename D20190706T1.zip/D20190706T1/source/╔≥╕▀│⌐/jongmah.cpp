#include<bits/stdc++.h>
using namespace std;
inline void read(int &x)
{
	char ch=getchar();
	int p=0;
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) p=p*10+ch-48,ch=getchar();
	x=p;
}
int tong[100005];
int pre[100005];
int m;
int ans;
bool g(int x,int y)
{
	return (y+(pre[m]-pre[x-1])/3)<ans;
}
void dfs(int x,int gs)
{
	if(x>m)
		{
			if(tong[x]<0||tong[x+1]<0) return ;
			ans=max(ans,gs);
			return ;
		}
	if(tong[x]<0) return;
	if(g(x,gs)) return ;
	if(tong[x]>3)
		{
			gs+=tong[x]/3;
			tong[x]%=3;
			if(tong[x]==0)
				{
					tong[x]=3;
					gs--;
				}
		}
	int t=tong[x];
	int d=tong[x],e=tong[x+1],f=tong[x+2];
	if(t==3)
		{
			tong[x]=d-1,tong[x+1]=e-1,tong[x+2]=f-1; 
			dfs(x+1,gs+1);
			tong[x]=d-2,tong[x+1]=e-2,tong[x+2]=f-2;
			dfs(x+1,gs+2);
			tong[x]=d-3,tong[x+1]=e,tong[x+2]=f; 
			dfs(x+1,gs+1);
			tong[x]=d,tong[x+1]=e,tong[x+2]=f; 
		}
	if(t==2)
		{
			tong[x]=d-1,tong[x+1]=e-1,tong[x+2]=f-1; 
			dfs(x+1,gs+1);
			tong[x]=d-2,tong[x+1]=e-2,tong[x+2]=f-2;
			dfs(x+1,gs+2);
			tong[x]=d,tong[x+1]=e,tong[x+2]=f; 
		}
	if(t==1)
		{
			tong[x]=d-1,tong[x+1]=e-1,tong[x+2]=f-1; 
			dfs(x+1,gs+1);
			tong[x]=d,tong[x+1]=e,tong[x+2]=f; 
		}
	dfs(x+1,gs);
	tong[x]=d,tong[x+1]=e,tong[x+2]=f; 
}
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	int n;
	read(n);
	read(m);
	for(int i=1;i<=n;i++)
		{
			int x;
			read(x);
			tong[x]++;
		}
	for(int i=1;i<=n;i++)
		{
			pre[i]=pre[i-1]+tong[i];
		}
	if(n<=200)
		{
			dfs(1,0);
		}
	else
		{
			for(int i=1;i<=m;i++)
				{
					int k=min(tong[i],min(tong[i+1],tong[i+2]));
					ans+=k;
					tong[i]-=k;
					tong[i+1]-=k;
					tong[i+2]-=k;
				}
		}
	cout<<ans<<endl;
	return 0;
}

