#include<cstdio>
#include<algorithm>
using namespace std;
int ans,ans1,ans2,n,k;
struct node
{
	int l,r,c;
}a[1000000];
bool cmp(node a,node b)
{
	return a.c>b.c;
}

int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
		scanf("%d%d",&a[i].l,&a[i].r),a[i].c=a[i].l-a[i].r;
	sort(a+1,a+1+n,cmp);
	for (int i=1;i<=n;i++) 
	{
		ans+=a[i].l*k+a[i].r*(n-1-k);
		k++;
	}
	printf("%d",ans);
}
