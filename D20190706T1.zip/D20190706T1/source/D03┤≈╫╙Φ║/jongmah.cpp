#include<cstdio>
#include<algorithm>
using namespace std;
int a[1000000],ans,n,m,x,tot;
int dfs(int k)
{
	ans=max(ans,k);
	for (int i=1;i<=n;i++)
	{
		if (a[i]>=3)
		{
			a[i]-=3;
			dfs(k+1);
			a[i]+=3;
			
		}
		if (a[i]&&a[i+1]&&a[i+2])
		{
			a[i]--;a[i+1]--;a[i+2]--;
			dfs(k+1);
			a[i]++;a[i+1]++;a[i+2]++;	
		}
	}
	
}
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	scanf("%d",&n,&m);
	for (int i=1;i<=n;i++)
	{
		scanf("%d",&x);
		a[x]++;
		
	}
	dfs(0);
	printf("%d",ans);
	
}
