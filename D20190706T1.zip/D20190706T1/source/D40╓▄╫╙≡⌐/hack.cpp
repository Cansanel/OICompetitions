#include<iostream>
#include<cstdio>
#include<queue>
using namespace std;
int n,m,flag;
bool used[1200100];
int mint[1200100],w[1200100],myt[1200100];
int from[1200100],to[1200100],tot,fa[800800];
priority_queue < pair<int,int> > q;
void case1()
{
	int x,y;
	for(int i=1;i<=m;i++) cin>>x>>y;
	for(int i=1;i<=n-1;i++) cin>>mint[i];
	for(int i=1;i<=m;i++)
	{
		if(mint[i]==i) cout<<i<<" ";
		else
		{
			cout<<n<<" ";
			for(int j=i+1;j<=m;j++) cout<<j-1<<" ";
			break;
		}
	}
}
void case2()
{
	for(int i=1;i<=m;i++) cout<<i<<" ";
}
void addedge(int x,int y)
{
	tot++;
	from[tot]=x;
	to[tot]=y;
}
int get(int x)
{
	if(x==fa[x]) return x;
	return fa[x]=get(fa[x]);
}
void merge(int x,int y)
{
	fa[get(x)]=get(y);
}
bool check()
{
	int treen=0;
	for(int i=1;i<=n;i++) fa[i]=i;
	for(int i=1;i<=m;i++) q.push(make_pair(-w[i],i));
	while(1)
	{
		pair<int,int> p=q.top();
		q.pop();
		int i=p.second;
		if(get(from[i])==get(to[i])) continue;
		merge(from[i],to[i]);
		treen++;
		myt[treen]=i;
		if(treen==n-1)
		{
			while(!q.empty())
			{
				q.pop();
			}
			for(int j=1;j<=n-1;j++)
			{
				if(!mint[myt[j]]) return false;
			}
			for(int j=1;j<=m;j++)
			{
				cout<<w[j]<<" ";
			}
			cout<<endl;
			return true;
		}
	}
}
void dfs(int i)
{
	if(i==m+1)
	{
		if(check()) flag=1;
		return;
	}
	for(int j=1;j<=m;j++)
	{
		if(!used[j]&&!flag)
		{
			if((j==1||j==2)&&!mint[i]) continue;
			used[j]=1;
			w[i]=j;
			dfs(i+1);
			used[j]=0;
		}
	}
}
int main()
{
	freopen("hack.in","r",stdin);
	freopen("hack.out","w",stdout);
	cin>>n>>m;
	if(n==m)
	{
		case1();
		return 0;
	}
	else if(n>1000&&n<=300000&&m>1000&&m<=300000)
	{
		case2();
		return 0;
	}
	for(int i=1;i<=m;i++)
	{
		int a,b;
		cin>>a>>b;
		addedge(a,b);
	}
	for(int i=1;i<=n-1;i++)
	{
		int x;
		cin>>x;
		mint[x]=1;
	}
	dfs(1);
	return 0;
}
