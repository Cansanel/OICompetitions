#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,a[100100],fa[100100],dep[100100],d1[100100],d2[100100],dm;
int head[100100],nxt[200100],to[200100],tot;
long long ans[100100],answer;
bool disable[200100],changed[100100],visited[100100],isroot[100100];
inline int read()
{
	int x=0;
	bool f=0;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')
		{
			f=1;
			c=getchar();
		}
	}
	while(c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+c-'0';
		c=getchar();
	}
	return f?-x:x;
}
inline void write(long long x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
inline void addedge(int u,int v)
{
	tot++;
	to[tot]=v;
	nxt[tot]=head[u];
	head[u]=tot;
}
inline void dfs(int u,int father,int root)
{
	if(changed[u]||visited[u])
	{
		if(d1[u]+d2[u]-a[u]>ans[root]) ans[root]=d1[u]+d2[u]-a[u];
		for(int i=head[u];i;i=nxt[i])
		{
			if(to[i]==father||disable[i]) continue;
			dfs(to[i],u,root);
		}
		return;
	}
	changed[u]=1;
	d1[u]=d2[u]=a[u];
	fa[u]=father;
	dep[u]=dep[father]+1;
	for(int i=head[u];i;i=nxt[i])
	{
		if(to[i]==father||disable[i]) continue;
		dfs(to[i],u,root);
		if(d1[to[i]]+a[u]>d1[u])
		{
			d2[u]=d1[u];
			d1[u]=d1[to[i]]+a[u];
		}
		else if(d1[to[i]]+a[u]>d2[u])
		{
			d2[u]=d1[to[i]]+a[u];
		}
	}
	if(d1[u]+d2[u]-a[u]>ans[root]) ans[root]=d1[u]+d2[u]-a[u];
}
int main()
{
	freopen("forest.in","r",stdin);
	freopen("forest.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<n;i++)
	{
		int a,b;
		a=read();b=read();
		addedge(a,b);
		addedge(b,a);
	}
	dfs(1,0,1);
	answer=1;
	isroot[1]=1;
	for(int i=1;i<=n;i++)
	{
		if(ans[i]==0) continue;
		answer=(answer*ans[i])%1000000007;
	}
	write(answer);
	putchar('\n');
	for(int i=1;i<n;i++)
	{
		int k;
		k=read();
		disable[k<<1]=1;
		disable[(k<<1)-1]=1;
		int u=to[k<<1];
		int v=to[(k<<1)-1];
		if(dep[u]>dep[v]) swap(u,v);
		changed[v]=0;
		isroot[v]=1;
		do
		{
			changed[u]=0;
			ans[u]=0;
			u=fa[u];
		}while(fa[u]);
		changed[u]=0;
		ans[u]=0;
		memset(visited,0,sizeof(visited));
		for(int j=1;j<=n;j++)
		{
			if(visited[j]||!isroot[j]) continue;
			dfs(j,fa[j],j);
		}
		answer=1;
		for(int j=1;j<=n;j++)
		{
			if(ans[j]==0) continue;
			answer=(answer*ans[j])%1000000007;
		}
		//if(i==1)
			//cout<<"1";
		write(answer);
		putchar('\n');
	}
}
/*
7
3 2 1 5 4 7 6
1 2
2 4
2 5
1 3
4 6
4 7
4
2
1
6
3
5
*/
