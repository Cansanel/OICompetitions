#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctime>
using namespace std;
int n,m;
char c[260][260];
int sum[260][128],dp[260][260];
bool check(int i,int j)
{
	int len=j-i+1;
	int ji=0;
	for(int k='a';k<='z';k++)
	{
		if((sum[j][k]-sum[i-1][k])%2) ji++;
	}
	if(len%2)
	{
		if(ji==1) return true;
		return false;
	}
	if(ji) return false;
	return true;
}
void case1()
{
	int ans=0;
	for(int i=1;i<=m;i++)
	{
		char x;
		cin>>x;
		for(int j='a';j<='z';j++)
			if(j==x) sum[i][j]=sum[i-1][j]+1;
			else sum[i][j]=sum[i-1][j];
	}
	for(int i=1;i<=m;i++)
	{
		for(int j=i;j<=m;j++)
		{
			if(check(i,j)) ans++;
		}
	}
	cout<<ans;
	return;
}
void case2()
{
	
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	srand((unsigned)time(0));
	cin>>n>>m;
	if(n==1)
	{
		case1();
		return 0;
	}
	if(m==1)
	{
		case2();
		return 0;
	}
	cout<<rand()*rand()%100000000;
	return 0;
}
