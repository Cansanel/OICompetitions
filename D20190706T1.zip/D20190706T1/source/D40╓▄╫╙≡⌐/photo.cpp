#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
//color[i][j]��i�е�j�� 
int n,m,t,color[2100][2100],sum[2100],used[2100],ans;
inline bool check()
{
	int sum1=0,sum2=0;
	//��q�к͵�q+1�� 
	for(int q=1;q<m;q++)
	{
		memset(used,0,sizeof(used));
		for(int i=1;i<=n;i++)
		for(int j=1;j<=q;j++)
		{
			if(!used[color[i][j]])
			{
				sum1++;
				used[color[i][j]]=1;
			}
		}
		memset(used,0,sizeof(used));
		for(int i=1;i<=n;i++)
		for(int j=q+1;j<=m;j++)
		{
			if(!used[color[i][j]])
			{
				sum2++;
				used[color[i][j]]=1;
			}
		}
		if(sum1!=sum2) return false;
	}
	return true;
}
inline void dfs(int i,int j)
{
	if(j==m+1)
	{
		if(check()) ans++;
		return;
	}
	for(int k=1;k<=t;k++)
	{
		color[i][j]=k;
		if(i==n)
		{
			dfs(1,j+1);
		}
		else dfs(i+1,j);
	}
}
int main()
{
	freopen("photo.in","r",stdin);
	freopen("photo.out","w",stdout);
	cin>>n>>m>>t;
	dfs(1,1);
	cout<<ans;
	return 0;
}
