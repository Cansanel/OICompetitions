#include<iostream>
#include<cstdio>
using namespace std;
int a[30]={1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912};
int t,n;
int main()
{
	freopen("lemon.in","r",stdin);
	freopen("lemon.out","w",stdout);
	cin>>t;
	bool flag=0;
	while(t--)
	{
		cin>>n;
		flag=0;
		for(int i=0;i<30;i++)
		{
			if(n==a[i])
			{
				cout<<"Yes\n";
				flag=1;
				break;
			}
		}
		if(!flag) cout<<"No\n";
	}
	return 0;
}
