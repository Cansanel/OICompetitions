#include<iostream>
#include<cstdio>
using namespace std;
int mod=998244353;
long long n,sum;
int a[10001000];
long long fmod(long long a,long long b)
{
	long long r=1;
	while(b)
	{
		if(b&1) r=(r*a)%mod;
		a=(a*a)%mod;
		b>>=1;
	}
	return r;
}
int main()
{
	freopen("helpers.in","r",stdin);
	freopen("helpers.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		sum+=a[i];
	}
	for(int i=1;i<=n;i++)
	{
		printf("%d ",(fmod(sum,mod-2)%mod*a[i])%mod);
	}
	return 0;
}
