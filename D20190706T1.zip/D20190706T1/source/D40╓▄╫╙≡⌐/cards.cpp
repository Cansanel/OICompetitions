#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,a[500],lose,win,must,get[500],board;
inline int read()
{
	int x=0;
	bool f=0;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')
		{
			f=1;
			c=getchar();
		}
	}
	while(c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+c-'0';
		c=getchar();
	}
	return f?-x:x;
}
inline void write(long long x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
inline int gcd(int a,int b)
{
	if(b==0) return a;
	else return gcd(b,a%b);
}
//player:1��0���֣���k���� 
inline void dfs(int player,int k)
{
	if(k==n+1)
	{
		if(player) lose++;
		else win++;
		return;
	}
	for(int i=1;i<=n;i++)
	{
		if(!get[i])
		{
			get[i]=1;
			int t=board;
			board=gcd(board,a[i]);
			if(board==1)
			{
				if(player) lose++;
				else win++;
				get[i]=0;
				board=t;
				continue;
			}
			if(player) dfs(0,k+1);
			else dfs(1,k+1);
			get[i]=0;
			board=t;
		}
	}
}
int main()
{
	freopen("cards.in","r",stdin);
	freopen("cards.out","w",stdout);
	n=read();
	if(n>20)
	{
		printf("%.9f %.9f",(double)must,(double)must);
		return 0;
	}
	for(int i=1;i<=n;i++) a[i]=read();
	dfs(1,1);
	if(win) must=1;
	printf("%.9f %.9f",(double)win/(double)(win+lose),(double)must);
	return 0;
}
