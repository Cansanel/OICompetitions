#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
struct person{
	int a,b,c;
}p[500500];
int n;
long long ans;
inline bool comp(person a,person b)
{
	return a.c>b.c;
}
inline int read()
{
	int x=0;
	bool f=0;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')
		{
			f=1;
			c=getchar();
		}
	}
	while(c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+c-'0';
		c=getchar();
	}
	return f?-x:x;
}
inline void write(long long x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		p[i].a=read();
		p[i].b=read();
		p[i].c=p[i].a-p[i].b;
	}
	sort(p+1,p+n+1,comp);
	for(int i=1;i<=n;i++)
	{
		ans+=p[i].a*(i-1)+p[i].b*(n-i);
	}
	write(ans);
	return 0;
}
