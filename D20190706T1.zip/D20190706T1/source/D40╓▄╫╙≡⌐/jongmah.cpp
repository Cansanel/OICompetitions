#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
inline int read()
{
	int x=0;
	bool f=0;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')
		{
			f=1;
			c=getchar();
		}
	}
	while(c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+c-'0';
		c=getchar();
	}
	return f?-x:x;
}
inline void write(long long x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
int n,m;
int f[100100][5][5];
int a[100100],amin;
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	n=read();m=read();
	amin=100000000;
	for(int i=1;i<=n;i++)
	{
		int x;
		x=read();
		a[x]++;
		amin=min(amin,x);
	}
	for(int i=1;i<=m;i++)
	{
		for(int j=0;j<=2;j++)
		{
			for(int k=0;k<=2;k++)
			{
				for(int l=0;l<=2;l++)
				{
					if(a[i+2]>=j&&a[i+1]>=j+k&&a[i]>=j+k+l&&a[i-1]>=k+l&&a[i-2]>=l)
						f[i][j][k]=max(f[i][j][k],f[i-1][k][l]+j+(a[i]-j-k-l)/3);
				}
			}
		}
	}
	cout<<f[m][0][0];
	return 0;
}
