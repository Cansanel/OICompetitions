/*
  	�����е�����ѧ ��˧
*/

#include <bits/stdc++.h>
#define LL long long 
using namespace std;

inline long long read()
{
	int a = 0;
	char c = getchar();
	int	f = 1;
	while (!isdigit(c)) {if (c == '-') f = -1; c = getchar();}
	while (isdigit(c)) {a = a * 10 + c - '0'; c = getchar();}
	return a * f;
}

inline long long write(long long x)
{
	if (x < 0)
	{
		putchar('-');
		x = -x;
	}
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}

struct node
{
	int l, r, qz;
}a[500005];

bool cmp(node x, node y)
{
	return x.qz > y.qz;
}

int main()
{
	freopen("queue.in", "r", stdin);
	freopen("queue.out", "w", stdout);
	int n = read();
	for (int i = 1; i <= n; i++)
	{
		a[i].l = read();
		a[i].r = read();
		a[i].qz = a[i].l - a[i].r;
	}
	sort(a + 1, a + n + 1, cmp);
	LL ans = 0;
	for (int i = 1; i <= n; i++)
	{
		ans = ans + (a[i].l * (i - 1) + a[i].r * (n - i));
	}
	write(ans);
	cout << endl;
	return 0;
}

