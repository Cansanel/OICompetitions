#include <bits/stdc++.h>
#define LL long long 
using namespace std;

int n, m;

char a[301][301];

string sum[301][301], temp[301];

int vis[2000]; 

map <char, int> mp;

void solve()
{
	LL ans = 0; 
	string sumall = "";
	for (int i = 1; i <= n; i++)
	{
		sumall = "";
	    for (int j = 1; j <= m; j++)
	    {
	    	memset(vis, 0, sizeof(vis));
	    	sumall = sumall + a[i][j];
			for (int l = 0; l < sumall.size(); l++)
			{
				vis[int(sumall[l])]++;
			} 
			int s = 0;
			for (int l = 97; l <= 122; l++)
			{
				if (vis[l] % 2 == 1) s++;
			}
			if (s <= 1) ans++;
		}
	}		 
	cout << ans << endl;
}

void init()
{
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
		{
		    cin >> a[i][j];
		}
	}
}

int main()
{
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	init();
	solve();
	return 0;
}

