#include<bits/stdc++.h>
using namespace std;
int a[500001],b[500001],f[500001],n;
int q(int x,int y)
{
	return a[y]*(x-1)+b[y]*(n-x);
}
bool bj(int x,int y)
{
	return a[x]-b[x]>a[y]-b[y];
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	int i,ans=0;
	cin>>n;
	for(i=1;i<=n;i++)
	{cin>>a[i]>>b[i];f[i]=i;}
	sort(f+1,f+n+1,bj);
	for(i=1;i<=n;i++)ans+=q(i,f[i]);
	cout<<ans;
	return 0;
	fclose(stdin);
	fclose(stdout);
}
