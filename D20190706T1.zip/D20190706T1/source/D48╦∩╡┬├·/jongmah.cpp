#include<bits/stdc++.h>
using namespace std;
int c[100001],f[100001];
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	int n,a,i,j,m,maxm=0,maxn;
	cin>>n>>m;
	for(i=1;i<=n;i++)
	{
		cin>>a;
		c[a]++;
	}
	for(i=1;i<=m;i++)
	{
		maxn=f[i-1]+c[i]/3;
		if(i>=3)
		if(c[i]%3==0)maxm=0;
		else if(c[i-1]%3==0&&c[i-2]%3==0)maxm=f[i-3]+c[i]/3+c[i-1]/3+c[i-2]/3-2+min(min(c[i]%3,c[i-1]%3+3),c[i-2]%3+3);
		else if(c[i-1]%3==0)maxm=f[i-3]+c[i]/3+c[i-1]/3+c[i-2]/3-1+min(min(c[i]%3,c[i-1]%3+3),c[i-2]%3);
		else if(c[i-2]%3==0)maxm=f[i-3]+c[i]/3+c[i-1]/3+c[i-2]/3-1+min(min(c[i]%3,c[i-1]%3),c[i-2]%3+3);
		else maxm=f[i-3]+c[i]/3+c[i-1]/3+c[i-2]/3+min(min(c[i]%3,c[i-1]%3),c[i-2]%3);
		f[i]=max(maxn,maxm);
    }
    cout<<f[m];
    fclose(stdin);
    fclose(stdout);
}
