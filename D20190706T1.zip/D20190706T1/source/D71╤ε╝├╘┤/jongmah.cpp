#include<bits/stdc++.h>
using namespace std;
template <typename T> inline void read(T &x)
{
	int f = 1; x = 0;
	char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}
const int N = 1e5 + 5;
int n, m;
int a[N];
int h[N];
int f[N][4][4][4];
int maxn[N][4][4];
int main(){
	freopen ("jongmah.in", "r", stdin);
	freopen ("jongmah.out", "w", stdout);
	read(n); read(m);
	for (int i = 1; i <= n; i++) read(a[i]), h[a[i]]++;
	sort(a + 1, a + n + 1);
	
	int ans = 0;
	for (int i = 1; i <= m; i++)
	if (h[i] > 3)
	{
		ans += h[i] / 3 - 1;
		h[i] = 3;
	}
	int now = 0;
	for (int i = 1; i <= m; i++)
	{
		for (int j = 0; j <= h[i]; j++)
		{
			for (int k = 0; k <= h[i - 1]; k++)
			{
				for (int l = 0; l <= h[i - 2]; l++)
			 	{
			 		int x = min(j, min(k, l)), y;
			 		bool is1 = 0, is2 = 0, is3 = 0;
			 		if (j == 3) is1 = 1; if (k == 3) is2 = 1; if (l == 3) is3 = 1;
			 		y = is1 + is2 + is3;
			 		for (int p = 0; p <= x; p++)
			 		f[i][j][k][l] = max(f[i][j][k][l], p + maxn[i - 1][k - p][l - p]) ;
			 		f[i][j][k][l] = max(f[i][j][k][l], f[i][j - is1 * 3][k - is2 * 3][l - is3 * 3] + y);
				    maxn[i][j][k] = max(maxn[i][j][k], f[i][j][k][l]);
				    now = max(now, f[i][j][k][l]);
			 	}
			}
			 
		}
	}
	printf("%d\n", ans + now);
  return 0;
}
