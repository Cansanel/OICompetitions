#include<bits/stdc++.h>
using namespace std;
const int N = 3e2 + 5;
int a[N][N];
string st[N];
int n, m;
int cnt[30];
bool h[N][N][N];
inline void solve_20pts()
{
	if (n == 1)
	{
		int sum = 0;
		for (int l = 1; l <= m; l++)
		 for (int r = l; r <= m; r++)
		  sum += h[1][l][r];
		  
		printf("%d\n", sum);
	}
	else
	{
		 int sum = 0;
	 	 for (int l = 1; l <= n; l++)
	 	 {
	 		memset(cnt, 0, sizeof(cnt));
	 		cnt[a[l][1]]++;
	 		int odd = 1;
	 		int r = l;
	 		while (r <= n)
	 		{
		 		if (odd <= 1) sum++;
		 		r++;
	 			cnt[a[r][1]]++;
	 			if (cnt[a[r][1]] % 2) odd++; else odd--;
	 		}
	 	 }
	 	printf("%d\n", sum);
	}
}
pair <int, pair <int, int> > p[N * N * N];
int tot;
inline bool check(int x1, int y1, int z1, int x2, int y2, int z2)
{
	if (!h[x1][y1][z1] || !h[x2][y2][z2]) return 0;
	string st1 = st[x1].substr(y1 - 1, z1 - y1 + 1);
	string st2 = st[x2].substr(y2 - 1, z1 - y1 + 1);
	sort(st1.begin(), st1.end());
	sort(st2.begin(), st2.end());
	if (st1 != st2) return 0;
	return 1;
}
inline void solve()
{
	int ans = 0;
	for (int i = 1; i <= tot; i++)
	{
		int x1 = p[i].first, y1 = p[i].second.first, z1 = p[i].second.second;
		int x2 = x1, y2 = y1, z2 = z1;
		while (check(x1, y1, z1, x2, y2, z2))
		{
			ans++;
			x1--; x2++;
			if (x1 < 1 || x2 > n) break;
		}	
			if (check(x1, y1, z1, x1 + 1, y2, z2))
			{
				x2 = x1 + 1;
				while (check(x1, y1, z1, x2, y2, z2))
				{
				ans++;
				x1--; x2++;
				if (x1 < 1 || x2 > n) break;
				}
			}
	}
	printf("%d\n", ans);
}
int main(){
	freopen ("matrix.in", "r", stdin);
	freopen ("matrix.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
	{
		cin >> st[i];
		for (int j = 0; j < m; j++)
		a[i][j + 1] = st[i][j] - 'a';
	}
	
	for (int i = 1; i <= n; i++)
	 for (int l = 1; l <= m; l++)
	 {
	 	memset(cnt, 0, sizeof(cnt));
	 	cnt[a[i][l]]++;
	 	int odd = 1;
	 	int r = l;
	 	while (r <= m)
	 	{
		 	if (odd <= 1)
		 	{
		 		h[i][l][r] = 1;
		 		p[++tot] = make_pair(i, make_pair(l, r));
		 	}
		 	else h[i][l][r] = 0;
		 	r++;
	 		cnt[a[i][r]]++;
	 		
	 		if (cnt[a[i][r]] % 2) odd++; else odd--;
	 	}
	 }
	 if (n == 1 || m == 1) solve_20pts();
	 
	 else solve();
	 
  return 0;
}
