#include<bits/stdc++.h>
#define LL long long
using namespace std;
template <typename T> inline void read(T &x)
{
	int f = 1; x = 0;
	char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}
const int N = 5e5 + 5;
struct info
{
	LL a, b;
}num[N];
inline bool comp(info x, info y)
{
	return x.a - x.b > y.a - y.b;
}
int main(){
	freopen ("queue.in", "r", stdin);
	freopen ("queue.out", "w", stdout);
	int n;
	read(n);
	for (int i = 1; i <= n; i++) read(num[i].a), read(num[i].b);
	sort(num + 1, num + n + 1, comp);
	
	LL ans = 0;
	for (int i = 1; i <= n; i++) ans += num[i].a * (i - 1) + num[i].b * (n - i);
	printf("%lld\n", ans);
  return 0;
}
