#include <bits/stdc++.h>
#define open(name) freopen(#name".in", "r", stdin), freopen(#name".out", "w", stdout)
#define LL long long
#define ULL unsigned long long
#define Endl putchar('\n')
using namespace std;

template < typename T >
void readin(T &value)
{
	value = 0;
	T f = 1;
	char ch = getchar();
	while(!isdigit(ch) && ch != '-')
		ch = getchar();
	if (ch == '-')
	{
		f *= -1;
		ch = getchar();
	}
	do
	{
		value = value * 10 + (ch - '0');
		ch = getchar();
	}
	while(isdigit(ch));
}

template < typename T >
void write(T value)
{
	if (value == 0) return;
	if (value < 0)
	{
		putchar('-');
		write(value * -1);
	}
	else
	{
		write(value / 10);
		putchar((value % 10) + '0');
	}
}

template < typename T >
void writeout(T value)
{
	if (value == 0) putchar('0');
	else write(value);
}

typedef pair < LL , pair < LL, LL > > Que;

Que que[100005];

bool cmp(Que a, Que b)
{
	return a > b;
}

int main()
{
	open(queue);
	int n;
	readin(n);
	for (int i = 1; i <= n; ++i)
	{
		readin(que[i].second.first);
		readin(que[i].second.second);
		que[i].first = que[i].second.first - que[i].second.second;
	}
	sort(que + 1, que + n + 1, cmp);
	LL sum1 = 0, sum2 = 0, sum3 = 0;
	for (int i = 1;i <= n; ++i)
	{
		sum1 += que[i].first * i;
		sum2 += que[i].second.first;
		sum3 += que[i].second.second;
	}
	writeout(sum1 - sum2 + sum3 * n);
	Endl;
	return 0;
}
