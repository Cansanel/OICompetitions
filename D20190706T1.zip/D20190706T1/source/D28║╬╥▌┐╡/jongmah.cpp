#include <bits/stdc++.h>
#define open(name) freopen(#name".in", "r", stdin), freopen(#name".out", "w", stdout)
#define LL long long
#define ULL unsigned long long
#define Endl putchar('\n')
using namespace std;

template < typename T >
void readin(T &value)
{
	value = 0;
	T f = 1;
	char ch = getchar();
	while(!isdigit(ch) && ch != '-')
		ch = getchar();
	if (ch == '-')
	{
		f *= -1;
		ch = getchar();
	}
	do
	{
		value = value * 10 + (ch - '0');
		ch = getchar();
	}
	while(isdigit(ch));
}

template < typename T >
void write(T value)
{
	if (value == 0) return;
	if (value < 0)
	{
		putchar('-');
		write(value * -1);
	}
	else
	{
		write(value / 10);
		putchar((value % 10) + '0');
	}
}

template < typename T >
void writeout(T value)
{
	if (value == 0) putchar('0');
	else write(value);
}

int r[100005], f[100005];//[60][60];
stack < int > jong;

int main()
{
	open(jongmah);
	int n, m, begin = INT_MAX;
	readin(n);
	readin(m);
	for (int i = 1; i <= n; ++i)
	{
		//int a;
	//	readin(a);
	//	++r[a];
	///	begin = min(begin, a);
		readin(r[i]);
	}
	
	int Ans = 0;
	for (int i = 1; i <= n; ++i)
	{
		if (!jong.empty() && jong.top() == r[i])
			++f[r[i]];
		else if (jong.size() >= 2)
		{
			int num1 = r[i];
			int num2 = jong.top();
			jong.pop();
			int num3 = jong.top();
			jong.pop();
			if (num1 == num2 + 1 && num2 == num3 + 1)
			{
				++Ans;
				if (f[num3])
				{
					jong.push(num3);
					--f[num3];
				}
				if (f[num2])
				{
					jong.push(num2);
					--f[num2];
				}
			}
			else
			{
				jong.push(num3);
				jong.push(num2);
				jong.push(num1);
			}
		}
		else
		{
			jong.push(r[i]);
		}
	}
	while(!jong.empty())
	{
		++f[jong.top()];
		jong.pop();
	}
	for (int i = 1;i <= m; ++i)
		Ans += (f[i] / 3);
	writeout(Ans);
	
	/*
	int len = 0;
	for (int i = 1; i * 3 <= r[begin]; ++i)
		f[begin][0][r[begin] - i * 3] = i;
	for (int i = begin + 1; i <= m; ++i)
		//for (int j = r[i - 2]; j >= 0; --j)
		for (int j = 0; j <= r[i - 2]; ++j)
			//for (int k = r[i - 1]; k >= 0; --k)
			for (int k = 0; k <= r[i - 1]; ++k)
			{
				for (int p = 1; p <= j && p <= k; ++p)
				{
					len = max(f[i][k - p][r[i] - p] = max(f[i][k - p][r[i] - p], f[i - 1][j][k] + p), len);
					if (f[i - 1][j][k]) cout << ((j >= k) ? "Yes" : "No") << endl;
				}
					
				for (int p = 1; p * 3 <= r[i]; ++p)
				{
					len = max(f[i][k][r[i] - p * 3] = max(f[i][k][r[i] - p * 3], f[i][k][r[i]] + p), len);
				}
					
			}
	writeout(len);
	
	int len = 0;
	for (int i = 0; i * 3 <= r[begin]; ++i)
		len = max(f[begin][0][r[begin] - i * 3] = i, len);
	for (int i = begin + 1; i <= m; ++i)
	{
		for (int j = 0; j <= r[i - 2]; ++j)
			for (int k = 0; k <= r[i - 1]; ++k)
			{					
				len = max(f[i][k][r[i]] = f[i - 1][j][k], len);
			}
		for (int p = 1; p <= r[i] && r[i - 2]; ++p)
		{
			for (int k = p; k <= r[i - 1]; ++k)
			{
				if (f[i - 1][j][k]) len = max(f[i][k][r[i]] = max(f[i][k][r[i]], f[i - 1][][k + p] + p), len);					
			}	
		}
		for (int p = 1; p * 3 <= r[i]; ++p)
		{
			for (int j = 0; j <= r[i - 2]; ++j)
				for (int k = 0; k <= r[i - 1]; ++k)
				{
					if (f[i - 1][j][k]) len = max(f[i][k][r[i] - p * 3] = max(f[i][k][r[i] - p * 3], f[i][k][r[i]] + p), len);
				}
		}
	}
	writeout(len);
	Endl;
	for (int i = 1; i <= m; ++i)
	{
		putchar('\n');
		cout << i << ':' << endl << "   ";
		for (int k = 0; k <= 30; ++k)
		{
			cout << setw(3) << k;
		}
		putchar('\n');
		for (int j = 0; j <= 30; ++j)
		{	
			cout << setw(3) << j;
			for (int k = 0; k <= 30; ++k)
			{
				cout << setw(3) << f[i][j][k];
			}
			putchar('\n');
		}
		putchar('\n');
	}
	*/
	return 0;
}
