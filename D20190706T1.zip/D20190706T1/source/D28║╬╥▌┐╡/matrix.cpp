#include <bits/stdc++.h>
#define open(name) freopen(#name".in", "r", stdin), freopen(#name".out", "w", stdout)
#define LL long long
#define ULL unsigned long long
#define Endl putchar('\n')
using namespace std;

template < typename T >
void readin(T &value)
{
	value = 0;
	T f = 1;
	char ch = getchar();
	while(!isdigit(ch) && ch != '-')
		ch = getchar();
	if (ch == '-')
	{
		f *= -1;
		ch = getchar();
	}
	do
	{
		value = value * 10 + (ch - '0');
		ch = getchar();
	}
	while(isdigit(ch));
}

template < typename T >
void write(T value)
{
	if (value == 0) return;
	if (value < 0)
	{
		putchar('-');
		write(value * -1);
	}
	else
	{
		write(value / 10);
		putchar((value % 10) + '0');
	}
}

template < typename T >
void writeout(T value)
{
	if (value == 0) putchar('0');
	else write(value);
}

template < typename T >
void copy(T* ch1, T* ch2) 
{
	int count = 0;
	while(*(ch1 + count))
	{
		*(ch1 + count) = *(ch2 + count);
		++count;
	}
}

struct line
{
	int chs[26];
	void insert(char ch)
	{
		++chs[ch - 'a'];
	}
	void del(char ch, int t)
	{
		chs[ch - 'a'] -= t;
	}
	friend line operator+(line &a, line &b)
	{
		line c;
		copy(c.chs, a.chs);
		for (int i = 0; i < 26; ++i)
		{
			c.insert(b.chs[i]);
		}
		return c;
	}
	friend line operator+(line &a, char &ch)
	{
		line c;
		copy(c.chs, a.chs);
		c.insert(ch);
		return c;
	}
	friend line operator-(line &a, line &b)
	{
		line c;
		copy(c.chs, a.chs);
		for (int i = 0; i < 26; ++i)
		{
			c.del(i + 'a', b.chs[i]);
		}
		return c;
	}
	bool hw()
	{
		int odd = 0;
		for (int i = 0; i < 26; ++i)
		{
			odd += (this -> chs)[i] & 1;
		}
		return odd <= 1;
	}
}lines[255][255];

int main()
{
	open(matrix);
	int n, m;
	readin(n);
	readin(m);
	if (n == 1) 
	{
		writeout(m);
		return 0;
	}
	for (int j = 1; j <= n; ++j)
	{
		for (int i = 1; i <= m; ++i)
		{
			char ch;
			scanf("%c", &ch);
			lines[i][j] = lines[i - 1][j] + ch;
		}
	}
	int Ans = 0;
	for (int l = 1;l <= m; ++l)
	{
		for (int i = 1; i <= l; ++i)
		{
			int sum = 0;
			for (int j = 1; j <= n; ++j)
			{
				if ((lines[l][j] - lines[i - 1][j]).hw())
				{
					//cout << j << " " << l - i + 1 << endl;
					sum++;
					Ans += sum;
				}
				else
				{
					sum = 0;
				}
			}
		}
	}
	writeout(Ans);
	return 0;
}

