#include<bits/stdc++.h>
#define re register
using namespace std;
template <typename T>void read(T &x)
{
	x=0;char str=getchar();
	while(!isdigit(str))str=getchar();
	while(isdigit(str)){x=(x<<3)+(x<<1)+str-48;str=getchar();}
}
int buf[100],top;
template <typename T>void print(T x)
{
	while(x)buf[++top]=x%10,x/=10;
	while(top)putchar(buf[top--]+48);
	putchar('\n');
}
const int maxn=500010;
int n;
long long ans;
struct cdt
{
	long long a,b,cha;
}s[maxn];
bool cmp(cdt a,cdt b){return a.cha>b.cha;}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	read(n);
	for (re int i=1;i<=n;i++)
	{
		read(s[i].a);read(s[i].b);
		s[i].cha=s[i].a-s[i].b;
	}
	sort(s+1,s+n+1,cmp);
	for (re int i=1;i<=n;i++)
	{
		ans+=s[i].a*(i-1);
		ans+=s[i].b*(n-i);
	}
	print(ans);
	return 0;
}
