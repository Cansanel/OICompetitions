#include<bits/stdc++.h>
#define re register
using namespace std;
template <typename T>void read(T &x)
{
	x=0;char str=getchar();
	while(!isdigit(str))str=getchar();
	while(isdigit(str)){x=(x<<3)+(x<<1)+str-48;str=getchar();}
}
int buf[100],top;
template <typename T>void print(T x)
{
	while(x)buf[++top]=x%10,x/=10;
	while(top)putchar(buf[top--]+48);
	putchar('\n');
}
const int maxn=100010;
int n,m,as,a[maxn],b[maxn];
int f[maxn][4][4][4];
void dfs(int i,int x,int y,int z)
{
	if (i>m)return;
	int xx=x,yy=y,zz=z,kk;
	kk=min(xx,min(yy,zz));
	if (f[i][x][y][z]-3*kk<f[i][xx-kk][yy-kk][zz-kk])f[i][xx-kk][yy-kk][zz-kk]=f[i][x][y][z]-3*kk,dfs(i,xx-kk,yy-kk,zz-kk);
	
	xx+=3;
	if (xx<=b[i])
	{
		kk=min(xx,min(yy,zz));
	    if (f[i][x][y][z]+3-3*kk<f[i][xx-kk][yy-kk][zz-kk])f[i][xx-kk][yy-kk][zz-kk]=f[i][x][y][z]+3-3*kk,dfs(i,xx-kk,yy-kk,zz-kk);
	}
	xx-=3;
	
	yy+=3;
	if (yy<=b[i-1])
	{
		kk=min(xx,min(yy,zz));
	    if (f[i][x][y][z]+3-3*kk<f[i][xx-kk][yy-kk][zz-kk])f[i][xx-kk][yy-kk][zz-kk]=f[i][x][y][z]+3-3*kk,dfs(i,xx-kk,yy-kk,zz-kk);
	}
	yy-=3;
	
	zz+=3;
	if (zz<=b[i-2])
	{
		kk=min(xx,min(yy,zz));
	    if (f[i][x][y][z]+3-3*kk<f[i][xx-kk][yy-kk][zz-kk])f[i][xx-kk][yy-kk][zz-kk]=f[i][x][y][z]+3-3*kk,dfs(i,xx-kk,yy-kk,zz-kk);
	}
	zz-=3;
	
	xx+=3;yy+=3;
	if (xx<=b[i]&&yy<=b[i-1])
	{
		kk=min(xx,min(yy,zz));
	    if (f[i][x][y][z]+6-3*kk<f[i][xx-kk][yy-kk][zz-kk])f[i][xx-kk][yy-kk][zz-kk]=f[i][x][y][z]+6-3*kk,dfs(i,xx-kk,yy-kk,zz-kk);
	}
	xx-=3;yy-=3;
	
	xx+=3;zz+=3;
	if (xx<=b[i]&&zz<=b[i-2])
	{
		kk=min(xx,min(yy,zz));
	    if (f[i][x][y][z]+6-3*kk<f[i][xx-kk][yy-kk][zz-kk])f[i][xx-kk][yy-kk][zz-kk]=f[i][x][y][z]+6-3*kk,dfs(i,xx-kk,yy-kk,zz-kk);
	}
	xx-=3;zz-=3;
	
	yy+=3;zz+=3;
	if (yy<=b[i-1]&&zz<=b[i-2])
	{
		kk=min(xx,min(yy,zz));
	    if (f[i][x][y][z]+6-3*kk<f[i][xx-kk][yy-kk][zz-kk])f[i][xx-kk][yy-kk][zz-kk]=f[i][x][y][z]+6-3*kk,dfs(i,xx-kk,yy-kk,zz-kk);
	}
	yy-=3;zz-=3;
	
	for (re int fuck=0;fuck<=3;fuck++)
	{
		if (f[i][x][y][z]+fuck<f[i+1][fuck][x][y])
		{
			f[i+1][fuck][x][y]=f[i][x][y][z]+fuck;
			dfs(i+1,fuck,x,y);
		}
	}
}
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	read(n);read(m);
	for (re int i=1;i<=n;i++)read(as),a[as]++,b[as]++;
	for (re int i=1;i<=m;i++)
	{
		if (!a[i])continue;
		a[i]%=3;
	}
	memset(f,0x7f,sizeof(f));
	f[3][a[3]][a[2]][a[1]]=a[1]+a[2]+a[3];
	dfs(3,a[3],a[2],a[1]);
	int ans=2147483647;
	for (re int i=0;i<=3;i++)
	{
		for (re int j=0;j<=3;j++)
		{
			for (re int k=0;k<=3;k++)
			{
				ans=min(ans,f[m][i][j][k]);
			}
		}
	}
	ans=(n-ans)/3;
	print(ans);
	return 0;
}
