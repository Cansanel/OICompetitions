#include<bits/stdc++.h>
#define re register
using namespace std;
template <typename T>void read(T &x)
{
	x=0;char str=getchar();
	while(!isdigit(str))str=getchar();
	while(isdigit(str)){x=(x<<3)+(x<<1)+str-48;str=getchar();}
}
int buf[100],top;
template <typename T>void print(T x)
{
	while(x)buf[++top]=x%10,x/=10;
	while(top)putchar(buf[top--]+48);
	putchar('\n');
}
const int maxn=260;
int n,m,a[maxn][maxn];
int p[30],cnt;
bool pd[maxn][maxn];
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int ans=0;
	char st;
	read(n);read(m);
	for (re int i=1;i<=n;i++)
	{
		for (re int j=1;j<=m;j++)
		{
			cin>>st;
			a[i][j]=st-'a';
		}
	}
	if (n==1)
	{
		for (re int i=1;i<=m;i++)
		{
			for (re int j=i;j<=m;j++)
			{
				memset(p,0,sizeof(p));
				for (re int k=i;k<=j;k++)p[a[1][k]]++;
				cnt=0;
				for (re int k=0;k<26;k++)cnt+=p[k]&1;
				if (cnt<=1)ans++;
			}
		}
		print(ans);
		return 0;
	}
	if (m==1)
	{
		memset(pd,0,sizeof(pd));
		for (re int i=1;i<=n;i++)pd[i][i]=1,ans++;
		for (re int i=2;i<=n;i++)
		{
			for (re int j=1;j<=n-i+1;j++)
			{
				if (pd[j+1][j+i-2]&&a[j][1]==a[j+i-1][1])pd[j+1][j+i-2]=1,ans++;
			}
		}
		print(ans);
		return 0;
	}
}
