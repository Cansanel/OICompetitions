#include<bits/stdc++.h>
#include<cctype>
using namespace std;
inline int readd(){
	int x=0,w=1;
	char c=getchar();
	while(!isdigit(c)){
		if(c=='-'){
			w=-1;
		}
		c=getchar();
	}
	while(isdigit(c)){
		x=x*10+c-'0';
		c=getchar();
	}
	return x*w;
}
long long n,m,i,j,k,l,s,d,f,r,a[1000005],b[1000050],aa[1000005];
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	n=readd();
	for(i=1;i<=n;i++){
		a[i]=readd();
		b[i]=readd();
		aa[i]=i;
	}
	for(i=1;i<n;i++){
		for(j=i+1;j<=n;j++){
			if(a[aa[i]]*(i-1)+b[aa[i]]*(n-i)+a[aa[j]]*(j-1)+b[aa[j]]*(n-j)>a[aa[j]]*(i-1)+b[aa[j]]*(n-i)+a[aa[i]]*(j-1)+b[aa[i]]*(n-j)){
				swap(aa[i],aa[j]);
			}
		}
	}
	long long ans=0;
	for(i=1;i<=n;i++){
		ans+=a[aa[i]]*(i-1)+b[aa[i]]*(n-i);
	}
	cout<<ans<<endl;
	return 0;
}

