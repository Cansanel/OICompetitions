#include<bits/stdc++.h>

using namespace std;
const int MAXN = 1e5 + 10;
#define check(x, i) (times[x] > 0 && times[x + i] > 0 && times[x + i + i] > 0)
int num[MAXN], n, m, a[MAXN], cnt[MAXN], ind;
int times[MAXN];
inline void init(void){
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; ++ i){
		scanf("%d", &num[i]);
	}	
	sort(num + 1, num + n + 1);
	for(int i = 1; i <= n; ++ i){
		if(num[i] != num[i - 1]){
			a[++ ind] = num[i];
			cnt[ind] = 1; 
		}
		else{
			cnt[ind] ++;
		}
		times[num[i]] ++;
	}
	for(int i = 1; i <= ind; ++ i){
		cout << a[i] << "   " << cnt[i] << endl;
	}
}
int ans;
inline void turn(int x, int add, int i){
	times[x] += add;
	times[x + i] += add;
	times[x + i + i] += add;
}
void dfs(int step, int sum){
	if(step == ind + 1){
		ans = max(ans, sum);
		return ;
	}
	if(times[a[step]] == 0)
		dfs(step + 1, sum);
	int now = a[step];
	if(times[now] >= 3){
		turn(now, -1, 0);
		dfs(step, sum + 1);
		turn(now, 1, 0);
	}
	if(check(now, 1)){
		int minn = min(times[now], min(times[now + 1], times[now + 2]));
		turn(now, -1, 1);
		dfs(step, sum + 1);
		turn(now, 1, 1);
	}
	dfs(step + 1, sum);
}
inline void work(void){
	dfs(1, 0);
	cout << ans;
}

int main(){
	freopen("jongmah.in", "r", stdin);
	freopen("jongmah.out", "w", stdout);
	init();
	work();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
