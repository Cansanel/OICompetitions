#include<bits/stdc++.h>

using namespace std;
const int MAXN = 5e5 + 10;
struct node{
	int a, b;
	bool operator < (const node &another) const{
		return (a - b) > (another.a - another.b);
	}
}army[MAXN];
int n;
int Fread(){
	char ch = getchar();
	int now= 0, op = 1;
	while((ch > '9' || ch < '0') && (ch != '-'))
		ch = getchar();
	if(ch == '-'){
		op = -1; ch = getchar();
	}
	while((ch >= '0') && (ch <= '9')){
		now = (now << 1) + (now << 3) + ch - '0';
		ch = getchar();
	}
	return now * op;
}
inline void init(void){
	n = Fread();
	for(int i = 1; i <= n; ++ i){
		army[i].a = Fread();
		army[i].b = Fread();
	}
	sort(army + 1, army + n + 1);
}
long long ans;
inline void work(void){
	for(int i = 1; i <= n; ++ i){
		ans += (army[i].a - army[i].b) * (i - 1);
		ans += army[i].b * (n - 1);
	}
	printf("%lld", ans);
}

int main(){
	freopen("queue.in", "r", stdin);
	freopen("queue.out", "w", stdout);
	init();
	work();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
