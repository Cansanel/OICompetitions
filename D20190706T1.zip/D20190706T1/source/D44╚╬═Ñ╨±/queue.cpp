#include <bits/stdc++.h>
using namespace std;
const int maxn = 500010;
int read() {
	int res = 0, f = 1; char c = getchar();
	while(c != '-' && (c < '0' || c > '9')) c = getchar(); if(c == '-') f = -1, c = getchar();
	while(c >= '0' && c <= '9') res = (res << 3) + (res << 1) + c - '0', c = getchar(); return f * res;
}
int n, a[maxn], b[maxn];
long long ans;
bool cmp(int x, int y) {
	return x > y;
}
int main() {
	freopen("queue.in", "r", stdin);
	freopen("queue.out", "w", stdout);
	n = read();
	for(int i = 1; i <= n; i++) {
		a[i] = read(), b[i] = read();
		ans += b[i] * n - a[i];
		a[i] -= b[i];
	}
	sort(a + 1, a + 1 + n, cmp);
	for(int i = 1; i <= n; i++) ans += a[i] * i;
	printf("%lld\n", ans);
	return 0;
}
