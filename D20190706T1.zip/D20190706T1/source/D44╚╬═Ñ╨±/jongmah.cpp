#include <bits/stdc++.h>
using namespace std;
const int maxn = 100010;
int read() {
	int res = 0, f = 1; char c = getchar();
	while(c != '-' && (c < '0' || c > '9')) c = getchar(); if(c == '-') f = -1, c = getchar();
	while(c >= '0' && c <= '9') res = (res << 3) + (res << 1) + c - '0', c = getchar(); return f * res;
}
template<typename T> void chkmax(T &x, T y) { x = max(x, y); }
template<typename T> void chkmin(T &x, T y) { x = min(x, y); }
int n, m, a[maxn], c[maxn], f[maxn][4][6], ans;
int main() {
	freopen("jongmah.in", "r", stdin);
	freopen("jongmah.out", "w", stdout);
	n = read(); m = read();
	for(int i = 1; i <= n; i++) a[i] = read(), c[a[i]]++;
	memset(f, -1, sizeof(f));
	f[2][c[1] % 3][c[2] % 3] = c[1] / 3 + c[2] / 3;
	if(c[1] >= 3 && c[1] % 3 == 0) f[2][3][c[2] % 3] = c[2] / 3 + c[1] / 3;
	if(c[2] >= 3) f[2][c[1] % 3][c[2] % 3 + 3] = c[1] / 3 + c[2] / 3 - 1;
	if(c[1] >= 3 && c[1] % 3 == 0 && c[2] >= 3) f[2][3][c[2] % 3 + 3] = c[1] / 3 + c[2] / 3 - 1;
//	for(int i = 0; i < 4; i++)
//		for(int j = 0; j < 6; j++) cout << i << ' ' << j << ' ' << f[2][i][j] << endl;
	for(int i = 3; i <= m; i++) {
		for(int x = 0; x < 4; x++) {
			for(int y = 0; y < 6; y++) {
				if(c[i] < y) continue;
				int t = (c[i] - y) % 3;
				for(int k = t; k < 4; k++) 
					 if(f[i-1][k][x + t] >= 0) 
					 	chkmax(f[i][x][y], f[i-1][k][x + t] + t + (c[i] - y - t) / 3);
//				cout << i << ' ' << x << ' ' << y << ' ' << f[i][x][y] << endl;
			}
		}
	}
	for(int i = 0; i < 3; i++)
		for(int j = 0; j < 3; j++)
			chkmax(ans, f[m][i][j]);
	printf("%d\n", ans);
	return 0;
}

