#include <bits/stdc++.h>
using namespace std;
const int maxn = 300, B = 233, mod = 1e9+7;
int n, m, c[maxn][27], hsh[maxn], po[30], ji[maxn];
long long ans;
char s[maxn][maxn];
int ns[maxn * 2], nn, f[maxn];
void manacher(int l, int r) {
	if(r < l) return;
	nn = 0;
	ns[++nn] = mod + 1;  ns[0] = mod + 2; 
	for(int i = l; i <= r; i++) ns[++nn] = hsh[i], ns[++nn] = mod + 1;
	ns[++nn] = mod + 3;
	int mx = 1, pos = 1; f[1] = 1;
	for(int i = 2; i < nn; i++) {
		f[i] = min(f[2 * pos - i], mx - i);
		if(f[i] < 1) f[i] = 1;
		while(ns[i + f[i]] == ns[i - f[i]]) f[i]++;
		if(i + f[i] > mx) mx = i + f[i], pos = i;
	}
	for(int i = 1; i < nn; i++) ans += f[i] / 2;
}
int main() {
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; i++) scanf("%s", s[i] + 1);
	po[0] = 1; for(int i = 1; i < 26; i++) po[i] = 1ll * po[i-1] * B % mod;
	for(int l = 1; l <= m; l++) {
		memset(hsh, 0, sizeof(hsh));
		memset(c, 0, sizeof(c));
		memset(ji, 0, sizeof(ji));
		for(int r = l; r <= m; r++) {
			for(int i = 1; i <= n; i++) {
				int tmp = s[i][r] - 'a';
				c[i][tmp]++, hsh[i] = (hsh[i] + po[tmp]) % mod;
				if(c[i][tmp] & 1) ji[i]++;
				else ji[i]--;
			}
			int las = 1;
			for(int i = 1; i <= n; i++) if(ji[i] > 1) {
				manacher(las, i - 1);
				las = i + 1;
			}
			if(las <= n) manacher(las, n);
		}
		
	}
	printf("%lld\n", ans);
	return 0;
}
