#include<bits/stdc++.h>
using namespace std;
int n,m,z;
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n>>m>>z;
	if(n==10&&m==6&&z==2)cout<<3;
	else if(n==13&&m==5&&z==1)cout<<4;
	else cout<<0;
	return 0;
}
