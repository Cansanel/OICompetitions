#include<bits/stdc++.h>
using namespace std;
int n,b[10000];pair<int,int>a[10000];long long mn=999999999999999;bool f=1;
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i].first>>a[i].second;
		b[i]=a[i].second;
		f&=!a[i].first;
	}
	if(f){
		long long s=0;
		sort(b,b+n);
		for(int i=0;i<n;i++)
			s+=b[i]*(n-i-1);
		cout<<s;
	}
	else{
		sort(a,a+n);
		do{
			long long s=0;
			for(int i=0;i<n;i++)
				s+=(long long)(a[i].first*i)+(long long)(a[i].second*(n-i-1));
			mn=min(s,mn);
		}while(next_permutation(a,a+n));
		cout<<mn;
	}	
	return 0;
}
