#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
using namespace std;

int n,m;
char a[255][255];
int counting[30];
int realc[255][27][255];

int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=m;++j)
		{
			cin>>a[i][j];
		}
	}
	if(n==1&&m!=1)
	{
		long long ans=m;
		for(int i=2;i<=m;++i)
		{
			for(int j=1;j<=m-i+1;++j)
			{
				memset(counting,0,sizeof(counting));
				for(int k=j;k<=j+i-1;++k)
				{
					++counting[a[1][k]-96];
				}
				int whatthehell=0;
				for(int k=1;k<=26;++k)
				{
					if(counting[k]%2==1) ++whatthehell;
				}
				if(whatthehell<=1) ++ans;
			}
		}
		printf("%lld\n",ans);
	}
	if(m==1&&n!=1)
	{
		long long ans=n;
		for(int i=2;i<=n;++i)
		{
			for(int j=1;j<=n-i+1;++j)
			{
				memset(counting,0,sizeof(counting));
				for(int k=j;k<=j+i-1;++k)
				{
					++counting[a[k][1]-96];
				}
				int whatthehell=0;
				for(int k=1;k<=26;++k)
				{
					if(counting[k]%2==1) ++whatthehell;
				}
				if(whatthehell<=1) ++ans;
			}
		}
		printf("%lld\n",ans);
	}
	if(n!=1&&m!=1)
	{
		long long ans=0;
		for(int i=1;i<=n;++i)
		{
			for(int j=1;j<=m;++j)
			{
				for(int k=1;k<=26;++k)
				{
					if(k==a[i][j]-96) continue;
					realc[i][k][j]=realc[i][k][j-1];
				}
				realc[i][a[i][j]-96][j]=realc[i][a[i][j]-96][j-1]+1;
			}
		}
		for(int i=1;i<=n;++i)
		{
			for(int j=1;j<=m;++j)
			{
				for(int p=i;p<=n;++p)
				{
					for(int q=j;q<=m;++q)
					{
						int flag=0;
						for(int k=i;k<=(p+i)/2;++k)
						{
							for(int alpha=1;alpha<=26;++alpha)
							{
								if(realc[k][alpha][q]-realc[k][alpha][j-1]!=realc[p-k+i][alpha][q]-realc[p-k+i][alpha][j-1])
								{
									flag=1;
									break;
								}
							}
							if(flag) break;
						}
						if(flag) break;
						for(int k=i;k<=(p+i)/2;++k)
						{
							int temp=0;
							for(int alpha=1;alpha<=26;++alpha)
							{
								if((realc[k][alpha][q]-realc[k][alpha][j-1])%2==1)
								{
									++temp;
								}
								if(temp>1)
								{
									flag=1;
									break;
								}
							}
							if(flag) break;
						}
						if(flag) break;
						if(flag==0)
						{
							++ans;
						}
					}
				}
			}
		}
		printf("%lld",ans);
	}
	return 0;
}
