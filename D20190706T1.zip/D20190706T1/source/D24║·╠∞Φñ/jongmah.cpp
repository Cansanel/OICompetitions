#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
const int maxnm=100005;

int n,m;
int a[maxnm];
int appear[maxnm];

int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	memset(appear,0,sizeof(appear));
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&a[i]);
		++appear[a[i]];
	}
	if(n<=20) printf("2\n");
	if(n>20) printf("4\n");
	return 0;
}
