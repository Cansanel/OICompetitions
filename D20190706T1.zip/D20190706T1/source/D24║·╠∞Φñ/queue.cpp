#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std;

int n;
long long a[500005],b[500005];
long long aminusb[500005];

bool cmp(long long a,long long b){return a>b;}

int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	{
		scanf("%lld%lld",&a[i],&b[i]);
		aminusb[i]=a[i]-b[i];
	}
	sort(aminusb+1,aminusb+n+1,cmp);
	long long ans=0;
	for(long long i=1;i<=n;++i)
	{
		ans+=i*aminusb[i]+n*b[i]-a[i];
	}
	printf("%lld\n",ans);
	return 0;
}
