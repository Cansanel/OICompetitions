#include <bits/stdc++.h>
using namespace std;

#define INF 0x3F3F3F3F

int n, m, ans, res, mini;
int c[100005], a[100005];
int f[105][105][105];

int dfs(int now, int c1, int cn)
{
	if (f[now][c1][cn] != INF) return f[now][c1][cn];
	int ans = 0;
	if (now - 2 > 0)
	{
		for (int i = 0; i <= cn; i++)
		{
			if (c[now - 2] >= i && c1 >= i)
				ans = max(ans, dfs(now - 1, c[now - 2] - i, c1 - i) + i + (cn - i) / 3);
			else 
				break;
		}
	}
	else {
		ans = cn / 3 + c1 / 3;
	}
	f[now][c1][cn] = ans;
	return ans;
}

int min3(int x, int y, int z)
{
	return min(min(x, y), z);
}

int main()
{
	freopen("jongmah.in", "r", stdin);
	freopen("jongmah.out", "w", stdout);
	//change filename
	ios::sync_with_stdio(false);
	
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	sort(a + 1, a + n + 1);
	for (int i = 1; i <= n; i++)
		c[a[i]]++;
	memset(f, 0x3F, sizeof(f));
	if (n <= 100 && m <= 100)
	{
		cout << dfs(m, c[m - 1], c[m]) << endl;
		return 0;
	}
	for (int i = 1; i <= m - 2; i++)
	{
		mini = min3(c[i], c[i + 1], c[i + 2]);
		res += mini;
		c[i] -= mini; c[i + 1] -= mini; c[i + 2] -= mini;
	}
	cout << res << endl;
	
	//f[now][c1][cn] now:Position c1:Previous cn:Now
	
	return 0;
}

