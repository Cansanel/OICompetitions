#include <bits/stdc++.h>
using namespace std;

struct person
{
	long long a, b, c;
}h[500010];
long long n, ans;

bool cmp(person x, person y)
{
	if (x.c == y.c)
		return x.a > y.a;
	return x.c > y.c;
}

int main()
{
	freopen("queue.in", "r", stdin);
	freopen("queue.out", "w", stdout);
	ios::sync_with_stdio(false);
	
	cin >> n;
	for (long long i = 1; i <= n; i++)
	{
		cin >> h[i].a >> h[i].b;
		h[i].c = h[i].a - h[i].b;
	}
	sort(h + 1, h + n + 1, cmp);
	for (long long i = 1; i <= n; i++)
		ans += h[i].a * (i - 1) + h[i].b * (n - i);
	cout << ans << endl;
	
	return 0;
}

