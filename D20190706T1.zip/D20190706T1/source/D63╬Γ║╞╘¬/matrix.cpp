#include <bits/stdc++.h>
using namespace std;

long long s[310][310], c[310][310][310];
char a[310][310];
long long n, m, ans;

bool check(int i, int j, int k, int l)
{
	int q = k, oddcnt = 0;
	for (int o = i; o <= q; o++)
	{
		oddcnt = 0;
		for (int p = 1; p <= 26; p++)
		{
			s[1][p] = c[o][l][p] - c[o][j - 1][p];
			if (s[1][p] % 2 == 1)
			{
				oddcnt++;
				if (oddcnt == 2) return false;
			}
		}
		oddcnt = 0;
		for (int p = 1; p <= 26; p++)
		{
			s[2][p] = c[q][l][p] - c[q][j - 1][p];
			if (s[2][p] % 2 == 1)
			{
				oddcnt++;
				if (oddcnt == 2) return false;
			}
		}
		for (int p = 1; p <= 26; p++)
			if (s[1][p] != s[2][p]) return false;
		q--;
	}
}

int main()
{
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	ios::sync_with_stdio(false);
	
	cin >> n >> m; cin.ignore();
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
		{
			cin >> a[i][j];
			c[i][j][a[i][j] - 'a' + 1] = 1;
		}
		cin.ignore();
	}
	/*
	for (int j = 1; j <= m; j++)
	{
		for (int k = 1; k <= 26; k++)
			cout << c[1][j][k] << " ";
		cout << endl;
	}
	*/
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			for (int k = 1; k <= 26; k++)
				c[i][j][k] += c[i][j - 1][k];
	
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			for (int k = i; k <= n; k++)
				for (int l = j; l <= m; l++)
				{
					if (check(i, j, k, l))
						ans++;
				}
	cout << ans << endl;
	
	return 0;
}

