#include<bits/stdc++.h>
using namespace std;
int n,m,a[251][251][26];
bool check(int x1,int y1,int x2,int y2){
	for(int i=x1;i<=x2;i++){
		int s=0;
		for(int j=1;j<=26;j++){
			if((a[i][y2][j]-a[i][y1-1][j])%2==1)s++;
			if(s>1)return 0;
		}
	}
	for(int i=1;i<=ceil((x2-x1)*1.0/2);i++){
		for(int j=1;j<=26;j++){
			int h1=a[x1+i-1][y2][j]-a[x1+i-1][y1-1][j];
			int h2=a[x2-i+1][y2][j]-a[x2-i+1][y1-1][j];
			if(h1!=h2)return 0;
		}
	}
	return 1;
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	char ch;cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			ch=getchar();while(ch<'a'||ch>'z')ch=getchar();
			for(int k=1;k<=26;k++){
				a[i][j][k]=a[i][j-1][k];
			}	
			a[i][j][ch-'a'+1]++;
		}
	}int ans=0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			for(int ii=i;ii<=n;ii++){
				for(int jj=j;jj<=m;jj++){
					if(check(i,j,ii,jj)){
						//cout<<i<<' '<<j<<' '<<ii<<' '<<jj<<endl;
						ans++;
					}
				}
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}
