#include<bits/stdc++.h>
using namespace std;
int read(){
	int f=1,s=0;char ch=getchar();
	while(ch<'0'||ch>'9'&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(ch>='0'&&ch<='9')s=s*10+ch-'0',ch=getchar();
	return s*f;
}
struct F{
	int c;
	int num;
}h[500001];
bool cmp(F a,F b){
	return a.c>b.c;
}
int a[500001],b[500001];
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	int n;n=read();
	for(int i=1;i<=n;i++){
		a[i]=read(),b[i]=read();
		h[i].c=a[i]-b[i];h[i].num=i;
	}
	sort(h+1,h+n+1,cmp);
	long long ans=0;
	for(int i=1;i<=n;i++){
		ans+=a[h[i].num]*(i-1)+b[h[i].num]*(n-i);
	//	cout<<h[i].num<<endl;
	}
	cout<<ans<<endl;
	return 0;
}
