#include<bits/stdc++.h>
using namespace std;
int read(){
	int f=1,s=0;char ch=getchar();
	while(ch<'0'||ch>'9'&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(ch>='0'&&ch<='9')s=s*10+ch-'0',ch=getchar();
	return s*f;
}
int a[100006];
int tot=0,ma=0,ans=0;
void dfs(int h){
	int f=1;
	for(int i=1;i<=ma;i++){
		int c=min(min(a[i],a[i+1]),a[i+2]);
		if(c!=0){
			a[i]-=c;a[i+1]-=c;a[i+2]-=c;
			dfs(h+c);f=0;
			a[i]+=c;a[i+1]+=c;a[i+2]+=c;
		}
		if(a[i]>=3){
			a[i]-=3;
			dfs(h+1);
			a[i]+=3;
			f=0;
		}
	}
	if(f)ans=max(ans,h);
	return ;
}
void pian(){
	for(int i=1;i<=ma-2;i++){
		int c=min(min(a[i],a[i+1]),a[i+2]);
		if(c!=0){
			a[i]-=c;a[i+1]-=c;a[i+2]-=c;
			ans+=c;
		}
	}
}
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	int n,x,m,f=1;
	n=read();m=read();
	for(int i=1;i<=n;i++){
		x=read();
		if(a[x]==0)tot++;
		a[x]++;ma=max(x,ma);
		if(a[x]>=3)f=0;
	}if(f){
		pian();
		cout<<ans<<endl;
	}else{
		dfs(0);
		cout<<ans<<endl;
	}
	return 0;
}
