#include<bits/stdc++.h>
using namespace std;
int n,m,a[100005],num[100005],times[100005],js,ans,summer_army_is_nhr[100005];
inline int Max(int a,int b)
{
	return a>b?a:b;
}
inline void dfs(int step,int sum)
{
	if((summer_army_is_nhr[js]-summer_army_is_nhr[step]+times[num[step]])/3+sum<=ans)
	return ;
	if(step==js+1)
	{
		ans=Max(ans,sum);
		return ;
	}
	if(times[num[step]]==0)
	{
		dfs(step+1,sum);
		return ;
	}
	if(times[num[step]]>=3)
	{
		times[num[step]]-=3;
		dfs(step,sum+1);
		times[num[step]]+=3;
	}
	if(times[num[step]]>=1&&times[num[step]+1]>=1&&times[num[step]+2]>=1)
	{
		--times[num[step]],--times[num[step]+1],--times[num[step]+2];
		dfs(step,sum+1);
		++times[num[step]],++times[num[step]+1],++times[num[step]+2];
	}
	dfs(step+1,sum);
}
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&a[i]);
		if(!times[a[i]])
		{
			++js;
			num[js]=a[i];
		}
		++times[a[i]];
	}
	sort(num+1,num+js+1);
	for(int i=1;i<=js;++i)
	summer_army_is_nhr[i]=summer_army_is_nhr[i-1]+times[num[i]];
	sort(a+1,a+n+1);
	dfs(1,0);
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
