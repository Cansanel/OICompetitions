#include<bits/stdc++.h>
using namespace std;
int n;
long long ans;
struct node{
	int a,b;
}q[500005];
inline bool cmp(const node &p,const node &q)
{
	return (p.a-p.b)>(q.a-q.b);
}
inline int fread()
{
	char ch=getchar();
	short f=1;
	int cnt=0;
	while((ch<'0'||ch>'9')&&ch!='-')
	ch=getchar();
	if(ch=='-')
	{
		ch='0';
		f=-1;
	}
	while(ch>='0'&&ch<='9')
	{
		cnt=(cnt<<1)+(cnt<<3)+ch-'0';
		ch=getchar();
	}
	return cnt*f;
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	{
		q[i].a=fread();
		q[i].b=fread();
	}
	sort(q+1,q+n+1,cmp);
	for(int i=1;i<=n;++i)
	ans+=(i-1)*q[i].a+(n-i)*q[i].b;
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
