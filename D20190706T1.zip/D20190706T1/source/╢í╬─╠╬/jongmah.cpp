#include<bits/stdc++.h>
#define up(l,r,i) for(int i=l;i<=r;i++)
#define dn(r,l,i) for(int i=r;i>=l;i--)
using namespace std;
const int SIZE =10000 +3;
typedef long long LL;
char bef[SIZE],*p1=bef,*p2=bef;
char readc(){
	if(p1==p2) p2=bef+fread(bef,1,SIZE,stdin);
	return p1==p2?EOF:*p1++;
}
int qread(){
	int ret,w=1,c;
	while((c=readc())> '9'||c< '0')
	w=(c=='-')?-1:1; ret=c-'0';
	while((c=readc())>='0'&&c<='9')
	ret=ret*10+c-'0';
	return ret*w;
}
const int MAXN =100000+3;
int n,m,ans,cnt[MAXN],flag,tot;
void fix(int s,int t){
	up(1,t,i){
		if(cnt[i]>=3) ans+=cnt[i]/3,cnt[i]%=3;
		if(cnt[i]==-2) cnt[i]=1,ans--; else
		if(cnt[i]==-1) cnt[i]=0,ans--,cnt[i+1]++,cnt[i+2]++; else
		if(cnt[i]==1) cnt[i]=0,ans++,cnt[i+1]--,cnt[i+2]--; else
		if(cnt[i]==2 ) cnt[i]=1,cnt[i+1]++,cnt[i+2]++;
	}

	
}
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	
	n=qread(),m=qread();
	up(1,n,i) cnt[qread()]++;
	up(1,m,i) ans+=cnt[i]/3,cnt[i]%=3;
	up(1,100,i) fix(1,m);
	if(cnt[m+1]!=0) ans--;
	printf("%d\n",ans);
	return 0;
}
//��ѧ���漣 
/*
13  5
1  1  5  1  2  3  3  2  4  2  3  4  5
*/
