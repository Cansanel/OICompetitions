#include<bits/stdc++.h>
#define up(l,r,i) for(int i=l;i<=r;i++)
#define dn(r,l,i) for(int i=r;i>=l;i--)
using namespace std;
const int SIZE =100000 +3;
typedef long long LL;
char bef[SIZE],*p1=bef,*p2=bef;
char readc(){
	if(p1==p2) p2=bef+fread(bef,1,SIZE,stdin);
	return p1==p2?EOF:*p1++;
}
LL qread(){
	LL ret,w=1,c;
	while((c=readc())> '9'||c< '0')
	w=(c=='-')?-1:1; ret=c-'0';
	while((c=readc())>='0'&&c<='9')
	ret=ret*10+c-'0';
	return ret*w;
}
const int MAXN =500000 +3;
struct P{
	int a,b;
	bool operator <(const P x) const{
		int c=x.a,d=x.b;
		return (c-a+b-d<0);
	}
}A[MAXN];
long long ans,n;
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	
	n=qread();
	up(1,n,i) A[i].a=qread(),A[i].b=qread();
	sort(A+1,A+1+n);
	up(1,n,i) ans+=(LL)(i-1)*A[i].a+(LL)(n-i)*A[i].b;
	printf("%d\n",ans);
	return 0;
}
/*
10
5  10
12  4
31  45
20  55
30  17
29  30
41  32
7  1
5  5
3  15
*/
