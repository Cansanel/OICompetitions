#include<bits/stdc++.h>
#define up(l,r,i) for(int i=l;i<=r;i++)
#define dn(r,l,i) for(int i=r;i>=l;i--)
using namespace std;
const int SIZE =100000 +3;
typedef long long LL;
char bef[SIZE],*p1=bef,*p2=bef;
char readc(){
	if(p1==p2) p2=bef+fread(bef,1,SIZE,stdin);
	return p1==p2?EOF:*p1++;
}
int qread(){
	int ret,w=1,c;
	while((c=readc())> '9'||c< '0')
	w=(c=='-')?-1:1; ret=c-'0';
	while((c=readc())>='0'&&c<='9')
	ret=ret*10+c-'0';
	return ret*w;
}
const int MAXN =250 +3;
unsigned long long sum[MAXN][MAXN],pre[MAXN][MAXN],n,m,P[MAXN][MAXN];
LL ans;
bool use[(1<<26)+1];
bool check(int a,int b,int c,int d){
	up(a,c,i){
		int res=sum[i][d]^sum[i][b-1]^sum[i-1][d]^sum[i-1][b-1];
		if(!use[res]) return false;
	}
	up(a,(a+c)>>1,i){
		int t=a+c-i;
		int h1=pre[i][d]-pre[i-1][d]-pre[i][b-1]+pre[i-1][b-1];
		int h2=pre[t][d]-pre[t-1][d]-pre[t][b-1]+pre[t-1][b-1];
		if(h1!=h2) return false;
	}
	return true;
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	
	up(0,26,i) use[1<<i]=true;  use[0]=true;
	scanf("%d%d",&n,&m),getchar();
	up(1,n,i){
		up(1,m,j) P[i][j]=1<<(getchar()-'a');
		getchar();
	}
	up(1,n,i){
		up(1,m,j) sum[i][j]=sum[i-1][j]^sum[i][j-1]^sum[i-1][j-1]^P[i][j];
	}
	up(1,n,i){
		up(1,m,j) pre[i][j]=pre[i-1][j]+pre[i][j-1]-pre[i-1][j-1]+P[i][j];
	}
	int cnt=0;
	up(1,n,i) up(i,n,j) up(1,m,k) up(k,m,l)
		if(check(i,k,j,l)) ans++; 
	printf("%lld\n",ans);
	return 0;
}
/*
2 3
aca
aac
*/
