#include<bits/stdc++.h>
#define LL long long
using namespace std;
struct node{
	LL a,b,tmp;
}p[500010];
LL n,ans;
bool comp(node x,node y){
	return x.tmp>y.tmp;
}
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	cin>>n;
	for(LL i=1;i<=n;i++){
		cin>>p[i].a>>p[i].b;
		ans+=p[i].b*n-p[i].a;
		p[i].tmp=p[i].a-p[i].b;
	}
	sort(p+1,p+n+1,comp);
	for(LL i=1;i<=n;i++){
		ans+=p[i].tmp*i;
	}
	cout<<ans<<endl;
	return 0;
}

