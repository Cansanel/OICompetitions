#include<bits/stdc++.h>
using namespace std;
int n,m,num[100010],ans;
void dfs(int dep,int sum){
	if(dep>n){
		ans=max(ans,sum);
		return;
	}
	if(num[dep]>=3){
		num[dep]-=3;
		dfs(dep,sum+1);
		num[dep]+=3;
	}
	if(num[dep]&&num[dep+1]&&num[dep+2]){
		num[dep]-=1;
		num[dep+1]-=1;
		num[dep+2]-=1;
		dfs(dep,sum+1);
		num[dep]+=1;
		num[dep+1]+=1;
		num[dep+2]+=1;
	}
	dfs(dep+1,sum);
}
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		int x;
		cin>>x;
		num[x]++;
	}
	dfs(1,0);
	cout<<ans<<endl;
	return 0;
}

