#include<bits/stdc++.h>
using namespace std;
int n,m,a[260][260],ans,num[30],num2[30];
bool checkn1(int x,int y){
	memset(num,0,sizeof(num));
	for(int i=x;i<=y;i++){
		num[a[1][i]]++;
	}
	int ji=0,ou=0;
	for(int i=1;i<=26;i++){
		if(num[i]){
			if(num[i]%2){
				ji++;
			}else{
				ou++;
			}
		}
	}
	int tmp=y-x+1;
	if(tmp%2){
		if(ji==1){
			return 1;
		}else{
			return 0;
		}
	}else{
		if(ji==0){
			return 1;
		}else{
			return 0;
		}
	}
}
bool checkm1(int x,int y){
	memset(num,0,sizeof(num));
	for(int i=x;i<=y;i++){
		num[a[i][1]]++;
	}
	int ji=0,ou=0;
	for(int i=1;i<=26;i++){
		if(num[i]){
			if(num[i]%2){
				ji++;
			}else{
				ou++;
			}
		}
	}
	int tmp=y-x+1;
	if(tmp%2){
		if(ji==1){
			return 1;
		}else{
			return 0;
		}
	}else{
		if(ji==0){
			return 1;
		}else{
			return 0;
		}
	}
}
bool check(int x,int y,int xx,int yy){
	for(int i=x;i<=(x+xx)/2;i++){
		memset(num,0,sizeof(num));
		memset(num2,0,sizeof(num2));
		for(int j=y;j<=yy;j++){
			num[a[i][j]]++;
			num2[a[xx-(i-x)][j]]++;
		}
		int ji,ou,ji2,ou2;
		ji=ou=ji2=ou2=0;
		for(int j=1;j<=26;j++){
			if(num[j]!=num2[j]){
				return 0;
			}
			if(num[j]%2){
				ji++;
			}else{
				ou++;
			}
			if(num2[j]%2){
				ji2++;
			}else{
				ou2++;
			}
		}
		int tmp=yy-y+1;
		if(tmp%2){
			if(ji!=1||ji2!=1){
				return 0;
			}
		}else{
			if(ji!=0||ji2!=0){ 
				return 0;
			}
		}
	}
	return 1;
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			char ch;
			cin>>ch;
			a[i][j]=ch-'a'+1;
		}
	}
	ans=n*m;
	if(n==1){
		for(int i=1;i<m;i++){
			for(int j=i+1;j<=m;j++){
				if(checkn1(i,j)){
					ans++;
				}
			}
		}
	}else if(m==1){
		for(int i=1;i<n;i++){
			for(int j=i+1;j<=n;j++){
				if(checkm1(i,j)){
					ans++;
				}
			}
		}
	}else{
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				for(int ii=i;ii<=n;ii++){
					for(int jj=j;jj<=m;jj++){
						if(i==ii&&j==jj){
							continue;
						}
						if(check(i,j,ii,jj)){
							ans++;
						}
					}
				}
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}

