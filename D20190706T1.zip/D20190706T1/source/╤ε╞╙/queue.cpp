#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
#define MAXN 500000+5
#define LL long long
int n;
LL ans;
struct Node
{
	int x;
	int y;
}a[MAXN];
bool cmp(Node n1,Node n2)
{
	return (n1.x-n1.y)>(n2.x-n2.y);
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i].x>>a[i].y;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
		ans+=1LL*(i-1)*a[i].x+1LL*(n-i)*a[i].y;
	cout<<ans;
	return 0;
}
