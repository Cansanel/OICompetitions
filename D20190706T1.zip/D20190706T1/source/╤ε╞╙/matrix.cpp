//20%
#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
#define MAXN 250+5
int n,m,a[MAXN],cnt[27],ans;
int change(char x)
{
	return (int) x-'a'+1;
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>m;
	n=n*m;
	for(int i=1;i<=n;i++)
	{
		char t;
		cin>>t;
		a[i]=change(t);
	}
	for(int i=1;i<=n;i++)
		for(int j=i;j<=n;j++)
		{
			memset(cnt,0,sizeof(cnt));
			for(int k=i;k<=j;k++)
				cnt[a[k]]++;
			int len=j-i+1,odd=0;
			for(int k=1;k<=26;k++)
				if(cnt[k]&1)
					odd++;
			if((len&1)&&odd<=1)
				ans++;
			else if((len%2==0)&&odd==0)
				ans++;
		}
	cout<<ans;
	return 0;
}
