#include<iostream>
#include<cstdio>
using namespace std;
#define MAXN 100000+5
int n,m,x,t[MAXN],f[MAXN][3][3];
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>x;
		t[x]++;
	}
	for(int i=1;i<=m+2;i++)
		for(int j=0;j<=2;j++)
			for(int k=0;k<=2;k++)
				for(int l=0;l<=2;l++)
					if(j+k+l<=t[i]&&j+k<=t[i+1]&&j<=t[i+2])
						f[i][j][k]=max(f[i][j][k],f[i-1][k][l]+j+(t[i]-j-k-l)/3);
	cout<<f[m+2][0][0];
	return 0;
}
