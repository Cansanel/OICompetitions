#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<iomanip>
#include<algorithm>
using namespace std;
int n,m,a[100005],ans,f[100005];
void dfs(int s,int t)
{
	f[s+1]=max(f[s+1],t);
	if(t<f[s-1])return;
	if(s==m+1)
	{
		ans=max(ans,t);
		return;
	}
	if(a[s]>=3)
	{
		a[s]-=3;
		dfs(s,t+1);
		a[s]+=3;
	}
	if(a[s]>=1&&a[s+1]>=1&&a[s+2]>=1)
	{
		a[s]--;
		a[s+1]--;
		a[s+2]--;
		dfs(s,t+1);
		a[s]++;
		a[s+1]++;
		a[s+2]++;
	}
	dfs(s+1,t);
	return;
}
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	int i,x;
	cin>>n>>m;
	for(i=1;i<=n;i++)
	{
		cin>>x;
		a[x]++;
	}
	for(i=0;i<=m;i++)f[i]=-1;
	dfs(1,0);
	cout<<ans<<endl;
	return 0;
}

