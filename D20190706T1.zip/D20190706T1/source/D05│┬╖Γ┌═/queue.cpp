#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<iomanip>
#include<algorithm>
using namespace std;
long long n,ans;
struct abc
{
	long long x,y;
}a[500005];
long long cmp(abc p,abc q)
{
	return p.x-p.y>q.x-q.y;
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	int i;
	cin>>n;
	for(i=1;i<=n;i++)
	cin>>a[i].x>>a[i].y;
	sort(a+1,a+n+1,cmp);
	for(i=1;i<=n;i++)
	ans=ans+(i-1)*a[i].x+(n-i)*a[i].y;
	cout<<ans<<endl;
	return 0;
}

