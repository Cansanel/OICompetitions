#include <bits/stdc++.h>
using namespace std;
int n,m,cnt;
char cch;
int a[264][264],r[27];
int f[264][264][264],ff[264][264][264];

inline void zrread(char &x)
{
	x = getchar();
	while(!islower(x))	x = getchar();
}

inline void zread(int &x)
{
	char ch = getchar();	x = 0;	int sy = 1;
	while(!isdigit(ch) && ch != '-')	ch = getchar();
	if(ch == '-')	sy = -1,ch = getchar();
	while(isdigit(ch))	x = (x << 1) + (x << 3) + (ch ^ 48),ch = getchar();
	x *= sy;
}

inline bool zjudge(int x,int s,int t)
{
	if(f[x][s][t])	return f[x][s][t] == 1 ? false : true;
	char r[26];	int c;
	for(int i = s; i <= t; ++i)	++r[a[x][i]];
	for(int i = 0; i ^ 26; ++i)
		if(r[i] & 1)
			++c;
	if((t - s + 1) & 1)	c == 1 ? f[x][s][t] = 2 : f[x][s][t] = 1;
	else	c ? f[x][s][t] = 1 : f[x][s][t] = 2;
	return f[x][s][t] == 1 ? false : true;
}

inline bool zzjudge(int x,int s,int t)
{
	if(ff[x][s][t])	return ff[x][s][t] == 1 ? false : true;
	char r[26];	int c;
	for(int i = s; i <= t; ++i)	++r[a[i][x]];
	for(int i = 0; i ^ 26; ++i)
		if(r[i] & 1)
			++c;
	if((t - s + 1) & 1)	c == 1 ? f[x][s][t] = 2 : f[x][s][t] = 1;
	else	c ? f[x][s][t] = 1 : f[x][s][t] = 2;
	return ff[x][s][t] == 1 ? false : true;
}

int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	zread(n),zread(m);
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= m; ++j)
			cin >> cch,a[i][j] = cch - 'a';
//	for(int ab = 1; ab <= n; ++ab)
//	{
//		for(int i = 1; i <= m; ++i)//ö���������
//		{
//			for(int k = i; i <= m; ++k)//ö��ͬ���յ� 
//			{
//				if(zjudge(ab,i,k)) 
//				{
//					for(int kk = ab; kk <= n; ++k)
//					{
//						if(zjudge(kk,i,k))
//						{
//							bool flag = true;
//							for(int j = i; j <= k; ++j)
//								if(!zzjudge(j,ab,kk))
//									flag = false;
//							if(flag)	++cnt;
//						}
//					}
//				}
//			}
//		}
//	}
	cout << m * n << endl;
	return 0;	
}
//��һ�����ۣ�
//���೤��Ϊż���Ļ��Ĵ����������ǻ���
//һ������Ϊ�����Ļ��Ĵ������ɸ�ż��������������
// 
//˼·���ֿ飺 
//�� 
