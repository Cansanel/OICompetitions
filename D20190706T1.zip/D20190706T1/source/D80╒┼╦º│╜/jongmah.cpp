#include <bits/stdc++.h>
using namespace std;
int n,emmmn,x,cnt;
int a[156000];
map <int,int> T,M,S;
int b[4];

inline void zread(int &x)
{
	char ch = getchar();	x = 0;	int sy = 1;
	while(!isdigit(ch) && ch != '-')	ch = getchar();
	if(ch == '-')	sy = -1,ch = getchar();
	while(isdigit(ch))	x = (x << 1) + (x << 3) + (ch ^ 48),ch = getchar();
	x *= sy;
}

//inline bool zjudge()	{return b[2] == b[1] + 1 && b[3] == b[2] + 1;}
//
//inline void zadjust()	{b[1] = b[2],b[2] = b[3];	return;}

int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	zread(n),zread(emmmn);
	for(int i = 1; i <= n; ++i)	zread(a[i]);
	sort(a + 1,a + n + 1);
	S[a[1]] = 1,T[a[n]] = n;
	for(int i = 2; i <= n; ++i)
		if(a[i] ^ a[i - 1])
			S[a[i]] = i,T[a[i - 1]] = i - 1,M[a[i - 1]] = T[a[i - 1]] - S[a[i - 1]] + 1;
	M[a[n]] = n - S[a[n]] + 1;
	int ki = 1;
	while(ki < S[a[n]])
	{
		int nxt = T[a[ki]] + 1,nnxt = T[a[nxt]] + 1,k;
		if(T[a[ki]] == n || T[a[nxt]] == n)	break;
		k = min(M[a[ki]],min(M[a[nxt]],M[a[nnxt]]));
		cnt += k,M[a[ki]] -= k,M[a[nxt]] -= k,M[a[nnxt]] -= k;
		ki = T[a[ki]] + 1;
	}
	ki = 1;
	while(true)
	{
		cnt += M[a[ki]] / 3,ki = T[a[ki]] + 1;
		if(ki == S[a[n]])	break;
	}
	cout << cnt << endl;
}
