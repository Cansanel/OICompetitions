#include <bits/stdc++.h>
using namespace std;
int n,x,y,ans,s;
int a[560000];

inline void zread(int &x)
{
	char ch = getchar();	x = 0;	int sy = 1;
	while(!isdigit(ch) && ch != '-')	ch = getchar();
	if(ch == '-')	sy = -1,ch = getchar();
	while(isdigit(ch))	x = (x << 1) + (x << 3) + (ch ^ 48),ch = getchar();
	x *= sy;
}

inline bool cmp(int x,int y)	{return x > y;}

int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	zread(n);
	for(int i = 1; i <= n; ++i)	zread(x),zread(y),a[i] = x - y,s += y;
	sort(a + 1,a + n + 1,cmp),ans = s * (n - 1);
	for(int i = 0; i ^ n; ++i)	ans += i * a[i + 1];
	cout << ans << endl;
	return 0;
}
