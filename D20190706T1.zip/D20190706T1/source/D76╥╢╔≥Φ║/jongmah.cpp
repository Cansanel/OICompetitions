#include<bits/stdc++.h>
#define ll long long
using namespace std;
int h[100010];
int hb[100010];
int main()
{
	freopen("jongmah.in", "r", stdin);
	freopen("jongmah.out", "w", stdout);
	int n, i, t;
	cin >> n;
	int m;
	cin >> m;
	int ans = 0;
	memset(h, 0, sizeof(h));
	memset(hb, 0, sizeof(hb));
	for(i = 1;i <= n;i++)
	{
		scanf("%d", &t);
		h[t] ++;
	}
	for(i = 1;i <= m;i++)
	{
		while(h[i] >= 1 && h[i +1] >= 1 && h[i +2] >= 1)
		{
			h[i] --;
			h[i +1] --;
			h[i +2] --;
			ans ++;
			hb[i -1] ++;
			hb[i] += 2;
			hb[i +1] += 2;
			hb[i +2] += 2;
			hb[i +3] ++;
		}
	}
	for(i = 1;i <= m;i++)
	{
		while(h[i] >= 3)
		{
			h[i] -= 3;
			ans ++;
		}
	}
	for(i = 1;i <= m;i++)
	{
		if(h[i] == 2 && h[i +1] == 2 && hb[i] + hb[i +1] >= 2)
		{
			ans ++;
		}
	}
	/*
	for(i = 1;i <= m;i++)
	{
		if(h[i] >= 1)
		{
			if(h[i +1] >= 1 && h[i +2] >= 1)
			{
				if(h[i +1] -2 >= h[i] && h[i +2] -2 >= h[i] && h[i +3] +1 < min(h[i +1], h[i +2]))
				{
					if(h[i] >= 3)
					{
						while(h[i] >= 3)
							{
							h[i] -= 3;
							ans ++;
						}
					}
				}
				else 
				{
					while(h[i] >= 1 && h[i +1] >= 1 && h[i +2] >= 1)
					{
						h[i] --;
						h[i +1] --;
						h[i +2] --;
						ans ++;
					}
					if(h[i] >= 3)
					{
						while(h[i] >= 3)
							{
							h[i] -= 3;
							ans ++;
						}
					}
				}
			}
			else 
			{
				if(h[i] >= 3)
				{
					while(h[i] >= 3)
					{
						h[i] -= 3;
						ans ++;
					}
				}
			}
		}
	}*/
	cout << ans;
	return 0;
}

