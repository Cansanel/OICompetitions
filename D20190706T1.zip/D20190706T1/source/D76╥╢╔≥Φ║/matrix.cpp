#include<bits/stdc++.h>
#define ll long long
using namespace std;
bool hw[260][260][260];
int a[260][260];
int h[30];
int hs[260][30];
inline bool phw(int n, int l, int r, int ds)
{
	int i;
	for(i = 1;i <= 26;i++)
	{
		if(h[i] % 2 == 1)
		{
			ds--;
			if(ds == -1)return 0;
		}
	}
	return 1;
} 
inline bool byy(int l, int r)
{
	int i, j;
	int k;
	for(i = l, j = r;i <= j;i++, j--)
	{
		for(k = 1;k <= 26;k++)
		{
			if(hs[i][k] != hs[j][k])return 0;
		}
	}	
	return 1;
}
inline bool phww(int l, int r, int s, int e)
{
	int i;
	for(i = l;i <= r;i++)
	{
		if(hw[i][s][e] == 0)return 0;
	}
	return 1;
}
int main()
{
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	int n, m;
	int i, j, k, l;
	cin >> n >> m;
	for(i = 1;i <= n;i++)
	{
		for(j = 1;j <= m;j++)
		{
			char t;
			cin >> t;
			a[i][j] = t -'a' +1;
		}
	}
	for(i = 1;i <= n;i++)
	{
		for(j = 1;j <= m;j++)
		{
			memset(h, 0, sizeof(h));
			for(k = j;k <= m;k++)
			{
				h[a[i][k]] ++;
				hw[i][j][k] = phw(i, j, k, (k -j +1) %2);
			}
		}
	}
	ll ans = 0;
	int o;
	for(i = 1;i <= n;i++)
	{
		for(j = i;j <= n;j++)
		{
			for(k = 1;k <= m;k++)
			{
				memset(hs, 0, sizeof(hs));
				for(l = k;l <= m;l++)
				{
					for(o = i;o <= j;o++)
					{
						hs[o][a[o][l]]++;
					}
					if(phww(i, j, k, l) && byy(i, j))ans ++;
				}
			}
		}
	}
	cout << ans;
	return 0;
}

