#include<bits/stdc++.h>
#define ll long long
using namespace std;
int l[500010];
int r[500010];
int a[500010];
int main()
{
	freopen("queue.in", "r", stdin);
	freopen("queue.out", "w", stdout);
	ll ans = 0;
	int n;
	cin >> n;
	int i;
	for(i = 1;i <= n;i++)
	{
		scanf("%d%d", &l[i], &r[i]);
		a[i] = r[i] -l[i];
		ll lins = r[i];
		ans = ans +lins *(n -1); 
	}
	sort(a +1, a +n +1);
	for(i = 1;i <= n;i++)
	{
		ans = ans - a[i] * (i -1);
	}
	cout << ans;
	return 0;
}

