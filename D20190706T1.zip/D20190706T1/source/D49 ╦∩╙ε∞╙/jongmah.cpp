#include<bits/stdc++.h>
using namespace std;
map <int,bool> used;
int dp[1000005],num[1000005],last[1000005];
inline int read() {
	int x=0,neg=1;char ch=getchar();
	while(!isdigit(ch)) {
		if (ch=='-') neg=-1;
		ch=getchar();
	}
	while(isdigit(ch)) {
		x=x*10+(ch-'0');
		ch=getchar();
	}
	return x*neg;
}
int main() {
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	
	int n=read(),m=read();
	for (int i=1;i<=n;++i) {
		num[i]=read();
	}
	sort(num+1,num+n+1);
	for (int i=1;i<=n;++i) {
		used[num[i]]=true;
		last[num[i]]=i;
	}
	dp[0]=0,dp[1]=0,dp[2]=0;
	for (int i=3;i<=n;++i) {
		dp[i]=dp[i-1];
		if (num[i-2]==num[i]) dp[i]=max(dp[i],dp[i-3]+1);
		if (used[num[i]]&&used[num[i]-1]&&used[num[i]-2]) {
			dp[i]=max(dp[i],dp[last[num[i]-1]-1]+1);
		} 
	}
//	for (int i=1;i<n;++i) cout<<dp[i]<<' ';
	cout<<dp[n]<<'\n';
	return 0;
}
