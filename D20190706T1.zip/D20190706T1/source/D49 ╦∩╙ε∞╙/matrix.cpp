#include<bits/stdc++.h>
using namespace std;
int ans,n,m,got[205],sum,len[205],num[205][205];
char ch[205][205];
inline int read() {
	int x=0,neg=1;char ch=getchar();
	while(!isdigit(ch)) {
		if (ch=='-') neg=-1;
		ch=getchar();
	}
	while(isdigit(ch)) {
		x=x*10+(ch-'0');
		ch=getchar();
	}
	return x*neg;
}
bool cmp(int a,int b) {
	if (got[a]>1||got[b]>1) return false;
	for (int i=0;i<26;++i) if (num[a][i]!=num[b][i]) return false;
	return true;
}
inline void manacher() {
	int k=0,sum=0;
	len[0]=1;
	for (int i=1;i<=2*n;++i) {
		if (i<=sum) len[i]=min(sum-i,len[2*k-i]);
		else len[i]=1;
		while(i-len[i]>=0&&i+len[i]<=2*n+1&&cmp(i+len[i],i-len[i])) {
			len[i]++;
		}
		if (got[i]>1) {
			len[i]=1;
		}
		if (sum<i+len[i]) {
			k=i;
			sum=i+len[i];
		}
		ans+=(len[i])/2;
	}
}
int main() {
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	
	n=read(),m=read();
	for(int i=1;i<=n;++i) 
		for (int j=1;j<=m;++j) 
			 cin>>ch[i][j];
	for (int i=1;i<=m;++i) {
		for (int j=1;j<=n;++j) 
			for (int k=0;k<26;++k) 
				num[j*2-1][k]=got[j*2-1]=0;
		for (int j=i;j<=m;++j) {
			for (int k=1;k<=n;++k) {
				++num[2*k-1][ch[k][j]-'a'];
				if (num[2*k-1][ch[k][j]-'a']&1) got[2*k-1]++;
				else got[2*k-1]--;
			}
			manacher();
		} 
	}
	cout<<ans<<'\n';
	return 0;
}
