#include<bits/stdc++.h>
using namespace std;
//int pre1[1000005],pre2[1000005]��
int ans,n;
inline int read() {
	int x(0),neg(1);char ch=getchar();
	while(!isdigit(ch)) {
		if (ch=='-') neg=-1;
		ch=getchar();
	}
	while(isdigit(ch)) {
		x=x*10+(ch-'0');
		ch=getchar();
	}
	return x*neg;
}
struct node{
	int x,y,pos;
}p[1000005];
inline int calc(node a,int k) {
	return a.x*(k-1)+a.y*(n-k);
}

bool cmp(node a,node b) {
	return a.x+b.y>b.x+a.y;
}

int main() {
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	 
	n=read();
	for (int i(1);i<=n;++i) {
		p[i].x=read(),p[i].y=read(),p[i].pos=i;
	}
	sort(p+1,p+n+1,cmp);
//	cout<<"POS:"<<'\n';
//	for (int i=1;i<=n;++i) {
//		cout<<p[i].pos<<'\n';
//	}
//	puts("");
//	for (int i=1;i<=n;++i) {
//		pre1[i]=pre1[i-1]+p[i].x;
//		pre2[i]=pre2[i-1]+p[i].y;
//	}
//	for (int i=1;i<=n;++i) cout<<p[i].x<<' '<<p[i].y<<'\n';
	for (int i(1);i<=n;++i) {
		ans=ans+p[i].x*(i-1)+p[i].y*(n-i);
	}
	cout<<ans<<'\n';
	return 0;
}
