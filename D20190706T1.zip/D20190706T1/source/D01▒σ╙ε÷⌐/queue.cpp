#include<cstdio>
#define ll long long
#define cy(tmp,x,y) for(int tmp=x;tmp<=y;++tmp)
#define ocy(tmp,x,y) for(int tmp=x;tmp>=y;--tmp)
using namespace std;
int n,tmp,a[500007],b[500007],q[500007];
ll ans,sum,x,suma[500007],sumb[500007];
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&n);
	cy(i,1,n) scanf("%d%d",&a[i],&b[i]);
	q[1]=1;suma[1]=a[1];sumb[1]=b[1];
	cy(i,2,n){
		sum=1e13;
		cy(j,0,i-1){
			x=sumb[j]+suma[j+1]+a[i]*j+b[i]*(i-j-1);
			if(a[i]>b[i]&&x<sum){
				tmp=j;
				sum=x;
			}
			if(b[i]>=a[i]&&x<=sum){
				tmp=j;
				sum=x;
			}
		}
		ans+=sum;
		ocy(j,i-1,tmp+1) q[j+1]=q[j];
		q[tmp+1]=i;
		cy(j,tmp+1,i) sumb[j]=sumb[j-1]+b[q[j]];
		suma[i]=a[q[i]];
		ocy(j,i-1,1) suma[j]=suma[j+1]+a[q[j]];
	}
	printf("%lld",ans);
	return 0;
}
