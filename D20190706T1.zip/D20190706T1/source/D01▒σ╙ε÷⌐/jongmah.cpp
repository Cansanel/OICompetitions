#include<cstdio>
#include<algorithm>
#define cy(tmp,x,y) for(int tmp=x;tmp<=y;++tmp)
using namespace std;
int n,m,tot,x,ans,a[100007],q[100007],sum[100007];
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	scanf("%d%d",&n,&m);
	cy(i,1,n) scanf("%d",&a[i]);
	sort(a+1,a+n+1);
	cy(i,1,n){
		q[++tot]=a[i];
		x=1;
		while(a[i+x]==a[i]) x++;
		sum[tot]=x;
		i+=x-1;
	}
	cy(i,1,tot-2)
		if(q[i]==q[i+1]-1&&q[i]==q[i+2]-2){
			x=min(min(sum[i],sum[i+1]),sum[i+2]);
			ans+=x;
			sum[i]-=x;
			sum[i+1]-=x;
			sum[i+2]-=x;
		}
	cy(i,1,tot) ans+=sum[i]/3;
	printf("%d",ans);
	return 0;
}
