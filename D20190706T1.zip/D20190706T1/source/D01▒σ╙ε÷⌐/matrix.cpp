#include<cstdio>
#define cy(tmp,x,y) for(int tmp=x;tmp<=y;++tmp)
using namespace std;
int n,m,t,ans,sum[250][250],a[250][250];
char ch;
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d%d",&n,&m);
	ch=getchar();
	cy(i,1,n){
		while(ch<'a'||ch>'z') ch=getchar();
		cy(j,1,m){
			a[i][j]=int(ch);
			ch=getchar();
		}
	}
	if(n==1){
		cy(i,1,m) sum[i][a[1][i]]++;
		cy(i,2,m)
			cy(j,int('a'),int('z')) sum[i][j]+=sum[i-1][j];
		cy(i,1,m)
			cy(j,i,m){
				t=0;
				cy(k,int('a'),int('z')) if((sum[j][k]-sum[i-1][k])%2!=0) t++;
				if(t<=1) ans++;
			}
		printf("%d",ans);
	}
	if(m==1){
		cy(i,1,n)
			cy(j,i,n){
				t=0;
				cy(k,i,(i+j)/2)
					if(a[k][1]!=a[j-k+i][1]){
						t=1;
						break;
					}
				if(t==0) ans++;
			}
		printf("%d",ans);
	}
	return 0;
}
