#include <bits/stdc++.h>
#define ll long long
using namespace std;
inline int read(){
	int x=0,y=1;char c=getchar();
	while((c>'9'||c<'0')&&c!='-') c=getchar();
	if(c=='-') y=-1,c=getchar();
	while(c<='9'&&c>='0') x=(x<<3)+(x<<1)+c-'0',c=getchar();
	return x*y;
}
const int N=100005;
int n,m,a[N],st0[N],st1[N],st2[N],st3[N],st4[N],f[N][4];
int val[N],l[5],r[5],t1=1,t2=1,ans,h[N],la,cnt=1,id[N];
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++)
		a[i]=read(),h[a[i]]++;;
	sort(a+1,a+1+n);
	for(int i=1;i<=n;i++){
		if(a[i]==a[i-1]) continue;
		id[a[i]]=i;
		if(a[i]<3) continue;
		val[a[i]]=min(min(h[a[i]],h[a[i]-1]),h[a[i]-2]);
		cout<<a[i]<<' '<<val[a[i]]<<endl;
	}
	f[0][0]=0;f[0][1]=f[0][2]=f[0][3]=-1;
	l[0]=l[1]=l[2]=l[3]=l[4]=1;r[0]=r[1]=r[2]=r[3]=r[4]=1;
	for(int i=1;i<=n;i++){
		if(a[i]==a[i-1]) cnt++; else cnt=1;
		while(l[1]<=r[1]&&a[st1[l[1]]]<a[i]-1) l[1]++;
		if(l[1]>r[1]) st1[l[1]]=0;
		while(l[2]<=r[2]&&a[st2[l[2]]]<a[i]-1) l[2]++;
		if(l[2]>r[2]) st2[l[2]]=0;
		while(l[3]<=r[3]&&a[st3[l[3]]]<a[i]) l[3]++;
		if(l[3]>r[3]) st3[l[3]]=0;
		while(l[4]<=r[4]&&a[st4[l[4]]]<a[i]) l[4]++;
		if(l[4]>r[4]) st4[l[4]]=0;
		while(a[t1]<a[i]-1) t1++;
		while(a[t1]==a[i]-1){
			while(l[1]<=r[1]&&f[st1[r[1]]][1]<f[t1][1]) r[1]--;
			st1[++r[1]]=t1;t1++;
		}
		while(a[t2]<a[i]-1) t2++;
		while(a[t2]==a[i]-1){
			while(l[2]<=r[2]&&f[st2[r[2]]][2]<f[t2][2]) r[2]--;
			st2[++r[2]]=t2;t2++;
		}
		f[i][1]=f[st0[l[0]]][0];
		f[i][2]=f[st1[l[1]]][1];
		f[i][3]=f[st3[l[3]]][1];
		int k=min(val[a[i]],cnt);
		f[i][0]=f[st2[l[2]]][2]+k;
		if(a[id[a[i]-1]+h[a[i]-1]-1-k]==a[i]-1) f[i][0]+=f[a[id[a[i]-1]+h[a[i]-1]-1-k]][0];
		if(a[id[a[i]-2]+h[a[i]-2]-1-k]==a[i]-2) f[i][0]+=f[a[id[a[i]-2]+h[a[i]-2]-1-k]][0];
		if(a[i]==a[i-1]&&a[i-1]==a[i-2])
			f[i][0]=max(f[i][0],la+1);
		f[i][0]=max(f[i][0],0);
		while(l[0]<=r[0]&&f[st0[r[0]]][0]<f[i][0]) r[0]--;
		st0[++r[0]]=i;
		while(l[3]<=r[3]&&f[st3[l[3]]][1]<f[i][1]) r[3]--;
		st3[++r[3]]=i;
		while(l[4]<=r[4]&&f[st4[l[4]]][3]<f[i][3]) r[4]--;
		st4[++r[4]]=i;
		cout<<f[i][0]<<' '<<f[i][1]<<' '<<f[i][2]<<endl;
		ans=max(ans,f[i][0]);
		if(i>=2&&a[i]==a[i-1]) la=max(la,f[i-2][0]);
	}
	printf("%d\n",ans);
	return 0;
}
