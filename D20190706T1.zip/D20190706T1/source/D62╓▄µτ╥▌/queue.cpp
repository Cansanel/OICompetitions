#include <bits/stdc++.h>
#define ll long long
using namespace std;
inline int read(){
	int x=0,y=1;char c=getchar();
	while((c>'9'||c<'0')&&c!='-') c=getchar();
	if(c=='-') y=-1,c=getchar();
	while(c<='9'&&c>='0') x=(x<<3)+(x<<1)+c-'0',c=getchar();
	return x*y;
}
const int N=500005;
int n;ll ans;
struct person{int l,r;} p[N];
inline bool cmp(person x,person y){
	return x.r-x.l<y.r-y.l;
}
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++){
		p[i].l=read(),p[i].r=read();
	}
	/*for(int i=1;i<=n;i++)
		for(int j=1;j<n;j++){
			if(p[j].l*(j-1)+p[j].r*(n-j)+p[j+1].l*j+p[j+1].r*(n-j+1)>p[j].r*(n-j+1)+p[j].l*j+p[j+1].l*(j-1)
			+p[j+1].r*(n-j)) swap(p[j],p[j+1]);
		}*/
	sort(p+1,p+1+n,cmp);
	for(int i=1;i<=n;i++)
		ans+=1ll*p[i].l*(i-1)+p[i].r*(n-i);
	printf("%lld\n",ans);
	return 0;
}
