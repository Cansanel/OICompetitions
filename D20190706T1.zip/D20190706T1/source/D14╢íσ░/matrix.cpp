#include<bits/stdc++.h>
using namespace std;
char s[255][255];
int a[16005][30],tot[16005],len[16005];
int n,m;
long long ans;
bool cmp(int x,int y){
	if (tot[x]>1||tot[y]>1) return false;
	for (int i=0;i<26;i++)
		if (a[x][i]!=a[y][i]) return false;
	return true;
}
/*int manacher(){
	int i;
	int len=n;
	len++;
	len<<=1;
	long long ret=0,mx=0,id=0;
	for (int i=1;i<len;i++){
		if (mx>i) p[i]=min(p[id*2-i],mx-i);
		else p[i]=1;
		int o=i;
		while (i-p[i]>=0&&i+p[i]<len&&cmp(i-p[i],i+p[i])){
			p[i]++;
			o++;
		}
		if (tot[i]>1) p[i]=1;
		if (mx<p[i]+i) mx=p[i]+i,id=i;
		ret=max(ret,p[i]);
		ans+=p[i]/2;
	} 
	return ret-1;
}*/
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++) scanf("%s",s[i]+1);
	for (int i=1;i<=m;i++)
	{
		for (int j=1;j<=n;j++)
			for (int k=0;k<26;k++)
		a[2*j-1][k]=tot[2*j-1]=0;
		for (int j=i;j<=m;j++)
		{
			for (int k=1;k<=n;k++)
			{
				if (a[2*k-1][s[k][j]-'a']&1) tot[2*k-1]--;
				else tot[2*k-1]++;
				a[2*k-1][s[k][j]-'a']++;
			}
			len[0]=1;
			int mxpos=0,mx=0;
			for (int k=1;k<=2*n;k++){
				if (k<=mx){
					int mk=2*mxpos-k;
					if (len[mk]<mx-k) len[k]=len[mk];
					else {
						int p=mx;
						while (p<=2*n&&p<=2*k&&cmp(2*k-p,p)) p++;
						len[k]=p-k;
					}
				}
				else {
					int p=k;
					while (p<=2*n&&p<=2*k&&cmp(2*k-p,p)) p++;
					len[k]=p-k;
				}
				if (k+len[k]-1>mx){
					mx=k+len[k]-1;
					mxpos=k;
				}
				ans+=len[k]/2;
			}
		}
	}
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
