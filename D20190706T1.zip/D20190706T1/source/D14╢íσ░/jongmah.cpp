#include<bits/stdc++.h>
using namespace std;
int n,m,p;
int cnt[100005],f[100005][5][5];
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++){
		scanf("%d",&p);
		cnt[p]++;
	}
	memset(f,-1,sizeof(f));
	f[0][0][0]=0;
	for (int i=0;i<=m+1;i++)
		for (int j=0;j<=2;j++)
			for (int k=0;k<=2;k++)
	{
		if (f[i][j][k]<0) continue;
		int tmp=cnt[i+1]-k-j;
		for (int l=0;l<=2&&l<=tmp;l++) f[i+1][k][l]=max(f[i+1][k][l],f[i][j][k]+(tmp-l)/3+l);
	}
	printf("%d\n",f[m+1][0][0]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
