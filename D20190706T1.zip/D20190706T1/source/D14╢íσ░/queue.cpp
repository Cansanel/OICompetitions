#include<bits/stdc++.h>
using namespace std;
int n;
struct p{
	int a,b;
}f[500005];
bool cmp(p x,p y){
	return (x.a-x.b)>(y.a-y.b);
}
long long ans,tmpa,tmpb;
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++) {
		scanf("%d%d",&f[i].a,&f[i].b);
		tmpa+=f[i].a;
		tmpb+=f[i].b; 
	}
	ans=n*tmpb-tmpa;
	sort(f+1,f+n+1,cmp);
	for (int i=1;i<=n;i++) ans+=i*(f[i].a-f[i].b);
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
