#include<bits/stdc++.h>
#define N 500001
#define llint long long
using namespace std;
int n,r,l,k[N];
llint b=0;
bool cmp(int x,int y){
	return x>y;
}
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&n);
	for(register int i=1;i<=n;++i) scanf("%d%d",&l,&r),k[i]=l-r,b+=r*n-l;
	sort(k+1,k+1+n,cmp);
	llint ans=0;
	for(register int i=1;i<=n;++i) ans+=k[i]*i;
	printf("%lld\n",ans+b);
	return 0;
}
