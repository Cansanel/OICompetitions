#include<bits/stdc++.h>
#define M 100001
#define max(a,b) a>b?a:b
using namespace std;
int n,m,cnt[M];
int sum,ans=0;
void dfs(){
	bool t=1;
	for(register int i=1;i<=m;++i)
		if(cnt[i]>=3){
			cnt[i]-=3,++sum;
			dfs();
			cnt[i]+=3,--sum;
			t=0;
		}
	for(register int i=1;i<=m-2;++i)
	    if(cnt[i]&&cnt[i+1]&&cnt[i+2]){
	    	--cnt[i],--cnt[i+1],--cnt[i+2],++sum;
	    	dfs();
	    	++cnt[i],++cnt[i+1],++cnt[i+2],--sum;
	    	t=0;
	    }
	if(t) ans=max(ans,sum);
	return;
}
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	scanf("%d%d",&n,&m);
	memset(cnt,0,sizeof(cnt));
	int tmp;
	for(register int i=1;i<=n;++i) scanf("%d",&tmp),++cnt[tmp];
	sum=0;dfs();
	printf("%d\n",ans);
	return 0;
}

