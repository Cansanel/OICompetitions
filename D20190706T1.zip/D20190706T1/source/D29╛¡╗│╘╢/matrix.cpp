#include<bits/stdc++.h>
#define N 251
using namespace std;
int n,m;
string s[N];
int f[N][N];
bool check(int a,int b,int c,int d){
	int p=0;
	for(register int i=a;i<=c;++i){
		for(register int j=b;j<=d;++j)
		    p=p^(1<<(s[i][j]-'a'));
		int isok=0;
		for(;p;p>>=1) isok+=p%2;
		if(isok>1) return 0;
	}
	return 1;
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(register int i=1;i<=n;++i) cin>>s[i],s[i]=' '+s[i];
	int ans=0;
	for(register int a=1;a<=n;++a) for(register int b=1;b<=m;++b)
		for(register int c=a;c<=n;++c) for(register int d=b;d<=m;++d)
			if(check(a,b,c,d)) ++ans;
	printf("%d\n",ans);
	return 0;
}

