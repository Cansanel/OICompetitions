#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int hh[28]={0,1999603,1999607,1999619,1999631,1999633,1999651,1999661,1999667,1999681,1999691,1999703,1999721,1999733,1999771,1999799,1999817,1999819,1999853,1999859,1999867,1999871,1999889,1999891,1999957,1999969,1999979,1999993};
int a[256][256],n,m,i,j,k,x,y,z,x1,y1,x2,y2,v[28],ans;
bool hw[256][256][256];
long long s[256][256];
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++)
	  for(j=1;j<=m;j++)
	  {
	  	char ch=getchar();
	  	while((ch>'z')||(ch<'a'))ch=getchar();
	  	a[i][j]=ch-'a'+1;
	  }
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=m;j++)
		  s[i][j]=s[i][j-1]+hh[a[i][j]];
	}
	for(i=1;i<=n;i++)
	{
	  for(j=1;j<=m;j++)
	  {
	    memset(v,0,sizeof(v));int p=0;
	    for(k=j;k<=m;k++)
	    {
	    	v[a[i][k]]++;
	    	if(v[a[i][k]]%2==1)p++;
	    	else p--;
	    	if(p<=1)hw[i][j][k]=true;
		}
	  }
	}
	for(x1=1;x1<=n;x1++)
	  for(y1=1;y1<=m;y1++)
	    for(x2=x1;x2<=n;x2++)
	      for(y2=1;y2<=m;y2++)
	      {
	      	for(i=0;x1+i<=x2-i;i++)
	      	  if(!hw[x1+i][y1][y2]||
				(s[x1+i][y2]-s[x1+i][y1-1]!=s[x2-i][y2]-s[x2-i][y1-1]))break;
			if(x1+i<=x2-i)continue;
			ans++;
		  }
	printf("%d\n",ans);
	return 0;
}
/*
3 5
accac
aaaba
cccaa
*/
