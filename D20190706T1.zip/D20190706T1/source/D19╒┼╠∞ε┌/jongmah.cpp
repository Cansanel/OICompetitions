#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int a[100008],n,m,i,j,k,x,y,z,f[100008][7][10],ans,p,q,ma;
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++)
	{
	  scanf("%d",&x);
	  a[x+2]++;
	}
	m+=2;
	for(i=1;i<=m;i++)
		if(a[i]>6)ans+=(a[i]-6)/3,a[i]=(a[i]-6)%3+6;
	for(i=2;i<=m+2;i++)
	  for(j=0;j<=min(a[i-1],5);j++)
	    for(k=0;k<=min(a[i],8);k++)
		{
		  f[i][j][k]=max(f[i][j][k],max(f[i][j+1][k],f[i][j][k+1]));
		  for(p=0;j+3*p<=min(a[i-1],5);p++)
		    for(q=0;k+3*q<=min(a[i],8);q++)
		      f[i][j][k]=max(f[i][j][k],f[i][j+3*p][k+3*q]+p+q);
		  for(p=0;p<=min(min(j,k),a[i+1]);p++)
		    f[i+1][k-p][a[i+1]-p]=max(f[i+1][k-p][a[i+1]-p],f[i][j][k]+p);
		}
	printf("%d\n",ans+f[m+2][0][0]);
	return 0;
}
/*
112233
  223344
    334455
    
13 5
1 1 5 1 2 3 3 2 4 2 3 4 5
1 1 1 2 2 2 3 3 3 4 4 5 5
3 3 3 4 4 4 5 5 5 6 6 7 7

*/
