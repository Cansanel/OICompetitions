#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
using namespace std;
struct arr{
	long long a,b;
}a[500008];
bool cmp(arr a,arr b)
{
	return (a.a-a.b)>(b.a-b.b);
}
long long n,i,ans;
void read(long long &x)
{
	char ch=getchar();x=0;
	for(;(ch>'9')||(ch<'0');ch=getchar());
	for(;(ch>='0')&&(ch<='9');ch=getchar())
	  x=x*10+ch-'0';
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++)
	  read(a[i].a),read(a[i].b);
	sort(a+1,a+1+n,cmp);
	for(i=1;i<=n;i++)
	  ans+=a[i].a*(i-1)+a[i].b*(n-i);
	cout<<ans<<endl;
	return 0;
}
/*
10
5 10
12 4
31 45
20 55
30 17
29 30
41 32
7 1
5 5
3 15

*/
