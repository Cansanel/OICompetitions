#include<bits/stdc++.h>
using namespace std;
long long n;
struct node{
	long long a,b,id;
}arr[500005];
bool cmp(node aa,node bb){
	return aa.a-aa.b>bb.a-bb.b;
}
long long ans;
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	cin>>n;
	long long i,j,k;
	for(i=1;i<=n;i++)scanf("%d%d",&arr[i].a,&arr[i].b);
	for(i=1;i<=n;i++)ans+=n*arr[i].b-arr[i].a;
	sort(arr+1,arr+n+1,cmp);
	for(j=1;j<=n;j++)ans+=j*(arr[j].a-arr[j].b);
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
