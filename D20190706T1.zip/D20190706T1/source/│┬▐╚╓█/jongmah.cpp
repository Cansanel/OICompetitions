#include<bits/stdc++.h>
using namespace std;
int n,arr[100005],book[100005],m;
int vis[100005],tot;bool ifne[100005];
long long ans;
void dfs(int step,int num){
	int ci=0;
	if(ans<num)ans=num;
	if(step==tot+1)return;
	while(vis[step]>0&&vis[step-1]>0&&vis[step-2]>0&&step>=3&&ifne[step]&&ifne[step-1]){
		ci++;
		vis[step]--;vis[step-1]--;vis[step-2]--;
		dfs(step+1,num+ci);
	}
	while(ci--){vis[step]++;vis[step-1]++;vis[step-2]++;}
	ci=0;
	while(vis[step]>=3){
		vis[step]-=3;ci++;
		dfs(step+1,num+ci);
	}
	while(ci--)vis[step]+=3;
	dfs(step+1,num);
}
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n>>m;
	int i,j;
	for(i=1;i<=n;i++){
		scanf("%d",&arr[i]);
		book[arr[i]]++;
	}
	for(i=1;i<=m;i++){
		if(book[i]){
			vis[++tot]=book[i];
			if(book[i-1])ifne[tot]=1;
		}
	}
	dfs(1,0);
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
