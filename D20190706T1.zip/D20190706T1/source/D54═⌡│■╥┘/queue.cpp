#include <bits/stdc++.h>

using namespace std;

struct node{
	int a,b;
}g[500010];

int n;
long long ans;

bool cmp(node x,node y){
	int a1=x.a,b1=x.b,a2=y.a,b2=y.b;
	return b1+a2<a1+b2;
}

int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	ios::sync_with_stdio(false);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)scanf("%d %d",&g[i].a,&g[i].b);
	sort(g+1,g+n+1,cmp);
	for (int i=1;i<=n;i++){
		ans+=g[i].a*(i-1)+g[i].b*(n-i);
	}
	cout<<ans<<endl;
	
	return 0;
}
/*
3
4 2
2 3
6 1

10
5 10
12 4
31 45
20 55
30 17
29 30
41 32
7 1
5 5
3 15
*/
