#include <bits/stdc++.h>

using namespace std;

int n,m;
int cnt[100010];
int pos[100010];
vector<int> v;
int ans;

void dfs(int x,int sum){
	if(!cnt[x])return ;
	ans=max(ans,sum);
	if (cnt[x]>=3){
		cnt[x]-=3;
		for (int i=pos[x];i<v.size();i++)dfs(v[i],sum+1);
		cnt[x]+=3;
	}
	if (cnt[x] && cnt[x+1] && cnt[x+2]){
		cnt[x]--;cnt[x+1]--;cnt[x+2]--;
		for (int i=pos[x];i<v.size();i++)dfs(v[i],sum+1);
	}
	return ;
}

void solve(){
	for (int i=0;i<v.size();i++)if (cnt[i])dfs(i,0);
}

int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m;
	for (int i=1,x;i<=n;i++){
		cin>>x;
		if (!cnt[x])v.push_back(x);
		cnt[x]++;
	}
	sort(v.begin(),v.end());
	for (int i=0;i<v.size();i++)pos[v[i]]=i;
	solve();
	cout<<ans<<endl;
	
	return 0;
}
/*
10 6
2 3 3 3 4 4 4 5 5 6

13 5
1 1 5 1 2 3 3 2 4 2 3 4 5

12 6
1 5 3 3 3 4 3 5 3 2 3 3
*/
