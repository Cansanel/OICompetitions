#include <bits/stdc++.h>

#define x1 qaq
#define y1 mogician

using namespace std;

int n,m;
int a[250][250];
int s[30][250][250];
long long ans;

int sum(int c,int x1,int y1,int x2,int y2){
	return s[c][y2][x2]-s[c][y2][x1-1]-s[c][y1-1][x2]+s[c][y1-1][x1-1];
}

bool judge(int x1,int y1,int x2,int y2){
	int h=y2-y1+1,w=x2-x1+1;
	if (h==1 && w==1)return 1;
	if ((h&1) && (w&1)){
		int cnt1=0,cnt2=0;
		for (int i=1;i<=26;i++){
			int su=sum(i,x1,y1,x2,y2);
//			cout<<char(i+'a'-1)<<' '<<su<<endl;
			if (su!=0)
				if (su&3){
					if (su&1){
						if (cnt2)return 0;
						cnt2=1;
						if ((su-1)&3){
							if (cnt1+(su>>1)>=h+w)return 0;
							cnt1+=(su>>1);
						}
					}
					else{
						if (cnt1+(su>>1)>=h+w)return 0;
						cnt1+=(su>>1);
					}
				}
			
		}
		return 1;
	}
	else if (h&1){
		int cnt1=0,cnt2=0;
		for (int i=1;i<=26;i++){
			int su=sum(i,x1,y1,x2,y2);
//			cout<<char(i+'a'-1)<<' '<<su<<endl;
			if (su!=0)
				if (su&3){
					if (su&1)return 0;
					else{
						if (cnt1+(su>>1)>=w)return 0;
						cnt1+=(su>>1);
					}
				}
		}
		return 1;
	}
	else if (w&1){
		int cnt1=0,cnt2=0;
		for (int i=1;i<=26;i++){
			int su=sum(i,x1,y1,x2,y2);
//			cout<<char(i+'a'-1)<<' '<<su<<endl;
			if (su!=0)
				if (su&3){
					if (su&1)return 0;
					else{
						if (cnt1+(su>>1)>=h)return 0;
						cnt1+=(su>>1);
					}
				}
		}
		return 1;
	}
	else {
		for (int i=1;i<=26;i++){
			int su=sum(i,x1,y1,x2,y2);
//			cout<<char(i+'a'-1)<<' '<<su<<endl;
			if (su!=0)
				if (su&3)return 0;
		}
		return 1;
	}
}

int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m;
	for (int i=1;i<=n;i++){
		string str;
		cin>>str;
		for (int j=1;j<=m;j++){
			a[i][j]=str[j-1]-'a'+1;
			for (int x=1;x<=26;x++){
				s[x][i][j]=s[x][i-1][j]+s[x][i][j-1]-s[x][i-1][j-1]+(a[i][j]==x);
			}
		}
	}
//	for (int i=1;i<=26;i++){
//		cout<<char(i+'a'-1)<<endl;
//		for (int j=1;j<=n;j++){
//			for (int k=1;k<=m;k++){
//				cout<<s[i][j][k]<<' ';
//			}
//			cout<<endl;
//		}
//		cout<<endl;
//	}
//	cout<<s[1][3][1]<<' '<<s[1][2-1][1]<<' '<<s[1][3][1-1]<<' '<<s[1][2-1][1-1]<<endl;
	
	for (int x1=1;x1<=m;x1++){
		for (int x2=x1;x2<=m;x2++){
			for (int y1=1;y1<=n;y1++){
				for (int y2=y1;y2<=n;y2++){
					if (judge(x1,y1,x2,y2))/*cout<<ans<<' '<<x1<<' '<<y1<<' '<<x2<<' '<<y2<<' '<<1<<endl,*/ans++;
//					else cout<<x1<<' '<<y1<<' '<<x2<<' '<<y2<<' '<<0<<endl;
				}
			}
		}
	}
	cout<<ans<<endl;
	
	return 0;
}
/*
2 3
aca
aac

3 5
accac
aaaba
cccaa
*/
