#include<bits/stdc++.h>
using namespace std;
template<typename T>inline void read(T &x){
	long long f=1;x=0;char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	x*=f;
}
template<typename T>inline void write(T x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
}
template<typename T>inline void writeln(T x){
	write(x);
	putchar('\n');
}
struct Info{
	long long A,B;	
}a[500010];
bool cmp(const Info&a,const Info&b){
	return a.A-a.B>b.A-b.B;
}
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);

	long long n;
	read(n);
	for(long long i=1;i<=n;i++){
		read(a[i].A);read(a[i].B);
	}
	
	sort(a+1,a+n+1,cmp);
	
	long long ans=0;
	for(long long i=1;i<=n;i++){
		ans+=a[i].A*(i-1)+a[i].B*(n-i);
	}
	writeln(ans);
	return 0;
}
/*
3
4 2
2 3
6 1
 
10
5  10
12  4
31  45
20  55
30  17
29  30
41  32
7  1
5  5
3  15

*/
