#pragma GCC optimize(2)
#include<bits/stdc++.h>
using namespace std;
template<typename T>inline void read(T &x){
	long long f=1;x=0;char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	x*=f;
}
template<typename T>inline void write(T x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
}
template<typename T>inline void writeln(T x){
	write(x);
	putchar('\n');
}
int n,m,a[200000],b[200000],h[200000],s[200000],ans=0;
void dfs(int dep,int tot){
	if(s[dep]/3+tot<=ans)return;
	if(dep>m){
		if(tot>ans)ans=tot;
	}else{
		if(h[dep]>1&&h[dep+1]>1&&h[dep+2]>1){
			h[dep]-=2;h[dep+1]-=2;h[dep+2]-=2;
			dfs(dep+1,tot+2+h[dep]/3);
			h[dep]+=2;h[dep+1]+=2;h[dep+2]+=2;
		}	
		if(h[dep]&&h[dep+1]&&h[dep+2]){
			h[dep]--;h[dep+1]--;h[dep+2]--;
			dfs(dep+1,tot+1+h[dep]/3);
			h[dep]++;h[dep+1]++;h[dep+2]++;
		}
	
		dfs(dep+1,tot+h[dep]/3);
	}
}
void baoli(){
	for(int i=m;i>=1;i--)s[i]=s[i+1]+h[i];
	
	dfs(1,0);
	writeln(ans);
}
void shun(){
	int res=0;
	for(int i=1;i<=m;i++){
		while(h[i]&&h[i+1]&&h[i+2]){
			h[i]--;h[i+1]--;h[i+2]--;
			res++;
		}
	}
	writeln(res);
}
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);

	read(n);read(m);
	for(int i=1;i<=n;i++){
		read(a[i]);
	}
	
	sort(a+1,a+n+1);
		
	int len=0,num=0;
	for(int i=1;i<=n;i++){
		if(a[i]!=a[i-1]){
			b[++len]=++num;
		}else{
			b[++len]=num;
		}
	}
	for(int i=1;i<=len;i++)h[b[i]]++;
	m=len;
	
	if(n<=100&&m<=100){
		baoli();
	}else{
		shun();
	}
	return 0;
}
/*
10 6
2 3 3 3 4 4 4 5 5 6

13 5
1 1 5 1 2 3 3 2 4 2 3 4 5

12 4
1 1 2 2 2 2 3 3 3 3 4 4

*/
