#include<bits/stdc++.h>
using namespace std;
template<typename T>inline void read(T &x){
	long long f=1;x=0;char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	x*=f;
}
template<typename T>inline void write(T x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
}
template<typename T>inline void writeln(T x){
	write(x);
	putchar('\n');
}
int a[2000][2000],h[2000],h1[2000],h2[2000];
bool check(int x1,int y1,int x2,int y2){
	for(int k=0;k<=(x2-x1)/2;k++){
		memset(h1,0,sizeof(h1));
		memset(h2,0,sizeof(h2));
		for(int i=y1;i<=y2;i++){
			h1[a[x1+k][i]]++;
			h2[a[x2-k][i]]++;
		}
		for(int i=1;i<=26;i++){
			if(h1[i]!=h2[i])return 0;
		}
	}
	
	for(int i=x1;i<=x2;i++){
		memset(h,0,sizeof(h));
		for(int j=y1;j<=y2;j++){
			h[a[i][j]]++;
		}
		int odd=0;
		for(int j=1;j<=26;j++){
			if(h[j]%2)odd++;
		}
		if(odd>1)return 0;
	}
	return 1;
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);

	int n,m;
	read(n);read(m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			char ch;
			cin>>ch;
			a[i][j]=ch-'a'+1;
		}
	}
	
	if(n==1){
		int ans=0;
		for(int i=1;i<=m;i++){
			for(int j=i;j<=m;j++){
				memset(h,0,sizeof(h));
				for(int k=i;k<=j;k++)h[a[1][k]]++;
				int odd=0;
				for(int k=1;k<=26;k++){
					if(h[k]%2)odd++;
				}
				if(odd<=1){
					ans++;
				}
			}
		}
		writeln(ans);
	}
	if(m==1){
		int ans=0;
		for(int i=1;i<=n;i++){
			for(int j=i;j<=n;j++){
				memset(h,0,sizeof(h));
				for(int k=i;k<=j;k++)h[a[k][1]]++;
				int odd=0;
				for(int k=1;k<=26;k++){
					if(h[k]%2)odd++;
				}
				if(odd<=1){
					ans++;
				}
			}
		}
		writeln(ans);
	}else{
		int ans=0;
		for(int i1=1;i1<=n;i1++){
			for(int j1=1;j1<=m;j1++){
				for(int i2=i1;i2<=n;i2++){
					for(int j2=j1;j2<=m;j2++){
						if(check(i1,j1,i2,j2)){
							ans++;
						}
					}
				}
			}
		}
		writeln(ans);
	}
	return 0;
}
/*
2 3
aca
aac

3 5
accac
aaaba
cccaa

*/
