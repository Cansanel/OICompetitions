#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pqq priority_queue
#define itt ::iterator
void setIO(string y)
{
    if(y=="")
        return ;
#ifndef ybw
    freopen((y+".in").c_str(),"r",stdin);
    freopen((y+".out").c_str(),"w",stdout);
#endif
}
#define endl '\n'
struct ins{
    template<typename T>inline void read1(T &n){n=0;int f=1;char c=getchar();for(;!(c>='0'&&c<='9');c=getchar())if(c=='-')f=-1;for(;(c>='0'&&c<='9');c=getchar())n=n*10+c-'0';if(c!='.')return ;T x=0.1;for(;(c>='0'&&c<='9');c=getchar(),x*=0.1)n=n+(c-'0')*x;n*=f;}
    inline void write1(const char *n){int len=strlen(n);for(register int i=0;i<len;++i)putchar(n[i]);}
    inline void write1(char n){putchar(n);}
    inline void write1(double n){printf("%lf",n);}
    inline void write1(long double n){printf("%Lf",n);}
    template<typename T>inline void write1(T n)
    {
        if(n<0)putchar('-'),n=-n;
        if(n>=10)write1(n/10);
        putchar('0'+n%10);

    }
    template<typename T> ins operator <<(T n){write1(n);return *this;}
    template<typename T> ins operator >>(T &n){read1(n);return *this;}
}yin,yout;
const int maxn=1e5+10;
int n,m;
int a[maxn],maxi[maxn],f[maxn][4][4][4],b[maxn];
int main()
{
    setIO("jongmah");
    yin>>n>>m;
    for(int i=1;i<=n;i++)
        yin>>a[i],++b[a[i]];
    int ans=0,ss=0,sss=0;
    for(int i=1;i<=m;i++)
    {
        if(b[i])ss++,sss+=b[i]/3;
    }
    if(ss<3)
    {
        cout<<sss<<endl;
        return 0;
    }
    for(int i=1;i<=m;i++)
    {
        if(b[i]%3)
        {
            ans+=b[i]/3;
            b[i]%=3;
        }
        else
        {
            if(b[i])
            {
                ans+=b[i]/3-1;
                b[i]=3;
            }
        }
    }
    for(int i=3;i<=m;i++)
    {
        for(int j=1;j<=3;j++)
        {
            if(b[i-2]<j)break;
            for(int k=1;k<=3;k++)
            {
                if(b[i-1]<k)break;
                for(int kk=1;kk<=3;kk++)
                {
                    if(kk>b[i])break;
                    int x=0;
                    for(int kkk=1;kkk<=b[i-3];kkk++)
                        x=max(x,f[i-1][kkk][b[i-2]-j][b[i-1]-k]);
                    // int x=max(f[i-1][1][b[i-2]-j][b[i-1]-k],max(f[i-1][2][b[i-2]-j][b[i-1]-k],f[i-1][3][b[i-2]-j][b[i-1]-k]));
                    f[i][j][k][kk]=max(x+min(j,min(kk,k)),x+j/3+kk/3+k/3);
                }
                
            }
        }
        for(int j=0;j<=3;j++)
        {
            for(int k=0;k<=3;k++)
            {
                f[i][0][j][k]=max(f[i-1][0][0][j],max(f[i-1][1][0][j],max(f[i-1][2][0][j],f[i-1][3][0][j])));
                f[i][j][0][k]=max(f[i-1][0][j][0],max(f[i-1][1][j][0],max(f[i-1][2][j][0],f[i-1][3][j][0])));
                f[i][j][k][0]=max(f[i-1][0][j][k],max(f[i-1][1][j][k],max(f[i-1][2][j][k],f[i-1][3][j][k])));
            }
        }
    }
    // cout<<f[5][1][1][1]<<endl;
    int sum=0;
    for(int i=1;i<=3;i++)
        for(int j=1;j<=3;j++)
            for(int k=1;k<=3;k++)
            {
                sum=max(sum,f[m][i][j][k]);
            }
    cout<<ans+sum<<endl;
    return 0;
}