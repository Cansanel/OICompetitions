#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pqq priority_queue
#define itt ::iterator
void setIO(string y)
{
    if(y=="")
        return ;
#ifndef ybw
    freopen((y+".in").c_str(),"r",stdin);
    freopen((y+".out").c_str(),"w",stdout);
#endif
}
#define endl '\n'
struct ins{
    void read1(char &c)
    {
        c=getchar();
        for(;c==' '||c=='\n'||!isprint(c);c=getchar());
    }
    template<typename T>inline void read1(T &n){n=0;int f=1;char c=getchar();for(;!(c>='0'&&c<='9');c=getchar())if(c=='-')f=-1;for(;(c>='0'&&c<='9');c=getchar())n=n*10+c-'0';if(c!='.')return ;T x=0.1;for(;(c>='0'&&c<='9');c=getchar(),x*=0.1)n=n+(c-'0')*x;n*=f;}
    inline void write1(const char *n){int len=strlen(n);for(register int i=0;i<len;++i)putchar(n[i]);}
    inline void write1(char n){putchar(n);}
    inline void write1(double n){printf("%lf",n);}
    inline void write1(long double n){printf("%Lf",n);}
    template<typename T>inline void write1(T n)
    {
        if(n<0)putchar('-'),n=-n;
        if(n>=10)write1(n/10);
        putchar('0'+n%10);

    }
    template<typename T> ins operator <<(T n){write1(n);return *this;}
    template<typename T> ins operator >>(T &n){read1(n);return *this;}
}yin,yout;
const int maxn=300;
char a[maxn][maxn];
set<pair<int,int> > c[maxn];
int n,m;
void init()
{
    int b[230];
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            memset(b,0,sizeof(b));
            ++b[(int)(a[i][j]-'a')];
            c[i].insert(make_pair(j,j));
            int yj=1;
            for(int k=j+1;k<=m;k++)
            {
                ++b[(int)(a[i][k]-'a')];
                if(b[(int)(a[i][k]-'a')]&1)
                    yj++;
                else
                    yj--;
                if(yj<=1)c[i].insert(make_pair(j,k));
            }
        }
    }
}
int main()
{
    setIO("matrix");
    yin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            yin>>a[i][j];
        }
    }
    init();
    if(n==1)
    {
        cout<<c[1].size()<<endl;
        return 0;
    }
    if(m==1)
    {
        for(int i=1;i<=n;i++)a[1][i]=a[i][1];
        int ans=0;
        for(int i=1;i<=n;i++)
        {
            int mii=min(i,n-i);
            for(int j=0;j<=mii;j++)
            {
                if(a[1][i-j]!=a[1][i+j])break;
                // cout<<i<<" "<<j<<endl;
                ans++;
                // cout<<ans<<endl;
            }
        }
        cout<<ans<<endl;
        return 0;
    }
    cout<<(n+2)*(m+2)<<endl;
    // for(int i=1;i<=n;i++)
    // {
        // for(set<pair<int,int> > ::iterator j=c[i].begin();j!=c[i].end();j++)
        // {
            // chuli(a[i][j].first,)
        // }
    // }
    return 0;
}