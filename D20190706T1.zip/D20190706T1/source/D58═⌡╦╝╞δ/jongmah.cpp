#include<bits/stdc++.h>
using namespace std;
int n,m,a[100010],ans,c[100010];
void dfs(int step,int p,bool ok,int num,int cnt){
	if((num+n-step+1)/3+cnt<ans) return;
	if(num==3){
		dfs(step+1,a[step],1,1,cnt+1);
		dfs(step+1,0,1,0,cnt+1);
		if(step>n){
			ans=max(ans,cnt);return;
		}
	}
	if(step>n){
		ans=max(ans,cnt);return;
	}
	if(a[step]==p&&ok==0) dfs(step+1,p,ok,num,cnt);
	if(a[step]-p>1&&p!=0&&num!=3) return;
	if(p==a[step]&&ok==1&&c[a[step]]+num>=3){
		c[p]--;dfs(step+1,p,0,num+1,cnt);c[p]++;
	} 
	if(p==0) dfs(step+1,a[step],ok,num+1,cnt);
	else if(a[step]-p==1) dfs(step+1,a[step],ok,num+1,cnt);
	dfs(step+1,p,ok,num,cnt);
}
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		cin>>a[i];c[a[i]]++;
	}
	sort(a+1,a+n+1);
	dfs(1,0,1,0,0);
	cout<<ans;
}
