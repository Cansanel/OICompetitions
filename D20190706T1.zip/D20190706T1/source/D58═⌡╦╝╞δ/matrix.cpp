#include<bits/stdc++.h>
using namespace std;
int n,m,a[444][444],c[255][255][255];
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			cin>>a[i][j];c[a[i][j]][i][j]+=c[a[i][j]][i][j-1];
		}
	}
	cout<<n*m;return 0;
}
