#include<bits/stdc++.h>
using namespace std;
struct rec{int x,y,z;}e[500010];
int n,ans;
bool operator<(rec a,rec b){
	return a.z>b.z;
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>e[i].x>>e[i].y;e[i].z=e[i].x-e[i].y;
	}
	sort(e+1,e+n+1);
	for(int i=1;i<=n;i++){
		ans+=e[i].x*(i-1)+e[i].y*(n-i);
	}
	cout<<ans;
}
