#include<iostream>
#include<cstdio>
using namespace std;

int n,m,l,r,s1=0;
int ans=0;
int s[100010],f[100010];
bool b=0;
struct msm
{
	int s,t;
}a[100010];
int max1(int a,int b)
{
	if(a>b)	return a;
	return b;
}
void dfs(int x,int now)
{
	if(x==r+1)	return;
	f[x]=max1(f[x],now);
	if(now<f[x-3]&&x-3>=l)	return;
	if(s[x]>2)
	{
		s[x]-=3;
		dfs(x,now+1);
		s[x]+=3;
	}
	if(s[x]>0&&s[x+1]>0&&s[x+2]>0)
	{
		--s[x],--s[x+1],--s[x+2];
		dfs(x,now+1);
		++s[x],++s[x+1],++s[x+2];
	}
	dfs(x+1,now);
}
void tx()
{
	int ans1=0;
	for(register int i=1;i<=m-2;++i)
		while(s[i]>0&&s[i+1]>0&&s[i+2]>0)
			++ans1,--s[i],--s[i+1],--s[i+2];
	cout<<ans1<<endl;
}
int read()
{
	int x=0;
	char ch=getchar();
	while(ch>'9'||ch<'0')	ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return x;
}
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	n=read(),m=read();
	for(register int i=1;i<=n;++i)
	{
		int x=read();
		++s[x];
		if(s[x]>=3)	b=1;
	}
	if(b==0)
	{
		tx();
		return 0;
	}
	for(register int i=1;i<=m;++i)
	{
		if(s[i]>0&&s[i-1]==0)	a[++s1].s=i;
		if(s[i]>0&&s[i+1]==0)	a[s1].t=i;
	}
	for(register int i=1;i<=m;++i)	f[i]=-1e9;
	for(register int i=1;i<=s1;++i)
	{
		l=a[i].s,r=a[i].t;
		dfs(a[i].s,0);
		ans+=f[r];
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
