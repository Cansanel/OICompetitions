#include<iostream>
#include<cstdio>
using namespace std;

int n,m,k,ans=0;
int a[301];
int s[27];
int max1(int x,int y)
{
	if(x>y)	return x;
	return y;
}
bool check(int f,int r)
{
	int jsgs=0;
	for(register int i=1;i<=26;++i)	s[i]=0;
	for(register int i=f;i<=r;++i)	++s[a[i]];
	for(register int i=1;i<=26;++i)
		if(s[i]%2==1)	++jsgs;
	if(jsgs>1)	return 0;
	return 1;
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>m;
	char ch;
	if(n==1)	for(register int i=1;i<=m;++i)
	{
		cin>>ch;
		a[i]=ch-'a'+1;
	}
	if(m==1)	for(register int i=1;i<=n;++i)
	{
		cin>>ch;
		a[i]=ch-'a'+1;
	}
	k=max1(n,m);
	ans=k;
	for(register int i=1;i<k;++i)	if(a[i]==a[i+1])	++ans;
	for(register int i=1;i<=k-2;++i)
		for(register int j=1;i+j<=k;++j)
		{
			int k=i+j;
			if(check(i,k)==1)	++ans;
		}
	cout<<ans<<endl; 
	fclose(stdin);
	fclose(stdout);
	return 0;
}
//ȥ����մ����У������һ���ӳ�졣���治֪�δ�ȥ���һ�����Ц����
