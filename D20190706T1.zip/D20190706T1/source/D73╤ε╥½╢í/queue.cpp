#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;

struct px
{
	int a,b,c;
}s[500010];
int n;
long long ans=0;
bool cmp(px x,px y)
{
	return x.c<y.c;
}
int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch>'9'||ch<'0')
	{
		if(ch=='-')	f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;++i)
	{
		s[i].a=read();
		s[i].b=read();
		s[i].c=s[i].b-s[i].a;
	}
	sort(s+1,s+1+n,cmp);
	for(register int i=1;i<=n;++i)	ans+=s[i].a*(i-1)+s[i].b*(n-i);
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
