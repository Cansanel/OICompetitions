#include <bits/stdc++.h>
using namespace std;
inline long long read(){
	long long zf=1,num=0;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-')zf=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		num=num*10+c-48;
		c=getchar();
	}
	return zf*num;
}
long long n;
long long ans;
struct node{
	long long a,b,c;
}num[500005];
inline bool cmp(node x,node y){
	return x.c>y.c;
}
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;i++){
		num[i].a=read();
		num[i].b=read();
		num[i].c=num[i].a-num[i].b;
	}
	sort(num+1,num+n+1,cmp);
	for(register int i=1;i<=n;i++){
		ans+=(i-1)*num[i].c;
		ans+=(n-1)*num[i].b;
	}
	printf("%lld\n",ans);
	return 0;
}
