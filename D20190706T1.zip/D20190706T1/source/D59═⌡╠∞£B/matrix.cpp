#include <bits/stdc++.h>
using namespace std;
int n,m;
string a[255];
int num[30][255][255];
int ans;
inline bool check(int i,int j,int k,int l){
	if(k-i==1&&l-j==1){
		for(int c='a';c<='z';c++)
		if((num[c-'a'+1][k][l]-num[c-'a'+1][i-1][l]-num[c-'a'+1][k][j-1]+num[c-'a'+1][i-1][j-1])==4)
		return 1;
		return 0;
	}
	int mistake=0;
	if((k-i)%2==0&&(l-j)%2==0)
		mistake=-1;
	for(int c='a';c<='z';c++)
	if((num[c-'a'+1][k][l]-num[c-'a'+1][i-1][l]-num[c-'a'+1][k][j-1]+num[c-'a'+1][i-1][j-1])%2!=0)
	{
		mistake++;
		if(mistake>0)return 0;
	}
	return 1;
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		for(int j=m;j>=1;j--)
			a[i][j]=a[i][j-1];
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			for(int k='a';k<='z';k++)
			{
				num[k-'a'+1][i][j]=num[k-'a'+1][i-1][j]+num[k-'a'+1][i][j-1]-num[k-'a'+1][i-1][j-1];
				if(k==a[i][j])num[k-'a'+1][i][j]++;
			}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			for(int k=i;k<=n;k++)
				for(int l=j;l<=m;l++)
					if(check(i,j,k,l)==1)
					{
						ans++;
					}
	cout<<ans<<endl;
	return 0;
}
