#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int zf=1,num=0;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-')zf=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		num=num*10+c-48;
		c=getchar();
	}
	return zf*num;
}
int n,m;
int ans;
int a[100005];
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	sort(a+1,a+n+1);
	int l=1;
	while(l+2<=n)
	{
		if(a[l+1]-a[l]<=1&&a[l+2]-a[l+1]<=1)
		{
			ans++;
			l+=2;
		}
		l++;
	}
	printf("%d\n",ans);
	return 0;
}
