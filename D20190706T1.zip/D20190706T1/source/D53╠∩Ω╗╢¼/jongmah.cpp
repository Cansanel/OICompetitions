#include <bits/stdc++.h>
using namespace std;
#define max(a, b) (a < b ? b : a)
int N, M;
int f[100010][3][3];
int r[100010];
int main() {
	freopen("jongmah.in", "r", stdin);
	freopen("jongmah.out", "w", stdout);
	scanf("%d%d", &N, &M);
	for (register int i = 1; i <= N; ++i) {
		int p;
		scanf("%d", &p);
		r[p]++; // rp++!
	}
	memset(f, 0xcf, sizeof(f));
	f[0][0][0] = 0;
	for (register int i = 1; i <= M + 2; i++) {
		for (register int a = 0; a <= 2; ++a) {
			for (register int b = 0; b <= 2; ++b) {
				for (register int c = 0; c <= 2; ++c) {
					if (r[i] >= a + b + c && r[i + 1] >= b + c && r [i + 2] >= c) {
						f[i][b][c] = max(f[i][b][c], f[i - 1][a][b] + a + (r[i] - a - b - c) / 3);
					}
				}
			}
		}
	}
	printf("%d", f[M + 2][0][0]);
	return 0;
}
/*

10 6
2 3 3 3 4 4 4 5 5 6

13 5
1 1 5 1 2 3 3 2 4 2 3 4 5

*/
