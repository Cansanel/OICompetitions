#include <bits/stdc++.h>
using namespace std;

int N, M;
char a[255][255];

int s[200];

inline bool check(int len) {
	int cnt = 0;
	for (register int i = 'a'; i <= 'z'; ++i)
		if (s[i] & 1) cnt++;
	if (len & 1) {
		if (cnt == 1) return 1;
		return 0;
	}
	else {
		if (cnt == 0) return 1;
		return 0;
	}
}

inline bool Circ(int x, int y) {
	while (x < y) {
		if (a[x][1] != a[y][1]) return false;
		x++, y--;
	}
	return true;
}

int main() {
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	scanf("%d%d", &N, &M);
	for (register int i = 1; i <= N; ++i) 
		for (register int j = 1; j <= M; ++j)
			cin >> a[i][j];
	int ans = 0;
	if (N == 1) {
		for (register int i = 1; i <= M; ++i) {
			memset(s, 0, sizeof(s));
			for (register int j = i; j <= M; ++j) {
				s[a[1][j]]++;
				if (check(j - i + 1)) ans++;
			}
			
		}
		printf("%d", ans);
	}
	if (M == 1) {
		for (register int i = 1; i <= N; ++i) {
			for (register int j = i; j <= N; ++j) {
				if (Circ(i, j)) ans++;
			}
		}
		printf("%d", ans);
	}

	
	return 0;
}
