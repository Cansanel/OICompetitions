#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct person {
	int a, b, id;
}a[500005];
int N;
inline bool cmp(person x, person y) {
	return y.a - x.a + x.b - y.b < 0;
}
int main() {
	freopen("queue.in", "r", stdin);
	freopen("queue.out", "w", stdout);
	scanf("%d", &N);
	for (register int i = 1; i <= N; ++i)
		scanf("%d%d", &a[i].a, &a[i].b), a[i].id = i;
	sort(a + 1, a + 1 + N, cmp);
	ll ans = 0;
	for (register int i = 1; i <= N; ++i)
		ans += a[i].a * (i - 1), ans += a[N - i + 1].b * (i - 1);
	cout << ans;
	return 0;
}
/*
3
4 2
2 3
6 1

10
5 10
12 4
31 45
20 55
30 17
29 30
41 32
7 1
5 5
3 15

*/
