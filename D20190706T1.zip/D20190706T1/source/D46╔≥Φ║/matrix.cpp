#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,a[1001][1001],ha[10001],sum,ans;
string st;
signed main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>m;
	if (m==1) {
		cout<<n*(n+1)/2<<endl;
		return 0;
	}
	for (int i=1;i<=n;i++){
		cin>>st;
		for (int j=0;j<m;j++) a[i][j+1]=st[j]-'a';
	}
	if (n==1){
		int ans=0;
		for (int i=1;i<=m;i++)
		for (int j=i;j<=m;j++) {
			memset(ha,0,sizeof(ha));
			for (int k=i;k<=j;k++) ha[a[1][k]]++;
			sum=0;
			for (int k=0;k<=25;k++) if (ha[k]%2==1) sum++;
			if (sum<=1) ans++; 
		}
		cout<<ans<<endl;
		return 0;
	}
	for (int i=1;i<=n;i++)
	for (int j=i;j<=n;j++)
	for (int k=1;k<=m;k++)
	for (int l=k;l<=m;l++) {
	memset(ha,0,sizeof(ha));
	for (int x=i;x<=j;x++) 
	for (int y=k;y<=l;y++)ha[a[x][y]]++;
	sum=0;
	for (int k=0;k<=25;k++) if (ha[k]%2==1) sum++;
	if (sum<=1) ans++; 
	}
	cout<<ans<<endl;
	return 0;
}
