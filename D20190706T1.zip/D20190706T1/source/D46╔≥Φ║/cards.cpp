#include<bits/stdc++.h>
using namespace std;
int read(){
	int f=1,r=0;
	char ch=getchar();
	while (!isdigit(ch)&&ch!='-') ch=getchar();
	if (ch=='-') f=-1,ch=getchar();
	while (isdigit(ch)) r=r*10+ch-'0',ch=getchar();
	return r*f;
}
int gcd(int x,int y){
	if (x==0) return y;
	if (y==0) return x;
	return gcd(y,x%y);
}
double ans;
int n,a[10001],x[10001],sss;
void hs(int x){
	long long s=1;
	for (int i=1;i<=x;i++) s*=i;
	ans+=1.0/s;
}
void dg(int dep,int now){
	sss=dep;
	if (dep>n){
		if (n%2==1) hs(n);
	} 
	for (int i=1;i<=n;i++) {if (a[i]==-1) continue;if (gcd(now,a[i])==1&&dep%2==0) hs(dep);x[i]=a[i];a[i]=-1;dg(dep+1,gcd(now,a[i]));a[i]=x[i];}
	return ;
}
int main(){
	freopen("cards.in","r",stdin);
	freopen("cards.out","w",stdout);
	cin>>n;
	for (int i=1;i<=n;i++) cin>>a[i];
	if (n<=10) dg(1,0),cout<<fixed<<setprecision(8)<<ans<<' ';
	else cout<<0<<' ';
	cout<<1<<endl;
	return 0;
}

