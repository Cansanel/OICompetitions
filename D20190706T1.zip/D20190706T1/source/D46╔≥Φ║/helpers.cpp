#pragma GCC optimmize(2)
#include<bits/stdc++.h>
#define int long long
using namespace std;
int read(){
	int f=1,r=0;
	char ch=getchar();
	while (!isdigit(ch)&&ch!='-') ch=getchar();
	if (ch=='-') f=-1,ch=getchar();
	while (isdigit(ch)) r=r*10+ch-'0',ch=getchar();
	return r*f;
}
const int m=998244353;
int ksm(int n,int k){
	n%=m;
	int ans=1;
	while (k){
		if (k%2) ans=ans*n%m;
		n=n*n%m;
		k/=2;
	}
	return ans%m;
}
int n,s,a[10000005],sum;
signed main(){
	freopen("helpers.in","r",stdin);
	freopen("helpers.out","w",stdout);
	cin>>n;
	for (int i=1;i<=n;i++) a[i]=read(),s+=(a[i]==1),sum+=a[i];
	if (s==n){
		int ans=ksm(n,m-2);
		for (int i=1;i<n;i++) printf("%lld ",ans);
		printf("%lld\n",ans);
		return 0;
	}
	if (n==1){
		puts("1");
		return 0;
	}
	if (n==2){
		printf("%lld %lld\n",ksm(a[1]+a[2],m-2)*a[1]%m,ksm(a[1]+a[2],m-2)*a[2]%m);
		return 0;
	}
	int ans1=ksm(s,m-2);
	for (int i=1;i<n;i++) printf("%lld ",ans1*a[i]%m);
	printf("%lld\n",ans1*a[n]%m); 
	return 0;
}

