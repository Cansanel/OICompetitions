#include <bits/stdc++.h>
#define p int(1e9 + 7)
#define RG register
#define ll long long
using namespace std;
template <typename T> inline void read(T &n){
	T f = 1; char c; n = 0;
	for (c = getchar(); !isdigit(c); c = getchar()) if(c == '-') f = -1;
	for (; isdigit(c); c = getchar()) n = (n << 1) + (n << 3) + (c ^ 48);
	n *= f;
}
template <typename T> inline void write(T n){
	if (n < 0) {
		putchar('-');
		n = -n;
	}
	if (n > 9) write(n / 10);
	putchar(n % 10 + '0');
}
template <typename T> inline void writesp(T n){
	write(n);
	putchar(' ');
}
template <typename T> inline void writeln(T n){
	write(n);
	putchar('\n');
}
inline void FO(string s){
	freopen((s + ".in").c_str(), "r", stdin);
	freopen((s + ".out").c_str(), "w", stdout);
}
inline ll C(int a, int b){
	ll ans = 1;
	for (int i = 1; i <= b; ++i){
		ans = ans * (a - i + 1) / i;
		ans %= p;
	}
	return ans;
}
inline ll qm(int a, int b){
	ll re = 1;
	while (b){
		if (b & 1){
			re *= a;
			re %= p;
		}
		a = a * a % p; b >>= 1;
	}
	return re;
}
int main(){
	FO("photo");
	int n, m, k;
	ll ans = 0;
	ll f[2010];
	read(n), read(m), read(k);
	f[1] = 1;
	if (n == 1){
		cout << qm(k, m) << endl;
		return 0;
	}
	for (RG int i = 2; i <= n; ++i){
		f[i] = qm(i, n);
		for (RG int j = 1; j < i; ++j){
			f[i] -= j * C(i, j) % p;
			f[i] %= p;
		}
		if (f[i] < p) f[i] = (p + f[i]) % p;
	}
	for (int i = 1; i <= min(n, k); ++i)
		for (int j = i; 2 * i - j <= k && j >= (m == 2 ? 0 : 1); --j){
			int cs = 2 * i - j;
			ans += C(cs, i) * C(k, cs) % p * f[i] * f[i] % p * qm(j, (m - 2) * n) % p;
		} 
	cout << ans << endl;
	return 0;
}
/* 2 2 2 */
