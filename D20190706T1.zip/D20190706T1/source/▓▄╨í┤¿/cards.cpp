#include <bits/stdc++.h>
#define RG register
#define ll long long
using namespace std;
template <typename T> inline void read(T &n){
	T f = 1; char c; n = 0;
	for (c = getchar(); !isdigit(c); c = getchar()) if(c == '-') f = -1;
	for (; isdigit(c); c = getchar()) n = (n << 1) + (n << 3) + (c ^ 48);
	n *= f;
}
template <typename T> inline void write(T n){
	if (n < 0) {
		putchar('-');
		n = -n;
	}
	if (n > 9) write(n / 10);
	putchar(n % 10 + '0');
}
template <typename T> inline void writesp(T n){
	write(n);
	putchar(' ');
}
template <typename T> inline void writeln(T n){
	write(n);
	putchar('\n');
}
inline void FO(string s){
	freopen((s + ".in").c_str(), "r", stdin);
	freopen((s + ".out").c_str(), "w", stdout);
}
bool visited[310];
int failure, n, a[310];
ll tot;
inline int gcd(int x, int y){
	if (y == 0) return x;
	return gcd(y, x % y);
}
inline void dfs(int dep, int gc, string s){
	if (dep % 2 == 1 && gc == 1){
		++failure;
		++tot;
//	cout << s << endl;
		return ;
	}
	if (gc == 1 && dep % 2 == 0){
		++tot;
//	cout << s << endl;
		return ;
	}
	if (dep == n){
		++failure;
		++tot;
//	cout << s << endl;
		return ;
	}
	for (RG int i = 1; i <= n; ++i){
		if (!visited[i]){
			visited[i] = 1;
			dfs(dep + 1, gcd(gc, a[i]), s + char(i + 48));
			visited[i] = 0;
		}
	}
}
int main(){
	FO("cards");
	read(n);
	for (RG int i = 1; i <= n; i++) read(a[i]);
	if (n <= 12){
		dfs(0, 0, "");
		printf("%.9lf ", double(tot - failure) / double(tot));
	}
	memset(visited, 0, sizeof visited);
	int gy = 1;
	for (RG int i = 1; i <= n; i++){
		int ff = 0;
		for (RG int j = 1; j <= n; j++){
			if (i != j && gcd(a[i], a[j]) == 1){
				++ff;
			}
		}
		if (ff % 2 == 0){
			puts("1.000000000");
			return 0;
		}
	}
	puts("0.000000000");
	return 0;
}
