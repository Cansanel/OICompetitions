#include <bits/stdc++.h>
#define ll long long
#define RG register
#define U(x, y, z) for(RG int x = y; x <= z; ++x)
#define D(x, y, z) for(RG int x = y; x >= z; --x)
using namespace std;
template <typename T> inline void read(T &n){
	T f = 1; char c; n = 0;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) n = (n << 1) + (n << 3) + (c ^ 48);
	n *= f;
}
template <typename T> inline void write(T n){
	if (n < 0){
		putchar('-');
		n = -n;
	}
	if (n > 9) write(n / 10);
	putchar(n % 10 + '0');
}
template <typename T> inline void writesp(T n){
	write(n);
	putchar(' ');
}
template <typename T> inline void writeln(T n){
	write(n);
	putchar('\n');
}
template <typename T> inline void chkmin(T &x, T y){
	x = x < y ? x : y;
}
template <typename T> inline void chkmax(T &x, T y){
	x = x > y ? x : y;
}
inline void FO(string s){
	freopen((s + ".in").c_str(), "r", stdin);
	freopen((s + ".out").c_str(), "w", stdout);
}
int n, m, ans, t[100010];
inline void dfs(int dep, int sum){
	if (dep > m){
		chkmax(ans, sum);
		return ;
	}
	if (t[dep] < 3 && t[dep + 1] < 3 && t[dep + 2] < 3 && t[dep] > 0 && t[dep + 1] > 0 && t[dep + 2] > 0){
		int add = min(t[dep], min(t[dep + 1], t[dep + 2]));
		t[dep] -= add, t[dep + 1] -= add, t[dep + 2] -= add;
		dfs(dep + 1, sum + add);
		t[dep] += add, t[dep + 1] += add, t[dep + 2] += add;
		return ;
	}
//	cout << dep << " " << sum << endl;
	for (int i = 0; i <= t[dep]; ++i){
		int add = min(i, min(t[dep + 1], t[dep + 2]));
		t[dep] -= add, t[dep + 1] -= add, t[dep + 2] -= add;
		dfs(dep + 1, sum + add + (t[dep] - i) / 3);
		t[dep] += add, t[dep + 1] += add, t[dep + 2] += add;
	}
}
int main(){
	FO("jongmah");
	read(n), read(m);
	U(i, 1, n){
		int x;
		read(x);
		++t[x];
	}
	dfs(1, 0);
	writeln(ans);
	return 0;
}
/*10  6
2  3  3  3  4  4  4  5  5  6*/

