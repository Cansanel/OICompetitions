#include <bits/stdc++.h>
#define ll long long
#define RG register
#define U(x, y, z) for(RG int x = y; x <= z; ++x)
#define D(x, y, z) for(RG int x = y; x >= z; --x)
using namespace std;
template <typename T> inline void read(T &n){
	T f = 1; char c; n = 0;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) n = (n << 1) + (n << 3) + (c ^ 48);
	n *= f;
}
template <typename T> inline void write(T n){
	if (n < 0){
		putchar('-');
		n = -n;
	}
	if (n > 9) write(n / 10);
	putchar(n % 10 + '0');
}
template <typename T> inline void writesp(T n){
	write(n);
	putchar(' ');
}
template <typename T> inline void writeln(T n){
	write(n);
	putchar('\n');
}
template <typename T> inline void chkmin(T &x, T y){
	x = x < y ? x : y;
}
template <typename T> inline void chkmax(T &x, T y){
	x = x > y ? x : y;
}
inline void FO(string s){
	freopen((s + ".in").c_str(), "r", stdin);
	freopen((s + ".out").c_str(), "w", stdout);
}
struct node{
	int a, b;
}a[500010];
inline bool cmp(node a, node b){
	return a.b + b.a < a.a + b.b;
}
int main(){
	FO("queue");
	int n;
	read(n);
	U(i, 1, n){
		read(a[i].a), read(a[i].b);
	}
	sort(a + 1, a + n + 1, cmp);
	ll ans = 0;
	U(i, 1, n) ans += a[i].a * (i - 1) + a[i].b * (n - i);
	writeln(ans);	
	return 0;
}
