#include <bits/stdc++.h>
#define ll long long
#define RG register
#define U(x, y, z) for(RG int x = y; x <= z; ++x)
#define D(x, y, z) for(RG int x = y; x >= z; --x)
using namespace std;
template <typename T> inline void read(T &n){
	T f = 1; char c; n = 0;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) n = (n << 1) + (n << 3) + (c ^ 48);
	n *= f;
}
template <typename T> inline void write(T n){
	if (n < 0){
		putchar('-');
		n = -n;
	}
	if (n > 9) write(n / 10);
	putchar(n % 10 + '0');
}
template <typename T> inline void writesp(T n){
	write(n);
	putchar(' ');
}
template <typename T> inline void writeln(T n){
	write(n);
	putchar('\n');
}
template <typename T> inline void chkmin(T &x, T y){
	x = x < y ? x : y;
}
template <typename T> inline void chkmax(T &x, T y){
	x = x > y ? x : y;
}
inline void FO(string s){
	freopen((s + ".in").c_str(), "r", stdin);
	freopen((s + ".out").c_str(), "w", stdout);
}
int n, m, ans;
int mt[51][51];
bool g[51][51][51];
int main(){
	FO("matrix");
	read(n), read(m);
	U(i, 1, n){
		string s;
		cin >> s;
		U(j, 0, m - 1){
			mt[i][j + 1] = (s[j] ^ 48);
		}
		
	}
	U(i, 1, n)
		U(j, 1, m)
			U(k, j, m){
				set<int> S;
				int dba = 0;
				U(l, j, k){
					if (S.count(mt[i][l]))
						dba++;
					S.insert(mt[i][l]);
				}
				if (k - j + 1 - 2 * dba < 2) g[i][j][k] = 1;
			}
	U(i, 1, n)
		U(j, 1, m)
			U(k, j, m){
				if (g[i][j][k]) ++ans;
				else break;
			//	cout << " " << i << " " << j <<  " " << k << endl;
				U(l, i + 1, n){
					if (!g[l][j][k]) break;
					++ans;
			//		cout << l << " " << j << " " << k << endl;
				}
			}
	writeln(ans);
	return 0;
}
/*
2 3
aca
aac
*/
