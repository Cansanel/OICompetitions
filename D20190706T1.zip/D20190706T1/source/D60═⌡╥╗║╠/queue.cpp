#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <algorithm>
using namespace std;
struct queue{
	int l;
	int r;
};
bool cmp(queue a,queue b){
	return a.l>b.l;
}
queue Q[500001],N[500001],D[500001];
int F[500001];
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	int n,i,c=0,x,y,ans=0;
	cin>>n;
	memset(Q,0,sizeof(Q));
	memset(N,0,sizeof(N));
	memset(D,0,sizeof(D));
	memset(F,0,sizeof(F));
	for(i=0;i<n;i++){
		cin>>Q[i].l>>Q[i].r;
	}
	for(i=0;i<n;i++){
		D[i].l=Q[i].l-Q[i].r;
		D[i].r=i;
	}
	sort(D+0,D+n,cmp);
	/*for(i=0;c<n-1;i++){
		if(D[i][0]>D[i+1][0]){
			x=D[i][0];D[i][0]=D[i+1][0];D[i+1][0]=x;
			y=D[i][1];D[i][1]=D[i+1][1];D[i+1][1]=y;
		}
		if(i==n-2){
			i=0;c=0;
			for(int j=0;j<=n-2;j++){
				if(D[j][0]<=D[j+1][0]){
					c++;
				}
			}
			if(c==n-1) break;
		}
	}*/
	for(i=0;i<n;i++){
		N[i]=Q[D[i].r];
	}
	for(i=0;i<n;i++){
		ans+=(N[i].l*i+N[i].r*(n-i-1));
	}
	cout<<ans;
	return 0;
}
