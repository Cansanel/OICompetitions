#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <algorithm>
using namespace std;
bool cmp(int a,int b){
	return a>b;
}
int F[100001],G[100001];
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	int n,m,i,j,c=0,sum1=0,sum2=0,f1=0,f2=0,ans=0;
	cin>>n>>m;
	memset(F,0,sizeof(F));
	memset(G,0,sizeof(G));
	for(i=0;i<n;i++){
		cin>>F[i];
	}
	sort(F+0,F+n,cmp);
	for(i=0;i<n;i++){
		G[F[i]]++;
	}
	/*for(i=1;i<=m;i++){
		if(G[i]>=3) c++;
	}*/
	for(;;){
		for(i=2;i<=m-1;i++){
			c=0;
			if((G[i-1]>0)&&(G[i]>0)&&(G[i+1]>0)){
				G[i-1]--;G[i]--;G[i+1]--;
				c++;
			}
		}
		if(c==0) break;
	}
	for(;;){
		for(i=1;i<=m;i++){
			c=0;
			if(G[i]>3){
				G[i]-=3;
				c++;
			}
		}
		if(c==0) break;
	}
	for(i=1;i<m;i++){
		if((G[i]==2)&&(G[i+1]==2)) f1++;
	}
	for(i=1;i<=m;i++){
		sum1+=G[i];
	}
	memset(G,0,sizeof(G));
	for(i=0;i<n;i++){
		G[F[i]]++;
	}
	for(;;){
		for(i=1;i<=m;i++){
			c=0;
			if(G[i]>3){
				G[i]-=3;
				c++;
			}
		}
		if(c==0) break;
	}
	for(;;){
		for(i=2;i<=m-1;i++){
			c=0;
			if((G[i-1]>0)&&(G[i]>0)&&(G[i+1]>0)){
				G[i-1]--;G[i]--;G[i+1]--;
				c++;
			}
		}
		if(c==0) break;
	}
	for(i=1;i<=m;i++){
		sum2+=G[i];
	}
	ans=max((n-sum1)/3+f1,(n-sum2)/3+f2);
	cout<<ans;
	return 0;
}
