#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <algorithm>
using namespace std;
char F[250][250];
int C[26];
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n,m,i,c=0,c1=0,d,l,r,ans=0;
	cin>>n>>m;
	memset(F,0,sizeof(F));
	if(n==1){
		ans=ans+n*m;
		string A;
		cin>>A;
		for(i=0;i<m;i++){
			F[i][0]=A[i]-'a';
		}
		for(i=0;i<m-1;i++){
			if(F[i][0]==F[i+1][0]) ans++;
		}
		for(d=3;d<=m;d++){
			for(l=0,r=l+d-1;r<m;l++,r++){
				memset(C,0,sizeof(C));
				c1=0;
				for(i=l;i<=r;i++){
					C[F[i][0]]++;
				}
				for(i=0;i<26;i++){
					if(C[i]%2==1) c1++;
				}
				if((d%2==1&&c1==1)||(d%2==0&&c1==0)) ans++;
			}
		}
		cout<<ans;
		return 0;
	}
	if(m==1){
		ans=ans+n*m;
		for(i=0;i<n;i++){
			cin>>F[i][0];
			F[i][0]=F[i][0]-'a';
		}
		for(i=0;i<n-1;i++){
			if(F[i][0]==F[i+1][0]) ans++;
		}
		for(d=3;d<=n;d++){
			for(l=0,r=l+d-1;r<n;l++,r++){
				c1=0;
				for(i=l;i<=(r-(i-l));i++){
					if(F[i][0]!=F[r-(i-l)][0]) c1++;
				}
				if(c1==0) ans++;
			}
		}
		cout<<ans;
		return 0;
	}
	cout<<m*n;
	return 0;
}
