#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
using namespace std;
template<typename T> void read(T &num){
	char c=getchar();T f=1;num=0;
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){num=(num<<3)+(num<<1)+(c^48);c=getchar();}
	num*=f;
}
template<typename T> void qwq(T x){
	if(x>9)qwq(x/10);
	putchar(x%10+'0');
}
template<typename T> void write(T x){
	if(x<0){x=-x;putchar('-');}
	qwq(x);putchar('\n');
}
int co[260][260];int pre[27][260][260];int t[260][26];
bool h[260];
inline bool S(int t1,int t2){
	rep(i,1,26){if(t[t1][i]!=t[t2][i])return false;}
	return true;
}

int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);

	int n,m;read(n);read(m);
	rep(i,1,n){
		rep(j,1,m){
			char ch;cin>>ch;co[i][j]=ch-'a'+1;
			rep(k,1,26)pre[k][i][j]=pre[k][i][j-1];
			pre[co[i][j]][i][j]++;
		}
	}
	
	long long ans=0;
	rep(i,1,m){
		rep(j,i,m){
			memset(t,0,sizeof(t));memset(h,0,sizeof(h));
			rep(k,1,n){
				int cnt=0;
				rep(l,1,26){
					t[k][l]=pre[l][k][j]-pre[l][k][i-1];
					cnt+=(t[k][l]%2==1);
				}
				h[k]=(cnt<=1);
			}
			rep(k,1,n){
				if(!h[k])continue;
				int tmp=1;
				while(k-tmp>=1&&k+tmp<=n&&h[k-tmp]&&h[k+tmp]
				&&S(k-tmp,k+tmp))tmp++;
				ans+=tmp;
			}
			rep(k,1,n-1){
				int tmp=1;
				while(k-tmp+1>=1&&k+tmp<=n&&h[k-tmp+1]&&h[k+tmp]
				&&S(k-tmp+1,k+tmp))tmp++;
				ans+=tmp-1;
			}
		}
	}
	write(ans);
	return 0;
}
