#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
using namespace std;
template<typename T> void read(T &num){
	char c=getchar();T f=1;num=0;
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){num=(num<<3)+(num<<1)+(c^48);c=getchar();}
	num*=f;
}
template<typename T> void qwq(T x){
	if(x>9)qwq(x/10);
	putchar(x%10+'0');
}
template<typename T> void write(T x){
	if(x<0){x=-x;putchar('-');}
	qwq(x);putchar('\n');
}
struct wzy{
	int ai,bi;
}co[500010];
inline bool cmp(wzy a,wzy b){
	return a.ai-a.bi>b.ai-b.bi;
}

int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	
	int n;read(n);
	rep(i,1,n){read(co[i].ai);read(co[i].bi);}
	sort(co+1,co+n+1,cmp);
	
	long long ans=0;
	rep(i,1,n){ans+=1ll*co[i].ai*(i-1);ans+=1ll*co[i].bi*(n-i);}
	write(ans);
	return 0;
}
