#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
using namespace std;
template<typename T> void read(T &num){
	char c=getchar();T f=1;num=0;
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){num=(num<<3)+(num<<1)+(c^48);c=getchar();}
	num*=f;
}
template<typename T> void qwq(T x){
	if(x>9)qwq(x/10);
	putchar(x%10+'0');
}
template<typename T> void write(T x){
	if(x<0){x=-x;putchar('-');}
	qwq(x);putchar('\n');
}
template<typename T> void chkmax(T &x,T y){x=x>y?x:y;}
int co[100010];int t[100010][2];int dp[100010][7][7];

int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);

	int n,m;read(n);read(m);
	rep(i,1,n)read(co[i]);
	sort(co+1,co+n+1);
	int len=0;
	rep(i,1,n){
		if(co[i]==t[len][0]){t[len][1]++;}
		else{t[++len][0]=co[i];t[len][1]=1;}
	}
	
	int ans=0;
	rep(i,1,len){
		if(t[i][1]<=3)continue;
		if(t[i][1]%3==0){ans+=(t[i][1]-6)/3;t[i][1]=6;}
		else{ans+=(t[i][1]-3)/3;t[i][1]-=(t[i][1]-3)/3*3;}
	}
	rep(i,1,len){
		rep(j,0,6){
			rep(k,0,6)chkmax(dp[i][0][j],dp[i-1][j][k]);
		}
		if(t[i][1]>=3){
			rep(j,0,6){
				rep(k,0,6)chkmax(dp[i][3][j],dp[i-1][j][k]+1);
			}
		}
		if(t[i][1]>=6){
			rep(j,0,6){
				rep(k,0,6)chkmax(dp[i][6][j],dp[i-1][j][k]+2);
			}
		}	
		if(t[i-2][0]+1!=t[i-1][0]||t[i-1][0]+1!=t[i][0])continue;
		rep(l,1,6){
			if(t[i][1]<l)break;
			rep(j,0,t[i-1][1]-l){
				rep(k,0,t[i-2][1]-l)chkmax(dp[i][l][j+l],dp[i-1][j][k]+l);
			}
		}
	}
	int mx=0;
	rep(i,0,6){
		rep(j,0,6)chkmax(mx,dp[len][i][j]);
	}
	write(ans+mx);
	return 0;
}
