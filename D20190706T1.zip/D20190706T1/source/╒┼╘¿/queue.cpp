#include<bits/stdc++.h>
using namespace std;

int a[500500], b[500500];

int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	int n, s = 0;
	cin >> n;
	for (int i = 1; i <= n; ++ i)
		cin >> a[i] >> b[i];
	sort(b + 1, b + n + 1);
	for (int i = 1; i < n; ++ i)
		s += b[i] * (n - i);
	cout << s << endl;
	return 0;
}

