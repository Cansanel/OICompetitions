#include<bits/stdc++.h>
using namespace std;

int a[100500], b[100500];

int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	int n, m;
	cin >> n >> m;
	for (int i = 1; i <= n; ++ i)
	{
		cin >> a[i];
		b[a[i]] ++;
	}
	int s = 0, x;
	for (int i = 1; i <= m; ++ i)
	{
//		cout << b[i] << endl;
		if (b[i] > 0 && b[i + 1] > 0 && b[i + 2] > 0)
		{
			x = min(min(b[i], b[i + 1]), b[i + 2]);
			s += x;
			b[i] -= x;
			b[i + 1] -= x;
			b[i + 2] -= x;
		}
		if (b[i] >= 3)
		{
			s += b[i] / 3;
			b[i] %= 3;
		}
//		cout << s << endl;
	}
	cout << s << endl;
	return 0;
}

