#include<bits/stdc++.h>
using namespace std;

char a[300][300];

int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n, m;
	cin >> n >> m;
	for (int i = 1; i <= n; ++ i)
		for (int j = 1; j <= m; ++ j)
			cin >> a[i][j];
	int s = 0;
	for (int i = 1; i <= n; ++ i)
	{
		int x = 1;
		while(a[i][1] == a[i + x][1])
		{
			s ++;
			x ++;
		}
	}
	cout << s + n << endl;
	return 0;
}

