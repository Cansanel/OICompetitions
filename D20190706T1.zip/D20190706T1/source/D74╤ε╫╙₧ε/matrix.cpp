#include<bits/stdc++.h>
using namespace std;
int b[27][251];
int a[251];
inline void read(int &X)
{
    X=0;int w=0; char ch=0;
    while(!isdigit(ch)) {w|=ch=='-';ch=getchar();}
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    X=w?-X:X;
}
inline void writen(int x)
{
     if(x<0) putchar('-'),x=-x;
     if(x>9) writen(x/10);
     putchar(x%10+'0');
}
inline void write(int x)
{
   writen(x);
   putchar(' ');
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n,m,sum=0;
	read(n);
	read(m);
	char c;
	if(n==1){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			c=getchar();
			b[c-'a'+1][i]=1;
		}
		getchar();
	}
	int f=1,flag=1,ans=0;

	for(int i=1;i<=n;i++){
		f=1;
		ans=0;
	while(f<=m){
		if(f%2==0)flag=0;
		for(int j=1;j<=26;i++){
			if(b[j][i]%2==1&&flag==1){
				if(ans+b[j][i]>=f){
					sum+=m-f+1;break;
					
				}
				else ans+=b[j][i];
			}
			if(b[j][i]%2==0){
				if(ans+b[j][i]>=f){
					sum+=m-f+1;break;
					
				}else ans+=b[j][i];
			}
			if(b[j][i]%2==0){
				if(ans+b[j][i]>f){
					sum+=m-f+1;break;
					
				}else ans=ans+b[j][i]-1;
			}
		}
		f++;cout<<sum;
		return 0;
	}
}
}
	if(m==1){
		for(int i=1;i<=n;i++){a[i]=getchar();getchar();}
		for(int i=1;i<=n;i++){
			sum++;
			for(int j=1;j<=n;j++){
				if(a[i-j]==a[i+j]&&i>j)sum++;
			}
		}
		cout<<sum;
		return 0;
	}
	cout<<11743243;

	return 0;
}

