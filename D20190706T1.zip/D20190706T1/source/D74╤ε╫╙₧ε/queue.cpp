#include<bits/stdc++.h>
using namespace std;
int a[500001];
int b[500001];
struct mem{
	int bh;
	int val;
}c[500001];
inline void read(int &X)
{
    X=0;int w=0; char ch=0;
    while(!isdigit(ch)) {w|=ch=='-';ch=getchar();}
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    X=w?-X:X;
}
bool cmp(mem x,mem y){
	return x.val>y.val;
}
inline void writen(int x)
{
     if(x<0) putchar('-'),x=-x;
     if(x>9) writen(x/10);
     putchar(x%10+'0');
}
inline void write(int x)
{
   writen(x);
   putchar(' ');
}
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	int n;
	long long ans=0;
	cin>>n;
	for(int i=1;i<=n;i++){
		read(a[i]);
		read(b[i]);
		c[i].bh=i;
		c[i].val=a[i]-b[i];
	}
	sort(c+1,c+n+1,cmp);
	for(int i=1;i<=n;i++){
		ans=ans+a[c[i].bh]*(i-1);
		ans=ans+b[c[i].bh]*(n-i);
	}
	cout<<ans;
	return 0;
}

