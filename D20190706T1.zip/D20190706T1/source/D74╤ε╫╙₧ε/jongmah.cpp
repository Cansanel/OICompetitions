#include<bits/stdc++.h>
using namespace std;
int cs[100001];
int f[100001][7][7];
int maxf[100001][7];
inline void read(int &X)
{
    X=0;int w=0; char ch=0;
    while(!isdigit(ch)) {w|=ch=='-';ch=getchar();}
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    X=w?-X:X;
}
inline void writen(int x)
{
     if(x<0) putchar('-'),x=-x;
     if(x>9) writen(x/10);
     putchar(x%10+'0');
}
inline void write(int x)
{
   writen(x);
   putchar(' ');
}
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	
	int n,m;
	read(n);
	read(m);
	int x;
	int ans=0;
	for(int i=1;i<=n;i++){
		read(x);
		cs[x]++;
	}
	for(int i=1;i<=m;i++){
		if(cs[i]>4){
			ans+=(cs[i]-4)/3;
			cs[i]=(cs[i]-4)%3+4;
	}
	}
	for(int i=1;i<=m;i++){
		if(i<3){
			for(int j=0;j<=cs[i];j++){
				for(int k=0;k<=cs[i-1];k++){
					
						f[i][j][k]=max(f[i][j][k],f[i-1][k][0]+(cs[i]-j)/3);
						if(maxf[i][0]<=f[i][j][k]){
							maxf[i][0]=f[i][j][k];
							maxf[i][1]=j;
							maxf[i][2]=k;
					}
				}
			}
		}else{
			for(int j=0;j<=cs[i];j++){
				for(int k=0;k<=cs[i-1];k++){
						f[i][j][k]=max(f[i][j][k],f[i-1][k][0]+(cs[i]-j)/3);
						if(maxf[i][0]<=f[i][j][k]){
									maxf[i][0]=f[i][j][k];
									maxf[i][1]=j;
									maxf[i][2]=k;
					}
						for(int l=0;l<=cs[i-2];l++)
						for(int jcs=0;jcs+k<=cs[i-1]&&jcs+j<=cs[i]&&l+jcs<=cs[i-2];jcs++){
							f[i][j][k]=max(f[i][j][k],f[i-1][k+jcs][l+jcs]+jcs);
								if(maxf[i][0]<=f[i][j][k]){
									maxf[i][0]=f[i][j][k];
									maxf[i][1]=j;
									maxf[i][2]=k;
					}
					}
				}
				}
			}
	}
	

	cout<<ans+maxf[m][0];
	return 0;
}

