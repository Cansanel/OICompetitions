#include <bits/stdc++.h>
using namespace std;
#define maxn 100005
#define maxm 100005
int n,m,ans,h[maxn];
template <typename Tp>
void read(Tp &x){x=0;int f=1;char c=getchar();
	while((c>'9'||c<'0')){if(c=='-'){f=-1;}c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+(c&15);c=getchar();}x*=f;
}
double st;
void dfs(int x,int sum){
	if((clock()-st)/CLOCKS_PER_SEC>=0.9)return;
	if(x==m+1){
		ans=max(ans,sum);
		return ;
	}
	if(h[x]){
		int rnd=rand()&1;
		if(rnd){
			if(h[x]>=3){
				h[x]-=3;
				dfs(x,sum+1);
				h[x]+=3;
			}
			if(h[x+1]&&h[x+2]){
				h[x]--;h[x+1]--;h[x+2]--;
				dfs(x,sum+1);
				h[x]++;h[x+1]++;h[x+2]++;
			}
		}
		else{
			if(h[x+1]&&h[x+2]){
				h[x]--;h[x+1]--;h[x+2]--;
				dfs(x,sum+1);
				h[x]++;h[x+1]++;h[x+2]++;
			}
			if(h[x]>=3){
				h[x]-=3;
				dfs(x,sum+1);
				h[x]+=3;
			}
		}
	}
	dfs(x+1,sum);
}
int main(){
	srand(time(0));
	st=clock();
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	int x;
	read(n);read(m);
	for(int i=1;i<=n;i++){
		read(x);h[x]++;
	}
	dfs(1,0);
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
