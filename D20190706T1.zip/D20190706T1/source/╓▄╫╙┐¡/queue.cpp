#include <bits/stdc++.h>
using namespace std;
#define maxn 500005
#define maxm 1000005
#define inf 0x3f3f3f3f
#define linf 0x3f3f3f3f3f3f3f3fll
#define LL long long
struct node{
	LL a,b;
	bool operator <(node c)const{
		LL tmp1=a-b,tmp2=c.a-c.b;
		return tmp1>tmp2;
	}
}p[maxn];
int n,m;
template <typename Tp>
void read(Tp &x){x=0;int f=1;char c=getchar();
	while((c>'9'||c<'0')){if(c=='-'){f=-1;}c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+(c&15);c=getchar();}x*=f;
}
LL ans;
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++){
		read(p[i].a);read(p[i].b);
	}
	sort(p+1,p+n+1);
	for(int i=1;i<=n;i++){
		ans+=(LL)(i-1)*p[i].a+(LL)(n-i)*p[i].b;
	}
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

