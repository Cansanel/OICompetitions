#include <bits/stdc++.h>
using namespace std;
#define maxn 255
#define maxm 255
#define LL long long
int n,m,mimi=200,mamx;
template <typename Tp>
void read(Tp &x){x=0;int f=1;char c=getchar();
	while((c>'9'||c<'0')){if(c=='-'){f=-1;}c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+(c&15);c=getchar();}x*=f;
}
int a[maxn][maxm];
//int s[maxn][maxm];
int st[maxn][maxn][30];
LL ans;
int check(int ii,int jj,int kk,int ll){
	int cha[maxn][30];
	for(int i=ii;i<=kk;i++){
		int fl=0;
		for(int j=mimi;j<=mamx;j++){
			cha[i][j]=st[i][ll][j]-st[i][jj-1][j];
			fl+=(cha[i][j]&1);
		}
		if(fl>1)return 0;
	}
	int mid=(kk-ii)>>1;
	for(int i=0;i<=mid;i++){
		int fl=0;
		for(int j=mimi;j<=mamx;j++){
			if(cha[i+ii][j]!=cha[kk-i][j]){
				fl=1;
				break;
			}
		}
		if(fl)return 0;
	}
	return 1;
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("\n");
		for(int j=1;j<=m;j++){
			char c;
			scanf("%c",&c);
			a[i][j]=c-'a'+1;
			mimi=min(mimi,a[i][j]);
			mamx=max(mamx,a[i][j]);
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			mimi=min(mimi,a[i][j]);
			for(int l=mimi;l<=mamx;l++)st[i][j][l]=st[i][j-1][l];
			st[i][j][a[i][j]]++;
//			s[i][j]=s[i-1][j]^s[i][j-1]^s[i-1][j-1]^(1<<(a[i][j]-1));
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			for(int k=i;k<=n;k++){
				for(int l=j;l<=m;l++){
					ans+=check(i,j,k,l);
				}
			}
		}
	}
	printf("%lld\n",ans);
	fclose(stdout);
	fclose(stdout);
	return 0;
}
