#include <bits/stdc++.h>
#define maxN 500005

using namespace std;

struct node {
	int a,b;
}q[maxN];

bool operator <(const node &x,const node &y){
	return x.a-x.b+y.b-y.a>0;
}

int read (){
	int ret = 0; char c =getchar();
	while (c>'9'||c<'0')c=getchar();
	while (c<='9'&&c>='0')ret=ret*10+c-'0',c=getchar();
	return ret;
}

int n,ans;

int main (){
	freopen ("queue.in","r",stdin);
	freopen ("queue.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++){
		q[i].a=read(),q[i].b=read();
	}
	sort (q+1,q+n+1);
	for (int i=1;i<=n;i++){
		ans+=q[i].a*(i-1)+q[i].b*(n-i);
	}
	cout<<ans;
	return 0;
}
