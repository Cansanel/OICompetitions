#include <bits/stdc++.h>
#define maxN 255

using namespace std;

typedef long long ll;

int read (){
	int ret = 0; char c =getchar();
	while (c>'9'||c<'0')c=getchar();
	while (c<='9'&&c>='0')ret=ret*10+c-'0',c=getchar();
	return ret;
}

char readchar (){
	char c =getchar();
	while (c>'z'||c<'a')c=getchar();
	return c;
}

int n,m,num[maxN][maxN][27];
ll g[maxN][maxN],ans;
bool tmp[maxN];

bool check(int top,int bot,int l,int r){
	int t1=top,t2=bot;
//	bool flag=1;
	while (t1<t2){
		for (int i=0;i<26;i++){
			if (num[t1][r][i]-num[t1][l-1][i]!=num[t2][r][i]-num[t2][l-1][i]){
				return 0;
			}
		}
		t1++,t2--;
	}
	return 1;
}

ll cnt(int a,int b){
	ll l=1,r=1,len=0,ret=0;
	while (r<=n+1){
		if (tmp[r]==0){
			for (int i=l;i<=r-1;i++){
				for (int j=i;j<=r-1;j++){
					if (check(i,j,a,b))ret++;
				}
			}
			l=++r;
			len=0;
		}
		else{
			++len;
			++r;
		}
		
	}
	return ret;
}

int main (){
	freopen ("matrix.in","r",stdin);
	freopen ("matrix.out","w",stdout);
	n=read();
	m=read();
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			char c;
			
			c=readchar();
			for (int k=0;k<26;k++){
				num[i][j][k]=num[i][j-1][k];
			}
			num[i][j][c-'a']++;
			g[i][j]=g[i][j-1]^(1<<(c-'a'));
		}
	}
//	cout<<'!'<<check(1,2,1,1)<<endl;
	for (int l=1;l<=m;l++){
		for (int r=l;r<=m;r++){
			for (int k=1;k<=n;k++){
				ll x=g[k][r]^g[k][l-1];
				if (x==0||x-(x&-x)==0)tmp[k]=1;
				else tmp[k]=0;
			}
//			cout<<l<<' '<<r<<':'<<cnt(l,r)<<endl;
			ans+=cnt(l,r);
		}
	}
	cout<<ans;
	return 0;
}
