#include <bits/stdc++.h>
#define maxN 500005

using namespace std;

int read (){
	int ret = 0; char c =getchar();
	while (c>'9'||c<'0')c=getchar();
	while (c<='9'&&c>='0')ret=ret*10+c-'0',c=getchar();
	return ret;
}

int n,m,cnt[maxN],a[maxN],maxh,ans,tans;

void cnt1 (){
	for (int i=1;i<=m;i++){
		while (cnt[i]>0&&cnt[i+1]>0&&cnt[i+2]>0){
			cnt[i]--,cnt[i+1]--,cnt[i+2]--;
			ans++;
		}
	}
}

void sol1 (){
	cnt1();
	for (int i=1;i<=m;i++){
		if (cnt[i]>=3){
			ans+=cnt[i]/3;
			cnt[i]%=3;
		}
		
	}
}

void cnt2 (){
	for (int i=m;i>=2;i--){
		while (a[i]>0&&a[i-1]>0&&a[i-2]>0){
			a[i]--,a[i-1]--,a[i-2]--;
			tans++;
		}
	}
//	cout<<tans;
}

void sol2 (){
//	int tans=0;
	cnt2();
	for (int i=1;i<=m;i++){
		if (a[i]>=3){
			tans+=a[i]/3;
			a[i]%=3;
		}
		
	}
	ans=max(ans,tans);
}

int main (){
	freopen ("jongmah.in","r",stdin);
	freopen ("jongmah.out","w",stdout);
	n=read();
	m=read();
	for (int i=1;i<=n;i++){
		int x=read();
		cnt[x]++;
		maxh=max(maxh,cnt[x]); 
	}
	for (int i=1;i<=m;i++){
		a[i]=cnt[i];
	}
	if (maxh<3){
		cnt1();
		cout<<ans;
		return 0;
	}
	sol1();
//	cout<<ans<<endl;
	sol2();
	cout<<ans;
	return 0;
}
