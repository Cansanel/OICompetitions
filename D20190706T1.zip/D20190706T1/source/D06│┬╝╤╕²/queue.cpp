#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll maxn = 5e5 + 5;
const ll mod = 1e9 + 7;
struct node
{
	ll x,y,det;
};
node a[maxn];
ll n,sum,res;
bool cmp(node x,node y)
{
	return x.det < y.det;
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	cin>>n;
	for(int i = 1;i <= n;i++)
	{
		cin>>a[i].x>>a[i].y;
		a[i].det = a[i].y - a[i].x;
	}
	sort(a + 1,a + n + 1,cmp);
	for(int i = 1;i <= n;i++)
	{
		sum += a[i].x * (i - 1) + a[i].y * (n - i);
	}	
	res = sum;
	cout<<res;
	return 0;
}
/*
10
5 10
12  4
31  45
20  55
30  17
29  30
41  32
7 1
5 5
3 15
*/
