#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll maxn = 5e5 + 5;
ll n,m,x,a[maxn],cnt[maxn],tre[maxn],sum,cur,icur,tem;
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n>>m;
	for(int i = 1; i <= n;i++)
	{
		cin>>a[i];
		cnt[a[i]]++;
	}
	//sort(a + 1,a + n + 1);
	//for(int i = 1;i <= n;i++)if(cnt[a[i]])cout<<a[i]<<" "<<cnt[a[i]]<<"\n";
	//cout<<endl;
	for(int i = 1;i <= m;i++)
	{
		cur = cnt[i] / 3;
		sum += cur;
		tre[i] += cur;
		cnt[i] -= cur * 3;
		if(i >= 3)
		{
			icur = min(cnt[i],min(cnt[i - 1],cnt[i - 2]));
			sum += icur;
			for(int j = i - 2;j <= i;j++)cnt[j] -= icur;
		}
	}
	/*for(int i = 1;i <= m;i++)
	{
		cout<<i<<" "<<tre[i]<<" "<<cnt[i]<<"\n";
	}*/
	for(int i = 1;i < m;i++)
	{
		if(cnt[i] == 2 && cnt[i + 1] == 2)
		{
			if(i == m - 1)
			{
				if(tre[i - 1])
				{
					sum++;
					tre[i - 1]--;
					cnt[i - 1]++;
					if(i - 3 >= 1)
					{
						icur = min(cnt[i - 1],min(cnt[i - 2],cnt[i - 3]));
						sum += icur;
						cnt[i - 1] -= icur;
						cnt[i - 2] -= icur;
						cnt[i - 3] -= icur;
					}
					cnt[i] -= 2;
					cnt[i + 1] -= 2;
				}
			}
			else
			{
				if(i > 3 && cnt[i - 2] && cnt[i - 3])
				{
					if(tre[i - 1])
					{
						sum++;
						tre[i - 1]--;
						cnt[i - 1]++;
						icur = min(cnt[i - 1],min(cnt[i - 2],cnt[i - 3]));
						sum += icur;
						cnt[i - 1] -= icur;
						cnt[i - 2] -= icur;
						cnt[i - 3] -= icur;
						cnt[i] -= 2;
						cnt[i + 1] -= 2;
					}
					else if(tre[i + 2])
					{
						sum++;
						tre[i + 2]--;
						cnt[i + 2]++;
						if(i + 4 <= m)
						{
							icur = min(cnt[i + 2],min(cnt[i + 3],cnt[i + 4]));
							sum += icur;
							cnt[i + 2] -= icur;
							cnt[i + 3] -= icur;
							cnt[i + 4] -= icur;
						}
						cnt[i] -= 2;
						cnt[i + 1] -= 2;
					}
				}
				else
				{
					if(tre[i + 2])
					{
						sum++;
						tre[i + 2]--;
						cnt[i + 2]++;
						if(i + 4 <= m)
						{
							icur = min(cnt[i + 2],min(cnt[i + 3],cnt[i + 4]));
							sum += icur;
							cnt[i + 2] -= icur;
							cnt[i + 3] -= icur;
							cnt[i + 4] -= icur;
						}
						cnt[i] -= 2;
						cnt[i + 1] -= 2;
					}
					else if(i > 1 && tre[i - 1])
					{
						sum++;
						tre[i - 1]--;
						cnt[i - 1]++;
						if(i - 3 >= 1)
						{
							icur = min(cnt[i - 1],min(cnt[i - 2],cnt[i - 3]));
							sum += icur;
							cnt[i - 1] -= icur;
							cnt[i - 2] -= icur;
							cnt[i - 3] -= icur;
						}
						cnt[i] -= 2;
						cnt[i + 1] -= 2;
					}
				}
			}
		}
		else if(i > 1 && cnt[i - 1] == 2 && cnt[i + 1] == 2)
		{
			if(tre[i])
			{
				tre[i]--;
				sum++;
				cnt[i]++;
				cnt[i - 1] -= 2;
				cnt[i + 1] -= 2;
			}
		}
	}
	//cout<<sum<<endl;
	tem = 0;
	for(int i = 1;i <= m;i++)
	{
		//cout<<tre[i]<<" "<<cnt[i]<<" "<<tem<<endl;
		if(tre[i])
		{
			if(i > 1 && !tre[i - 1])tem += cnt[i - 1];
			tem += cnt[i];
		}
		else
		{
			tem += cnt[i];
			sum += tem / 3;
			tem = 0;
		}
	}
	cout<<sum;
	/*for(int i = 1;i <= m;i++)
	{
		cout<<i<<" "<<tre[i]<<" "<<cnt[i]<<"\n";
	}*/
	return 0;
}
/*
13 4
1 1 1 1 2 2 2 3 3 3 3 3 4
/*
200 100
2
5
3
4
4
3
5
7
6
5
7
9
6
4
3
5
7
8
3
1
1
2
5
7
9
71
5
4
2
4
71
8
8
5
7
71
7
5
4
2
2
5
7
8
9
6
9
7
7
7
5
4
4
6
8
8
3
6
4
3
5
6
4
1
2
3
2
4
3
2
5
5
5
6
6
3
4
2
1
2
3
4
5
6
6
6
5
4
2
2
2
3
3
2
3
9
8
9
6
7
2
5
3
4
4
3
5
7
6
5
7
9
6
4
3
5
7
8
3
1
1
2
5
7
9
71
5
4
2
4
71
8
8
5
7
71
7
5
4
2
2
5
7
8
9
6
9
7
7
7
5
4
4
6
8
8
3
6
4
3
5
6
4
1
2
3
2
4
3
2
5
5
5
6
6
3
4
2
1
2
3
4
5
6
6
6
5
4
2
2
2
3
3
2
3
9
8
9
6
7
*/
