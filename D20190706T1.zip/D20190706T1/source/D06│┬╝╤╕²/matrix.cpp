#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll maxn = 300;
ll a[maxn][maxn],n,m,cnt[30],res;
char cur;
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>m;
	for(int i = 1; i <= n;i++)
	{
		for(int j = 1;j <= m;j++)
		{
			cin>>cur;
			a[i][j] = cur - 'a';
		}
	}
	if(n == 1)
	{
		for(int i = 1;i <= m;i++)
		{
			for(int j = i;j <= m;j++)
			{
				memset(cnt,0,sizeof(cnt));
				ll tem = 0;
				for(int k = i;k <= j;k++)
				{
					cnt[a[1][k]]++;
				}
				for(int k = 0;k < 26;k++)
				{
					if(cnt[k] % 2 == 1)tem++;
				}
				if(tem <= 1)res++;
				//if(tem > 1)cout<<i<<" "<<j<<" "<<tem<<"\n";
			}
		}
	}
	else if(m == 1)
	{
		for(int i = 1;i <= n;i++)
		{
			for(int j = i;j <= n;j++)
			{
				ll l = i;
				ll r = j;
				bool pd = true;
				while(r >= l)
				{
					if(a[l][1] != a[r][1])pd = false;
					r--;
					l++;
				}
				if(pd)res++;
			}
		}
	}
	else
	{
		for(int p = 1;p <= m;p++)
		{
			for(int i = 1;i <= n;i++)
			{
				for(int j = i;j <= n;j++)
				{	
					ll l = i;
					ll r = j;
					bool pd = true;
					while(r >= l)
					{
						if(a[l][p] != a[r][p])pd = false;
						r--;
						l++;
					}
				if(pd)res++;
				}
			}
		}
		for(int p = 1;p <= n;p++)
		{
			for(int i = 1;i <= m;i++)
			{
				for(int j = i;j <= m;j++)
				{
					memset(cnt,0,sizeof(cnt));
					ll tem = 0;
					for(int k = i;k <= j;k++)
					{
						cnt[a[p][k]]++;
					}
					for(int k = 0;k < 26;k++)
					{
						if(cnt[k] % 2 == 1)tem++;
					}
					if(tem <= 1)res++;
					//if(tem > 1)cout<<i<<" "<<j<<" "<<tem<<"\n";
				}
			}
		}
		res -= n * m;
	}
	cout<<res;
	return 0;
}
/*
7 1
a b c a b a c
*/
