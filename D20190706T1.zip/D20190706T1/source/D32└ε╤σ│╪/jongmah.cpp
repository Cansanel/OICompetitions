#include <iostream>
#include <fstream>
using namespace std;
#define min(a,b) (a<b?a:b)
#define max(a,b) (a>b?a:b)
#define endl '\n'
int n,m;
int a[100005];
int rest[100005];
int div[100005];
int ans=0;

int read(){
	int f=1,ans=0;
	char c=getchar();
	if (c=='-') f=-1;
	while ('0'<=c&&c<='9'){ans=ans*10+(c-'0');c=getchar();}
	return f*ans;
}

int main()

{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	n=read();m=read();
	for (int i=1;i<=n;i++){
		int x=read();
		a[x]++;
	}

	for (int i=1;i<=m;i++){
		if (a[i]>=3) div[i]=a[i]/3;
		rest[i]=a[i]%3;
		ans+=a[i]/3;
	}

	for (int i=1;i<m-1;i++){
		if (rest[i]>=1&&rest[i+1]>=1&&rest[i+2]>=1){
			int mn=min(rest[i],min(rest[i+1],rest[i+2]));
			ans+=mn;
			rest[i]-=mn;
			rest[i+1]-=mn;
			rest[i+2]-=mn;
		}
	}

	for (int i=1;i<m;i++){
		if (rest[i]==2&&rest[i+2]==2){
			if (div[i+1]){
				div[i+1]--;
				rest[i+1]++;
				if (rest[i+1]==3){
					ans++;
					rest[i+1]=0;
					div[i+1]++;
				}
				ans++;
				rest[i]=0;
				rest[i+2]=0;
			}
		}
		if (rest[i]==2&&rest[i+1]==2){
			if (div[i+2]){
				div[i+2]--;
				ans++;
				rest[i]=0;
				rest[i+1]=0;
				rest[i+2]++;
				if (rest[i+2]==3){
					rest[i+2]=0;
					ans++;
					div[i+2]++;
				}
			}
			else if (div[i-1]){
				div[i-1]--;
				ans++;
				rest[i]=0;
				rest[i+1]=0;
				rest[i-1]++;
				if (rest[i-1]==3){
					rest[i-1]=0;
					ans++;
					div[i-1]++;
				}
			}
		}
	}

	for (int i=1;i<m;i++){
		if (rest[i]==2&&rest[i+1]==1||rest[i]==1&&rest[i+1]==2){
			for (int j=i-1;j>1;j--){
				if (!div[j]) break;
				div[j]--;
				if (rest[j-1]>=1){
					rest[j-1]--;
					rest[j]=1;
					rest[i]=rest[i+1]=0;
					ans++;
					break;
				}
			}
		}
	}

	cout<<ans<<endl;
	return 0;
}
/*
10 6
2 3 3 3 4 4 4 5 5 6

13 5
1 1 5 1 2 3 3 2 4 2 3 4 5
*/