#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;
#define min(a,b) (a<b?a:b)
#define endl '\n'
int n;
int a[1005],b[1005];
int ans=1e9;
bool placed[105];

int read(){
	int f=1,ans=0;
	char c=getchar();
	if (c=='-') f=-1;
	while ('0'<=c&&c<='9'){ans=ans*10+(c-'0');c=getchar();}
	return f*ans;
}

void dfs(int now,int uh){
	if (now>n){
		ans=min(ans,uh);
		return;
	}

	for (int i=1;i<=n;i++){
		if (!placed[i]){
			placed[i]=true;
			dfs(now+1,uh+(i-1)*a[now]+(n-i)*b[now]);
			placed[i]=false;
		}
	}
}

int main()

{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++){
		a[i]=read();b[i]=read();
	}
	if (n<=10){
		dfs(1,0);
		cout<<ans<<endl;
	}
	else{
		sort(b+1,b+1+n);
		for (int i=1;i<=n;i++){
			ans+=b[i]*(n-i);
		}
		cout<<ans<<endl;
	}
	return 0;
}
/*
3
4 2
2 3
6 1

10
5 10
12 4
31 45
20 55
30 17
29 30
41 32
7 1
5 5
3 15
*/
