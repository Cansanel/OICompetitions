#include <bits/stdc++.h>
using namespace std;
int n,res;
const int maxn=500005;
struct Node{
	int x,y;
	bool operator < (const Node &t)const{
		return x-y> t.x-t.y;
	}
}num[maxn];
int pos[maxn];
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;++i){
		int u,v;
		scanf("%d%d",&u,&v);
		num[i]=(Node){u,v};
		pos[i]=i;
	}
	sort(num+1,num+n+1);
//	for (int i=1;i<=n;++i)printf("%d %d\n",num[i].x,num[i].y);
//	puts("");
	for (int i=1;i<=n;++i){
		res+=num[i].x*(i-1) + num[i].y*(n-i);
	}
	printf("%d\n",res);
	return 0;
}
