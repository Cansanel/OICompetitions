#include <bits/stdc++.h>
using namespace std;
const int maxn=100005;
int num[maxn];
int lst[maxn];
int n,dp[maxn];
map <int,bool > used;
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;++i){
		scanf("%d",num+i);
	}
	sort(num+1,num+1+n);
	for (int i=1;i<=n;++i){
		used[num[i]]=true;
		lst[num[i]]=i;
	}
	for (int i=3;i<=n;++i){
		dp[i]=dp[i-1];
		if (num[i-2]==num[i])dp[i]=max(dp[i],dp[i-3]+1);
		if (used[num[i]] && used[num[i]-1] && used[num[i]-1])dp[i]=max(dp[i],dp[lst[num[i]-1]-1]+1);
	}
	printf("%d\n",dp[n]);
	return 0;
}
