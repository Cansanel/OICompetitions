#include <bits/stdc++.h>
using namespace std;
const int maxn=205;
const int maxm=27;
int n,m;
int cnt[maxn][maxn],tcnt[maxn],mcren[maxn],res;
char s[maxn][maxn];
bool cmp(int a,int b){
	if (tcnt[a]>1 || tcnt[b]>1)return 0;
	for (int i=0;i<26;++i){
		if (cnt[a][i] != cnt[b][i])return 0;	
	}
	return 1;	
}
void manacher(){
	int pcnt=0,Max=0;
	mcren[0]=1;
	for (int i=1;i<=n*2;++i){
		if (i<=Max)mcren[i]=min(Max-i,mcren[2*pcnt-i]);
		else mcren[i]=1;
		while (i-mcren[i] >=0 && i+mcren[i]<=2*n+1 && cmp(i+mcren[i],i-mcren[i]))mcren[i]++;
		if (tcnt[i]>1)mcren[i]=1;
		if (Max<i+mcren[i]){
			pcnt=i;		
			Max=i+mcren[i];
		}
		res+=(mcren[i])/2;
	}
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;++i)scanf("%s",s[i]+1);
	for (int l=1;l<=m;++l){
		for (int i=1;i<=n;++i)
			for (int k=0;k<26;++k)
				cnt[i*2-1][k]=tcnt[i*2-1]=0;
		for (int r=l;r<=m;++r){
			for (int i=1;i<=n;++i){
				cnt[2*i-1][s[i][r]-'a']++;
				if (cnt[2*i-1][s[i][r]-'a'] & 1)tcnt[2*i-1]++;else tcnt[2*i-1]--;
			}
			manacher();
		}
	}
	printf("%d\n",res);
	return 0;
}
