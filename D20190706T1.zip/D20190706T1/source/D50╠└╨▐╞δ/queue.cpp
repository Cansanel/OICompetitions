#include <bits/stdc++.h>

using namespace std;

typedef long long LL;

const int maxn = 5e5 + 10;

struct node{
	int x, y;
	
	bool operator < (const node &t) const {
		return abs(x - y) > abs(t.x - t.y);
	}
} a[maxn];

int n;

LL getw(node a, int k){
	return 1ll * a.x * (k - 1) + a.y * (n - k);
}

int main(){
	freopen("queue.in", "r", stdin);
	freopen("queue.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) scanf("%d%d", &a[i].x, &a[i].y);
	sort(a + 1, a + n + 1);
	LL ans = 0; int l = 1, r = n;
	for (int i = 1; i <= n; i++){
		if (a[i].x < a[i].y) ans += getw(a[i], r--);
		else ans += getw(a[i], l++);
	}
	printf("%lld\n", ans);
	return 0;
}
