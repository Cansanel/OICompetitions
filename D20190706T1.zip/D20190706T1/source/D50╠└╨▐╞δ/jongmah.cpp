#include <bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 10, maxm = 110;

int n, m, Max;
int cnt[maxn];

int dfs(int dep){
	if (dep > Max) return 0;
	int re = 0, Min = min(min(cnt[dep], cnt[dep + 1]), cnt[dep + 2]);
	for (int i = 0; i <= Min; i++){
		re = max(re, dfs(dep + 1) + i + cnt[dep] / 3);
		cnt[dep]--;
		cnt[dep + 1]--;
		cnt[dep + 2]--;
	}
	cnt[dep] += Min + 1;
	cnt[dep + 1] += Min + 1;
	cnt[dep + 2] += Min + 1;
	return re;
}

int main(){
	freopen("jongmah.in", "r", stdin);
	freopen("jongmah.out", "w", stdout);
	scanf("%d%d", &n, &m);
	int C = 0;
	for (int i = 1; i <= n; i++){
		int x;
		scanf("%d", &x);
		Max = max(Max, x);
		cnt[x]++;
		C = max(C, cnt[x]);
	}
	if (C < 3){
		int ans = 0;
		for (int i = 1; i <= Max; i++){
			int t = min(min(cnt[i], cnt[i + 1]), cnt[i + 2]);
			if (t){
				ans += t;
				cnt[i] -= t;
				cnt[i + 1] -= t;
				cnt[i + 2] -= t;
			}
		}
		printf("%d\n", ans);
	} else printf("%d\n", dfs(1));
	
	return 0;
}
