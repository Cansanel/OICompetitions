#include<bits/stdc++.h>
using namespace std;
struct pp{
	long long a,b,c;
}d[500010];
long long n,ans;
bool cmp(pp a,pp b)
{
	return a.c>b.c;
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);		
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>d[i].a>>d[i].b;
		d[i].c=d[i].a-d[i].b;
	}
	sort(d+1,d+n+1,cmp);
	for(int i=1;i<=n;i++)
	ans+=d[i].a*(i-1)+d[i].b*(n-i);
	cout<<ans<<endl;
	return 0;
}
