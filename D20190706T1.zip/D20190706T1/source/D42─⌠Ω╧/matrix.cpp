#include<bits/stdc++.h>
using namespace std;
int ans,n,m,a[251][251][30];
string s[252];
bool bl(int x,int y,int xx,int yy)
{
	for(register int i=x;i<=(x+xx)/2;i++)
	{
		int tt=0;
		for(register int j=0;j<26;j++)
		{
			int t1=a[i][yy][j]-a[i][y-1][j],t2=a[x+xx-i][yy][j]-a[x+xx-i][y-1][j];
			if(t1!=t2)
			return 0;
			if(t1%2)tt++;
		}
		if(tt>=2)return 0;
	}
	return 1;
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);	
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>s[i];
		for(int j=1;j<=m;j++)
		for(int k=j;k<=m;k++)
		a[i][k][int(s[i][j-1])-int('a')]++;
	}
	for(register int i=1;i<=n;i++)
	for(register int j=1;j<=m;j++)
	for(register int ii=i;ii<=n;ii++)
	for(register int jj=j;jj<=m;jj++)
	if(bl(i,j,ii,jj))
	ans++;
	cout<<ans<<endl;
	return 0;
}
