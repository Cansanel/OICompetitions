#include<bits/stdc++.h>
using namespace std;
int n,m,x,ans,a[100010];
bool b;
void dfs(int x,int t)
{
	if(x>m)
	{
		if(t>ans)
		ans=t;
		return;
	}
	if(a[x]>=3)
	{
		a[x]-=3;
		dfs(x,t+1);
		a[x]+=3;
	}	
	if(a[x]&&a[x+1]&&a[x+2])
	{
		a[x]-=1,a[x+1]-=1,a[x+2]-=1;
		dfs(x,t+1);
	}	
	dfs(x+1,t);
}
int main()
{
	freopen("jongmach.in","r",stdin);
	freopen("jongmach.out","w",stdout);	
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>x;
		a[x]++;
	}	
	for(int i=0;i<=m;i++)
	if(a[i]>=3)
	{
		b=1;
		break;
	}
	if(b)
	dfs(0,0);
	else
	for(int i=0;i<=1;i++)
	if(a[x]&&a[x+1]&&a[x+2])
	{
		a[x]-=1,a[x+1]-=1,a[x+2]-=1;	
		ans++;	
	}
	cout<<ans<<endl;
	return 0;
}
