#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <queue>
#include <stack>
#include <map>

#define submit

template <typename T>
void read(T& x)
{
    int flag = 0;
    char c = getchar();
    for (x = 0; !isdigit(c); flag |= c == '-', c = getchar());
    for (; isdigit(c); x = x * 10 + (c ^ 48), c = getchar());
    if (flag)
        x = -x;
}

int n, m, x;
int a[100010];
int f[100010][5][5];

int main()
{
#ifdef submit
    freopen("jongmah.in", "r", stdin);
    freopen("jongmah.out", "w", stdout);
#endif
    read(n), read(m);
    for (int i = 1; i <= n; ++i)
        read(x), ++a[x];
    ++m;
    for (int i = 0; i <= m; ++i)
    {
        for (int j = 0; j < 3; ++j)
        {
            for (int k = 0; k < 3; ++k)
            {
                int p = a[i] - j - k, q = a[i + 1] - k, r = a[i + 2];
                for (int l = 0; l < 3; ++l)
                {
                    if (p >= l && q >= l && r >= l)
                        f[i + 1][k][l] = std::max(f[i + 1][k][l], f[i][j][k] + l + (p - l) / 3);
                }
            }
        }
    }
    
    int ans = 0;
    
    for (int i = 0; i <= m; ++i)
    {
        for (int j = 0; j < 3; ++j)
        {
            for (int k = 0; k < 3; ++k)
                ans = std::max(ans, f[i][j][k]);
        }
    }
    
    std::cout << ans << std::endl;
    return 0;
}
