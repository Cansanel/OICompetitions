#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <queue>
#include <stack>
#include <map>

#define submit

template <typename T>
void read(T& x)
{
    int flag = 0;
    char c = getchar();
    for (x = 0; !isdigit(c); flag |= c == '-', c = getchar());
    for (; isdigit(c); x = x * 10 + (c ^ 48), c = getchar());
    if (flag)
        x = -x;
}

long long n, ans;
long long a[500010], b[500010], c[500010];

int main()
{
#ifdef submit
    freopen("queue.in", "r", stdin);
    freopen("queue.out", "w", stdout);
#endif
    read(n);
    for (long long i = 1; i <= n; ++i)
        read(a[i]), read(b[i]),
        c[i] = a[i] - b[i];
    std::sort(c + 1, c + n + 1);
    
    for (long long i = 1; i <= n; ++i)
        ans += i * c[n - i + 1];
    for (long long i = 1; i <= n; ++i)
        ans += n * b[i] - a[i];
    std::cout << ans << std::endl;
    return 0;
}
