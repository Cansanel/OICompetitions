#include<bits/stdc++.h>
#define rep(i,j,k) for(int (i)=(j);(i)<=(k);(i)++)
#define pb push_back
using namespace std;
typedef long long ll;
int a[100005],f[100005][4][4][4],n,m;
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,n){
		int tmp;
		scanf("%d",&tmp);
		a[tmp]++;
	}
	rep(i,1,m)
	rep(j,0,3)
	rep(k,0,3)
	rep(l,0,3){
		if(j>a[i]||k>a[i+1]||l>a[i+2]) continue;
		if(i==1) f[i][j][k][l]+=(a[i]-j)/3+(a[i+1]-k)/3+(a[i+2]-l)/3;
		int x=min(j,min(k,l));
		rep(r,0,x){
			f[i+1][k-r][l-r][a[i+3]%3]=max(f[i][j][k][l]+r+a[i+3]/3,f[i+1][k-r][l-r][a[i+3]%3]);
			if(a[i+3]>0) f[i+1][k-r][l-r][3]=max(f[i][j][k][l]+r+a[i+3]/3-1,f[i+1][k-r][l-r][3]);
		}
		
	}
	int ans=0;
	rep(r,0,4) rep(i,0,3) rep(j,0,3) rep(k,0,3) ans=max(ans,f[max(m-r,1)][i][j][k]);
	printf("%d\n",ans);
	return 0;
}
