#include<bits/stdc++.h>
#define rep(i,j,k) for(int (i)=(j);(i)<=(k);(i)++)
#define pb push_back
using namespace std;
typedef long long ll;
int n,m,msk[255],ans;bool ok[255][255][255];char c[255][255];
struct lett{
	unsigned char a[27];
	lett operator -(lett x){
		lett tmp;tmp.a[26]=0;
		rep(i,0,25) tmp.a[i]=a[i]-x.a[i];
		return tmp;
	}
	bool operator ==(lett x){
		rep(i,0,25) if(a[i]!=x.a[i]) return 0;
		return 1;
	}
}g[255][255][255];
int tdi(char x){return x-97;}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,n) scanf("%s",c[i]+1);
	rep(i,1,n){
		rep(j,1,m) msk[j]=0;
		rep(j,1,m){
			msk[j]=msk[j-1]^(1<<tdi(c[i][j]));
			rep(k,1,j) {
				int val=msk[j]^msk[k-1];
				if(val==0||(val&(val-1))==0) ok[i][k][j]=1;
			}
		}
	}
	//rep(i,1,m) rep(j,1,i) printf("%d%c",ok[1][j][i],j==i?'\n':' ');
	rep(i,1,n)
	rep(j,1,m){
		g[i][0][j]=g[i][0][j-1];
		g[i][0][j].a[tdi(c[i][j])]++;
		rep(k,1,j) g[i][k][j]=g[i][0][j]-g[i][0][k-1];
	}
	rep(i,1,n)
	rep(j,1,m)
	rep(k,j,m){
		for(int l=0;i-l>0&&i+l<=n;l++){
			if(!(ok[i-l][j][k]&&ok[i+l][j][k])) break;
			lett a=g[i-l][j][k],b=g[i+l][j][k];
			if(!(a==b)) break;
			ans++;
		}
		for(int l=0;i-l-1>0&&i+l<=n;l++){
			if(!(ok[i-l-1][j][k]&&ok[i+l][j][k])) break;
			lett a=g[i-l-1][j][k],b=g[i+l][j][k];
			if(!(a==b)) break;
			ans++;
		}
	}
	printf("%d ",ans);
	return 0;
}
