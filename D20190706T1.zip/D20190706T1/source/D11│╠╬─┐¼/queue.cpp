#include<bits/stdc++.h>
#define rep(i,j,k) for(int (i)=(j);(i)<=(k);(i)++)
#define pb push_back
typedef long long ll;
using namespace std;
int n;ll ans;struct ss{int a,b;}k[500005];
bool cmp(ss x,ss y){return x.a-x.b>y.a-y.b;}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	cin>>n;
	rep(i,1,n) cin>>k[i].a>>k[i].b;
	sort(k+1,k+n+1,cmp);
	rep(i,1,n) ans+=(ll)k[i].a*(i-1)+(ll)k[i].b*(n-i);
	cout<<ans;
	return 0;
}
