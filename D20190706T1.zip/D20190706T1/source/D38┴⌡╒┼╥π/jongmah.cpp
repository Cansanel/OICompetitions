#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int MAXN=1e5+10;
const int MAXN2=2*1e3;
int n,m;
int num[MAXN];
int ans=0;
int exist[MAXN];
int f[MAXN][MAXN2];
int check(int pos)
{
  if(exist[pos]>=3)  return 2;
  if(exist[pos]==0||pos<=2)  return 0;
  if(exist[pos]>0&&exist[pos-1]>0&&exist[pos-2]>0)  return 1;
  return 0;
}
void dfs(int pos,int total)
{
  if(f[pos][exist[pos]]>=total)  return;
  f[pos][exist[pos]]=total;
  while(check(pos)==0&&pos<=m)  pos++;
//  printf("%d\n",total);
//  printf("%d %d\n",exist[pos],pos);
  if(pos==m+1)
  {
  	ans=max(ans,total);
  	return;
  }
  if(exist[pos]>=3)
  {
  	exist[pos]-=3;
  	dfs(pos,total+1);
  	exist[pos]+=3;
  }
  if(exist[pos]>0&&exist[pos-1]>0&&exist[pos-2]>0)
  {
  	for(int i=0;i<3;i++)
  	  exist[pos-i]--;
  	dfs(pos,total+1);
  	for(int i=0;i<3;i++)
  	  exist[pos-i]++;
  }
  if(pos<m)  dfs(pos+1,total);
}
int main()
{
  freopen("jongmah.in","r",stdin);
  freopen("jongmah.out","w",stdout);
  scanf("%d %d",&n,&m);
  memset(f,-1,sizeof(f));
  for(int i=1;i<=n;i++)  scanf("%d",&num[i]);
  for(int i=1;i<=n;i++)  exist[num[i]]++;
  dfs(1,0);
  printf("%d\n",ans);
  return 0;
}

