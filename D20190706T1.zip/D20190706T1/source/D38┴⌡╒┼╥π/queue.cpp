#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int MAXN=5*1e5+10;
long long ans=0;
int n;
struct node{
  int a,b,mis;
}per[MAXN];

bool cmp(node a,node b)
{
  return a.mis>b.mis;
}

long long s1,s2,s3;
int main()
{
  freopen("queue.in","r",stdin);
  freopen("queue.out","w",stdout);
  scanf("%d",&n);
  for(int i=1;i<=n;i++)
  {
  	scanf("%d %d",&per[i].a,&per[i].b);
  	per[i].mis=per[i].a-per[i].b;
  }
  sort(per+1,per+1+n,cmp);
  for(int i=1;i<=n;i++)
    s1+=n*per[i].b;
  for(int i=1;i<=n;i++)
    s2+=per[i].a;
  for(int i=1;i<=n;i++)
    s3+=i*per[i].mis;
  ans=s1-s2+s3;
  printf("%ld\n",ans);
  return 0;
}
