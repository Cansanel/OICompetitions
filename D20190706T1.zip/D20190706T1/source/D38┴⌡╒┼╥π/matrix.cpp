#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#define mkp make_pair
using namespace std;
int n,m;
int let[30];
long long ans=0;
char mmap[260][260];
int opp[30];
map<string,int> mp;
string ms(int x,int y,int lx,int ly)
{
  string ans="";
  string div="|";
  while(x>0)
  {
  	int k=x%10;
  	x/=10;
  	char ch=k+'0';
  	ans+=ch;
  }
  ans+=div;
  while(y>0)
  {
  	int k=y%10;
  	y/=10;
  	char ch=k+'0';
  	ans+=ch;
  }
  ans+=div;
  while(lx>0)
  {
  	int k=lx%10;
  	lx/=10;
  	char ch=k+'0';
  	ans+=ch;
  }
  ans+=div;
  while(ly>0)
  {
  	int k=ly%10;
  	ly/=10;
  	char ch=k+'0';
  	ans+=ch;
  }
  return ans;
}

bool check(int x,int y,int lx,int ly)
{
  if(mp[ms(x,y,lx,ly)]==1)  return 1;
  if(mp[ms(x,y,lx,ly)]==-1)  return 0;
  if(ly==1&&lx==1)  return mp[ms(x,y,lx,ly)]=1;
  if(lx==1)
  {
  	memset(let,0,sizeof(let));
  	for(int i=y;i<y+ly;i++)  let[mmap[x][i]-'a'+1]++;
  	int judge=2;
  	for(int i=1;i<=26;i++)
  	{
  	  if(let[i]%2==1) judge--;
  	  if(judge==0)  break;
  	}
  	if(judge==0){mp[ms(x,y,lx,ly)]=-1;return 0;}
  	if(judge>=1){mp[ms(x,y,lx,ly)]=1;return 1;}
  }
  if(lx>1&&ly==1)
  {
  	for(int i=0;i<lx/2;i++)  if(mmap[x+i][y]!=mmap[x+lx-1-i][y]){mp[ms(x,y,lx,ly)]=-1;return 0;}
  	mp[ms(x,y,lx,ly)]=1;
	return 1;
  }
  if(lx>1&&ly>1)
  {
  	bool judge=1;
  	for(int i=0;i<lx;i++)  judge=judge&check(x+i,y,1,ly);
  	for(int i=0;i<lx/2;i++)
  	{
  	  int opx=x+i;
  	  int pox=x+lx-1-i;
  	  memset(let,0,sizeof(let));
  	  memset(opp,0,sizeof(opp));
  	  for(int j=y;j<y+ly;j++)  let[mmap[opx][j]-'a'+1]++;
  	  for(int j=y;j<y+ly;j++)  opp[mmap[pox][j]-'a'+1]++;
  	  for(int i=1;i<=26;i++)  if(opp[i]!=let[i])  judge=0;
  	}
  	if(judge){mp[ms(x,y,lx,ly)]=1;return 1;}
  	if(!judge){mp[ms(x,y,lx,ly)]=-1;return 0;}
  }
}
int main()
{
  ifstream fin("matrix.in");
  ofstream fout("matrix.out");
  fin>>n>>m;
  for(int i=1;i<=n;i++)
  	for(int j=1;j<=m;j++)
  	  fin>>mmap[i][j];
  for(int i=1;i<=n;i++)
  	for(int j=1;j<=m;j++)
  	  for(int k=1;k<=n-i+1;k++)
  	  	for(int l=1;l<=m-j+1;l++)
  	  	  if(check(k,l,i,j))
		  	ans++;
  fout<<ans<<endl;
  return 0;
}

