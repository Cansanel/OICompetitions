#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
#define ld long double
#define F(i,j,k) for(int i=j;i<=k;i++)
#define DF(i,j,k) for(int i=j;i>=k;i--)
#define P pair
#define M make_pair
#define dui priority_queue
template<typename T>inline void read(T &n){
	T w=1;n=0;char ch=getchar();
	while(!isdigit(ch)&&ch!=EOF){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch)&&ch!=EOF){n=(n<<3)+(n<<1)+(ch&15);ch=getchar();}
	n*=w;
}
template<typename T>inline void write(T x){
	T l=0;
	ull y=0;
	if(!x){putchar(48);return;}
	if(x<0){x=-x;putchar('-');}
	while(x){y=y*10+x%10;x/=10;l++;}
	while(l){putchar(y%10+48);y/=10;l--;}
}
template<typename T>inline void writes(T x){
	write(x);
	putchar(' ');
}
template<typename T>inline void writeln(T x){
	write(x);
	puts("");
}
template<typename T>inline void checkmax(T &a,T b){a=max(a,b);}
template<typename T>inline void checkmin(T &a,T b){a=min(a,b);}
int an[52][27];
char ch[52][52];
inline int check(int x,int y,int xx,int yy){
	memset(an,0,sizeof(an));
	F(i,x,xx){
		int f=0;
		F(j,y,yy)
			an[i][int(ch[i][j])-95]++;
		F(j,1,26)
			if(an[i][j]%2==1)f++;
		if(f>1)return 0;
	}
	F(i,x,xx)
		F(j,1,26)
			if(an[i][j]!=an[xx-i+x][j])return 0;
	return 1;
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int n,m;read(n);read(m);
	F(i,1,n){
		F(j,1,m)
			ch[i][j]=getchar();
		getchar();
	}
	int ans=0;
	F(i,1,n)
		F(j,1,m)
			F(k,i,n)
				F(l,j,m)
					if(check(i,j,k,l))ans++;
	writeln(ans);
	return 0;
}

