#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
#define ld long double
#define F(i,j,k) for(int i=j;i<=k;i++)
#define DF(i,j,k) for(int i=j;i>=k;i--)
#define P pair
#define M make_pair
#define dui priority_queue
template<typename T>inline void read(T &n){
	T w=1;n=0;char ch=getchar();
	while(!isdigit(ch)&&ch!=EOF){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch)&&ch!=EOF){n=(n<<3)+(n<<1)+(ch&15);ch=getchar();}
	n*=w;
}
template<typename T>inline void write(T x){
	T l=0;
	ull y=0;
	if(!x){putchar(48);return;}
	if(x<0){x=-x;putchar('-');}
	while(x){y=y*10+x%10;x/=10;l++;}
	while(l){putchar(y%10+48);y/=10;l--;}
}
template<typename T>inline void writes(T x){
	write(x);
	putchar(' ');
}
template<typename T>inline void writeln(T x){
	write(x);
	puts("");
}
template<typename T>inline void checkmax(T &a,T b){a=max(a,b);}
template<typename T>inline void checkmin(T &a,T b){a=min(a,b);}
int s[100100],ans,an,n,m;
inline void dfs(int wei,int sum){
	if(sum>an)an=sum;
	if(wei>m)return;
	if(s[wei]>3){
		s[wei]-=3;
		dfs(wei,sum+1);
		s[wei]+=3;
	}
	if(wei>1&&wei<m&&s[wei-1]>0&&s[wei]>0&&s[wei+1]>0){
		s[wei-1]--;
		s[wei]--;
		s[wei+1]--;
		dfs(wei,sum+1);
		s[wei-1]++;
		s[wei]++;
		s[wei+1]++;
	}
	dfs(wei+1,sum);
}
inline void work(){
	dfs(1,0);
	writeln(an);
}
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	read(n);read(m);
	int ff=0;
	F(i,1,n){int a;read(a);s[a]++;if(s[a]>2)ff=1;}
	if(ff){work();return 0;}
	F(i,1,m)while(s[i]>0&&s[i+1]>0&&s[i+2]>0){ans++;s[i]--;s[i+1]--;s[i+2]--;}
	writeln(ans);
	return 0;
}

