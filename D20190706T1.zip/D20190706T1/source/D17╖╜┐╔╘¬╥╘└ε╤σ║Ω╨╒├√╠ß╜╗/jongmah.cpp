#include<algorithm>
#include<cstring>
#include<cstdio>
const int MAXN = 1e5+10;
int n,m,k,l,r,a[MAXN];
bool v[MAXN];
inline int read(){
	int x=0; char c=0;
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	return x;
}
inline bool dfs(int dep,int maxdep){
	bool f=0;
	if (dep>maxdep){
		return true;
	}else{
		for(register int i=1;i<=n && !f;i++)
			if (!v[i]){
				for(register int j=i+1;j<=n && (a[i]+1==a[j] || a[i]==a[j]) && !f;j++)
					if (!v[j]){
						for(register int k=j+1;k<=n && a[k]<=a[i]+2 && !f;k++)
							if (!v[k] && (a[i]==a[j]?(a[j]==a[k]):(a[k]==a[j]+1)) ){
								v[i]=1; v[j]=1; v[k]=1;
								f=dfs(dep+1,maxdep);
								v[i]=0; v[j]=0; v[k]=0;
							}
					}
			}
	}
	return f;
}
int main(){
	freopen("jongmah.out","w",stdout);
	freopen("jongmah.in","r",stdin);
	n=read(); m=read();
	for(register int i=1;i<=n;a[i++]=read());
	std::sort(a+1,a+n+1);
	l=1; r=n/3;
	while(l<r){
		m=(l+r+1)>>1;
		if (dfs(1,m)) l=m;
			else r=m-1;
	}
	printf("%d",l);
	return 0;
}
