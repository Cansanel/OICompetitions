#include<cstring>
#include<cstdio>
#include<queue>
const int INF  = 2147483647;
const int MAXN = 5e6+10;
const int MAXM = 5e7+10;
int n,x[MAXN],y[MAXN],ed=1,s,t,maxflow,mincost,u[MAXM],v[MAXM],f[MAXM],c[MAXM],fst[MAXM],nxt[MAXN],flw[MAXN],dis[MAXN],h[MAXN],pre[MAXN],lst[MAXN];
bool vis[MAXN];
int min(int x,int y){
	return x<y?x:y;
}
int id(char c){
	return c>='0' && c<='9';
}
int read(){
	int x=0; char c=0;
	while(!id(c=getchar()));
	while(id(c)) x=x*10+c-'0',c=getchar();
	return x;
}
void addedge(int A,int B,int C,int D){
	u[++ed]=A; v[ed]=B; f[ed]=C; c[ed]=D;
	nxt[ed]=fst[u[ed]];
	fst[u[ed]]=ed;
}
bool dijkstra(){
	std::priority_queue<std::pair<int,int> > q;
	for(register int i=0;i<=2*n+1;dis[i++]=flw[i-1]=INF);
	for(register int i=0;i<=2*n+1;vis[i++]=0);
	dis[s]=0; pre[t]=-1;
	q.push(std::make_pair(0,s));
	while(!q.empty()){
		int nownode=q.top().second;
		q.pop();
		vis[nownode]=1;
		for(register int i=fst[nownode];i!=-1;i=nxt[i])
			if (!vis[v[i]] && f[i] && dis[v[i]]>dis[nownode]+c[i]+h[nownode]-h[v[i]]){
				dis[v[i]]=dis[nownode]+c[i]+h[nownode]-h[v[i]];
				flw[v[i]]=min(flw[nownode],f[i]);
				pre[v[i]]=nownode; lst[v[i]]=i;
				q.push(std::make_pair(-dis[v[i]],v[i]));
			}
	}
	return pre[t]!=-1;
}
void MCMF(){
	while(dijkstra()){
		maxflow+=flw[t];
		mincost+=flw[t]*(dis[t]+h[t]-h[s]);
		for(register int i=t;i!=s;i=pre[i]){
			f[lst[i]]-=flw[t];
			f[lst[i]^1]+=flw[t];
		}
		for(register int i=1;i<=n;i++)
			h[i]+=dis[i];
	}
}
void build(){
	s=0; t=n*2+1;
	for(register int i=1;i<=n;i++){
		addedge(s,i,1,0),
		addedge(i,s,0,0);
		for(register int j=1;j<=n;j++)
			addedge(i,j+n,1,x[i]*(j-1)+y[i]*(n-j)),
			addedge(j+n,i,0,-x[i]*(j-1)-y[i]*(n-j));
		addedge(i+n,t,1,0),
		addedge(t,i+n,0,0);
	}
}
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	memset(fst,255,sizeof fst);
	n=read();
	for(register int i=1;i<=n;i++)
		x[i]=read(),y[i]=read();
	build();
	MCMF();
	printf("%d",mincost);
	return 0;
}
