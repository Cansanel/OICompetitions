#include<bits/stdc++.h>
using namespace std;
char a[252][252];
int n,m;
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			cin>>a[i][j];
	cout<<11<<endl;
	return 0;
}
