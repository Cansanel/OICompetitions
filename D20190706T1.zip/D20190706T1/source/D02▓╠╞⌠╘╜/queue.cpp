#include<bits/stdc++.h>
using namespace std;
const int maxn=500010;
long long n,a[maxn],b[maxn],c[maxn],A,B,ans;
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i]>>b[i];
		A+=a[i];
		B+=b[i];
		c[i]=a[i]-b[i];
	}
	sort(c+1,c+n+1);
	for(int i=1;i<=n;i++)
		ans+=(c[i]*(n-i+1));
	cout<<ans-A+B*n<<endl;
	return 0;
}
