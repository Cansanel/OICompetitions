#include<bits/stdc++.h>
using namespace std;
int n,m,a[100010],bin,maxx,sum;
void dfs(int ans)
{
	if(sum==maxx)	return ;
	for(int i=1;i<=n;i++)
	{
		if(a[i]>0&&a[i+1]>0&&a[i+2]>0)
		{
			a[i]--;
			a[i+1]--;
			a[i+2]--;
			dfs(ans+1);
			sum=max(sum,ans+1);
			a[i]++;
			a[i+1]++;
			a[i+2]++;
		}
		if(a[i]>=3)
		{
			a[i]-=3;
			dfs(ans+1);
			sum=max(sum,ans+1);
			a[i]+=3;
		}
	}
}
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>bin;
		a[bin]++;
	}
	maxx=n/3;
	dfs(0);
	cout<<sum<<endl;
	return 0;
}
