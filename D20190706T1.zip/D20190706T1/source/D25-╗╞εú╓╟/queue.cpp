#include<bits/stdc++.h>
#define LL long long
using namespace std;
int N;
LL SA,SB,SC,Ans;
struct Xjh{
	LL A,B;
}E[500001];
bool Cmp(Xjh X,Xjh Y){
	return X.A-X.B>Y.A-Y.B;
}
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&N);
	for(int i=1;i<=N;++i)
		scanf("%lld%lld",&E[i].A,&E[i].B);
	sort(E+1,E+1+N,Cmp);
	for(int i=1;i<=N;++i){
		SA+=E[i].A;
		SB+=E[i].B;
		SC+=i*(E[i].A-E[i].B);
	}
	Ans=SC-SA+SB*N;
	printf("%lld\n",Ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
3
4  2
2  3
6  1
*/
/*
10
5  10
12  4
31  45
20  55
30  17
29  30
41  32
7  1
5  5
3  15
*/
