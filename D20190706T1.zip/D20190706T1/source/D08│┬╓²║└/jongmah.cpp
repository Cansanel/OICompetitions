#include <vector>
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
int n;
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n;
	cout<<n/3<<endl;
	return 0;
}
