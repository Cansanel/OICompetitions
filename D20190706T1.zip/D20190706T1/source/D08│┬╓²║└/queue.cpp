#include <iostream>
#include <cstdio>
#include <algorithm>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
struct arr{
	int k;
	int v;
}a[1000001];
long long n,ans;
int x,y,i;
bool cmp(arr a,arr b){
	return a.v>b.v;
}
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&n);
	rep(i,1,n){
		scanf("%d%d",&x,&y);
		a[i].v=x-y;
		a[i].k=y*n-x;
	}
	sort(a+1,a+n+1,cmp);
	rep(i,1,n)
		ans+=a[i].v*i+a[i].k;
	cout<<ans<<endl;
	return 0;
}
/*
10
5 10
12 4
31 45
20 55
30 17
29 30
41 32
7 1
5 5
3 15
*/
