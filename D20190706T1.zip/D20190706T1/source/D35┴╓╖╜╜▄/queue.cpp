#include<bits/stdc++.h>
using namespace std;
int n,ans;
struct point{
	int a,b;
	int s;
}p[5050];
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout); 
	cin>>n;
	for(int i=1;i<=n;i++){
		int x,y;
		cin>>p[i].a>>p[i].b;
		p[i].s=p[i].a-p[i].b;
	}
	for(int i=1;i<=n;i++)
	   for(int j=i+1;j<=n;j++){
	   	if(p[i].s<p[j].s)swap(p[i],p[j]);
	   }
	for(int i=1;i<=n;i++)ans+=p[i].a*(i-1)+p[i].b*(n-i);
	cout<<ans;
	return 0;
}
