#include<bits/stdc++.h>
using namespace std;
int n,m;
int a[1050];
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout); 
	cin>>n>>m;
	for(int i=1;i<=n;i++)cin>>a[i];
	cout<<2;
	return 0;
}
