#include<bits/stdc++.h>
using namespace std;

int s[57][57][27];
int a[27];
int n,m,x,ans;
template <typename Tp>
void read(Tp &x){
	x=0;char ch=1;int fh;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-'){
		fh=-1;ch=getchar();
	}
	else fh=1;
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	x*=fh;
}


void get(int &x){
	char ch=1;
	while(ch<'a'||ch>'z') ch=getchar();
	x=ch-'a'+1;
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	read(n);read(m);
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=m;j++){
			get(x);
			s[i][j][1]=s[i][j-1][1];
			s[i][j][2]=s[i][j-1][2];
			s[i][j][3]=s[i][j-1][3];
			s[i][j][4]=s[i][j-1][4];
			s[i][j][5]=s[i][j-1][5];
			s[i][j][6]=s[i][j-1][6];
			s[i][j][7]=s[i][j-1][7];
			s[i][j][8]=s[i][j-1][8];
			s[i][j][9]=s[i][j-1][9];
			s[i][j][10]=s[i][j-1][10];
			s[i][j][11]=s[i][j-1][11];
			s[i][j][12]=s[i][j-1][12];
			s[i][j][13]=s[i][j-1][13];
			s[i][j][14]=s[i][j-1][14];
			s[i][j][15]=s[i][j-1][15];
			s[i][j][16]=s[i][j-1][16];
			s[i][j][17]=s[i][j-1][17];
			s[i][j][18]=s[i][j-1][18];
			s[i][j][19]=s[i][j-1][19];
			s[i][j][20]=s[i][j-1][20];
			s[i][j][21]=s[i][j-1][21];
			s[i][j][22]=s[i][j-1][22];
			s[i][j][23]=s[i][j-1][23];
			s[i][j][24]=s[i][j-1][24];
			s[i][j][25]=s[i][j-1][25];
			s[i][j][26]=s[i][j-1][26];
			s[i][j][x]=s[i][j-1][x]+1;
		}
	}
	for(register int l=1;l<=n;l++){
		for(register int r=l;r<=n;r++){
			for(register int u=1;u<=m;u++){
				for(register int d=u;d<=m;d++){
					bool flag=false;
					for(int i=l,j=r;j>=i;i++,j--){
						int k=0;
						a[1]=a[2]=a[3]=a[4]=a[5]=a[6]=a[7]=a[8]=a[9]=a[10]=a[11]=a[12]=a[13]=a[14]=a[15]=a[16]=a[17]=a[18]=a[19]=a[20]=a[21]=a[22]=a[23]=a[24]=a[25]=a[26]=0;
						for(int p=1;p<=26;p++){
							int o=s[i][d][p]-s[i][u-1][p];
							if(o) a[p]=o;
							if(o&1) k++;
						}
						if(k>1){
							flag=1;break;
						}k=0;
						bool fafa=false;
						for(int p=1;p<=26;p++){
							int o=s[j][d][p]-s[j][u-1][p];
							if(o){
								if(a[p]!=o){flag=fafa=true;break;}
								a[p]=0;
							}
							if(o&1) k++;
						}
						if(k>1){
							flag=1;break;
						}
						if(fafa){
							break;
						}
						for(int p=1;p<=26;p++){
							if(a[p]){
								flag=fafa=true;break;
							}
						}
						if(fafa) break;
					}
					if(!flag) ans++;
				}
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}

