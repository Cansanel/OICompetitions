#include<bits/stdc++.h>
using namespace std;
#define maxm 100005
int n,m,x;
int cnt[maxm],ans;
int sum,lft;
double st;
template <typename Tp>
void read(Tp &x){
	x=0;char ch=1;int fh;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-'){
		fh=-1;ch=getchar();
	}
	else fh=1;
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	x*=fh;
}

void ff(int x){
	if((clock()-st)/CLOCKS_PER_SEC>=0.92){
		printf("%d\n",ans);exit(0);
	}
	ans=max(ans,sum);
	if(x==m+1){
		return;
	}
	lft-=cnt[max(0,x-3)];
	if(!cnt[x]){
		ff(x+1);lft+=cnt[max(0,x-3)];return;
	}
	if(sum+lft/3<=ans){
		lft+=cnt[max(0,x-3)];return;
	}
	int s=0;
	if(!((cnt[x]&&cnt[max(0,x-1)]&&cnt[max(0,x-2)])||(cnt[x]&&cnt[x-1]&&cnt[x+1])||(cnt[x]&&cnt[x+1]&&cnt[x+2]))){
		int k=cnt[x]/3;
		cnt[x]=cnt[x]%3;
		sum+=k;lft-=3*k;
		ff(x+1);
		lft+=3*k;
		lft+=cnt[max(0,x-3)];
		sum-=k;cnt[x]+=k*3;
		return;
	}
	do{
		int k=min(cnt[x],min(cnt[max(0,x-1)],cnt[max(0,x-2)]));
		sum+=k;
		cnt[x]-=k,cnt[x-1]-=k,cnt[x-2]-=k;
		lft-=3*k;
		ff(x+1);
		lft+=3*k;
		sum-=k;
		cnt[x]+=k,cnt[x-1]+=k,cnt[x-2]+=k;
		cnt[x]-=3;
		if(cnt[x]<0){
			cnt[x]+=3;break;
		}
		s++;
		sum++;
		lft-=3;
		ff(x+1);
	}while(cnt[x]);
	sum-=s;cnt[x]+=s*3;
	lft+=3*s;lft+=cnt[max(x-3,0)];
}

int main(){
	st=clock();
	freopen("jongmah.in","r",stdin);freopen("jongmah.out","w",stdout);
	read(n);read(m);
	for(register int i=1;i<=n;i++){
		read(x);cnt[x]++;
	}
	for(register int i=1;i<=m;i++){
		ans+=cnt[i]/3;
//		if((cnt[i-1]==0&&cnt[i+1]==0)||(cnt[i-1]==0&&cnt[i+2]==0)) cnt[i]=0;
	}
	lft=n;
	ff(1);
	printf("%d\n",ans);
	return 0;
}

