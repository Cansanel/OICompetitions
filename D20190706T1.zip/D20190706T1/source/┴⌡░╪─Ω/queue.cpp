#include<bits/stdc++.h>
using namespace std;

#define maxn 500005

int n;
struct node{
	int a,b,id;
}a[maxn];
int abs(int x){
	return x>0?x:-x;
}
bool comp(node a,node b){
	return (a.a-a.b)>(b.a-b.b);
}

template <typename Tp>
void read(Tp &x){
	x=0;char ch=1;int fh;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-'){
		fh=-1;ch=getchar();
	}
	else fh=1;
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	x*=fh;
}

long long ans;

int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	read(n);
	for(register int i=1;i<=n;i++){
		read(a[i].a);read(a[i].b);a[i].id=i;
	}
	sort(a+1,a+n+1,comp);

	for(register int i=1;i<=n;i++){
		ans=ans+(long long)(i-1)*a[i].a+(n-i)*a[i].b;
	}
	printf("%lld\n",ans);
	return 0;
}

