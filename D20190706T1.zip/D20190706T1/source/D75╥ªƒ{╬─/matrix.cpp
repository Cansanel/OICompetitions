#include<bits/stdc++.h>
using namespace std;
int n,m;
char a[250][250];
int zmgs[27];
bool pd(int x1,int x2,int y1,int y2){
	for(int i=x1;i<=x2;i++){
		for(int j=y1;j<=y2;j++){
			if(a[i][j]!=a[x2-(i-x1)][j])
				return false;
			if(a[i][j]!=a[i][y2-(j-y1)])
				return false;
		}
	}
	return true;
}
bool pdhw(int x1,int x2){
	memset(zmgs,0,sizeof zmgs);
	for(int j=x1;j<=x2;j++){
		zmgs[a[0][j]-'a']++;
	}
	bool yyjs=false;
	for(int i=0;i<26;i++){
		if(zmgs[i]%2==1&&yyjs)
		return false;
		if(zmgs[i]%2==1)
		yyjs=true;
	}
	return true;
}
int main(){
	freopen("martix.in","r",stdin);
	freopen("martix.out","w",stdout);
	cin>>n>>m;
//	ans=n*m;
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			cin>>a[i][j];
		}
	}
	if(m==1){
		int ans=0;
		for(int i=0;i<n;i++){
			for(int j=i;j<n;j++){
				if(pd(i,j,0,0))
				ans++;
			}
		}
		cout<<ans<<endl;
	}
	if(n==1){
		int ans=0;
		for(int i=0;i<m;i++){
			for(int j=i;j<m;j++){
				if(pdhw(i,j)){
					ans++;
				}
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}
