#include<bits/stdc++.h>
using namespace std;
struct per{
	int a,b,c;
};
int n;
per a[500005];
long long ans=0;
bool cmp(per a,per b){
	if(a.c>b.c)
	return true;
	return false;
}
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i].a>>a[i].b;
		a[i].c=a[i].a-a[i].b;
	}
	sort(a,a+n,cmp);
//	for(int i=0;i<n;i++){
//		cout<<a[i].a<<" "<<a[i].b<<" "<<a[i].c<<endl;
//	}
	for(int i=0;i<n;i++){
		ans+=a[i].a*i;
	}
	for(int i=n-1;i>=0;i--){
		ans+=a[i].b*(n-i-1);
	}
	cout<<ans<<endl;
	return 0;
}
