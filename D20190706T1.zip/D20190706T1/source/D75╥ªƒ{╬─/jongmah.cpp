#include<bits/stdc++.h>
using namespace std;
int n,m,a[100005];
int dp(int x){
	if(x==m+1)
		return 0;
	if(a[x]==0)
		return dp(x+1);
	int ans=0;
	if(a[x]>=3){
		a[x]-=3;
		ans=max(ans,dp(x)+1);
		a[x]+=3;
	}
	if(a[x]>0&&a[x+1]>0&&a[x+2]>0){
		a[x]--,a[x+1]--,a[x+2]--;
		ans=max(ans,dp(x)+1);
		a[x]++,a[x+1]++,a[x+2]++;
	}
	return ans=max(ans,dp(x+1));
}
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<n;i++){
		int x;
		cin>>x;
		a[x]++;
	}
	cout<<dp(0)<<endl;
	return 0;
}
