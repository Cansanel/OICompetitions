#include<bits/stdc++.h>
#define MAXN 310

using namespace std;

int n , m;
int a[MAXN][MAXN];
int f[MAXN][MAXN][120];
int ans;

template <typename T> inline void read(T &x) {
	x = 0; T f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}

template <typename T> inline void chkmax(T &x , T y) {x = x > y ? x : y; }
template <typename T> inline void chkmin(T &x , T y) {x = x < y ? x : y; }

template <typename T> inline void print(T x) {
	if (x > 9) print(x / 10);
	putchar(x % 10 + '0');
}
template <typename T> inline void write(T x) {
	if (x < 0) {x = -x; putchar('-');}
	print(x);
	putchar('\n');
}

bool chck(int x , int y , int xx , int yy) {
	for (int i = x; i <= (xx + x + 1) / 2; i++) {
		int t = 0;
		for (int j = 'a'; j <= 'z'; j++) {
			int nx = xx - i + 1; 
			if ((f[x][yy][j] - f[x - 1][yy][j] - f[x][y - 1][j] + f[x - 1][y - 1][j]) % 2 == 1) t++;
			if (f[x][yy][j] - f[x - 1][yy][j] - f[x][y - 1][j] + f[x - 1][y - 1][j] != f[nx][yy][j] - f[nx - 1][yy][j] - f[nx][y - 1][j] + f[nx - 1][y - 1][j]) return 0;
		}
		if (t > 1) return 0;
		if (t == 1 && (xx - x - 1) % 2 == 0) return 0;
	}
	return 1;
}

int main() {

//	freopen(".in" , "r" , stdin);
//	freopen(".out" , "w" , stdout);

	read(n); read(m);
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			char c = getchar();
			a[i][j] = c;
		}
		getchar();
	}
	
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			for (int k = 'a'; k <= 'z'; k++) {
				f[i][j][k] = f[i][j - 1][k] + f[i - 1][j][k] - f[i - 1][j - 1][k];
			}
		}
	}
	
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			for (int ii = i; ii <= n; ii++) {
				for (int jj = j; jj <= m; jj++) {
					if (chck(i , j , ii , jj)) {
						ans++;
						cout << i << " " << j << " " << ii << " " << jj << endl;
					}
				}
			}
		}
	}

	write(ans);
	return 0;
}

