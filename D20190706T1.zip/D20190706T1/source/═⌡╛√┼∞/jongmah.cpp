#include<bits/stdc++.h>
#define MAXNUM 110
#define MAXN 110

using namespace std;

int cnt[MAXNUM] , a[MAXN];
int n , m;
int ans;

template <typename T> inline void read(T &x) {
	x = 0; T f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}

template <typename T> inline void chkmax(T &x , T y) {x = x > y ? x : y; }
template <typename T> inline void chkmin(T &x , T y) {x = x < y ? x : y; }

template <typename T> inline void print(T x) {
	if (x > 9) print(x / 10);
	putchar(x % 10 + '0');
}
template <typename T> inline void write(T x) {
	if (x < 0) {x = -x; putchar('-');}
	print(x);
	putchar('\n');
}

inline void dfs(int dep , int tot) {
	if (dep > n) {
		chkmax(ans , tot);
		return;
	}
	dfs(dep + 1 , tot);
	if (a[dep] == a[dep + 1] && a[dep + 1] == a[dep + 2] && cnt[a[dep]] >= 3) {
		int c = a[dep];
		cnt[c] -= 3;
		dfs(dep + 3 , tot + 1);
		cnt[c] += 3;
	}
	if (cnt[a[dep]] != 0 && cnt[a[dep] + 1] != 0 && cnt[a[dep] + 2] != 0) {
		int p = a[dep];
		cnt[p]--; cnt[p + 1]--; cnt[p + 2]--;
		dfs(dep + 1 , tot + 1);
		cnt[p]++; cnt[p + 1]++; cnt[p + 2]++;
	}
}

int main() {

	freopen("jongmah.in" , "r" , stdin);
	freopen("jongmah.out" , "w" , stdout);

	read(n);
	read(m);
	for (int i = 1; i <= n; i++) {
		read(a[i]);
		cnt[a[i]]++;
	}
	
	sort(a + 1 , a + n + 1);
	
	if (n > 80) {
		for (int i = 1; i <= m - 2; i++) {
			int t = min(cnt[i] , min(cnt[i + 1] , cnt[i + 2]));
			if (t > 0) {
				ans += t;
				cnt[i] -=t;
				cnt[i + 1] -= t;
				cnt[i + 2] -= t;
			}
		}
		write(ans);
		return 0;
	}
	
	dfs(1 , 0);
	
	write(ans);

	return 0;
}

