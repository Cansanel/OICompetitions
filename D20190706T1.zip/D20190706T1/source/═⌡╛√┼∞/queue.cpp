#include<bits/stdc++.h>
#define MAXN 500010

using namespace std;

int n;

struct node{
	int a , b;
} con[MAXN];

template <typename T> inline void read(T &x) {
	x = 0; T f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}

template <typename T> inline void chkmax(T &x , T y) {x = x > y ? x : y; }
template <typename T> inline void chkmin(T &x , T y) {x = x < y ? x : y; }

template <typename T> inline void print(T x) {
	if (x > 9) print(x / 10);
	putchar(x % 10 + '0');
}
template <typename T> inline void write(T x) {
	if (x < 0) {x = -x; putchar('-');}
	print(x);
	putchar('\n');
}

bool cmp(node a , node b) {
	if ((a.a - a.b) > (b.a - b.b)) return 1;
	if ((a.a - a.b) < (b.a - b.b)) return 0;
	return a.a > b.a;
}

int main() {
	
	freopen("queue.in" , "r" , stdin);
	freopen("queue.out" , "w" , stdout);
	
	read(n);
	
	for (int i = 1; i <= n; i++) {
		read(con[i].a); read(con[i].b);
	}
	
	sort(con + 1 , con + n + 1 , cmp);
	
	long long ans = 0;
	for (int i = 1; i <= n; i++) {
		ans += con[i].a * (i - 1) + con[i].b * (n - i);
	}
	
	write(ans);
	
	return 0;
}
