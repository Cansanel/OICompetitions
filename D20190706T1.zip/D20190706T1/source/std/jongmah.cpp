#include <bits/stdc++.h>
#define ll long long
using namespace std;
int read() {
	int tot=0,fh=1;char c=getchar();
	while (c<'0'||c>'9') {if (c=='-') fh=-1;c=getchar();}
	while (c>='0'&&c<='9') {tot=tot*10+c-'0';c=getchar();}
	return tot*fh;
}
void getstr(char *a) {
	char c=getchar();int len=0;
	while (!((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9'))) c=getchar();
	while ((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')) {a[++len]=c;c=getchar();}
}
const int maxn=2e6+100;
int n,m,lim[maxn],f[maxn][7][4];
int main() {
	freopen("jongmah.in", "r", stdin);
	freopen("jongmah.out", "w", stdout);
	n=read();m=read();
	for (int i=1;i<=n;i++) {
		int x=read();
		lim[x]++;
	} 
	for (int i=0;i<=m;i++) {
		for (int j=0;j<6;j++)
			for (int k=0;k<3;k++) {
				int tmp=2;
				tmp=min(tmp,lim[i]-j);
				tmp=min(tmp,lim[i+1]-k);
				tmp=min(tmp,lim[i+2]);
				for (int t=0;t<=tmp;t++) 
					f[i+1][k+t][t]=max(f[i+1][k+t][t],f[i][j][k]+(lim[i]-j-t)/3+t);
			}
	}
	cout<<f[m+1][0][0]<<"\n";
	return 0;
}
