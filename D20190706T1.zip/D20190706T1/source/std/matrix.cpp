# include <bits/stdc++.h>
using namespace std;
namespace Base{
	# define mr make_pair
	typedef long long ll;
	typedef unsigned long long ull;
	typedef double db;
	const int inf = 0x3f3f3f3f, INF = 0x7fffffff;
	const ll  infll = 0x3f3f3f3f3f3f3f3fll, INFll = 0x7fffffffffffffffll;
	template<typename T> void read(T &x){
    	x = 0; int fh = 1; double num = 1.0; char ch = getchar();
		while (!isdigit(ch)){ if (ch == '-') fh = -1; ch = getchar(); }
		while (isdigit(ch)){ x = x * 10 + ch - '0'; ch = getchar(); }
	    if (ch == '.'){
	    	ch = getchar();
	    	while (isdigit(ch)){num /= 10; x = x + num * (ch - '0'); ch = getchar();}
		}
		x = x * fh;
	}
	template<typename T> void chmax(T &x, T y){x = x < y ? y : x;}
	template<typename T> void chmin(T &x, T y){x = x > y ? y : x;}
}
using namespace Base;

const int N = 252, K = 1e9 + 7;
ull ans;
int n, m;
char mp[N][N];
ull sg[N][N][N], np[27], s[N], st[N * 2];
bool fg[N][N][N], f[N], can[N * 2];
int len[N * 2], l[N * 2], r[N * 2], cnt[27];
int solve(bool *f, ull *s, int n){
	memset(len, 0, sizeof(len));
	for (int i = 1; i <= n; i++) st[i * 2] = s[i], can[i * 2] = f[i];
	ull key[3];
	for (int i = 0; i < 3; i++){
		int flag = false; ull tmp;
		while (!flag){
			tmp = ((1ull * rand()) << 16) + rand();
			flag = true;
			for (int j = 1; j <= n; j++) if (s[j] == tmp) flag = false;
		}
		key[i] = tmp;
	}
	st[0] = key[1], st[n * 2 + 2] = key[2]; st[n * 2 + 1] = key[0], can[n * 2 + 1] = 1;
	for (int i = 1; i <= n; i++) st[i * 2 - 1] = key[0], can[i * 2 - 1] = 1;
	int m = n * 2 + 1, p = 0, id = 0;
	for (int i = 1; i <= m; i++){
		if (i > p){
			int l = i - 1, r = i + 1; 
			while (st[l] == st[r]) l--, r++, len[i]++;
			p = r - 1, id = i;
			continue;
		}
		int q = id - (p - id), j = id - (i - id);
		if (q < j - len[j]) len[i] = len[j];
		else {
			int now = min(len[j], p - i);
			int l = i - now - 1, r = i + now + 1;
			len[i] = now;
			while (st[l] == st[r]) l--, r++, len[i]++;
			if (r - 1 > p) p = r - 1, id = i;
		}
	}
	r[m + 1] = m + 1; 
	for (int i = m; i >= 1; i--) if (can[i] == 0) r[i] = i; else r[i] = r[i + 1];
	l[0] = 0;
	for (int i = 1; i <= m; i++) if (can[i] == 0) l[i] = i; else l[i] = l[i - 1];
	int tot = 0;
	for (int i = 1; i <= m; i++){
		int lim = min((i - l[i]) / 2, (r[i] - i) / 2);
		tot = tot + min(lim, (len[i] + 1) / 2);
	}
	return tot;
}
int main(){
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	read(n); read(m);
	for (int i = 1; i <= n; i++) scanf("\n%s", mp[i] + 1);
	np[0] = 1; for (int i = 1; i < 27; i++) np[i] = np[i - 1] * K;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++){
			memset(cnt, 0, sizeof(cnt));
			int tmp = 0; ull sum = 0;
			for (int k = j; k <= m; k++){
				int x = mp[i][k] - 'a';
				sum = sum - cnt[x] * np[x];
				cnt[x]++; 
				sum = sum + cnt[x] * np[x];
				if (cnt[x] % 2 == 0) tmp--;
					else tmp++;
				if (tmp <= 1) fg[i][j][k] = true;
				sg[i][j][k] = sum;
			}
		}
	for (int i = 1; i <= m; i++)
		for (int j = i; j <= m; j++){
			for (int k = 1; k <= n; k++)
				f[k] = fg[k][i][j], s[k] = sg[k][i][j];
			ans += solve(f, s, n);
		}
	cout << ans << endl;
	return 0;
}


