#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,j,k) for (int i=j;i<=k;i++)
#define dep(i,j,k) for (int i=j;i>=k;i--)
#define M(a,b) memset(a,b,sizeof(a))
using namespace std;
int n,m,a[100005],find[100005];
bool flag;
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongma.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,n) scanf("%d",&a[i]),find[a[i]]++,flag=find[a[i]]>2?true:false;
	if (n>80 && flag) return 0;	
	
	return 0;
}
