#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,j,k) for (int i=j;i<=k;i++)
#define dep(i,j,k) for (int i=j;i>=k;i--)
#define M(a,b) memset(a,b,sizeof(a))
using namespace std;
struct node{
	int a,b,no,c;
}p[5005];
int n,x;
long long ans;
bool cmp(node x,node y){
	return x.c>y.c;
}
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&n);
	rep(i,1,n) scanf("%d%d",&p[i].a,&p[i].b),p[i].no=i,p[i].c=(p[i].a-p[i].b);
	rep(i,1,n) ans-=p[i].a,ans+=n*p[i].b;
	sort(p+1,p+1+n,cmp);
	rep(i,1,n) ans+=i*p[i].c;
	printf("%I64d",ans);
	return 0;
}

