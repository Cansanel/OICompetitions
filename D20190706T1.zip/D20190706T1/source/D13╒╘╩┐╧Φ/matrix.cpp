#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,j,k) for (int i=j;i<=k;i++)
#define dep(i,j,k) for (int i=j;i>=k;i--)
#define M(a,b) memset(a,b,sizeof(a))
using namespace std;
int n,m,map[300][300],ans;
char x;
bool check(int l,int r,char c[]){
	int d=0,s=0;
	int a[100];M(a,0);
	rep(i,1,r-l+1) a[c[i]-'a']++;
	rep(i,0,25) if (a[i]%2==0) s++;else d++;
	if (d>1) return false;
	return true;
}
int main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d%d",&n,&m);
	x=getchar();
	rep(i,1,n){
		while (x<'a' || x>'z') x=getchar();
		rep(j,1,m) map[i][j]=x,x=getchar();
	}
	if (n==1){
		ans=m;
		rep(l,1,m-1)
			rep(r,l+1,m){
				char ch[300];M(ch,0);
				rep(j,1,r-l+1) ch[j]=map[n][l+j-1];
				if (check(l,r,ch)) ans++;	
			}
		printf("%d",ans);
		return 0;
	}
	if (m==1){
		ans=n;
		rep(l,1,n-1)
			rep(r,l+1,n){
				char ch[300];M(ch,0);
				rep(j,1,r-l+1) ch[j]=map[l+j-1][m];
				if (check(l,r,ch)) ans++;	
			}
		printf("%d",ans);
		return 0;
	}
	return 0;
}
