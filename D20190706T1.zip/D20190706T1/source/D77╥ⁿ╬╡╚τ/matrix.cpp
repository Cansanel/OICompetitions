#include<cstdio>
#include<cstring>
int n,m,ans=0,flag;
char a[301][301],ch;
int sum[26][251][251]={};//sum[letter][row][line]
int ss[26][251][251]={};//ss[letter][[matrix]]
int tt[251][251];
int t[251][251],q[251]={};
void testit(int i1,int i2,int j1,int j2)
{
int l,r,pos=0;
for(int i=i1;i<=i2;++i)
for(int j=j1;j<=j2;++j)
tt[i][j]=a[i][j];
for(int k=i1;k<=i2;++k)
for(int i=j1;i<j2;++i)
for(int j=i;j<=j2;++j)
if(tt[k][i]<tt[k][j])
{tt[k][i]^=tt[k][j];tt[k][j]^=tt[k][i];tt[k][i]^=tt[k][j];}
putchar('\n');

for(int i=i1;i<=i2;++i)
	{
	for(int j=j1;j<=j2;++j)
	putchar(tt[i][j]);putchar('\n');
	}
putchar('\n');

for(int i=i1;i<=i2;++i)
	{
	for(int j=j1;j<=j2;++j)
		{
		if(tt[i][j]==tt[i][j+1])t[i][j/2]=t[i][j2-j/2+1]=tt[i][j],j+=2;
		else t[i][j2/2+1]=tt[i][j];
		}
	}
	
for(int i=i1;i<=i2;++i)
	{
	for(int j=j1;j<=j2;++j)
	putchar(t[i][j]);putchar('\n');
	}
putchar('\n');putchar('\n');putchar('\n');putchar('\n');
	
	
for(int j=j1;j<=j2;++j)
	{
	int ff=1;
	for(int i=i1;i<=i2;++i)
	if(t[i][j]!=t[i2-i+1][j]){ff=0;break;}
  if(!ff){flag=0x3f3f3f;return;}
	}
}
int main()
{
freopen("matrix.in","r",stdin);
freopen("matrix.out","w",stdout);
scanf("%d%d",&n,&m);
for(int i=1;i<=n;++i)
for(int j=1;j<=m;++j)
	{
	do{ch=getchar();}while(!(ch>='a'&&ch<='z'));
	a[i][j]=ch;
	for(int k=0;k<26;++k)
	sum[k][i][j]=sum[k][i][j-1];
	sum[ch-'a'][i][j]+=1;
	for(int k=0;k<26;++k)
	ss[k][i][j]=ss[k][i][j-1]+ss[k][i-1][j]-ss[k][i-1][j-1];
	ss[ch-'a'][i][j]+=1;
	}
ans=n*m;
for(int maxi=1;maxi<=n;++maxi)
for(int maxj=1;maxj<=m;++maxj)
{
if(maxi==1&&maxj==1)continue;
for(int i=1;i<=n-maxi+1;++i)
for(int j=1;j<=m-maxj+1;++j)
	{
	for(int ii=i;ii<=i+maxi-1;++ii)
	{
	flag=0;
		for(int k=0;k<26;++k)
		{
		flag+=(sum[k][ii][j+maxj-1]-sum[k][ii][j-1])&1;
		if(flag>1)break;
		}
	if(flag>1)break;	
	}
	if(flag>1)continue;
	flag=0;
	for(int k=0;k<26;++k)
	{
	flag+=(ss[k][i+maxi-1][j+maxj-1]+ss[k][i+maxi-1][j-1]
	+ss[k][i-1][j+maxj-1]-ss[k][i-1][j-1])&1;
	if(flag>1)break;
	}
	if(flag>1)continue;
	if(flag>1)continue;
	++ans;
	
	/*printf("\n%d:\n",ans-n*m);
	printf("i:%d->%d j:%d->%d\n",i,i+maxi-1,j,j+maxj-1);
	for(int iiii=i;iiii<=i+maxi-1;++iiii)
		{
		for(int jjjj=j;jjjj<=j+maxj-1;++jjjj)
		putchar(a[iiii][jjjj]);
		printf("\n");
		}*/
		
		
	}
}
printf("%d\n",ans);
fclose(stdout);
fclose(stdin);
return 0;
}
