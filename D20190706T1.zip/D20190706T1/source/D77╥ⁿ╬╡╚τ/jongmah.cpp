#include<cstdio>
#include<cstring>
#define min(x,y) (x<y?x:y)
#define max(x,y) (x>y?x:y)
int n,m;
int a[100011],f[100011][3][3]={};
int hash[100001]={};
inline int read()
{
int x=0,f=1;char ch=getchar();
while(ch>'9'||ch<'0')ch=='-'?f=-1,ch=getchar():ch=getchar();
while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+ch-48,ch=getchar();
return x*f;
}
int main()
{
freopen("jongmah.in","r",stdin);
freopen("jongmah.out","w",stdout);
n=read(),m=read();
for(int i=1;i<=n;++i)
++hash[read()];
for(int i=0;i<=m;++i)
for(int j=0;j<3;++j)
for(int k=0;k<3;++k)
{
int tmp=min(min(min(hash[i+1]-j-k,hash[i+2]-k),hash[i+3]),2);
for(int t=0;t<=tmp;++t)
f[i+1][k][t]=max(f[i+1][k][t],f[i][j][k]+t+(hash[i+1]-j-k-t)/3);
}
printf("%d\n",f[m+1][0][0]);
fclose(stdin);
fclose(stdout);
return 0;
}
