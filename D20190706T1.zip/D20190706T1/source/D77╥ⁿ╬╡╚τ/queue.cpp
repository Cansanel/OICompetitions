#include<cstdio>
#include<algorithm>
#include<iostream>
using namespace std;
#define ll long long
int n;
ll ans=0LL;
struct person
{
int val,pos,l,r;
}a[500001];
inline int read()
{
int x=0,f=1;char ch=getchar();
while(ch>'9'||ch<'0')ch=='-'?f=-1,ch=getchar():ch=getchar();
while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+ch-48,ch=getchar();
return x*f;
}
bool cmpval(person x,person y)
{return x.val>y.val;}
int main()
{
freopen("queue.in","r",stdin);
freopen("queue.out","w",stdout);
n=read();
for(int i=1;i<=n;++i)
a[i].l=read(),a[i].r=read(),
a[i].val=a[i].l-a[i].r,a[i].pos=i;
std::sort(a+1,a+1+n,cmpval);
for(int i=1;i<=n;++i)
ans+=(i-1)*a[i].l+(n-i)*a[i].r;
cout<<ans<<endl;
fclose(stdin);
fclose(stdout);
return 0;
}
