#include<cstdio>
#include<cctype>
#include<utility>
#include<algorithm>
#define MaxN 500010
#define pii std::pair<int, int>

typedef long long LL;

pii member[MaxN];
int n;
LL ans;

inline int read() {
	int x = 0, f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
	return x * f;
}

bool cmp(pii x, pii y) {
	return x.second + y.first < x.first + y.second;
}

int main() {
	freopen("queue.in", "r", stdin);
	freopen("queue.out", "w", stdout);
	n = read();
	for (int i = 1; i <= n; ++i)
		member[i] = std::make_pair(read(), read());
	std::sort(member + 1, member + n + 1, cmp);
	for (int i = 1; i <= n; ++i)
		ans += 1LL * member[i].first * (i - 1) + 1LL * member[i].second * (n - i);
	printf("%lld\n", ans);
	return 0;
}
