#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,ans;
struct node{
	int l,r,c;	
}p[500005];
bool cmp(const node &a,const node &b){
	return a.c<b.c;
}
signed main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>p[i].l>>p[i].r;
		p[i].c=p[i].r-p[i].l;
	}
	sort(p+1,p+n+1,cmp);
	for(int i=1;i<=n;i++)
		ans+=p[i].l*(i-1)+p[i].r*(n-i);
	cout<<ans<<endl;
	return 0;
}
/*
10
5 10
12 4
31 45
20 55
30 17
29 30
41 32
7 1
5 5
3 15
*/
