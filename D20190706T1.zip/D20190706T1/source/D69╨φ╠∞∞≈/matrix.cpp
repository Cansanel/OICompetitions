#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,s[255][255]['z'],ans;
char c[255][255];
signed main(){
//	freopen(".in","r",stdin);
//	freopen(".out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		getchar();
		for(int j=1;j<=m;j++)
			c[i][j]=getchar();
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			for(char k='a';k<='z';k++)
				s[i][j][k]=s[i-1][j][k]+s[i][j-1][k]-s[i-1][j-1][k];
			s[i][j][c[i][j]]++;
		}
	for(int a=1;a<=n;a++)
		for(int b=1;b<=m;b++)
			for(int c=a;c<=n;c++)
				for(int d=b;d<=m;d++)
				{
					int w=0;
					for(char k='a';k<='z';k++)
						if ((s[c][d][k]-s[a][b][k])%2==1) w++;
					if (w<=1) ans++;
				}
	cout<<ans<<endl;
	return 0;
}

