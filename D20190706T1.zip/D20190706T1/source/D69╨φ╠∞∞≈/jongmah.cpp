#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,a[100005],s[100005],d1[200005],d2[200005],d3[200005],tot,ans,sss;
void dfs(int dep){
	sss=max(sss,dep);
	for(int i=1;i<=m-2;i++)
		if (a[i]>=1&&a[i+1]>=1&&a[i+2]>=1)
		{
			a[i]--;
			a[i+1]--;
			a[i+2]--;
			dfs(dep+1);
			a[i]++;
			a[i+1]++;
			a[i+2]++;
		}
	for(int i=1;i<=m;i++)
		if (a[i]>=3)
		{
			a[i]-=3;
			dfs(dep+1);
			a[i]+=3;
		}
}
signed main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		int x;
		cin>>x;
		a[x]++;
	}
//	for(int i=1;i<=m;i++)
//		cout<<a[i]<<" ";
//	cout<<endl;
	for(int i=1;i<=m-2;i++)
	{
		 int l1=min(min(a[i],a[i+1]),a[i+2]),l2=max(a[i-1],a[i+3]);
		 int c=l1-l2;
		 if (c>0) 
		 {
		 	c/=3;
		 	a[i]-=c*3;
		 	a[i+1]-=c*3;
		 	a[i+2]-=c*3;
		 	ans+=c*3;
		 }
	}
	for(int i=1;i<=m;i++)
	{
		int l=max(a[i-1],a[i+1]);
		int c=a[i]-l;
		if (c>0)
		{
			c/=3;
			a[i]-=c*3;
			ans+=c;
		}
	}
	dfs(0);
	cout<<ans+sss<<endl;
	return 0;
}

