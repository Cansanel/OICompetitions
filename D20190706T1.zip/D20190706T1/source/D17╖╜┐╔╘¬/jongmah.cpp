#include<cstdio>
const int MAXN=1e5+10;
int n,m,e,l,r,x,p[MAXN],q[MAXN],idx[MAXN];
inline int d(char c){return c>='0'&&c<='9';}
inline int v(){int x=0;char c=0;while(!d(c=getchar()));while(d(c))x=x*10+c-'0',c=getchar();return x;}
inline bool s(int a,int b){
	bool f=0;
	if (a>b){return true;}else{
		for(register int i=1;i<=e && !f;i++){
			if (q[i]>=3){q[i]-=3;f=s(a+1,b);q[i]+=3;}
			if (i<=e-2&&p[i]+1==p[i+1]&&p[i+1]+1==p[i+2]&&p[i]>0&&p[i+1]>0&&p[i+2]>0){p[i]--;p[i+1]--;p[i+2]--;f=s(a+1,b);p[i]++;p[i+1]++;p[i+2]++;}
		}
	}
	return f;
}
int main(){
	freopen("jongmah.in","r",stdin);freopen("jongmah.out","w",stdout);
	n=v();m=v();for(register int i=1;i<=n;i++){x=v();if(idx[x]){q[idx[x]]++;}else{idx[x]=++e;p[e]=x;q[e]++;}}
	l=1;r=n/3;while(l<r){m=(l+r+1)>>1;if(s(1,m))l=m;else r=m-1;}
	printf("%d",l);
	return 0;
}
