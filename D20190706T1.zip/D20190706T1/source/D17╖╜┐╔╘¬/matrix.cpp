#include<cstring>
#include<cstdio>
int n,m,ans,a[251][251],tmp[251][251],chker[27];
char c;
bool chk(int x,int y){
	int cnt=0;
	for(register int i=1;i<=x;i++){
		memset(chker,0,sizeof chker);
		for(register int j=1;j<=y;j++)
			chker[tmp[i][j]]++;
		for(register int j=1;j<=26;j++)
			if (chker[j]%2) cnt++;
		if (cnt>1) return false;
	}
	return true;
}
int main(){
	freopen("matrix.out","w",stdout);
	freopen("matrix.in","r",stdin);
	scanf("%d%d",&n,&m);
	for(register int i=1;i<=n;i++)
		for(register int j=1;j<=m;j++){
			while(c=getchar())
				if (c>='a' && c<='z') break;
			a[i][j]=c-'a'+1;
		}
	for(register int x1=1;x1<=n;x1++)
		for(register int y1=1;y1<=m;y1++)
			for(register int x2=x1;x2<=n;x2++)
				for(register int y2=y1;y2<=m;y2++){
					for(register int i=x1;i<=x2;i++)
						for(register int j=y1;j<=y2;j++)
							tmp[i-x1+1][j-y1+1]=a[i][j];
					if (chk(x2-x1+1,y2-y1+1)) ans++;
				}
	printf("%d",ans+m-1);
	return 0;
}
