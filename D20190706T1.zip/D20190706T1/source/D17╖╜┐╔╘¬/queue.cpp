#include<algorithm>
#include<utility>
#include<cstdio>
const int MAXN = 5e5+1;
struct shit{
	int x,y;
};
shit sh[MAXN];
int n;
long long s;
bool cmp(shit a,shit b){
	return a.x-a.y>b.x-b.y;
}
int main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&n);
	for(register int i=1;i<=n;i++)
		scanf("%d%d",&sh[i].x,&sh[i].y);
	std::sort(sh+1,sh+n+1,cmp);
	for(register int i=1;i<=n;i++)
		s+=sh[i].x*(i-1)+sh[i].y*(n-i);
	printf("%lld",s);
	return 0;
}

