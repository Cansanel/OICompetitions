#include<bits/stdc++.h>
using namespace std;
int n,m;
int main( ){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	cin>>n>>m;cout<<n*m<<endl;
	return 0;
}
