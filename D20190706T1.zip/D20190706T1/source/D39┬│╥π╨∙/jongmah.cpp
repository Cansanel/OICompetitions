#include<bits/stdc++.h>
using namespace std;
int n,m,dp[100005][5][5],a[100005];
int main( ){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n>>m;int x;
	for(int i=1;i<=n;i++){
		cin>>x;a[x]++;
	}
	for(int i=0;i<=m;i++)
		for(int j=0;j<3;j++)
			for(int k=0;k<3;k++)
				for(int l=0;l<3;l++)
					if(a[i+2]>=l && a[i+1]>=k+l && a[i]>=k+l+j && a[i-1]>=k+j && a[i-2]>=j)
						dp[i+1][k][l]=max(dp[i+1][k][l],dp[i][j][k]+l+(a[i+1]-k-l)/3);
	cout<<dp[m+1][0][0]<<endl;return 0;
}
/*
35 14
1 1 1 1 1 1 1 2 2 2 2 2 3 3 3 4 4 5 6 6 6 7 8 9 9 9 9 9 10 11 11 12 13 13 14
*/
