#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m,ans;
struct node{
	ll x,y,z;
}c[500005];
bool cmp(node x,node y){
	return x.z>y.z;
}
int main( ){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>c[i].x>>c[i].y;
		c[i].z=c[i].x-c[i].y;
	}
	sort(c+1,c+1+n,cmp);
	for(int i=1;i<=n;i++){
		ans+=(c[i].x*(i-1)+c[i].y*(n-i));
	}
	cout<<ans<<endl;return 0;
}
