#include<bits/stdc++.h>
using namespace std;
int n,ans;
struct data{int a,b,cha;}f[100007];
bool operator < (data x,data y){return x.cha>y.cha;}
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		f[i].a=read();f[i].b=read();
		f[i].cha=f[i].a-f[i].b;
	}
	sort(f+1,f+n+1);
	for(int i=1;i<=n;i++)
	ans+=f[i].a*(i-1)+f[i].b*(n-i);
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
