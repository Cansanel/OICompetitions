#include<bits/stdc++.h>
using namespace std;
int n,m,a,num[100007],dp[100007];
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>a;
		num[a]++;
	}
	for(int i=1;i<=m;i++)
	dp[i]=max(dp[i-1]+num[i]/3,dp[i-3]+min(num[i],min(num[i-1],num[i-2])));
	cout<<dp[m]<<endl;
	return 0;
}
