#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cassert>
using namespace std;
typedef long long LL;
const int maxn=255;
char a[maxn][maxn]; int cnt[128];
int n,m;
struct Case1
{
	bool ok[maxn][maxn];
	int lie()
	{
		memset(ok,0,sizeof(ok));
		for(int i=1;i<=n;i++) ok[i][i]=1,ok[i+1][i]=1;
		for(int len=2;len<=n;len++)
			for(int i=1;i+len-1<=n;i++)
				ok[i][i+len-1]=(ok[i+1][i+len-2]&&a[i][1]==a[i+len-1][1]);
		int res=0;
		for(int i=1;i<=n;i++) for(int j=i;j<=n;j++) res+=ok[i][j];
		return res;
	}
	int hang()
	{
		memset(ok,0,sizeof(ok));
		for(int L=1;L<=m;L++)
		{
			memset(cnt,0,sizeof(cnt)); int ji=0;
			for(int R=L;R<=m;R++)
			{
				if(cnt[a[1][R]]&1) ji--;
				else ji++;
				cnt[a[1][R]]++;
				ok[L][R]=(ji<=1);
			}
		}
		int res=0;
		for(int i=1;i<=m;i++) for(int j=i;j<=m;j++) res+=ok[i][j];
		return res;
	}
	int main()
	{
		if(m==1) printf("%d\n",lie());
		else printf("%d\n",hang());
		return 0;
	}
};
struct Case2
{
	int cnt[105][128];
	inline bool check(int R1,int C1,int R2,int C2)
	{
		memset(cnt,0,sizeof(cnt));
		for(int i=R1;i<=R2;i++)
		{
			int ji=0;
			for(int j=C1;j<=C2;j++)
			{
				if(cnt[i][a[i][j]]&1) ji--;
				else ji++;
				cnt[i][a[i][j]]++;
			}
			if(ji>1) return 0;
		}
		for(int i=R1,j=R2;i<j;i++,j--)
			for(int k='a';k<='z';k++)
				if(cnt[i][k]!=cnt[j][k])
					return 0;
		return 1;
	}
	int main()
	{
		int res=0;
		for(int R1=1;R1<=n;R1++)
		for(int C1=1;C1<=m;C1++)
			for(int R2=R1;R2<=n;R2++)
			for(int C2=C1;C2<=m;C2++)
			{
				res+=check(R1,C1,R2,C2);
//				if(check(R1,C1,R2,C2)) printf("(%d,%d,%d,%d)\n",R1,C1,R2,C2);
			}
		printf("%d\n",res);
		return 0;
	}
};
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%s",a[i]+1);
	if(n==1||m==1) return (new Case1)->main();
	else return (new Case2)->main();
	return 0;
}
