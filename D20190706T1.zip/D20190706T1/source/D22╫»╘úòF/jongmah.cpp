#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=1e5+10;
int n,m,x,a[20],cnt[maxn],res1,res2,f[maxn][4][4][4],mx[maxn][4][4][4];
void Fake()
{
	m+=5;
	for(int i=1;i<=n;i++) { scanf("%d",&x); x+=5; cnt[x]++; }
	for(int i=6;i<=m;i++) if(cnt[i]>3)
	{
		int d=cnt[i]%3; if(d==0) d=3;
		res1+=(cnt[i]-d)/3;
		cnt[i]=d;
	}
	for(int i=6;i<=m;i++)
		for(int a=0;a<=cnt[i];a++)
		for(int b=0;b<=cnt[i-1];b++)
		for(int c=0;c<=cnt[i-2];c++)
		{
			int &now=f[i][a][b][c];
			now=max(now,mx[i-1][min(cnt[i-1],b)][min(cnt[i-2],c)][cnt[i-3]]+(a==3));
			for(int h=1;h<=a&&h<=b&&h<=c;h++)
				now=max(now,mx[i-1][cnt[i-1]-h][cnt[i-2]-h][cnt[i-3]]+h);
			int &nmx=mx[i][a][b][c];
			if(a>0) nmx=max(nmx,mx[i][a-1][b][c]);
			if(b>0) nmx=max(nmx,mx[i][a][b-1][c]);
			if(c>0) nmx=max(nmx,mx[i][a][b][c-1]);
			nmx=max(nmx,now);
			res2=max(res2,now);
		}
	printf("%d\n",res1+res2);
}
void BaoLi()
{
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	int res=0;
	do
	{
		int now=0;
		for(int i=3;i<=n;i++)
			if((a[i-2]==a[i-1]&&a[i-1]==a[i])||(a[i-2]+1==a[i-1]&&a[i-1]+1==a[i])) { now++; i+=2; }
		res=max(res,now);
	}
	while(next_permutation(a+1,a+1+n));
	printf("%d\n",res);
}
int main()
{
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n<=10) BaoLi();
	else Fake();
	return 0;
}
