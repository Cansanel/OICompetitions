#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long LL;
struct DT { int a,b; };
inline bool operator<(const DT &l,const DT &r) { return l.a-l.b>r.a-r.b; }
const int maxn=5e5+5;
int n; DT p[maxn];
int main()
{
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<n;i++) scanf("%d%d",&p[i].a,&p[i].b);
	sort(p,p+n);
	LL res=0;
	for(int i=0;i<n;i++) res+=i*p[i].a;
	for(int i=0;i<n;i++) res+=i*p[n-i-1].b;
	cout<<res<<endl;
	return 0;
}
