#include <cstdio>
#include <ctime>
#include <algorithm>

const int MAXN = 1e5 + 7;

int n, m, c[MAXN], ans;
double sta;

inline bool can1(int now)
{
	if (c[now] >= 3)
		return true;
	return false;
}

inline void choose1(int now)
{
	c[now] -= 3;
}

inline void unchoose1(int now)
{
	c[now] += 3;
}

inline bool can2(int now)
{
	if (now + 2 <= m && c[now] >= 1 && c[now + 1] >= 1 && c[now + 2] >= 1)
		return true;
	return false;
}

inline void choose2(int now)
{
	c[now]--, c[now + 1]--, c[now + 2]--;
}

inline void unchoose2(int now)
{
	c[now]++, c[now + 1]++, c[now + 2]++;
}

void dfs(int now, int cnt)
{
	if (clock() - sta >= 900)
	{
		printf("%d", n / 3);
		exit(0);
	}
	if (now > m)
	{
		ans = std::max(ans, cnt);
		return;
	}
	if (can1(now))
	{
		choose1(now);
		dfs(now, cnt + 1);
		unchoose1(now);
	}
	if (can2(now))
	{
		choose2(now);
		dfs(now, cnt + 1);
		unchoose2(now);
	}
	dfs(now + 1, cnt);
}

int main()
{
	freopen("jongmah.in", "r", stdin);
	freopen("jongmah.out", "w", stdout);
	sta = clock();
	scanf("%d%d", &n, &m);
	for (int i = 1, temp; i <= n; i++)
		scanf("%d", &temp), c[temp]++;
	dfs(1, 0);
	printf("%d", ans);
	return 0;
}
