#include <cstdio>
#include <algorithm>

typedef long long ll;

const int MAXN = 5e5 + 7;

int n, ab[MAXN];
ll ans;

bool cmp(int x, int y)
{
	return x > y;
}

int main()
{
	freopen("queue.in", "r", stdin);
	freopen("queue.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
	{
		int a, b;
		scanf("%d%d", &a, &b);
		ans += b * n - a;
		ab[i] = a - b;
	}
	std::sort(ab + 1, ab + n + 1, cmp);
	for (int i = 1; i <= n; i++)
		ans += ab[i] * i;
	printf("%lld", ans);
	return 0;
}
