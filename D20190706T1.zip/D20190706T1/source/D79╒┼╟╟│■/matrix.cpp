#include <cstdio>

int n, m;

int main()
{
	freopen("matrix.in", "r", stdin);
	freopen("matrix.out", "w", stdout);
	scanf("%d%d", &n, &m);
	printf("%d", (n * (n - 1) / 2 + n) * (m * (m - 1) / 2 + m));
	return 0;
}
