#include<bits/stdc++.h>
#define rep(i,j,k) for((i)=(j);(i)<=(k);++i)
using namespace std;
const int N = 1100000;
int n,i,l,k,g,L[N],a[N]; map<int,int> last;
int inline read(){
	char ch=getchar();int z=0,f=1;
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){z=z*10+ch-'0';ch=getchar();}
	return z*f;
}
int gcd(int x,int y){if(y==0)return x;return gcd(y,x%y);}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	n=read();
	rep(i,1,n){a[i]=read();L[i]=last[a[i]];last[a[i]]=i;}
	l = k = 1; g = 0;
	rep(i,2,n)
		if(L[i] >= l || gcd(abs(a[i] - a[i-1]),g) == 1){++k;l=i;g=0;}
		else g = gcd(abs(a[i] - a[i-1]),g);
	printf("%d\n",k);
	return 0;
}
