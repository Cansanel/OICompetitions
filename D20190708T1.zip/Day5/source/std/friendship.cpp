#include<bits/stdc++.h>
#define rep(i,j,k) for((i)=(j);(i)<=(k);++i)
#define per(i,j,k) for((i)=(j);(i)>=(k);--i)
using namespace std;
const int N = 2100000;
int dfn[N],last[N],f[N][2],low[N],du[N],a[N],dep[N],n,m,tot,x,y,t,op,k,i,j,u,v,cnt,tim;
struct edge{int v,next;}e[N]; 
struct query{int x,y;}Q[N];
int inline read(){
	char ch=getchar();int z=0,f=1;
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){z=z*10+ch-'0';ch=getchar();}
	return z*f;
}
void add(int u,int v){e[++cnt]=(edge){v,last[u]};last[u]=cnt;}
void dfs(int x){
	dfn[x]=++tim;
	for(int i=last[x];i;i=e[i].next){
		if(a[x]==0 || du[x]==1) f[e[i].v][0]=f[x][0]+1; else f[e[i].v][0]=0;
		if(a[x]==1 || du[x]==1) f[e[i].v][1]=f[x][1]+1; else f[e[i].v][1]=0;
		dep[e[i].v]=dep[x]+1; dfs(e[i].v);
	}
	low[x]=tim;
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	n=read();m=read();tot=0;
	rep(i,1,m){
		t=read();
		if(t==0){
			op=read();k=read();++n;
			rep(j,1,k){u=read();add(n,u);}
			a[n] = op; du[n] = k;
		}else{x=read();y=read();Q[++tot]=(query){x,y};}
	}
	per(i,n,1) if(!dfn[i]) dfs(i);
	rep(i,1,tot){
		u = Q[i].x; v = Q[i].y;
		if(dfn[u]<=dfn[v]&&low[v]<=low[u])
			if(f[v][0] >= dep[v] - dep[u]) puts("1");
			else puts("0");
		else if(dfn[v]<=dfn[u]&&low[u]<=low[v])
			if(f[u][1] >= dep[u] - dep[v]) puts("1");
			else puts("0");
		else puts("0");
	}
	return 0;
}
