#include<bits/stdc++.h>
#define rep(i,j,k) for((i)=(j);(i)<=(k);++i)
using namespace std;
typedef long long ll;
const int N = 1100000;
const ll inf = 1LL<<60;
struct node{ll j,val;}h1[N],h2[N];
bool operator <(node a,node b){return a.val>b.val;}
ll n,k,tot1,tot2,i,a[N],b[N],t1,t2,f[N];
int inline read(){
	char ch=getchar();int z=0,f=1;
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){z=z*10+ch-'0';ch=getchar();}
	return z*f;
}
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	n=read();k=read();tot1=1;
	rep(i,1,n)a[i]=read();
	rep(i,0,n-1)b[i]=read();
	rep(i,1,n)a[i]+=a[i-1];
	h1[0]=(node){0,b[0]};
	rep(i,1,n){
		t1 = t2 = inf;
		while(tot1){
			if(h1[0].j < i - k){pop_heap(h1,h1+tot1);--tot1;continue;}
			else if(h1[0].val < f[h1[0].j] - a[h1[0].j] + a[i]){
				h2[tot2++]=(node){h1[0].j,f[h1[0].j] - a[h1[0].j]};
				push_heap(h2,h2+tot2);
				pop_heap(h1,h1+tot1);--tot1;
				continue;
			}else break;
		}
		if(tot1) t1 = h1[0].val;
		while(tot2){
			if(h2[0].j < i - k){pop_heap(h2,h2+tot2);--tot2;continue;}
			else break;
		}
		if(tot2) t2 = h2[0].val + a[i];
		f[i] = min(t1,t2);
		h1[tot1++]=(node){i,f[i]+b[i]};
		push_heap(h1,h1+tot1);
	}
	printf("%lld\n",f[n]);
	return 0;
}
