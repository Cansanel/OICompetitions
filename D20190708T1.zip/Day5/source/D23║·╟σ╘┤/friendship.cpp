#include<bits/stdc++.h>
#define re register
using namespace std;
template <typename T>void read(T &x)
{
	x=0;char str=getchar();
	while(!isdigit(str))str=getchar();
	while(isdigit(str)){x=(x<<3)+(x<<1)+str-48;str=getchar();}
}
int buf[100],top;
template <typename T>void print(T x)
{
	if (!x)putchar('0');
	while(x)buf[++top]=x%10,x/=10;
	while(top)putchar(buf[top--]+48);
	putchar('\n');
}
const int maxn=500010;
int n,m,tot,a;
struct edge
{
	int to,nxt;
}e[maxn];
int head[maxn],cnt;
void add(int u,int v)
{
	e[++cnt].to=v;
	e[cnt].nxt=head[u];
	head[u]=cnt;
}
queue<int>q;
int ns,kk;
bool fuck;
void work1()
{
	int pd,op,k,x,y;
	tot=n;
	while(m--)
	{
		read(pd);
		if (!pd)
		{
			read(op);read(k);
			tot++;
			while(k--)
			{
				read(a);
				if (op)add(a,tot);
				else add(tot,a);
			}
		}
		else
		{
			read(x);read(y);
			q.push(x);
			fuck=0;
			while(!q.empty())
			{
				if (fuck)break;
				kk=q.front();q.pop();
				for (re int i=head[kk];i;i=e[i].nxt)
				{
					ns=e[i].to;
					if (ns==y)
					{
						fuck=1;
						break;
					}
					q.push(ns);
				}
			}
			while(!q.empty())q.pop();
			if (fuck)puts("1");
			else puts("0");
		}
	}
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	read(n);read(m);
	work1();
}
