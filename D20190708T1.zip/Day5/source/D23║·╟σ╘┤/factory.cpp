#include<bits/stdc++.h>
#define re register
using namespace std;
template <typename T>void read(T &x)
{
	x=0;char str=getchar();
	while(!isdigit(str))str=getchar();
	while(isdigit(str)){x=(x<<3)+(x<<1)+str-48;str=getchar();}
}
int buf[100],top;
template <typename T>void print(T x)
{
	if (!x)putchar('0');
	while(x)buf[++top]=x%10,x/=10;
	while(top)putchar(buf[top--]+48);
	putchar('\n');
}
const int maxn=100010;
int n,a[maxn],k,kk,ans;
int gcd(int x,int y){return y?gcd(y,x%y):x;}
map<int,bool>p;
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	read(n);
	for (re int i=1;i<=n;i++)read(a[i]);
	p[a[1]]=1;
	k=0;
	ans++;
	for (re int i=2;i<=n;i++)
	{
		if (p[a[i]])
		{
			p.clear();
			p[a[i]]=1;
			k=0;
			ans++;
		}
		else
		{
			kk=gcd(k,a[i]-a[i-1]);
			if (kk<0)kk=-kk;
			if (kk>1)
			{
				k=kk;
				p[a[i]]=1;
			}
			else
			{
				k=0;
				ans++;
				p.clear();
				p[a[i]]=1;
			}
		}
	}
	print(ans);
	return 0;
}
