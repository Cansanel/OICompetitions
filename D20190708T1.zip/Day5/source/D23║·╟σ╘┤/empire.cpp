#include<bits/stdc++.h>
#define re register
#define ttt first
#define ps second
using namespace std;
template <typename T>void read(T &x)
{
	x=0;char str=getchar();
	while(!isdigit(str))str=getchar();
	while(isdigit(str)){x=(x<<3)+(x<<1)+str-48;str=getchar();}
}
int buf[100],top;
template <typename T>void print(T x)
{
	if (!x)putchar('0');
	while(x)buf[++top]=x%10,x/=10;
	while(top)putchar(buf[top--]+48);
	putchar('\n');
}
const int maxn=500010,inf=2147483647;
int n,k;
long long a[maxn],b[maxn],pre[maxn];
long long f[maxn];
pair<long long,long long>kk;
priority_queue<pair<long long,long long> >q;
void work2()
{
	for (re int i=1;i<=n;i++)read(a[i]),pre[i]=pre[i-1]+a[i];
	for (re int i=0;i<n;i++)read(b[i]);
	memset(f,0x7f,sizeof(f));
	f[0]=0;
	kk=make_pair(0,0);
	q.push(kk);
	for (re int i=1;i<=n;i++)
	{
		while(q.top().ps<max(0,i-k))q.pop();
		while(1)
		{
			kk=q.top();
			if ( kk.ttt!=f[kk.ps]+max(pre[i]-pre[kk.ps],b[kk.ps]) )
			{
				q.pop();
				kk=make_pair( kk.ps,f[kk.ps]+max(pre[i]-pre[kk.ps],b[kk.ps]) );
			}
			else break;
		}
		kk=q.top();
		f[i]=kk.ttt;
		kk=make_pair(f[i]+b[i],i);
		q.push(kk);
	}
	print(f[n]);
}
void work1()
{
	for (re int i=1;i<=n;i++)read(a[i]),pre[i]=pre[i-1]+a[i];
	for (re int i=0;i<n;i++)read(b[i]);
	f[0]=0;
	for (re int i=1;i<=n;i++)
	{
		for (re int j=max(0,i-k);j<i;j++)
		{
			if (!f[i])f[i]=f[j]+max(pre[i]-pre[j],b[j]);
			f[i]=min(f[i],f[j]+max(pre[i]-pre[j],b[j]));
		}
	}
	print(f[n]);
}
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	read(n);read(k);
	if (n<=10000)work1();
	else work2();
	return 0;
}
