#include<bits/stdc++.h>
using namespace std;
map <int,bool> ma[500007];
map <int,int> mm[500007];
int num[500007];
inline int read()
{
	int x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x;
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	int n=read(),m=read(),g,op,k,a,b;
	for(int i=1;i<=m;i++)
	{
		g=read();
		if(g==0)
		{
			op=read();k=read();++n;
			if(op==0)
			for(int j=1;j<=k;j++)
			{
				a=read();
				ma[a][n]=1;
				mm[a][++num[a]]=n;
			}
			else
			for(int j=1;j<=k;j++)
			{
				a=read();
				ma[n][a]=1;
				mm[n][++num[n]]=a;
				for(int k=1;k<=num[a];k++)
				{
					ma[n][mm[a][k]]=1;
					mm[n][++num[n]]=mm[a][k];
				}
			}
		}
		else
		{
			a=read();b=read();
			if(ma[b][a]==1)printf("1\n");
			else printf("0\n");
		}
	}
	return 0;
}
