#include<bits/stdc++.h>
using namespace std;
map <int,bool> m[100007];
inline int read()
{
	int x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x;
}
inline int gcd(int x,int y)
{
	if(x<y)swap(x,y);
	if(y==0)return x;
	else return gcd(y,x%y);
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	int n=read(),a,b,c,gcd_now,ans=1;
	bool t=1;
	b=read();
	for(int i=2;i<=n;i++)
	{
		a=read();
		c=abs(a-b);
		gcd_now=gcd(c,gcd_now);
		if(gcd_now==1||m[ans][a]==1)
		{
			ans++;
			gcd_now=0;
		}
		m[ans][a]=1;
		b=a;
	}
	printf("%d\n",ans);
	return 0;
}

