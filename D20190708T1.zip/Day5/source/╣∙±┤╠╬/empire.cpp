#include<bits/stdc++.h>
using namespace std;
long long dp[500007],n,k,a[500007],b[500007],sum[500007];
bool t1,t2;
inline int read()
{
	int x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x;
}
inline void write_in()
{
	n=read(),k=read();
	for(int i=1;i<=n;i++)
	a[i]=read(),sum[i]=sum[i-1]+a[i];
	for(int i=0;i<n;i++)
	{	
		b[i]=read();
		if(b[i]!=1)t1=1;
		if(b[i]!=a[i+1])t2=1;
	}
}
inline void work1()
{
	printf("%lld\n",sum[n]);
	return;
}
inline void work2()
{
	memset(dp,0x3f,sizeof(dp));
	dp[0]=0;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=k;j++)
	{
		if(i-j<0)break;
		dp[i]=min(dp[i],dp[i-j]+max(sum[i]-sum[i-j],b[i-j]));
	}
	printf("%lld\n",dp[n]);
}
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	write_in();
	if(t1==0||t2==0||n==k)work1();
	else work2();
	return 0;
}
