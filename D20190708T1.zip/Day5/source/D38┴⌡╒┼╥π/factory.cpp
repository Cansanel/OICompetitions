#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
int n;
const int MAXN=1e6+10;
int wei[MAXN];
int ans=0x3f3f3f3f;
struct node{
  int cnt;
  vector<int> c;
}dp[MAXN][3];
int absq(int a,int b)
{
  return a>=b?a-b:b-a;
}
int min(int a,int b)
{
  return a<=b?a:b;
}
int gcd(int x,int y)
{
  if(x==0&&y==0)  return 1;
  if(x*y==0&&x+y!=0)  return x+y;
  return gcd(y,x%y);
}
bool check(node ab,int x)
{
  ab.c.push_back(x);
  sort(ab.c.begin(),ab.c.end());
  int k=ab.c[1]-ab.c[0];
  for(int i=1;i<ab.c.size();i++)
  {
  	int t=ab.c[i]-ab.c[i-1];
  	int q=gcd(k,t);
  	if(t==0||q==1)  return 0;
  	k=q;
  }
  return 1;
}
int main()
{
  freopen("factory.in","r",stdin);
  freopen("factory.out","w",stdout);
  scanf("%d",&n);
  for(int i=1;i<=n;i++)
  {
  	dp[i][0].cnt=0x3f3f3f3f;
  	dp[i][1].cnt=0x3f3f3f3f;
  }
  for(int i=1;i<=n;i++)  scanf("%d",&wei[i]);
  dp[1][0].cnt=1;
  dp[1][0].c.push_back(wei[1]);
  for(int i=2;i<=n;i++)
  {
  	dp[i][0].cnt=min(dp[i-1][0].cnt,dp[i-1][1].cnt)+1;
  	dp[i][0].c.push_back(wei[i]);
  	int judge=0;
  	if(check(dp[i-1][0],wei[i]))
	  if(dp[i][1].cnt>dp[i-1][0].cnt)
	  {
	  	judge=1;
	  	dp[i][1]=dp[i-1][0];
	  }
  	if(check(dp[i-1][1],wei[i]))
	  if(dp[i][1].cnt>dp[i-1][1].cnt)
	  {
	  	judge=2;
	  	dp[i][1]=dp[i-1][1];
	  }
	if(judge==1)
	{
	  for(int j=0;i<dp[i-1][0].c.size();j++)
	    dp[i][1].c.push_back(dp[i-1][0].c[j]);
	  dp[i][1].c.push_back(wei[i]);
	  sort(dp[i][1].c.begin(),dp[i][1].c.end());
	}
	if(judge==2)
	{
	  for(int j=0;i<dp[i-1][1].c.size();j++)
	    dp[i][1].c.push_back(dp[i-1][1].c[j]);
	  dp[i][1].c.push_back(wei[i]);
	  sort(dp[i][1].c.begin(),dp[i][1].c.end());
	}
  }
  printf("%d\n",min(dp[n][0].cnt,dp[n][1].cnt));
  return 0;
}
