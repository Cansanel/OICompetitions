#include <cstdio>
#include <cstring>
#include <vector>
#include <queue>
using namespace std;
const int MAXN=7e5+5e4+10;
int n,m;
vector<int> adj[MAXN];
int num;
bool vis[250010];
queue<int> q;
bool check(int sx,int ex)
{
  while(!q.empty())  q.pop();
  memset(vis,0,sizeof(vis));
  q.push(sx);
  while(!q.empty())
  {
  	int cur=q.front();
  	q.pop();
  	for(int i=0;i<adj[cur].size();i++)
  	{
  	  int t=adj[cur][i];
  	  if(vis[t])  continue;
  	  if(t==ex)  return 1;
  	  vis[t]=1;
  	  q.push(t);
  	}
  	
  }
  
  return 0;
  
}



int main()
{
  freopen("friendship.in","r",stdin);
  freopen("friendship.out","w",stdout);
  scanf("%d %d",&n,&m);
  num=n+1;
  for(int i=1;i<=m;i++)
  {
  	int sec;
  	scanf("%d",&sec);
  	if(sec==0)
  	{
  	  int lec,k,x;
  	  scanf("%d %d",&lec,&k);
  	  for(int i=1;i<=k;i++)
  	  {
  	  	scanf("%d",&x);
  	  	if(lec==0)  adj[num].push_back(x);
  	  	else  adj[x].push_back(num);
  	  }
  	  num++;
  	}else{
  	  int s,e;
  	  scanf("%d %d",&s,&e);
  	  if(check(s,e))  printf("1\n");
  	  else  printf("0\n");
  	}
  }
  return 0;
}
