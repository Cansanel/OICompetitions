#include <cstdio>
#include <cstring>
using namespace std;
int n,k;
long long dp[500010];
int b[500010];
long long sum[500010];
int minn(int a,int b)
{
  return a<=b?a:b;
}
long long min2(long long a,long long b)
{
  return a<=b?a:b;
}
int main()
{
  freopen("empire.in","r",stdin);
  freopen("empire.out","w",stdout);
  memset(dp,0x3f3f3f3f,sizeof(dp));
  scanf("%d %d",&n,&k);
  for(int i=1;i<=n;i++)
  {
  	scanf("%lld",&sum[i]);
  	sum[i]+=sum[i-1];
  }
  for(int i=0;i<n;i++)  scanf("%lld",&b[i]);
  dp[0]=0;
  for(int i=1;i<=n;i++)
  {
  	for(int j=1;j<=minn(k,i);j++)
  	{
  	  dp[i]=min2(dp[i],dp[i-j]+min2(sum[i]-sum[i-j],b[i-j]));
  	}
  }
  printf("%lld\n",dp[n]);
  return 0;
}
