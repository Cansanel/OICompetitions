#include<cstdio>
#include<cstring>
#include<iostream>
#include<cmath>
#include<algorithm>
#include<queue>
using namespace std;

int n,m;
struct Edge
{
	int u,v;
	int next;
}E[500005];
int header[500005],tot=0;
int v[500005];

void addEdge(int u,int v)
{
	E[++tot].u=u;E[tot].v=v;
	E[tot].next=header[u];header[u]=tot;
}

int ask(int a,int b)
{
	if(a==b) return 1;
	memset(v,0,sizeof(v));
	queue<int> q;
	q.push(a);v[a]=1;
	while(q.size()>0)
	{
		int x=q.front();q.pop();
		for(int i=header[x];i;i=E[i].next)
		{
			int y=E[i].v;
			if(v[y]) continue;
			if(y==b) return 1;
			v[y]=1;
			q.push(y);
		}
	}
	return 0;
}

int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	scanf("%d%d",&n,&m);
	int maxpoint=n;
	for(int i=1;i<=m;++i)
	{
		int oporask;
		scanf("%d",&oporask);
		if(oporask==0)
		{
			int op,num;
			scanf("%d%d",&op,&num);
			++maxpoint;
			if(op==0)
			{
				for(int i=1;i<=num;++i)
				{
					int endpoint;
					scanf("%d",&endpoint);
					addEdge(maxpoint,endpoint);
				}
			}
			if(op==1)
			{
				for(int i=1;i<=num;++i)
				{
					int endpoint;
					scanf("%d",&endpoint);
					addEdge(endpoint,maxpoint);
				}
			}
		}
		if(oporask==1)
		{
			int xx,yy;
			scanf("%d%d",&xx,&yy);
			printf("%d\n",ask(xx,yy));
		}
	}
	return 0;
}
