#include<cstdio>
#include<cstring>
#include<iostream>
#include<cmath>
#include<algorithm>
#include<set>
using namespace std;

int n;
int a[100005];

int gcd(int a,int b)
{
	return b?gcd(b,a%b):a;
}

int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	int ans=1;
	int gc=0;
	set<int> s;
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&a[i]);
	}
	s.insert(a[1]);
	for(int i=2;i<=n;++i)
	{
		gc=gcd(gc,abs(a[i]-a[i-1]));
		if(gc==1)
		{
			gc=0;++ans;
			s.clear();s.insert(a[i]);
			continue;
		}
		if(gc!=1&&*s.find(a[i])==*s.end()&&a[i]!=a[*s.end()])
			{s.insert(a[i]);continue;}
		if(gc!=1&&(*s.find(a[i])!=*s.end()||(*s.find(a[i])==*s.end()&&a[i]==a[*s.end()])))
		{
			gc=0;++ans;
			s.clear();s.insert(a[i]);
			continue;
		}
		if(gc!=1) s.insert(a[i]);
	}
	printf("%d\n",ans);
	return 0;
}
