#include<cstdio>
#include<cstring>
#include<iostream>
#include<cmath>
#include<algorithm>
using namespace std;

int n,k;
int a[500005],b[500005];
long long sum[500005];
long long f[500005];
long long sumb[500005];

long long minn(long long a,long long b)
{
	if(a<b) return a;
	return b;
}

long long maxx(long long a,long long b)
{
	if(a>b) return a;
	return b;
}

int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	scanf("%d%d",&n,&k);
	sum[0]=0;
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&a[i]);
		sum[i]=sum[i-1]+a[i];
	}
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&b[i-1]);
	}
	sumb[0]=b[0];
	for(int i=2;i<=n;++i)
	{
		sumb[i-1]=sum[i-2]+b[i-1];
	}
	if(sumb[n-1]!=n)
	{
		memset(f,0x3f,sizeof(f));
		f[0]=0;
		for(int i=1;i<=n;++i)
		{
			for(int j=1;j<=k;++j)
			{
				if(i-j>=0)
					f[i]=minn(f[i],f[i-j]+maxx(sum[i]-sum[i-j],b[i-j]));
			}
		}
		printf("%lld\n",f[n]);
	}
	if(sumb[n-1]==n)
	{
		printf("%lld\n",sum[n]);
	}
	return 0;
}
