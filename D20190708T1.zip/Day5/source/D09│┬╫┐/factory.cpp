#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <queue>
#include <stack>
#include <cmath>
#include <map>

#define submit

template <typename T>
void read(T& x)
{
    char c = getchar();
    for (x = 0; !isdigit(c); c = getchar());
    for (; isdigit(c); x = x * 10 + (c ^ 48), c = getchar());
}

int fact(int x)
{
    for (int i = 2, lim = (int)std::sqrt(x); i <= lim; ++i)
        if (x % i == 0)
            return i;
    return x;
}

int n, cnt = 1, d, r;
int a[1000010];

int main()
{
#ifdef submit
    freopen("factory.in", "r", stdin);
    freopen("factory.out", "w", stdout);
#endif
    read(n);
    read(a[1]);
    
    
    for (int i = 2; i <= n; ++i)
    {
        read(a[i]);
        if (d)
        {
            if ((a[i] - a[i - 1]) % d != r)
                ++cnt, d = 0, r = 0;
        }
        else
        {
            d = a[i] - a[i - 1];
            d = fact(d);
            r = (a[i] - a[i - 1]) % d;
        }
    }
    std::cout << cnt << std::endl;
    return 0;
} 
