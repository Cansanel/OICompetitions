#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <queue>
#include <stack>
#include <cmath>
#include <map>

#define submit

template <typename T>
void read(T& x)
{
    char c = getchar();
    for (x = 0; !isdigit(c); c = getchar());
    for (; isdigit(c); x = x * 10 + (c ^ 48), c = getchar());
}

int n, k, speC1 = 1, speC2 = 1;
int a[500010], b[500010];
long long s[500010], f[500010];

int main()
{
#ifdef submit
    freopen("empire.in", "r", stdin);
    freopen("empire.out", "w", stdout);
#endif
    read(n), read(k);
    for (int i = 1; i <= n; ++i)
        read(a[i]), s[i] = a[i] + s[i - 1];
    for (int i = 1; i <= n; ++i)
        read(b[i - 1]), speC1 &= (b[i - 1] == 1);
    for (int i = 1; i <= n; ++i)
        speC2 &= (a[i] == b[i - 1]);
    memset(f, 0x7f, sizeof f);
    f[0] = 0;
    if (!speC1)
    {
        for (int i = 0; i <= n; ++i)
        {
            for (int j = i + 1, lim = std::min(i + k, n); j <= lim; ++j)
                f[j] = std::min(f[j], f[i] + std::max((long long)b[i], s[j] - s[i]));
        }
    
        std::cout << f[n] << std::endl;
        return 0;
    }
    else
    {
        std::cout << s[n] << std::endl;
        return 0;
    }
}
