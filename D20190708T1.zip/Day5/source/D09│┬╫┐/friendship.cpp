#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <queue>
#include <stack>
#include <cmath>
#include <map>

#define submit

template <typename T>
void read(T& x)
{
    char c = getchar();
    for (x = 0; !isdigit(c); c = getchar());
    for (; isdigit(c); x = x * 10 + (c ^ 48), c = getchar());
}

struct Data
{
    int id, fa;
    Data(int id = 0, int fa = 0) : id(id), fa(fa) {}
};

int n, m, u, v, cntNode, cntQuery, typ, op, k, cntBlock;
int ans[250010], inDeg[250010], block[250010], vis[250010], tag[250010];
std::vector <int> g[250010], uG[250010];
std::vector <Data> q[250010];

void getBlock(int x)
{
    for (int i = 0, lim = uG[x].size(); i < lim; ++i)
    {
        int _t = uG[x][i];
        if (!block[_t])
            block[_t] = cntBlock, getBlock(_t);
    }
}

void dfs(int x)
{
    vis[x] = 1;
    
    for (int i = 0, lim = q[x].size(); i < lim; ++i)
    {
        Data _t = q[x][i];
        if (vis[_t.fa] && block[_t.fa] == block[x])
            ans[_t.id] = 1;
    }
    
    for (int i = 0, lim = g[x].size(); i < lim; ++i)
    {
        dfs(g[x][i]);
    }
}

int main()
{
#ifdef submit
    freopen("friendship.in", "r", stdin);
    freopen("friendship.out", "w", stdout);
#endif
    read(n), read(m);
    cntNode = n;
    for (int i = 1; i <= m; ++i)
    {
        read(typ);
        if (typ == 0)
        {
            read(op), read(k);
            ++cntNode;
            int _t = 0;
            if (op == 0)
            {
                for (int j = 1; j <= k; ++j)
                    read(_t), g[_t].push_back(cntNode), ++inDeg[cntNode],
                    uG[_t].push_back(cntNode), uG[cntNode].push_back(_t);
            }
            else
            {
                for (int j = 1; j <= k; ++j)
                    read(_t), g[cntNode].push_back(_t), ++inDeg[_t],
                    uG[_t].push_back(cntNode), uG[cntNode].push_back(_t);
            }
        }
        else
        {
            read(u), read(v);
            q[u].push_back(Data(++cntQuery, v));
        }
    }
    
    
    
    for (int i = 1; i <= n; ++i)
    {
        if (!block[i])
            block[i] = ++cntBlock, getBlock(i);
    }
    
    for (int i = 1; i <= cntNode; ++i)
        for (int j = 0, lim = q[i].size(); j < lim; ++j)
        {
            Data _t = q[i][j];
            if (block[i] != block[_t.fa])
                ans[_t.id] = 0;
            else
                tag[block[i]] = 1;
        }
    
    for (int i = 1; i <= cntNode; ++i)
    {
        if (tag[block[i]] && inDeg[i] == 0)
            dfs(i);
    }
    
    for (int i = 1; i <= cntQuery; ++i)
        printf("%d\n", ans[i]);
    return 0;
} 
