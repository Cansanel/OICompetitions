#include<bits/stdc++.h>
using namespace std;
set<int> q,p[755510];
int n,m,gg,tot,o,x,y,t,a[755510];
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);		
	cin>>n>>m;
	tot=n;
	for(int i=1;i<=n;i++)
	p[i].insert(i);
	for(int i=1;i<=m;i++)
	{
		cin>>o;
		if(!o)
		{
			cin>>gg;
			tot++;
			cin>>t;
			cin>>x;
			p[tot]=p[x];
			if(!gg)
			{
				for(int i=2;i<=t;i++)
				{
					cin>>x;
					for(set<int>::iterator it=p[tot].begin();it!=p[tot].end();it++)	
					{
						int z=p[x].size();
						p[x].insert(*it);
						if(p[x].size()!=z)
						{
							a[0]++,p[x].erase(*it);
							a[a[o]]=*it;
						}
					}
					for(int j=1;j<=a[0];j++)
					p[tot].erase(a[j]);
					a[0]=0;
				}
			}
			else
			for(int i=2;i<=t;i++)
			{
				cin>>x;
				for(set<int>::iterator it=p[x].begin();it!=p[x].end();it++)
				p[tot].insert(*it);
			}
		}
		if(o)
		{
			cin>>x>>y;
			q=p[y];
			for(set<int>::iterator it=p[x].begin();it!=p[x].end();it++)
			q.insert(*it);			
			if(q.size()==p[y].size())
			cout<<1<<endl;
			else
			cout<<0<<endl;
		}
	}
	return 0;
}
