#include<bits/stdc++.h>
using namespace std;
long long a[500010],c[500010],d[500010],e[500010];
int n,k,tot,t;
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);		
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	d[i]=5000000000001;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		e[i]=e[i-1]+a[i];
	}
	for(int i=0;i<n;i++)
	{
		cin>>c[i];	
		if(c[i]==1)
		tot++;
		if(c[i]==a[i-1])
		t++;
	}
	if(n==k||tot==n||t==n)
	{
		cout<<e[n]<<endl;
		return 0;
	}
	for(int i=1;i<=n;i++)
	for(int j=max(0,i-k);j<i;j++)
	d[i]=min(d[i],d[j]+max(c[j],e[i]-e[j]));
	cout<<d[n]<<endl;
	return 0;
}
