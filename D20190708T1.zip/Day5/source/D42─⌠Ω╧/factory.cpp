#include<bits/stdc++.h>
using namespace std;
int n,a[100010],ans,t=1,x=1;
set<int> q;
int ys(int x,int y)
{
	int z=x%y;
	while(z)
	{
		x=y,y=z;
		ys(x,y);
		z=x%y;
	}
	return y;
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);	
	cin>>n;
	cin>>a[1];
	q.insert(a[1]);
	for(int i=2;i<=n;i++)
	{
		cin>>a[i];		
		if(t==1)
		ans++,t=abs(a[i]-a[i-1]),x=0,q.clear();	
		else
		t=ys(abs(a[i]-a[i-1]),t);
		q.insert(a[i]);	
		x++;
		if(x!=q.size())
		{
			t=1;q.clear();q.insert(a[i]);x=1;
		}	
	}	
	if(t==1)
	ans++;
	cout<<ans<<endl;
	return 0;
}
