#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
int head[1000000],ver[1000000],next[1000000];
int n,m,i,j,k,t,p,q,x,y,tot;
int read(){
	int x=0;
	char c=getchar();
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9') x=(x<<3)+(x<<1)+c-'0',c=getchar();
	return x;
}
void add(int x,int y){
	ver[++tot]=y,next[tot]=head[x],head[x]=tot;
}
void dfs(int root){
	if (q==1) return;
	if (root==y) {q=1;return;}
	for (int i=head[root];i;i=next[i])
		dfs(ver[i]);
	return;
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	n=read(),m=read();
	do{
		t=read();
		if (t==0){
			p=read();
			k=read();
			n++;
			rep(i,1,k){
				x=read();
				if (p==0) add(n,x);
				else add(x,n);
			}
		}
		else{
			x=read(),y=read();
			q=0;
			dfs(x);
			cout<<q<<endl;
		}
		m--;	
	}while (m>0);
	return 0;
}
/*
3 5
0 0 2 1 2 
1 1 4
0 1 2 3 4 
1 4 5
1 4 2

*/
