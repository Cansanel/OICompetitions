#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <set>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
set <int> s;
int a[1000001],ans,i,j,k,n,t;
int read(){
	int x=0;
	char c=getchar();
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9') x=(x<<3)+(x<<1)+c-'0',c=getchar();
	return x;
}
int gcd(int a,int b){
	while (b) b^=a^=b^=a%=b;
	return a;
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	n=read();
	rep(i,1,n) a[i]=read();
	ans=1;
	rep(i,1,n-1){
		t++;
		if (t==1){
			if (a[i]==a[i+1]-1||a[i]==a[i+1]){ans++;t=0;continue;}
			k=abs(a[i]-a[i+1]);
			s.insert(a[i]);
			s.insert(a[i+1]);
		}
		else {
			k=gcd(k,abs(a[i]-a[i+1]));
			if (k==1||(!s.insert(a[i+1]).second)){
				ans++;
				t=0;
				s.clear();
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}
/*
7
1 5 11 2 6 4 7

8
4 2 6 8 5 3 1 7

3
2 4 2

*/
