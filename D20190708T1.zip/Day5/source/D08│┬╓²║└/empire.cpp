#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
long long f[1000001],a[1000001],b[1000001],sum[1000001];
int n,m,i,j,k;
int read(){
	int x=0;
	char c=getchar();
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9') x=(x<<3)+(x<<1)+c-'0',c=getchar();
	return x;
}
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	n=read(),k=read();
	rep(i,1,n) a[i]=read();
	rep(i,1,n) b[i]=read();
	rep(i,1,n) f[i]=1e17;
	rep(i,1,n) sum[i]=sum[i-1]+a[i];
	rep(i,1,n)
		for (j=i-1;j>=0&&j>=i-k;j--)
			f[i]=min(f[i],f[j]+max(sum[i]-sum[j],b[j+1]));
	cout<<f[n]<<endl;
	return 0;
}
/*
4 2
4 3 2 1
1 2 4 4


4 2 
4 3 2 1 
1 2 10 3

*/
