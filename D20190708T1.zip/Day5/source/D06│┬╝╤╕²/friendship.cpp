#include <bits/stdc++.h>
using namespace std;
typedef int ll;
const ll maxn = 500050;
ll n,m,fa[maxn],tot,pd,cur,ix,iy,k,ipd;
vector<ll> e[maxn];
vector<ll> tem;
bool vis[maxn];
bool check(ll x,ll y)
{
	vis[x] = 1;
	if(x == y)return true;
	for(int i = 0;i < e[x].size();i++)
	{
		if(vis[e[x][i]])continue;
		if(check(e[x][i],y))return true;
	}
	return false;
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	cin>>n>>m;
	tot = n;
	while(m--)
	{
		cin>>pd;
		if(pd == 0)
		{
			cin>>ipd>>k;
			tot++;
			tem.clear();
			if(k == 1)
			{
				cin>>cur;
				e[cur].push_back(tot);
				e[tot].push_back(cur);
				continue;
			}
			for(int i = 1;i <= k;i++)
			{
				cin>>cur;
				tem.push_back(cur);
			}
			for(int i = 0;i < tem.size();i++)
			{
				if(ipd == 1)
				{
					e[tot].push_back(tem[i]);
				}
				else
				{
					e[tem[i]].push_back(tot);
				}
			}
		}
		else
		{
			memset(vis,0,sizeof(vis));
			cin>>ix>>iy;
			if(check(iy,ix))
			{
				cout<<"1"<<"\n";
			}
			else cout<<"0"<<"\n";
		}
	}
	return 0;
}
/*
3 5
0 0 2 1 2
1 1 4
0 1 2 3 4
1 4 5
1 4 2
2 2
0 0 1 1
1 1 3
*/
