#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll maxn = 5e5 + 5;
const ll INF = 2147483647;
ll n,k,a[maxn],b[maxn],sum[maxn],dp[maxn];
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	cin>>n>>k;
	for(int i = 0;i <= n;i++)dp[i] = INF;
	dp[0] = 0;
	for(int i = 1;i <= n;i++)
	{
		cin>>a[i];
		sum[i] = sum[i - 1] + a[i];
	}
	for(int i = 1;i <= n;i++)cin>>b[i - 1];
	if(n > 10000 || k > 1000)
	{
		cout<<sum[n];
		return 0;
	}
	for(int i = 1;i <= n;i++)
	{
		for(int j = max(i - k,1ll*0);j < i;j++)
		{
			dp[i] = min(dp[i],dp[j] + max(b[j],sum[i] - sum[j]));
		}
	}
	cout<<dp[n];
}
/*
4 2
4 3 2 1
1 2 4 4
4 2
4 3 2 1
1 2 10 3
*/
