#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll maxn = 1e5 + 5;
ll n,a[maxn],diff[maxn],res,tem,cur,st;
map<ll,ll>tot;
map<ll,ll>re;
map<pair<ll,ll>,ll>m;
ll gcd(ll x,ll y)
{
	if(y == 0)return x;
	return gcd(y,x%y);
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	cin>>n;
	res = 1;
	for(int i = 1;i <= n;i++)
	{
		cin>>a[i];
		tot[a[i]]++;
		re[i] = tot[a[i]];
		m[make_pair(a[i],tot[a[i]])] = i;
		if(i > 1)diff[i - 1] = a[i] - a[i - 1];	
		if(diff[i - 1] < 0)diff[i - 1] = -diff[i - 1];
	}
	st = 1;
	for(int i = 1;i < n;i++)
	{
		tem = gcd(cur,diff[i]);
		if(tem == 1||tem == 0)
		{
			res++;
			cur = 0;
			st = i + 1;
			continue;
		}
		else
		{
			if(m[make_pair(a[i + 1],re[i + 1] - 1)] >= st)
			{
				res++;
				cur = 0;
				st = i + 1;
				continue;
			}
			cur = tem;
		}
	}
	cout<<res;
	return 0;
}
/*
7
1 5 11 2 6 4 7
 4 6 -9 4 -2 3 
1 3 5 7 9 11
2 4 6 8 10
1 10 7 5
9
2 4 2 6 2 8 2 10 2
 2 2
5
1 5 4 3 2
7
1 2 2 2 3 4 5
5
10 7 16 22 19 
 -3 9  6  -3
 */
