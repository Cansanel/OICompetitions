#include <bits/stdc++.h>
using namespace std;

const int maxn=500005;
const int inf=0x3f3f3f3f;
int dp[maxn];

struct Node{
	int j;long long val;
	bool operator < (const Node &a)const{
		return val>a.val;
	}
};

priority_queue <Node> q1,q2;

int n,k,ppp;
int a[maxn],b[maxn],sum[maxn];

int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	scanf("%d%d",&n,&k);
	for (int i=1;i<=n;++i){
		scanf("%d",a+i);
		sum[i]=sum[i-1]+a[i];
	}
	memset(dp,inf,sizeof dp);
	dp[0]=0;
	for (int i=0;i<n;++i){
		scanf("%d",b+i);
//		if (b[i]!=1)ppp=1;
	}
//	if (!ppp){
//		puts("-1");
//		return 0;
//	}
	for (int i=1;i<=n;++i){
		q1.push((Node){i-1,dp[i-1]+b[i-1]});
		while (!q1.empty()){
			Node nw=q1.top();
			if (i-nw.j>k)q1.pop();else break;
		}
		while (!q2.empty()){
			Node nw=q2.top();
			if (i-nw.j>k)q2.pop();else break;
		}
		while (!q1.empty()){
			Node nw=q1.top();
			if (nw.val>dp[nw.j]+sum[i]-sum[nw.j])break;
			q1.pop();
			q2.push((Node){nw.j,dp[nw.j]-sum[nw.j]});
		}
		while (!q2.empty()){
			Node nw=q2.top();
			if (i-nw.j>k)q2.pop();else break;			
		}
		long long tmp=inf;
		if (!q1.empty())tmp=min(tmp,q1.top().val);
		if (!q2.empty())tmp=min(tmp,q2.top().val+sum[i]);
		dp[i]=tmp;
	}
//	if (n==k)puts("0");else
	printf("%d\n",dp[n]);
	return 0;
}

