#include <bits/stdc++.h>
using namespace std;
const int maxn=700005;
int n,m,crg,kkk;
struct Node{
	int to,nxt;
}edge[maxn];
int head[maxn];
inline int read(){
	int x=0,neg=1;
	char ch=getchar();
	while (!isdigit(ch)){
		if (ch=='-')neg=-1;
		ch=getchar();
	}
	while (isdigit(ch)){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*neg;
}
inline void add(int u,int v){
	edge[++crg]=(Node){v,head[u]};
	head[u]=crg;
}
inline bool dfs(int u,int fa,int des){
	if (u==des)return 1;
	bool f=0;
	for (register int i=head[u];i!=0;i=edge[i].nxt){
		int v=edge[i].to;
		if (v==fa)continue;
		if (dfs(v,u,des)){
			f=1;
			break;
		}
	}
	return f;
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	n=read();
	m=read();
	kkk=n;
	while (m--){
		int op;
		op=read();
		if (op){
			int x,y;
			x=read();y=read();
			puts(dfs(x,x,y)?"1":"0");
		}else{
			int k,opp;
			opp=read();k=read();
			kkk++;
			if (k==1){
				int u;
				u=read();
				add(u,kkk);
				add(kkk,u);
				continue;
			}
			if (opp){
				for (register int i=1;i<=k;++i){
					int u;
					u=read();
					add(u,kkk);
				}
			}else{
				for(register int i=1;i<=k;++i){
					int u;
					u=read();
					add(kkk,u);
				}
			}
		}
	}
}
/*
for (int i=head[u];i!=0;i=edge[i].nxt){
	
}
*/
