#include <bits/stdc++.h>
using namespace std;

const int maxn=100005;

int n,cnt=0;
long long num[maxn],cha[maxn];
set <int> st;

int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;++i){
		scanf("%d",num+i);
	}
	int x=0,l=1;
	while (l<=n){
		int r=l+1;
		long long g=abs(num[r]-num[l]);
		st.insert(num[l]);
		while (r<=n && (__gcd(g,abs(num[r]-num[l]))!=1) && st.find(num[r])==st.end()){
			st.insert(num[r]);
			r++;
			g=__gcd(g,abs(num[r]-num[l]));
		}
		l=r;cnt++;st.clear();
	}
	printf("%d\n",cnt);
	return 0;
}
