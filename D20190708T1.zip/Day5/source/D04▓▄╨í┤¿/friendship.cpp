#include <bits/stdc++.h>
#define ll long long
#define RG register
#define U(x, y, z) for(RG int x = y; x <= z; ++x)
#define D(x, y, z) for(RG int x = y; x >= z; --x)
using namespace std;
inline void FO(string s){
	freopen((s + ".in").c_str(), "r", stdin);
	freopen((s + ".out").c_str(), "w", stdout);
}
template <typename T> inline void read(T &n){
	n = 0; char c; T f = 1;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) n = (n << 1) + (n << 3) + (c ^ 48);
	n *= f;
}
template <typename T> inline void write(T n){
	if (n < 0){
		n = -n;
		putchar('-');
	}
	if (n > 9) write(n / 10);
	putchar('0' + n % 10);
}
template <typename T> inline void writeln(T n){
	write(n);
	putchar('\n');
}
template <typename T> inline void writesp(T n){
	write(n);
	putchar(' ');
}
template <typename T> inline void chkmin(T &x, T y){
	x = x < y ? x : y;
}
template <typename T> inline void chkmax(T &x, T y){
	x = x > y ? x : y;
}
int cnt, n, m;
int head[500010];
struct edge{
	int nxt, v;
}e[500010];
inline void add_edge(int u, int v){
	++cnt;
	e[cnt].v = v;
	e[cnt].nxt = head[u];
	head[u] = cnt;
}
inline bool check(int S, int T){
	queue<int> Q;
	Q.push(S);
	while (!Q.empty()){
		int x = Q.front();
		Q.pop();
		if (x == T){
			return 1;
		}
		for (RG int i = head[x]; i; i = e[i].nxt)
			Q.push(e[i].v);
	}
	return 0;
}	
int main(){
	FO("friendship");
	read(n), read(m);
	int tot = 0;
	for (int i = 1; i <= m; i++){
		int cz, opt, k;
		read(cz), read(opt), read(k);
		if (cz == 0){
			++tot;
			U(i, 1, k){
				int v;
				read(v);
				if (opt == 0) add_edge( v,n + tot);
				else add_edge(n + tot, v);
			}                        
		}                 
		else{
			writeln(check(k, opt));
		}
	}
	return 0;
}
