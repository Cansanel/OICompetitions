#include <bits/stdc++.h>
#define ll long long
#define RG register
#define U(x, y, z) for(RG int x = y; x <= z; ++x)
#define D(x, y, z) for(RG int x = y; x >= z; --x)
using namespace std;
inline void FO(string s){
	freopen((s + ".in").c_str(), "r", stdin);
	freopen((s + ".out").c_str(), "w", stdout);
}
template <typename T> inline void read(T &n){
	n = 0; char c; T f = 1;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) n = (n << 1) + (n << 3) + (c ^ 48);
	n *= f;
}
template <typename T> inline void write(T n){
	if (n < 0){
		n = -n;
		putchar('-');
	}
	if (n > 9) write(n / 10);
	putchar('0' + n % 10);
}
template <typename T> inline void writeln(T n){
	write(n);
	putchar('\n');
}
template <typename T> inline void writesp(T n){
	write(n);
	putchar(' ');
}
template <typename T> inline void chkmin(T &x, T y){
	x = x < y ? x : y;
}
template <typename T> inline void chkmax(T &x, T y){
	x = x > y ? x : y;
}
int n, a[100010];
inline int gcd(int a, int b){
	if (b == 0) return a;
	return gcd(b, a % b);
}
int main(){
	FO("factory");
	read(n);
	U(i, 1, n) read(a[i]);
	int ys = 0;
	int tot = 1;
	U(i, 2, n){
		ys = gcd(ys, abs(a[i] - a[i - 1]));
		if (ys == 1){
			++tot;
			ys = 0;
		}
	}
	write(tot);
	return 0;
}
