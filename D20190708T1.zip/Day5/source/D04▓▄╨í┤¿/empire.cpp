#include <bits/stdc++.h>
#define ll long long
#define RG register
#define U(x, y, z) for(RG int x = y; x <= z; ++x)
#define D(x, y, z) for(RG int x = y; x >= z; --x)
using namespace std;
inline void FO(string s){
	freopen((s + ".in").c_str(), "r", stdin);
	freopen((s + ".out").c_str(), "w", stdout);
}
template <typename T> inline void read(T &n){
	n = 0; char c; T f = 1;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) n = (n << 1) + (n << 3) + (c ^ 48);
	n *= f;
}
template <typename T> inline void write(T n){
	if (n < 0){
		n = -n;
		putchar('-');
	}
	if (n > 9) write(n / 10);
	putchar('0' + n % 10);
}
template <typename T> inline void writeln(T n){
	write(n);
	putchar('\n');
}
template <typename T> inline void writesp(T n){
	write(n);
	putchar(' ');
}
template <typename T> inline void chkmin(T &x, T y){
	x = x < y ? x : y;
}
template <typename T> inline void chkmax(T &x, T y){
	x = x > y ? x : y;
}
int n, k;
int f[10010], a[500010], b[500010];
int main(){
	FO("empire");
	read(n), read(k);
	U(i, 1, n){
		read(a[i]);
	}
	U(i, 1, n){
		read(b[i]);
	}
	U(i, 1, n){
		a[i] += a[i - 1];
	}
	if (n * k <= 10000000){
		memset(f, 0x7f, sizeof f);
		f[0] = 0;
		U(i, 1, n){
			U(j, max(i - k, 0), i - 1)
				chkmin(f[i], f[j] + max(b[j + 1], a[i] - a[j]));
		}
		cout << f[n] << endl;
	}
	else cout << a[n] << endl;
	return 0;
}

