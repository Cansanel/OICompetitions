#include <bits/stdc++.h>
using namespace std;
#define fir first
#define sec second
#define mp(x,y) make_pair(x,y)
const int maxn = 500010;
typedef long long ll;
const ll inf = 0x3f3f3f3f3f3f3f3f;
ll read() {
	ll res = 0, f = 1; char c = getchar();
	while(c != '-' && (c < '0' || c > '9')) c = getchar(); if(c == '-') f = -1, c = getchar();
	while(c >= '0' && c <= '9') res = (res << 3) + (res << 1) + c - '0', c = getchar(); return res * f;
}
ll n, k, a[maxn], b[maxn], s[maxn], f[maxn];
void work1() {
	memset(f, 0x3f, sizeof(f));
	f[0] = 0;
	for(int i = 1; i <= n; i++) {
		for(int j = max(0ll, i - k); j < i; j++) 
			f[i] = min(f[i], f[j] + max(b[j], s[i] - s[j]));
	}
}
int pos[maxn], q[maxn];
vector<int>  rev[maxn];
set< pair<ll, int> > se;
ll calc(int x) {
	return f[x] + b[x];
}
void work2() {
	memset(f, 0x3f, sizeof(f)); f[0] = 0;
	int head = 1, tail = 0;
	for(int i = 0; i <= n; i++) {
		for(int j = 0; j < rev[i].size(); j++) 
			if(rev[i][j] + k >= i) se.insert(mp(f[rev[i][j]] - s[rev[i][j]], rev[i][j]));
		while(se.size() && (*se.begin()).sec + k < i) se.erase(se.begin());
		if(se.size()) f[i] = min(f[i], (*se.begin()).fir + s[i]);
//		cout << i << ' ' << f[i] << endl;
		while(head <= tail && (q[head] + k < i || pos[q[head]] <= i)) head++;
		if(head <= tail) f[i] = min(f[i], f[q[head]] + b[q[head]]);
		pos[i] = lower_bound(s + 1, s + 1 + n, b[i] + s[i]) - s;
//		cout << i << ' ' << f[i] << ' ' << pos[i] << endl;
		rev[pos[i]].push_back(i);
		if(i < pos[i]) {
			while(head <= tail && calc(q[tail]) >= calc(i)) tail--;
			q[++tail] = i;
		}
	}
}
int main() {
	freopen("empire.in", "r", stdin);
	freopen("empire.out", "w", stdout);
	n = read(); k = read();
	for(int i = 1; i <= n; i++) a[i] = read(), s[i] = s[i-1] + a[i];
	for(int i = 0; i < n; i++) b[i] = read();
	if(n * k <= 10000000) work1();
	else work2();
//	work2();
	printf("%lld\n", f[n]);
	return 0;
}
