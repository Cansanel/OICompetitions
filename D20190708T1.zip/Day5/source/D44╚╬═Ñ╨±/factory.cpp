#include <bits/stdc++.h>
using namespace std;
const int maxn = 100010;
int read() {
	int res = 0, f = 1; char c = getchar();
	while(c != '-' && (c < '0' || c > '9')) c = getchar(); if(c == '-') f = -1, c = getchar();
	while(c >= '0' && c <= '9') res = (res << 3) + (res << 1) + c - '0', c = getchar(); return res * f;
}
int n, a[maxn], ans, b[maxn], c[maxn];
int gcd(int x, int y) {
	if(!x) return y;
	return gcd(y % x, x);
}
int main() {
	freopen("factory.in", "r", stdin);
	freopen("factory.out", "w", stdout);
	n = read(); 
	for(int i = 1; i <= n; i++) b[i] = read();
	for(int i = 1; i < n; i++) a[i] = abs(b[i] - b[i+1]);
	memset(c, -1, sizeof(c));
	a[n] = 1; c[b[1]] = 0;
	for(int i = 1, t = 0; i <= n; i++) {
		int h = gcd(a[i], t);
		if(h == 1 || c[b[i + 1]] == ans) ans++, t = 0;
		else t = h;
		c[b[i + 1]] = ans;
	}
	printf("%d\n", ans);
	return 0;
}
