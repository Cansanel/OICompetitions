#include <bits/stdc++.h>
using namespace std;
const int maxn = 10010;
int read() {
	int res = 0, f = 1; char c = getchar();
	while(c != '-' && (c < '0' || c > '9')) c = getchar(); if(c == '-') f = -1, c = getchar();
	while(c >= '0' && c <= '9') res = (res << 3) + (res << 1) + c - '0', c = getchar(); return res * f;
}
bitset<maxn> od[maxn], id[maxn];
int n;
int main() {
	freopen("friendship.in", "r", stdin);
	freopen("friendship.out", "w", stdout);
	int Q; n = read(); Q = read();
	for(int i = 1; i <= n; i++) id[i].set(i), od[i].set(i);
	while(Q--) {
		int o = read();
		if(o == 0) {
			int op = read(), k = read();
			++n; id[n].set(n); od[n].set(n);
			while(k--) {
				int x = read();
				if(op == 0) od[n] = od[n] | od[x];
				else id[n] = id[n] | id[x];
			}
			for(int i = 1; i < n; i++) {
				if(od[n][i]) id[i].set(n);
				if(id[n][i]) od[i].set(n);
			}
		} else {
			int x = read(), y = read();
			if(x == y) printf("1\n");
			else printf("%d\n", od[x][y] ? 1 : 0);
		}
	}
	return 0;
}
