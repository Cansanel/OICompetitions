#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define INF 0x3F3F3F3F

queue<int> q;
LL n, m;
LL a[500010], b[500010], c[500010], f[500010];

LL cost(LL x, LL y)
{
	return max(c[y - 1] - c[x - 1], b[x]);
}

int main()
{
	freopen("empire.in", "r", stdin);
	freopen("empire.out", "w", stdout);
	//more data needed to test
	ios::sync_with_stdio(false);
	
	cin >> n >> m;
	for (LL i = 1; i <= n; i++)
		cin >> a[i];
	for (LL i = 1; i <= n; i++)
		cin >> b[i];
	for (LL i = 1; i <= n; i++)
		c[i] = c[i - 1] + a[i];
	memset(f, 0x3F, sizeof(f));
	isall1 = true;
	for (LL i = 1; i <= n; i++)
		if (b[i] != 1) isall1 = false;
	if (isall1)
	{
		cout << c[n] << endl;
		return 0;
	}
	f[1] = 0;
	q.push(1);
	for (LL now = 2; now <= n + 1; now++)
	{
		q.push(now);
		while (true)
		{
			LL pr = q.front();
			if (pr == now)
				break;
			q.pop();
			if (now - pr > m) continue;
			if (f[now] > f[pr] + cost(pr, now))
				f[now] = f[pr] + cost(pr, now);
			else if (b[pr] >= b[now])
				continue;
			q.push(pr);
		}
	}
	cout << f[n + 1] << endl;

	return 0;
}

