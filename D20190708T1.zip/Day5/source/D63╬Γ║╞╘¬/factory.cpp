#include <bits/stdc++.h>
using namespace std;

int n, now, ans;
int a[100010], b[100010];
map<int, bool> f;

int gcd(int a, int b)
{
	if (a == 0 || b == 0) return max(a, b);
	int t;
	while (b > 0)
	{
		t = a % b;
		a = b;
		b = t;
	}
	return a;
}

int main()
{
	//Note: more cases needed to test
	freopen("factory.in", "r", stdin);
	freopen("factory.out", "w", stdout);
	ios::sync_with_stdio(false);
	
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
		b[i] = abs(a[i] - a[i - 1]);
	}
	ans++;
	for (int i = 2; i <= n; i++)
	{
		now = 0;
		if (i == 2) f[1] = true;
		while (gcd(now, b[i]) != 1 && i <= n && f[a[i]] == false)
		{
			now = gcd(now, b[i]);
			f[a[i]] = true;
			i++;
		}
		if (i <= n)
		{
			ans++;
			f.clear();
			f[a[i]] = true;
		}
	}
	cout << ans << endl;

	return 0;
}

