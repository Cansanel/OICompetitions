#include <bits/stdc++.h>
using namespace std;

#define INF 0x3F3F3F3F

vector<int> g[250010];
int f[250010][25], maxf[250010], fa[250010], tim[250010], a[250010], d[250010];
int n, m, op, k, tmp, x, y, tot;
bool isempty[250010];

struct prob
{
	int x, y, t;
}q[250010];

void add(int t)
{
	tim[++n] = t;
	isempty[n] = true;
}

void comb(int t)
{
	tim[++n] = t;
	bool flag = true;
	for (int i = 1; i <= k; i++)
	{
		fa[a[i]] = n;
		g[n].push_back(a[i]);
		if (!isempty[a[i]])
			flag = false;
	}
	if (flag) isempty[n] = true;
}

prob mkprob(int x, int y, int t)
{
	prob p;
	p.x = x; p.y = y; p.t = t;
	return p;
}

void build(int now)
{
	f[now][0] = fa[now];
	for (int i = 1; i <= 19; i++)
		f[now][i] = f[f[now][i - 1]][i - 1];
	for (int i = 0; i < g[now].size(); i++)
	{
		int nxt = g[now][i];
		d[nxt] = d[now] + 1;
		build(nxt);
	}
}

int query(int x, int y, int t)
{
	int tar = y;
	if (isempty[x]) return true;
	if (!isempty[x] && isempty[y]) return false;
	if (d[x] < d[y])
		return false;
	for (int i = 19; i >= 0; i--) if (d[f[x][i]] >= d[y]) x = f[x][i];
	if (x == y)
	{
		if (tim[y] <= t)
			return true;
		return false;
	}
	return false;
	/*
	for (int i = 19; i >= 0; i--) 
		if (f[x][i] != f[y][i])
		{
			x = f[x][i]; y = f[y][i];
		}
	if (tim[fa[x]] <= t && tim[fa[x]] == tar)
		return true;
	return false;
	*/
}

int main()
{
	freopen("friendship.in", "r", stdin);
	freopen("friendship.out", "w", stdout);
	ios::sync_with_stdio(false);
	
	tim[0] = INF;
	cin >> n >> m;
	for (int i = 1; i <= m; i++)
	{
		cin >> tmp;
		if (tmp == 0)
		{
			cin >> op >> k;
			for (int j = 1; j <= k; j++)
				cin >> a[j];
			if (op == 0) 
				add(i);
			if (op == 1)
				comb(i);
		}
		if (tmp == 1)
		{
			cin >> x >> y;
			q[++tot] = mkprob(x, y, i);
		}
	}
	for (int i = 1; i <= n; i++)
		if (fa[i] == 0)
		{
			d[i] = 1;
			build(i);
		}
	for (int i = 1; i <= tot; i++)
	{
		cout << query(q[i].x, q[i].y, q[i].t) << endl;
	}

	return 0;
}

