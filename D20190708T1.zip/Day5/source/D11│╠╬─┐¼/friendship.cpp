#include<bits/stdc++.h>
#define rep(i,j,k) for(int (i)=(j);(i)<=(k);(i)++)
#define pb push_back
using namespace std;
typedef long long ll;
int n,q,bh;
vector<int> g[500005];
bool vis[500005];
void dfs(int x){
	//printf("%d\n",x);
	vis[x]=1;
	rep(i,0,(int)g[x].size()-1){
		if(!vis[g[x][i]])
		dfs(g[x][i]);
	}
}
int main()
{
	freopen("friendship.in","r",stdin);
	froepen("friendship.out","w",stdout);
	scanf("%d%d",&n,&q);
	bh=n;
	rep(r,1,q){
		int a;scanf("%d",&a);
		if(a==0){
			bh++;
			int op,k;scanf("%d%d",&op,&k);
			rep(i,1,k){
				int c;scanf("%d",&c);
				if(k==1) {g[bh].pb(c);g[c].pb(bh);break;}
				if(!op) g[bh].pb(c);else g[c].pb(bh);
			}
		}
		else {
			int b,c;
			scanf("%d%d",&b,&c);
			rep(i,1,bh) vis[i]=0;
			dfs(b);
			printf("%d\n",vis[c]);
		}
	}
	return 0;
}
