#include<bits/stdc++.h>
#define rep(i,j,k) for(int (i)=(j);(i)<=(k);(i)++)
#define pb push_back
using namespace std;
typedef long long ll;
int n,a[100005],cur,ans=1;set<int> s;
int gcd(int x,int y){
	if(!y) return x;
	return gcd(y,x%y);
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	scanf("%d",&n);
	rep(i,1,n) scanf("%d",a+i);
	s.insert(a[1]);
	rep(i,2,n){
		bool flg=0;
		if(s.find(a[i])!=s.end()) flg=1;
		cur=gcd(cur,abs(a[i]-a[i-1]));
		s.insert(a[i]);
		if(cur==1||flg){
			cur=0;
			ans++;
			s.clear();s.insert(a[i]);
			//i++;
		}
	}
	printf("%d",ans);
	return 0;
}
