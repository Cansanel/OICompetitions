#include<bits/stdc++.h>
#define rep(i,j,k) for(int (i)=(j);(i)<=(k);(i)++)
#define pb push_back
using namespace std;
typedef long long ll;
int n,k,a[500005],b[500005];ll pre[500005],f[500005],inf=1e18;
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	scanf("%d%d",&n,&k);
	rep(i,2,n+1) scanf("%d",a+i);
	rep(i,1,n) scanf("%d",b+i);
	rep(i,1,n+1) pre[i]=pre[i-1]+a[i];
	if((double)n*k>=1e8) {printf("%d\n",pre[n+1]);}
	rep(i,2,n+1) f[i]=inf;
	rep(i,2,n+1)
	rep(j,1,k){
		if(i-j<=0) break;
		f[i]=min(f[i],f[i-j]+max(pre[i]-pre[i-j],(ll)b[i-j]));
	}
	printf("%lld",f[n+1]);
	//printf("%I64d",f[n+1]);
	return 0;
}
