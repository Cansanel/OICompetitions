#include<bits/stdc++.h>
using namespace std;

#define maxn 500003

bool b1=true,ba=true;

int n,k;
long long a[maxn],b[maxn];
long long sum[maxn];
long long opt[maxn];
template <typename Tp>
void read(Tp &x){
	x=0;char ch=1;int fh;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-'){
		fh=-1;ch=getchar();
	}
	else fh=1;
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	x*=fh;
}

struct node{
	int id;
	long long num;
	bool operator <(node a)const{
		return num>a.num;
	}
};

priority_queue <node> sm,ob;

int main(){
	freopen("empire.in","r",stdin);freopen("empire.out","w",stdout);
	read(n);read(k);
	for(register int i=1;i<=n;i++){
		read(a[i]);sum[i]=sum[i-1]+a[i];
	}
	for(register int i=0;i<n;i++){
		read(b[i]);
		if(b[i]!=1) b1=false;
		if(b[i]!=a[i+1]) ba=false;
	}

	sm.push((node){0,0});ob.push((node){0,b[0]});
	for(register int i=1;i<=n;i++){
		node aa;
		do{
			aa=sm.top();
			if(aa.id<i-k) sm.pop();
		}while(aa.id<i-k);
		opt[i]=aa.num+sum[i];
		do{
			aa=ob.top();
			if(aa.id<i-k) ob.pop();
		}while(aa.id<i-k);
		opt[i]=max(opt[i],aa.num);
		sm.push((node){i,opt[i]-sum[i]});ob.push((node){i,b[i]+opt[i]});
	}
	printf("%lld\n",opt[n]);
	fclose(stdin);fclose(stdout);
	return 0;
}

