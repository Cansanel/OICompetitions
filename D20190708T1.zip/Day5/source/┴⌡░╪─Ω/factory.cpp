#include<bits/stdc++.h>
using namespace std;

#define maxn 100007

int n,a[maxn],ans=1,cnt,s;
set <int> st;
int gcd(int x,int y){
	if(!y) return x;
	return gcd(y,x%y);
}

template <typename Tp>
void read(Tp &x){
	x=0;char ch=1;int fh;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-'){
		fh=-1;ch=getchar();
	}
	else fh=1;
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	x*=fh;
}
int abs(int x){
	return x>0?x:-x;
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	read(n);
	for(register int i=1;i<=n;i++){
		read(a[i]);
	}
	st.insert(a[1]);
	for(register int i=2;i<=n;i++){
		if(st.count(a[i])){
			ans++;s=0;st.clear();continue;
		}
		s=gcd(abs(a[i]-a[i-1]),s);
		if(s==1){
			s=0;ans++;st.clear();continue;
		}
		st.insert(a[i]);
	}
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
