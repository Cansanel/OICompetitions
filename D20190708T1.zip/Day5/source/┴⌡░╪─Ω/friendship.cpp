#include<bits/stdc++.h>
using namespace std;

#define maxn 500003

int Head[maxn],Next[maxn],v[maxn],tot;
int n,m,x,y,k,ind,opt,mer;
template <typename Tp>
void read(Tp &x){
	x=0;char ch=1;int fh;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-'){
		fh=-1;ch=getchar();
	}
	else fh=1;
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	x*=fh;
}

inline void change(){
	++ind;
	read(mer);read(k);
	if(mer){
		for(register int i=1;i<=k;i++){
			read(x);
			v[++tot]=x,Next[tot]=Head[ind],Head[ind]=tot;
		}
	}
	else{
		for(register int i=1;i<=k;i++){
			read(x);
			v[++tot]=ind,Next[tot]=Head[x],Head[x]=tot;
		}
	}
}

inline void query(){
	read(x);read(y);
	queue <int> q;
	q.push(y);
	while(!q.empty()){
		int t=q.front();q.pop();
		if(t==x){
			puts("1");return;
		}
		for(int i=Head[t];i;i=Next[i]){
			q.push(v[i]);
		}
	}
	puts("0");
}

int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	read(n);read(m);ind=n;
	while(m--){
		read(opt);
		if(opt){
			query();
		}
		else{
			change();
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

