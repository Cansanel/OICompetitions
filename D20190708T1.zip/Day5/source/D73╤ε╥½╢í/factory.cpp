#include<algorithm>
#include<iostream>
#include<cstdio>
using namespace std;

int n,a[100010],s[100010],q[100010],last,ans=0;
struct pdxt
{
	int s,num;
}p[100010];
bool cmp(pdxt x,pdxt y)
{
	if(x.s!=y.s)	return x.s<y.s;
	return x.num<y.num;
}
int abs1(int a)
{
	if(a<0)	a=-a;
	return a;
}
int gcd(int a,int b)
{
	if(b==0||a==0)	return a+b;
	return gcd(b,a%b);
}
int read()
{
	int x=0;
	char ch=getchar();
	while(ch>'9'||ch<'0')	ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return x;
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;++i)	a[i]=read(),p[i].s=a[i],p[i].num=i,q[i]=0;
	sort(p+1,p+1+n,cmp);
	for(register int i=2;i<=n;++i)
		if(p[i].s==p[i-1].s)
			q[p[i].num]=p[i-1].num;
	last=0;
	s[1]=0;
	for(register int i=2;i<=n;++i)
	{
		int x=gcd(abs1(a[i]-a[i-1]),s[i-1]);
		if(x==1||x==0||q[i]==i-last)	s[i]=0,++ans,last=0;
		else	s[i]=x,++last;
	}
	++ans;
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
//�����쳹��̰���ĳ��� 
