#include<cstdio>
#include<iostream>
using namespace std;

int n,m;
int top[10010],bs=0,d[10010];
bool b[10010];
struct tu
{
	int k,next;
}a[200010];
void lb(int x,int y)
{
	++bs,a[bs].k=y,a[bs].next=top[x],top[x]=bs;
}
int read()
{
	int x=0;
	char ch=getchar();
	while(ch>'9'||ch<'0')	ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return x;
}
int bfs(int u,int v)
{
	if(u==v)	return 1;
	for(register int i=1;i<=n;++i)	b[i]=0;
	int f=1,r=1;
	d[1]=u;
	while(f<=r)
	{
		for(register int i=top[d[f]];i>0;i=a[i].next)
		{
			int nk=a[i].k;
			if(b[nk]==0)
			{
				b[nk]=1;
				d[++r]=nk;
			}
			if(nk==v)	return 1;
		}
		++f;
	}
	return 0;
}
int main()
{
	int x,a,b,c;
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	n=read();
	m=read();
	for(register int i=1;i<=m;++i)
	{
		x=read();
		if(x==1)
		{
			a=read();
			b=read();
			cout<<bfs(a,b)<<endl;
		}
		if(x==0)
		{
			++n;
			a=read(),b=read();
			if(a==1)
				for(register int j=1;j<=b;++j)
				{
					c=read();
					lb(c,n);
				}
			else
				for(register int j=1;j<=b;++j)
				{
					c=read();
					lb(n,c);
				}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
//���ͼ�֤�˻�������� 
