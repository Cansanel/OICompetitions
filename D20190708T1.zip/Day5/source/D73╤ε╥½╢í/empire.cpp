#include<iostream>
#include<cstdio>
using namespace std;

int n,k;
long long a[500010],b[500010];
int f[10010];
int read()
{
	int x=0;
	char ch=getchar();
	while(ch>'9'||ch<'0')	ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return x;
} 
int max1(int a,int b)
{
	if(a>b)	return a;
	return b;
}
int min1(int a,int b)
{
	if(a>b)	return b;
	return a;
}
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	n=read(),k=read();
	for(register int i=1;i<=n;++i)	a[i]=read(),a[i]+=a[i-1];
	for(register int i=1;i<=n;++i)	b[i-1]=read();
	if(n<=10000)
	{
		f[0]=0;
		for(register int i=1;i<=n;++i)	f[i]=1e9;
		for(register int i=1;i<=n;++i)
			for(register int j=max1(0,i-k);j<i;++j)
				f[i]=min1(f[i],f[j]+max1(a[i]-a[j],b[j]));
		cout<<f[n]<<endl;
	}
	else
	{
		if(n==k)
		{
			if(a[n]>b[0])	cout<<a[n]<<endl;
			else	cout<<b[0]<<endl;
		}
		else	cout<<a[n]<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
//��;�ѻ������������
