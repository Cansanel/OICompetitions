#include<bits/stdc++.h>
#define up(l,r,i) for(int i=l;i<=r;i++)
#define dn(r,l,i) for(int i=r;i>=l;i--)
using namespace std;
typedef long long LL;
const int SIZE=1000;
char bef[SIZE+3],*p1=bef,*p2=bef;
char readc(){
	if(p1==p2) p1=bef,p2=bef+fread(bef,1,SIZE,stdin);
	return p1==p2?EOF:*p1++;
}
int read(){
	int w=1,c,ret;
	while((c=readc())> '9'||c <'0')
	w=(c=='-'?-1:1);
	ret=c-'0';
	while((c=readc())>='0'&&c<='9')
	ret=ret*10+c-'0';
	return ret*w;
}
const int MAXN =500000 +3,MAXM=MAXN;
int tot,head[MAXN],ver[MAXM],nxt[MAXM],n,m,cnt;
void add(int u,int v){
	ver[++tot]=v,nxt[tot]=head[u],head[u]=tot;
}
bool vis[MAXN];
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	
	n=read(),m=read(),cnt=n;
	up(1,m,i){
		int k,op,t,x,y;
		switch(read()){
			case 0:
				op=read(),k=read(),cnt++;
				if(k==1) t=read(),add(t,cnt),add(cnt,t); else
				if(op) up(1,k,i) t=read(),add(t,cnt); else
				up(1,k,i) t=read(),add(cnt,t);
				break;
			case 1:
				x=read(),y=read();
				queue <int> q;
				q.push(x),memset(vis,0,sizeof(vis)),vis[x]=true;
				while(!q.empty()){
					int u=q.front();q.pop();
					for(int j=head[u];j;j=nxt[j]){
						int v=ver[j];
						if(!vis[v]) vis[v]=true,q.push(v);
						if(v==y){
							puts("1");
							goto end;
						}
					}
				}
				puts("0"); break;
		}
		end:;
	}
	return 0;
}
/*
3 5
0 0 2 1 2
1 1 4
0 1 2 3 4
1 4 5
1 4 2

*/
