#include<bits/stdc++.h>
#define up(l,r,i) for(int i=l;i<=r;i++)
#define dn(r,l,i) for(int i=r;i>=l;i--)
using namespace std;
typedef long long LL;
const int SIZE=1000;
char bef[SIZE+3],*p1=bef,*p2=bef;
char readc(){
	if(p1==p2) p1=bef,p2=bef+fread(bef,1,SIZE,stdin);
	return p1==p2?EOF:*p1++;
}
LL read(){
	LL w=1,c,ret;
	while((c=readc())> '9'||c <'0')
	w=(c=='-'?-1:1);
	ret=c-'0';
	while((c=readc())>='0'&&c<='9')
	ret=ret*10+c-'0';
	return ret*w;
}
const int MAXN =500000 +3;
LL n,A[MAXN],B[MAXN],sum[MAXN],k,dp[MAXN];
bool pt1=true,pt2=true,pt3=true;
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	n=read(),k=read();
	int t=1e8/n/3;
	up(1,n,i) A[i]=read(),sum[i]=sum[i-1]+A[i];
	up(1,n,i) B[i-1]=read();
	up(1,n,i) if(B[i-1]!=1) pt1=false;
	up(1,n,i) if(A[i]!=B[i-1]) pt2=false;
	if(n!=k) pt3=false;
	if(pt1){ 		//dp[i]=min(dp[i],(dp[j]-sum[j])+sum[i]);
		up(1,n,i) dp[n]+=A[i];
	} else if(pt2){ //dp[i]=min(dp[i],(dp[j]-sum[j])+sum[i]);
		up(1,n,i) dp[n]+=A[i];
	} else
	up(1,n,i){
		dp[i]=LLONG_MAX;
		LL flag;
		up(max((LL)0,i-k),min(max((LL)0,i-k)+t,(LL)i-1),j){
			LL cost=sum[i]-sum[j];
			if(dp[j]+max(cost,B[j])<dp[i]) flag=j;
			dp[i]=min(dp[i],dp[j]+max(cost,B[j]));
		}
	}
	printf("%lld\n",dp[n]);
	return 0;
}
/*
4 2
4 3 2 1
1 2 4 4
*/
/*
4 2
4 3 2 1
1 2 10 3
*/
