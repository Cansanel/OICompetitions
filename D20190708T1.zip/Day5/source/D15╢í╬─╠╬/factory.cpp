#include<bits/stdc++.h>
#define up(l,r,i) for(int i=l;i<=r;i++)
#define dn(r,l,i) for(int i=r;i>=l;i--)
using namespace std;
typedef long long LL;
const int SIZE=1000;
char bef[SIZE+3],*p1=bef,*p2=bef;
char readc(){
	if(p1==p2) p1=bef,p2=bef+fread(bef,1,SIZE,stdin);
	return p1==p2?EOF:*p1++;
}
int read(){
	int w=1,c,ret;
	while((c=readc())> '9'||c <'0')
	w=(c=='-'?-1:1);
	ret=c-'0';
	while((c=readc())>='0'&&c<='9')
	ret=ret*10+c-'0';
	return ret*w;
}
const int MAXN =100000 +3;
int delta,cnt,n,P[MAXN];
int gcd(int x,int y){
	return y==0?x:gcd(y,x%y);
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	
	n=read();
	up(1,n,i) P[i]=read();
	delta=-1,cnt=1;
	up(2,n,i){
		int t=abs(P[i]-P[i-1]);
		if(delta==-1) {
			if(t>1) delta=t; else cnt++,delta=-1;
		}else if(gcd(delta,t)>1) delta=gcd(delta,t);
		else cnt++,delta=-1;
	}
	printf("%d\n",cnt);
	return 0;
}
/*
7
1 5 11 2 6 4 7

8
4 2 6 8 5 3 1 7
*/
