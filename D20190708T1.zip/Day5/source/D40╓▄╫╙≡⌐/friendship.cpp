#include<iostream>
#include<cstdio>
#include<vector>
#include<cstring>
using namespace std;
int n,m,now;
vector <int> g[500500];
bool v[500500];
int query(int s,int e)
{
	if(v[s]) return 0;
	if(s==e) return 1;
	for(int i=0;i<g[s].size();i++)
	{
		if(query(g[s][i],e)) return 1;
	}
	return 0;
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	scanf("%d %d",&n,&m);
	now=n;
	for(int i=1;i<=m;i++)
	{
		int x,y,z;
		scanf("%d %d %d",&x,&y,&z);
		if(x==0)
		{
			if(y==0)
			{
				now++;
				if(z==1)
				{
					int ak;
					scanf("%d",&ak);
					g[now].push_back(ak);
					g[ak].push_back(now);
				}
				else
					while(z--)
					{
						int ak;
						scanf("%d",&ak);
						g[now].push_back(ak);
					}
			}
			else
			{
				now++;
				if(z==1)
				{
					int ak;
					scanf("%d",&ak);
					g[now].push_back(ak);
					g[ak].push_back(now);
				}
				else
					while(z--)
					{
						int ak;
						scanf("%d",&ak);
						g[ak].push_back(now);
					}
			}
		}
		else
		{
			memset(v,0,sizeof(v));
			printf("%d\n",query(y,z));
		}
	}
	return 0;
}
