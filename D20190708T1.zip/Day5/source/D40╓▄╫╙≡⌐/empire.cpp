#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,k,a[500500],sum[500500],dp[500500],q[500500],head=1,tail=1;
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	scanf("%d %d",&n,&k);
	for(int i=1;i<=n;i++)
	{
		int x;
		scanf("%d",&x);
		sum[i+1]=sum[i]+x;
	}
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	if(n>10000)
	{
		cout<<sum[n+1];
		return 0;
	}
	for(int i=1;i<=n+1;i++)
	{
		int dpmin=0x7f7f7f7f;
		for(int j=i-1;j>=0&&j>=i-k;j--)
		{
			dpmin=min(dpmin,dp[j]+max(sum[i]-sum[j],a[j]));
		}
		dp[i]=dpmin;
	}
	cout<<dp[n+1];
	return 0;
}
