#include<iostream>
#include<cstdio>
#include<set>
using namespace std;
int n,ans,nowgcd;
int a[100100],b[100100];
set <int> s;
inline int gcd(int x,int y)
{
	if(y==0) return x;
	return gcd(y,x%y);
}
inline int abs(int x)
{
	return x>0?x:-x;
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=2;i<=n;i++)
	{
		nowgcd=gcd(nowgcd,abs(a[i]-a[i-1]));
		if(nowgcd<=1||s.find(a[i])!=s.end())
		{
			ans++;
			nowgcd=0;
			s.clear();
		}
		s.insert(a[i]);
	}
	ans++;
	cout<<ans;
	return 0;
}
