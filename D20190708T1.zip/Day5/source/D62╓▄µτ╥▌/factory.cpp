#include <bits/stdc++.h>
using namespace std;
const int N=100005;
int n,p[N],gcd,ans,rt,cnt;
struct node{int ch[2],fa,num;} t[N];
inline void rotate(int x){
	int y=t[x].fa,z=t[y].fa,k=(t[y].ch[1]==x);
	if(z!=0) t[z].ch[t[z].ch[1]==y]=x;t[x].fa=z;
	t[y].ch[k]=t[x].ch[k^1];t[t[x].ch[k^1]].fa=y;
	t[y].fa=x;t[x].ch[k^1]=y;
}
inline void splay(int x){
	while(t[x].fa!=0){
		int y=t[x].fa,z=t[y].fa;
		if(z!=0) (t[z].ch[0]==y)^(t[y].ch[0]==x)?rotate(x):rotate(y);
		rotate(x);
	}
	rt=x;
}
inline void inst(int x){
	if(!rt){
		rt=++cnt;t[cnt].num=x;
		return;
	}
	int tmp=rt;
	while(tmp){
		if(x==t[tmp].num){
			t[tmp].num=-1e9;return;
		}
		int k=(t[tmp].num<x);
		if(t[tmp].ch[k]==0){
			t[++cnt].num=x;
			t[cnt].fa=tmp;
			t[tmp].ch[k]=cnt;
			splay(cnt);return;
		}
		tmp=t[tmp].ch[k];
	}
}
inline int getlast(int x){
	int tmp=rt;
	if(t[tmp].ch[0]==0) return 0;
	tmp=t[tmp].ch[0];
	while(tmp){
		if(t[tmp].ch[1]==0) return t[tmp].num;
		tmp=t[tmp].ch[1];
	}
}
inline int getnext(int x){
	int tmp=rt;
	if(t[tmp].ch[1]==0) return 0;
	tmp=t[tmp].ch[1];
	while(tmp){
		if(t[tmp].ch[0]==0) return t[tmp].num;
		tmp=t[tmp].ch[0];
	}
}
inline int getgcd(int x,int y){
	if(y==0) return x;
	return getgcd(y,x%y);
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&p[i]);
	for(int i=1;i<=n;){
		rt=0;gcd=0;inst(p[i]);i++;ans++;
		while(i<=n){
			inst(p[i]);
			if(t[rt].num==-1e9) break;
			int a=getlast(p[i]),b=getnext(p[i]);
			int u=getgcd(p[i]-a,b-p[i]);
			int k=getgcd(u,gcd);
			if(k==1) break;
			else gcd=k;
			i++;
		}
	}
	printf("%d\n",ans);
	return 0;
}
