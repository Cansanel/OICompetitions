#include <bits/stdc++.h>
using namespace std;
const int N=20005;
int n,m,tp[N],x[N],y[N],id[N],cnt,st1[N],t1,st2[N],t2;
vector<int> a[N];
void work1(){
	for(int i=1;i<=n;i++) id[i]=i;
	for(int i=1;i<=m;i++){
		if(tp[i]==0){
			id[++cnt]=id[a[i][0]];
		}
		else{
			if(id[x[i]]==id[y[i]])
				puts("1");
			else puts("0");
		}
	}
}
void work2(){
	for(int i=1;i<=n;i++) id[i]=i;
	for(int i=1;i<=m;i++){
		if(tp[i]==0){
			if(a[i].size()>1) id[++cnt]=0;
			else id[++cnt]=id[a[i][0]];
		}
		else{
			if(id[x[i]]==id[y[i]])
				puts("1");
			else puts("0");
		}
	}
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	bool ty1=1,ty2=1,ty3=1;
	scanf("%d%d",&n,&m);cnt=n;
	for(int i=1;i<=m;i++){
		scanf("%d%d%d",&tp[i],&x[i],&y[i]);
		if(tp[i]==0){
			if(y[i]>1) ty1=0;
			if(x[i]==1) ty2=0;
			for(int j=1;j<=y[i];j++){
				int u;scanf("%d",&u);
				a[i].push_back(u);
			}
		}
		if(i!=m&&tp[i]==1) ty3=0;
	}
	if(ty1){
		work1();
		return 0;
	}
	if(ty2){
		work2();
		return 0;
	}
	cout<<"gu~gu~gu~";
	return 0;
}
