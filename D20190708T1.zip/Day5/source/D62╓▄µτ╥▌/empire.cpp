#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N=500005;
int n,m;
ll a[N],b[N],f[10005],sum[10005];
void work1(){
	for(int i=1;i<=n;i++) sum[i]=sum[i-1]+a[i];
	memset(f,0x3f,sizeof(f));
	f[1]=max(a[1],b[0]);
	for(int i=2;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(i-j<1) break;
			f[i]=min(f[i],f[i-j]+max(sum[i]-sum[i-j],b[i-j]));
		}
	}
	printf("%lld\n",f[n]);
}
void work2(){
	ll s=0;
	for(int i=1;i<=n;i++) s+=a[i];
	printf("%lld\n",s);
}
void work3(){
	ll s=0;
	for(int i=1;i<=n;i++) s+=a[i];
	printf("%lld\n",max(s,b[0]));
}
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	bool ty=1;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=0;i<n;i++){
		if(b[i]!=1) ty=0;
		scanf("%d",&b[i]);
	}
	if(n<=10000){
		work1();
		return 0;
	}
	if(ty){
		work2();
		return 0;
	}
	if(n==m){
		work3();
		return 0;
	}
	return 0;
}
