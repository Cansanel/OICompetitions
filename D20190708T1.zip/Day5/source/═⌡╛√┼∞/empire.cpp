#include<bits/stdc++.h>
#define MAXN 10010
#define MAXK 1010

using namespace std;

int f[MAXN];
int n , m;
int a[MAXN] , b[MAXN];
int sum[MAXN];

template <typename T> inline void read(T &x) {
	x = 0; T f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}

template <typename T> inline void chkmax(T &x , T y) {x = x > y ? x : y ; }
template <typename T> inline void chkmin(T &x , T y) {x = x < y ? x : y ; }

int main(){

	freopen("empire.in" , "r" , stdin);
	freopen("empire.out" , "w" , stdout);

	read(n); read(m);
	for (int i = 1; i <= n; i++) {
		read(a[i]);
		sum[i] = sum[i - 1] + a[i];
	}
	for (int i = 1; i <= n; i++) read(b[i]);
	if (n > 10000 && n == m) {
		cout << max(b[1] , sum[n]) << endl;
		return 0;
	}
	if (n > 10000) {
		cout << sum[n] << endl;
		return 0;
	}
	
	memset(f , 127 , sizeof(f));
	
	f[0] = 0;
	if (a[1] > b[1]) f[1] = a[1];
	else f[1] = b[1];

	for (int i = 2; i <= n; i++) {
		for (int j = 1; j <= m && i - j + 1 > 0; j++) {
			chkmin(f[i] , f[i - j] + max(sum[i] - sum[i - j] , b[i - j + 1]));
		}
	}
	
	cout << f[n] << endl;

	return 0;
}


