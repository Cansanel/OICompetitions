#include<bits/stdc++.h>
#define MAXN 2010

using namespace std;

int n , m;
vector <int> v[MAXN << 1];
bool h[MAXN << 1][MAXN << 1];

template <typename T> inline void read(T &x) {
	x = 0; T f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}

template <typename T> inline void chkmax(T &x , T y) {x = x > y ? x : y ; }
template <typename T> inline void chkmin(T &x , T y) {x = x < y ? x : y ; }

int main(){

	srand(time(NULL));
	freopen("friendship.in" , "r" , stdin);
	freopen("friendship.out" , "w" , stdout);
	int n;
	read(n);
	for (int i = 1; i <= n; i++) cout << rand() % 2 << endl;

	return 0;
}


