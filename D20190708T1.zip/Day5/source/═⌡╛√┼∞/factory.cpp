#include<bits/stdc++.h>
#define MAXN 100010

using namespace std;

int n;
int a[MAXN];
int ans;
int las;

template <typename T> inline void read(T &x) {
	x = 0; T f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}

template <typename T> inline void chkmax(T &x , T y) {x = x > y ? x : y ; }
template <typename T> inline void chkmin(T &x , T y) {x = x < y ? x : y ; }

template <typename T> inline T gcd (T x , T y){return y ? gcd(y , x % y) : x; }

int main(){

	freopen("factory.in" , "r" , stdin);
	freopen("factory.out" , "w" , stdout);

	read(n);
	
	for (int i = 1; i <= n; i++){
		read(a[i]);
	}
	
	ans = 1;
	las = 1;
	if (abs(a[2] - a[1]) <= 1) {
		ans++; las = 2;
	}
	for (int i = 3; i <= n; i++){
		if (i == las + 1) {
			if (abs(a[i] - a[las]) <= 1) {
				las = i;
				ans ++;
			}
		}
		else {
			if (gcd(abs(a[i] - a[i - 1]) , abs(a[las + 1] - a[las])) == 1) {
				ans++;
				las = i;
			}
		}
	}
	
	cout << ans << endl;

	return 0;
}


