#include <iostream>
#include <iomanip>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
int A[500000],B[500000];
using namespace std;
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	int n,i,k,sum=0;
	cin>>n>>k;
	for(i=0;i<n;i++){
		cin>>A[i];
		sum=sum+A[i];
	}
	for(i=0;i<n;i++){
		cin>>B[i];
	}
	cout<<sum;
	return 0;
}
