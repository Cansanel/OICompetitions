#include <iostream>
#include <iomanip>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	cout<<"1";
	return 0;
}
