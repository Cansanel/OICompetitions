#include <iostream>
#include <iomanip>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	/*int n,m,i,k;
	bool c1,c2;
	//���� 
	for(i=0;i<m;i++){
		cin>>c1;
		if(!c1){
			//�ж����� 
			cin>>c2;
			cin>>k; 
			//��������ǽ��� 
			if(!c2){
				
			}
			else{
				
			}
		}
		else{
			
		}
	}*/
	cout<<"0";
	return 0;
}
