#include <bits/stdc++.h>

using namespace std;

const int maxn = 5e5 + 10;

int n, k;
int s[maxn], d[maxn], f[maxn];
int q[maxn], l, r;

int main(){
	freopen("empire.in", "r", stdin);
	freopen("empire.out", "w", stdout);
	scanf("%d%d", &n, &k);
	for (int i = 1; i <= n; i++){
		scanf("%d", s + i);
		s[i] += s[i - 1];
	}
	for (int i = 1; i <= n; i++) scanf("%d", &d[i - 1]);
	for (int i = 1; i <= n; i++){
		/*
		while (l <= r && q[l] < i - k) l++;
		f[i] = f[q[l]] + max(d[q[l]], s[i] - s[q[l]]);
		while (l <= r && d[q[l]] > d[q[r]]) r--;
		q[++r] = i;
		*/
		f[i] = INT_MAX;
		for (int j = max(i - k, 0); j < i; j++)
			f[i] = min(f[i], f[j] + max(d[j], s[i] - s[j]));
	}
	printf("%d\n", f[n]);
	return 0;
}
