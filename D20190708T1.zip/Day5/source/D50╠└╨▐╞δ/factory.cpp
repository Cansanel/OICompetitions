#include <bits/stdc++.h>

using namespace std;

const int maxn = 1e5 + 10;

int n, a[maxn];

int gcd(int a, int b){
	return b ? gcd(b, a % b) : a;
}

int Abs(int x){
	return x < 0 ? -x : x;
}

int main(){
	freopen("factory.in", "r", stdin);
	freopen("factory.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) scanf("%d", a + i);
	int cnt = 1, g = 0;
	for (int i = 2; i <= n; i++){
		g = gcd(Abs(a[i] - a[i - 1]), g);
		if (g == 1){
			cnt++;
			g = 0;
		}
	}
	printf("%d\n", cnt);
	
	return 0;
}
