#include <bits/stdc++.h>

using namespace std;

const int maxn = 2e6 + 10, maxm = maxn << 1, A = 20;

int n, m;
int qx[maxn], qy[maxn], qtot;
int anc[maxn][A];
bool qcol1[maxn][A], qcol2[maxn][A], col1[maxn], col2[maxn];
int deep[maxn], nowtot;
int head[maxn], nxt[maxm], to[maxm], tot;

inline void addedge(int u, int v){
	to[++tot] = v;
	nxt[tot] = head[u];
	head[u] = tot;
}

void dfs(int x, int fa, int dep, bool c1, bool c2){
	anc[x][0] = fa; qcol1[x][0] = c1; qcol2[x][0] = c2; deep[x] = dep;
	for (int i = 1; i < A; i++){
		anc[x][i] = anc[anc[x][i - 1]][i - 1];
		qcol1[x][i] = qcol1[anc[x][i - 1]][i - 1] & qcol1[x][i - 1];
		qcol2[x][i] = qcol2[anc[x][i - 1]][i - 1] & qcol2[x][i - 1];
	}
	for (int i = head[x]; i; i = nxt[i]){
		int p = to[i];
		if (p != fa) dfs(p, x, dep + 1, col1[x], col2[x]);
	}
}

inline int lca(int x, int y, bool &c1, bool &c2){
	if (deep[x] < deep[y]) swap(x, y);
	
	c1 = c2 = 1;
	for (int i = A - 1; i >= 0; i--)
		if (deep[anc[x][i]] >= deep[y]){
			c1 &= qcol1[x][i];
			c2 &= qcol2[x][i];
			x = anc[x][i];
		}
	
	if (x == y) return x;
	
	for (int i = A - 1; i >= 0; i--)
		if (anc[x][i] != anc[y][i]){
			c1 &= qcol1[x][i] & qcol1[y][i];
			c2 &= qcol2[x][i] & qcol2[y][i];
			x = anc[x][i];
			y = anc[y][i];
		}
	c1 &= qcol1[x][0] & qcol1[y][0];
	c2 &= qcol2[x][0] & qcol2[y][0];
	return anc[x][0];
}

int main(){
	freopen("friendship.in", "r", stdin);
	freopen("friendship.out", "w", stdout);
	scanf("%d%d", &n, &m);
	nowtot = n;
	for (int i = 1; i <= m; i++){
		int opt;
		scanf("%d", &opt);
		if (opt){
			qtot++;
			scanf("%d%d", &qx[qtot], &qy[qtot]);
		} else {
			int op, k;
			nowtot++;
			scanf("%d%d", &op, &k);
			for (int j = 1; j <= k; j++){
				int x;
				scanf("%d", &x);
				addedge(nowtot, x);
			}
			col1[nowtot] = (k == 1) | op;
			col2[nowtot] = (!op) | (k == 1);
		}
	}
	dfs(nowtot, 0, 1, 0, 0);
	bool c1, c2; int l;
	for (int i = 1; i <= qtot; i++){
		l = lca(qx[i], qy[i], c1, c2);
		if (l == qy[i] && c1) printf("1\n");
		else if (l == qx[i] && c2) printf("1\n");
		else printf("0\n");
	}
	return 0;
}
