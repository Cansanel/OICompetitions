#include<bits/stdc++.h>
using namespace std;
template <typename T> inline void read(T &x)
{
	int f = 1; x = 0;
	char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;  
}
const int N = 1e5 + 5;
int a[N];
int n;
inline int gcd(int x, int y) { return y == 0 ? x : gcd(y, x % y); }
int main(){
	freopen ("factory.in", "r", stdin);
	freopen ("factory.out", "w", stdout);
	read(n);
	for (int i = 1; i <= n; i++) read(a[i]);
	int ans = 1, now = 0;
	for (int i = 2; i <= n; i++)
	{
		int delta = gcd(abs(a[i] - a[i - 1]), now);
		if (delta <= 1)
		{
			ans++;
			now = 0;
		}
		else now = delta;
	}
	
	printf("%d\n", ans);
  return 0;
}
