#include<bits/stdc++.h>
#define LL long long
using namespace std;
template <typename T> inline void read(T &x)
{
	int f = 1; x = 0;
	char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}
const int N = 5e5 + 5;
const LL INF = 1e18;
LL a[N], b[N];
LL sum[N];
LL f[N];
int n, k;
deque <pair <LL, LL> > q1, q2;
inline void solve_60pts()
{
	for (int i = 1; i <= n; i++)
	{
		f[i] = INF;
		for (int j = i - 1; j >= max(0, i - k); j--)
		f[i] = min(f[i], f[j] + max(sum[i] - sum[j], b[j]));
	}
	printf("%lld\n", f[n]);
}
inline void solve()
{
	q1.push_back(make_pair(b[0], 0));
	q2.push_back(make_pair(0, 0));
	
	for (int i = 1; i <= n; i++)
	{
		while (!q1.empty() && i - q1.front().second > k) q1.pop_front();
		while (!q2.empty() && i - q2.front().second > k) q2.pop_front();
		f[i] = max(q1.front().first, q2.front().first + sum[i]);
		
		while (!q1.empty() && q1.back().first > f[i] + b[i]) q1.pop_back();
		q1.push_back(make_pair(f[i] + b[i], i));
		
		while (!q2.empty() && q2.back().first > f[i] - sum[i]) q2.pop_back();
		q2.push_back(make_pair(f[i] - sum[i], i));
	}
	
	printf("%lld\n", f[n]);
}
int main(){
	freopen ("empire.in", "r", stdin);
	freopen ("empire.out", "w", stdout);
	read(n); read(k);
	
	bool flag = 1;
	for (int i = 1; i <= n; i++) read(a[i]);
	for (int i = 0; i < n; i++)
	{
		read(b[i]);
		if (b[i] != 1) flag = 0;
	}
	
	for (int i = 1; i <= n; i++) sum[i] = sum[i - 1] + a[i];
	
	if (n == k) 
	{
		printf("%lld\n", max(b[0], sum[n]));
		return 0;
	}
	
	if (n <= 10000)
	{
		solve_60pts();
		return 0;
	}
	
	else solve();
  return 0;
}
