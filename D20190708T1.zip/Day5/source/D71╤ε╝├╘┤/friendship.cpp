#include<bits/stdc++.h>
using namespace std;
template <typename T> inline void read(T &x)
{
	int f = 1; x = 0;
	char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f; 
}
const int N = 8e5 + 5;
const int M = 5e5 + 5;
struct Graph
{
	int head[N], ver[M], Next[M], tot;
	inline void add(int u, int v)
	{
		ver[++tot] = v;
		Next[tot] = head[u];
		head[u] = tot;
	}
}G1, G2;
int n, m;
int vis1[N], vis2[N], sum;
inline int Find(int x, int y)
{
	queue <int> q1, q2;
	q1.push(x); q2.push(y);
	vis1[x] = vis2[y] = sum;
	int f1, f2;
	while (!q1.empty() || !q2.empty())
	{
		if (q1.empty()) f1 = 0; else f1 = q1.front(), q1.pop(); 
		if (q2.empty()) f2 = 0; else f2 = q2.front(), q2.pop();
		if (f1)
		for (int i = G1.head[f1]; i; i = G1.Next[i])
		{
			int v = G1.ver[i];
			if (v > max(x, y) || v < min(x, y)) continue;
			if (vis1[v] == sum) continue;
			vis1[v] = sum;
			q1.push(v);
			if (vis2[v] == vis1[v]) return 1;
		}
		
		if (f2)
		for (int i = G2.head[f2]; i; i = G2.Next[i])
		{
			int v = G2.ver[i];
			if (v > max(x, y) || v < min(x, y)) continue;
			if (vis2[v] == sum) continue;
			vis2[v] = sum;
			q2.push(v);
			if (vis2[v] == vis1[v]) return 1;
		}
	}
	return 0;
}
int main(){
	freopen ("friendship.in", "r", stdin);
	freopen ("friendship.out", "w", stdout);
	read(n); read(m);
	int op, t;
	while (m--)
	{
		read(op);
		if (op == 0)
		{
			n++;
			int k;
			read(t); read(k);
			int p;
			for (int i = 1; i <= k; i++)
			{
				read(p);
				if (t) G1.add(p, n), G2.add(n, p);
				else G1.add(n, p), G2.add(p, n); 
			}
		}
		else
		{
			int x, y;
			read(x); read(y);
			sum++;
			printf("%d\n", Find(x, y));
		}
	}
  return 0;
}
