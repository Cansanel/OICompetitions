#include<bits/stdc++.h>
using namespace std;
int t[1000010][2];
int i,j,n,m,k,op,a,b,c,x,y,ans;
void dfs(int d,int e)
{
	if(d==e)ans=1;
	else
	for(int l=1;l<=b;l++)
	if(t[l][1]==d)dfs(t[l][2],e);
	return;
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	cin>>n>>m;
	for(i=1;i<=m;i++)
	{
		cin>>a;
		if(a==0)
		{
			n++;
			cin>>op>>k;
			if(op==0)
			for(j=1;j<=k;j++)
			{
				cin>>c;
				b++;
				t[b][1]=n;t[b][2]=c;
			}
			else
			{
			for(j=1;j<=k;j++)
			{
				cin>>c;
				b++;
				t[b][1]=c;t[b][2]=n;
			}	
			}
		}
		else
		{
			ans=0;
			cin>>x>>y;
			dfs(x,y);
			cout<<ans;
		}
	}
	fclose(stdin);
	fclose(stdout);
}
