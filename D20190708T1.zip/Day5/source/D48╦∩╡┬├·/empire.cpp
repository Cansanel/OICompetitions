#include<bits/stdc++.h>
using namespace std;
long long a[500010],b[500010],f[500010],t[500010],n,k,i,j;
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	cin>>n>>k;
	for(i=1;i<=n;i++){cin>>a[i-1];f[i]=f[i-1]+a[i-1];}
	for(i=1;i<=n;i++)cin>>b[i-1];
	for(i=1;i<=n;i++)
	{
	t[i]=1000000000000000000;
	for(j=1;j<=min(k,i);j++)
	t[i]=min(t[i],t[i-j]+max(f[i]-f[i-j],b[i-j]));
    }
	cout<<t[n];
	fclose(stdin);
	fclose(stdout);
}
