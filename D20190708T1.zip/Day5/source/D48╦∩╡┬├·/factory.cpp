#include<bits/stdc++.h>
using namespace std;
long long n,k,i,j,l,r,ans,g;
long long a[100010],h[100010];
int gcd(int b,int c)
{
	if(b%c==0)return c;
	else gcd(c,b%c);
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++)cin>>a[i];
	l=1;
	for(;l<=n;l=r)
	{
		r=l+1;
		h[a[l]]=1;
		g=abs(a[r]-a[l]);
		while(r<=n&&gcd((a[l]-a[r]),g)!=1&&h[a[r]]==0)
		{
			h[a[r]]=1;
			g=gcd(g,abs(a[++r]-a[l]));
		}
		ans++;
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
}
