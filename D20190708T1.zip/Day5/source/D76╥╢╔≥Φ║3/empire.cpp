#include<bits/stdc++.h>
using namespace std;
long long qzh[500010];
long long sk[500010];
long long dp[500010];
int main()
{
	freopen("empire.in", "r", stdin);
	freopen("empire.out", "w", stdout);
	int n, m;
	int i, j, k;
	cin >> n >> m;
	memset(dp, 63, sizeof(dp));
	qzh[0] = 0;
	for(i = 1;i <= n;i++)
	{
		long long cp;
		scanf("%lld", &cp);
		qzh[i] = qzh[i -1] +cp;
	}
	for(i = 1;i <= n;i++)
	{
		scanf("%lld", &sk[i -1]);
	}
	dp[0] = 0;
	if(sk[0] > qzh[1])dp[1] = sk[0];
	else dp[1] = qzh[1];
	for(i = 2;i <= n;i++)
	{
		for(j = i -1;j >= 1 && j >= i -m;j--)
		{
			dp[i] = min(dp[i], max(sk[j], qzh[i] -qzh[j]) +dp[j]);
		}
	}
	cout << dp[n];
	return 0;
}

