#include<bits/stdc++.h>
using namespace std;
int a[100010];
struct AK{
	int gcd;
	int jian;
};
AK h[100010];
inline int f(int a, int b)
{
	if(b == 0)return a;
	else return f(b, a %b);
} 
int main()
{
	freopen("factory.in", "r", stdin);
	freopen("factory.out", "w", stdout);
	int n;
	int i;
	int ans = 1;
	cin >> n;
	for(i = 1;i <= n;i++)
	{
		scanf("%d", &a[i]);
		h[i].gcd = 0;
		h[i].jian = 0;
	} 
	h[1].gcd = -1;
	for(i = 2;i <= n;i++)
	{
		if(h[i -1].gcd != -1)
		{
			int lins = a[i] - h[i -1].jian;
			if(lins % h[i -1].gcd == 0)
			{
				h[i].gcd = h[i -1].gcd;
				h[i].jian = h[i -1].jian;
			}
			else 
			{
				if(h[i -1].gcd % lins == 0 && lins > 1)
				{
					h[i].gcd = lins;
					h[i].jian = h[i -1].jian % h[i].gcd;
				}
				else 
				{
					int wyy = f(max(lins, h[i -1].gcd), min(lins, h[i -1].gcd));
					if(wyy >= 2)
					{
						h[i].gcd = wyy;
						h[i].jian = h[i -1].jian % h[i].gcd;
					}
					else 
					{
						h[i].gcd = -1;
						ans ++;
					}
				}
			}
		}
		else 
		{
			h[i].gcd = max(a[i], a[i -1]) - min(a[i], a[i -1]);
			h[i].jian = a[i] % h[i].gcd;
		}
	}
	cout << ans << endl;
	return 0;
}

