#include<bits/stdc++.h>
using namespace std;
vector<int> ve[500010];
queue<int> q;
/*
struct Union_find{
	int a[500010];
	
	inline void mem()
	{
		int i;
		for(i = 1;i <= 500000;i++)
		{
			a[i] = i;
		}
	}
	
	inline int root(int p)
	{
		if(a[p] == p)return p;
		else 
		{
			a[p] = root(a[p]);
			return a[p];
		}
	}
	
	inline bool check(int a, int b)
	{
		if(root(a) == root(b))return 1;
		return 0;
	}
};
Union_find f;*/
int main()
{
	freopen("friendship.in", "r", stdin);
	freopen("friendship.out", "w", stdout);
	int n, m;
	int i, j;
	cin >> n >> m;
	int t;int k = n;
	//f.mem();
	for(i = 1;i <= m;i++)
	{
		scanf("%d", &t);
		if(t == 0)
		{
			int x;int num;
			scanf("%d%d", &x, &num);
			k++;
			if(x == 0)
			{
				for(j = 1;j <= num;j++)
				{
					int ci;
					scanf("%d", &ci);
					ve[k].push_back(ci);
				}
			}
			else 
			{
				for(j = 1;j <= num;j++)
				{
					int ci;
					scanf("%d", &ci);
					ve[ci].push_back(k);
				}
			}
		}
		else 
		{
			int b, e;
			bool chishi = 0;
			scanf("%d%d", &b, &e);
			int bfs;
			while(!q.empty())
			{
				q.pop();
			}
			q.push(b);
			while(!q.empty())
			{
				bfs = q.front();
				if(bfs == e)
				{
					chishi = 1;
					break;
				}
				for(j = 0;j < ve[bfs].size();j++)
				{
					q.push(ve[bfs][j]);
				}
				q.pop();
			}
			cout << chishi << endl;
		}
	}
	return 0;
}

