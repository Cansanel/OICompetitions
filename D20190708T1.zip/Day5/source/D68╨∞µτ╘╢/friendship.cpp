#include<bits/stdc++.h>
using namespace std;
const int S = 500000 + 100;
int n, m, c, op, k, a, s, t;
int head[S], nxt[S], to[S], tot;
void add(int x, int y){
	to[++ tot] = y;
	nxt[tot] = head[x];
	head[x] = tot;
}
bool dfs(int x, int fa){
	if(x == t){
		return true;
	}
	for(int i = head[x]; i; i = nxt[i]){
		int y = to[i];
		if(y == fa) continue;
		if(dfs(y, x))
			return true;
	}
	return false;
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= m; ++ i){
		scanf("%d", &c);
		if(c == 1){
			scanf("%d%d", &s, &t);
			if(dfs(s, 0))
				printf("1\n");
			else
				printf("0\n");
		}
		if(c == 0){
			++ n;
			scanf("%d%d", &op, &k);
			if(k == 1){
				scanf("%d", &a);
				add(a, n); add(n, a);
				continue;
			}
			if(op == 0){
				for(int j = 1; j <= k; ++ j){
					scanf("%d", &a);
					add(n, a);
				}
			}
			if(op == 1){
				for(int j = 1; j <= k; ++ j){
					scanf("%d", &a);
					add(a, n);
				}
			}
		}
	}
	return 0;
}
