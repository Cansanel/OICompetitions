#include<bits/stdc++.h>
using namespace std;
int n, a[100005];
set<int> vis;
int now, ans;
int Gcd(int x, int y){
	if(y == 0)
		return x;
	return Gcd(y, x % y);
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; ++ i){
		scanf("%d", &a[i]);
	}
	vis.insert(a[1]);
	for(int i = 2; i <= n; ++ i){
		if(vis.count(a[i]) != 0){
			ans ++;
			now = 0;
			vis.clear();
			vis.insert(a[i]);
			continue;
		}
		vis.insert(a[i]);
		int cha = abs(a[i] - a[i - 1]);
		int gcd = Gcd(cha, now);
		if(gcd == 1){
			ans ++;
			now = 0;
		}
		else {
			now = gcd;
		}
	}
	printf("%d", ans + 1);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
