#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<iomanip>
#include<algorithm>
using namespace std;
int n,a[100005],ans=1,x,b[100005];
int gcd(int x,int y)
{
	if(y==0)return x;
	return gcd(y,x%y);
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	int i,j;
	bool t;
	cin>>n;
	cin>>a[1];
	b[0]=1;
	b[1]=a[1];
	for(i=2;i<=n;i++)
	{
		cin>>a[i];
		t=0;
		for(j=1;j<=b[0];j++)
		if(b[j]==a[i])
		{
			t=1;
			break;
		}
		if(t==1)x=1;
		else 
		{
			x=gcd(x,abs(a[i]-a[i-1]));
			b[0]++;
			b[b[0]]=a[i];
		}
		if(x==1)
		{
			ans++;
			x=0;
			b[0]=1;
			b[1]=a[i];
		}
	}
	cout<<ans<<endl;
	return 0;
}

