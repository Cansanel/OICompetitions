#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<iomanip>
#include<algorithm>
using namespace std;
int n,m,fa[500005],fb[500005];
bool finda(int x,int y)
{
	if(x==y)return 1;
	if(x==0)return 0;
	return finda(fa[x],y);
}
bool findb(int x,int y)
{
	if(x==y)return 1;
	if(x==0)return 0;
	return findb(fb[x],y);
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	int i,j,p,q,k,x,y,z;
	cin>>n>>m;
	for(i=1;i<=m;i++)
	{
		cin>>p;
		if(p==0)
		{
			cin>>q;
			cin>>k;
			n++;
			for(j=1;j<=k;j++)
			{
				cin>>z;
				if(q==0)fa[z]=n;
				else fb[z]=n;
			}
		}
		else
		{
			cin>>x>>y;
			cout<<max(finda(y,x)==1,findb(x,y)==1)<<endl;
		}
	}
	return 0;
}

