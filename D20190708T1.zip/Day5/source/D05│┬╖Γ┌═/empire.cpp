#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<iomanip>
#include<algorithm>
using namespace std;
int n,m,a[500005],b[500005],f[500005];
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	int i,j;
	cin>>n>>m;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
		a[i]+=a[i-1];
	}
	for(i=0;i<n;i++)
	cin>>b[i];
	if(n>10000)
	{
		cout<<max(b[0],a[n])<<endl;
		return 0;
	}
	for(i=1;i<=n;i++)
	{
		f[i]=2100000000;
		for(j=1;j<=min(m,i);j++)
		f[i]=min(f[i],f[i-j]+max(a[i]-a[i-j],b[i-j]));
	}
	cout<<f[n]<<endl;
	return 0;
}

