#include<bits/stdc++.h>
using namespace std;
int n,a[100001],b[100000],c=1;
int gcd(int x,int y){
	if(!y)return x;
	return gcd(y,x%y);
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];
	for(int i=0;i<n-1;i++)
		b[i]=a[i+1]-a[i];
	int m=abs(b[0]);
	for(int i=1;i<n-1;i++){
		m=gcd(m,abs(b[i]));
		if(m<2)
			c++,m=b[i+1];
	}
	cout<<c;
	return 0;
}

