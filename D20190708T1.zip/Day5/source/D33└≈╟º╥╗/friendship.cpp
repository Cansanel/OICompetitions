#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	ios::sync_with_stdio(0);
	cout<<1;
	return 0;
}
