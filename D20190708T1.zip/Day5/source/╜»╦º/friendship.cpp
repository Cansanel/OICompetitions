/*
  	�����е�����ѧ ��˧
*/

#include <bits/stdc++.h>
using namespace std;

inline long long read()
{
	int a = 0;
	char c = getchar();
	int	f = 1;
	while (!isdigit(c)) {if (c == '-') f = -1; c = getchar();}
	while (isdigit(c)) {a = a * 10 + c - '0'; c = getchar();}
	return a * f;
}

inline long long write(long long x)
{
	if (x < 0)
	{
		putchar('-');
		x = -x;
	}
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}

int main()
{
	freopen("friendship.in", "r", stdin);
	freopen("friendship.out", "w", stdout);
	int n = read(), m = read();
	for (int i = 1; i <= m; i++)
	{
		int x = read();
		if (x == 0)
		{
			int op = read();
			int c = read();
			for (int j = 1; j <= c; j++)
			{
				int f = read();
			}
		} 
		else 
		{
			int x = read(), y = read();
			write(0);
			putchar('\n');
		}
	}
	return 0;
}

