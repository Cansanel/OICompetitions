/*
  	�����е�����ѧ ��˧
*/

#include <bits/stdc++.h>
using namespace std;

inline long long read()
{
	int a = 0;
	char c = getchar();
	int	f = 1;
	while (!isdigit(c)) {if (c == '-') f = -1; c = getchar();}
	while (isdigit(c)) {a = a * 10 + c - '0'; c = getchar();}
	return a * f;
}

inline long long write(long long x)
{
	if (x < 0)
	{
		putchar('-');
		x = -x;
	}
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}

int dp[500005], f[500005];

int a[500005], b[500005];

int main()
{
	freopen("empire.in", "r", stdin);
	freopen("empire.out", "w", stdout);
	memset(f, 0x3f, sizeof(f));
	int n = read(), m = read();
	for (int i = 1; i <= n; i++)
	{
		a[i] = read();
		dp[i] = dp[i - 1] + a[i];
	} 
	for (int j = 1; j <= n; j++)
	{
		b[j] = read();
	}
	f[1] = max(dp[1], b[1]);
	for (int i = 2; i <= m; i++)
	{
		for (int j = 1; j < i; j++)
		{
			f[i] = min(f[j] + max(b[j + 1], dp[i] - dp[j]), f[i]); 
		} 
	}
	for (int i = m + 1; i <= n; i++)
	{
		for (int j = i - m; j < i; j++)
		{
			f[i] = min(f[j] + max(b[j + 1], dp[i] - dp[j]), f[i]); 
		}
	}
	write(f[n]);
	cout << endl;
	return 0;
}

