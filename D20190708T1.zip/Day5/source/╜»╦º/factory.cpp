/*
  	�����е�����ѧ ��˧
*/

#include <bits/stdc++.h>
using namespace std;

inline long long read()
{
	int a = 0;
	char c = getchar();
	int	f = 1;
	while (!isdigit(c)) {if (c == '-') f = -1; c = getchar();}
	while (isdigit(c)) {a = a * 10 + c - '0'; c = getchar();}
	return a * f;
}

inline long long write(long long x)
{
	if (x < 0)
	{
		putchar('-');
		x = -x;
	}
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}

int a[100005], b[100005];

int ans = 1;

int c[100005];

int main()
{
	freopen("factory.in", "r", stdin);
	freopen("factory.out", "w", stdout);
	int n = read();
	for (int i = 1; i <= n; i++)
	{
		a[i] = read();
	} 
	for (int i = 1; i < n; i++)
	{
		b[i] = abs(a[i] - a[i + 1]);
	}
	for (int i = 1; i < n - 1; i++)
	{
		c[i] = __gcd(b[i], b[i + 1]);
	}
	int p = 0;
	for (int i = 1; i < n - 1; i++)
	{
		if (c[i] == 1)
		{
			if (p == 0)	ans++;
			p = 1;
		}
		else p = 0;
		
	}
	write(ans);
	putchar('\n');
	return 0;
}

