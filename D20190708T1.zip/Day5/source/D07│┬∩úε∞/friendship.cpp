#include<bits/stdc++.h>
using namespace std;
int n,m,num,t;
int head[1000010];
bool vis[1000010],flag;
struct edge{
	int to,next;
} e[1000010];
void add(int a,int b){e[++num].to=b;e[num].next=head[a];head[a]=num;}
int read(){
	int x=0,f=1;char c;
	c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+c-'0';c=getchar();}
	return x*f;
}
void dfs(int now){
	vis[now]=1;
	if(now==t){
		flag=true;
		return ;
	}
	for(int i=head[now];i;i=e[i].next){
		int v=e[i].to;
		if(!vis[v]) dfs(v);
	}
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	n=read();m=read();
	while(m--){
		char c;
		c=getchar();
		if(c=='0'){
			int op,k,a;
			op=read();k=read();
			n++;
			if(k==1) add(a,n),add(n,a);
			else if(op==1){
				for(int i=1;i<=k;i++){
					a=read();
					add(a,n);
				}
			}
			else{
				for(int i=1;i<=k;i++){
					a=read();
					add(n,a);
				}
			}
		}
		else{
			int x;
			x=read();t=read();
			memset(vis,0,sizeof(vis));
			flag=false;
			dfs(x);
			if(flag) printf("1\n");
			else printf("0\n");
		}
	}
	return 0;
}
/*
3 5
0 0 2 1 2
1 1 4
0 1 2 3 4
1 4 5
1 4 2
*/
