#include<bits/stdc++.h>
using namespace std;
int n,k;
int a[500010],b[500010],sum[500010];
long long f[500010];
int read(){
	int x=0,f=1;char c;
	c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+c-'0';c=getchar();}
	return x*f;
}
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	n=read();k=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
		sum[i]=sum[i-1]+a[i];
	}
	for(int i=0;i<n;i++)
		b[i]=read();
	memset(f,0x3f3f,sizeof(f));
	f[0]=0;
	for(int i=1;i<=k;i++){
		for(int j=i-1;j>=0;j--){
			f[i]=min(f[i],f[j]+max(sum[i]-sum[j],b[j]));
		}
	}
	for(int i=k+1;i<=n;i++){
		for(int j=i-1;j>=i-k;j--){
			f[i]=min(f[i],f[j]+max(sum[i]-sum[j],b[j]));
		}
	}
	cout<<f[n]<<endl;
	return 0;
}
/*
4 2
4 3 2 1
1 2 4 4
*/
/*
4 2
4 3 2 1
1 2 10 3
*/
