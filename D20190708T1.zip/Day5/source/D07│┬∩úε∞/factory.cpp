#include<bits/stdc++.h>
using namespace std;
int n,a[100010],t,num;
set <int> s;
int read(){
	int x=0,f=1;char c;
	c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+c-'0';c=getchar();}
	return x*f;
}
int gcd(int a,int b){
	return !b ? a : gcd(b,a%b);
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	t=abs(a[2]-a[1]);
	s.insert(a[1]);s.insert(a[2]);
	if(t==1||t==0) num++,t=0,s.clear();
	for(int i=3;i<=n;i++){
		int t1=abs(a[i]-a[i-1]);
		t=gcd(t,t1);
		if(t==1||t==0) {
			s.clear();
			num++;
			t=0;
		}
		else if(!s.insert(a[i]).second){
			num++;
			t=0;
		}
	}
	num++;
	cout<<num<<endl;
	return 0;
}
/*
7
1 5 11 2 6 4 7
*/
/*
8
4 2 6 8 5 3 1 7
*/
/*
8
1 2 2 2 3 4 5 6
*/
/*


*/

