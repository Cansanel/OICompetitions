#include<bits/stdc++.h>
using namespace std;
int read(){
	int f=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(ch>='0'&&ch<='9')s=s*10+ch-'0',ch=getchar();
	return s*f;
}
int gcd(int x,int y){
	return y?gcd(y,x%y):x;
}
int a[100001];
set<int> s1;
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	int n,ans=1;n=read();
	for(int i=1;i<=n;i++)a[i]=read();
	int s=2;
	while(abs(a[s]-a[s-1])<=1&&s<=n)ans++,s++;
	int h=abs(a[s]-a[s-1]);s1.insert(a[s]);s1.insert(a[s-1]);
	for(int i=s+1;i<=n;i++){
		int g=abs(a[i]-a[i-1]);h=gcd(h,g);
		if(h==1||s1.find(a[i])!=s1.end()){
			ans++;s=i+1;s1.clear();
			while(abs(a[s]-a[s-1])<=1&&s<=n)ans++,s++;
			s1.insert(a[s]);s1.insert(a[s-1]);
			h=abs(a[s]-a[s-1]);i=s;
		}else s1.insert(a[i]);
	}
	cout<<ans<<endl;
	return 0;
}
/*  8 
	4 2 6 8 5 3 1 7 */
