#include<bits/stdc++.h>
using namespace std;
int read(){
	int f=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(ch>='0'&&ch<='9')s=s*10+ch-'0',ch=getchar();
	return s*f;
}
int a[200001];
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	int n,m,ans=0;n=read(),m=read();
	for(int i=1;i<=n;i++){
		a[i]=read();ans+=a[i];
	}
	cout<<ans<<endl;
	return 0;
}

