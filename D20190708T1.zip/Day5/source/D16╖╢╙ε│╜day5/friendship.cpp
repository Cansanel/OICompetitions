#include<bits/stdc++.h>
using namespace std;
int read(){
	int f=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(ch>='0'&&ch<='9')s=s*10+ch-'0',ch=getchar();
	return s*f;
}
int f[2500006],a[250001],tot;                                       
set<int> s[2500006];
vector<int> p[2500006];
bool myfind(int x,int y){
	if(s[x].find(y)==s[x].end()){
		int ans=0;
		for(int i=0;i<p[x].size();i++){
			ans=max(ans,int(myfind(p[x][i],y)));
		}return ans;
	}else return 1;
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	int n,m;n=read(),m=read();tot=n;
//	for(int i=1;i<=n;++i)f[i]=i;
	int h,op,k,x,y;
	for(int i=1;i<=m;++i) {
		h=read();
		if(h==0){
			op=read(),k=read();++tot;
			for(int j=1;j<=k;++j){
				a[j]=read();
			}if(op==1){
				for(int j=1;j<=k;++j){
					s[tot].insert(a[j]);
					p[tot].push_back(a[j]);
					for(int d=0;d<p[a[j]].size();++d){
						s[tot].insert(p[a[j]][d]);
					}
				}
			}else {
				for(int j=1;j<=k;++j){
					s[a[j]].insert(tot);
					p[a[j]].push_back(tot);
				}
			}
//			if(op==1){
//				f[++tot]=tot;
//				for(int j=1;j<=k;i++){
//					f[k]=tot;
//				}
//			}else{
//				
//			}
		}else{
			x=read(),y=read();
			if(myfind(y,x)){
				cout<<1<<endl;
			}else cout<<0<<endl;
		}
	}
	return 0;
}
/*
3 5
0 0 2 1 2
1 1 4
0 1 2 3 4
1 4 5
1 4 2*/
