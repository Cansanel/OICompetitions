//����֪���ǡ��� 
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m,k;
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	scanf("%d%d",&n,&m);
	while(m--){
		int op;
		scanf("%d",&op);
		if (op==0){
			scanf("%d",&op);	
			scanf("%d",&k);	
			rep(i,1,k) scanf("%d",&k);	
		}
		else{
			int x,y;
			scanf("%d%d",&x,&y);
			if (x!=y) printf("0\n");
			else printf("1\n");
		}
	}
	return 0;
}
//������(��)��(�� )
