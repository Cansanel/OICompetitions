//����֪��̸����
#include<queue>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define rep(i,j,k) for (int i=j;i<=k;i++)
#define dep(i,j,k) for (int i=j;i>=k;i--)
#define M(a,b) memset(a,b,sizeof(a))
#define ll long long
#define pll pair<ll,ll>
using namespace std;
ll n,k,a[500005],b[500005],f[500005];
priority_queue<pll,vector<pll>,greater<pll> > q1,q2;
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	cin>>n>>k;
	rep(i,1,n) cin>>a[i],a[i]=a[i]+a[i-1];
	rep(i,1,n) cin>>b[i-1];
	M(f,127);f[0]=0;
	q1.push(make_pair(f[0]+b[0],0));
	pll temp;
	rep(i,1,n){
		while(!q1.empty() && ((temp=q1.top()).first||1) && (temp.second<i-k || temp.first<f[temp.second]+a[i]-a[temp.second])){
			q2.push(make_pair(f[temp.second]-a[temp.second],temp.second));
			q1.pop();
		}
		if (!q1.empty()) f[i]=min(f[i],temp.first);
		while (!q2.empty() && ((temp=q2.top()).first||1) && (temp.second<i-k)) q2.pop();
		if (!q2.empty()) f[i]=min(f[i],a[i]+temp.first);
		q1.push(make_pair(f[i]+b[i],i));	
	}
	cout<<f[n];
	return 0;
}
