//������
#include<set>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define rep(i,j,k) for (int i=j;i<=k;i++)
#define dep(i,j,k) for (int i=j;i>=k;i--)
#define M(a,b) memset(a,b,sizeof(a))
#define ll long long
using namespace std;
ll n,a[100005],b[100005],l,ans;
set<ll> pc;
ll gcd(ll a,ll b){
	while (a%b) a^=b^=a^=b%=a;
	return b;
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	cin>>n;
	rep(i,1,n) cin>>a[i];
	if (n==1){
		printf("1");
		return 0;
	}
	rep(i,1,n-1) b[i]=abs(a[i+1]-a[i]);
	pc.clear();
	l=1;
	while (l<n && b[l]<=1) l++,ans++;
	pc.insert(a[l]),pc.insert(a[l+1]);
	ll r=b[l],tmp;
	rep(i,l+1,n-1){
		tmp=gcd(r,b[i]);
		if (tmp==1 || pc.count(a[i+1])){
			r=b[i+1];
			ans++;
			pc.clear();
		}
		else r=tmp;
		pc.insert(a[i+1]);
	}
	cout<<ans+1;
	return 0;
}
//������ 
