#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
using namespace std;
int a[500008],b[500008],n,m,i,k,aa,bb,j,ss;
bool tt=true;
long long f[10008];
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	scanf("%d %d",&n,&k);
	for(i=0;i<n;i++)
	  scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
	  scanf("%d",&b[i]);
	  ss+=b[i];if(a[i]!=b[i])tt=false;
	}
	if((ss==n)||tt||(n==k))
	{
		long long ans=0;
		for(i=0;i<n;i++)
			ans+=a[i];
		cout<<ans<<endl;
		return 0;
	}
	if(n<=10000)
	{
		memset(f,122,sizeof(f));
		f[0]=0;
		for(i=1;i<=n;i++)
		{
			aa=0,bb=0;
			for(j=i-1;j>=max(0,i-1-k+1);j--)
			{
				aa+=a[j];
				f[i]=min(f[i],f[j]+max(b[j],aa));
			}
		}
		cout<<f[n]<<endl;
		return 0;
	}
	return 0;
}
/*
4 2
4 3 2 1
1 2 10 3
*/

