#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,w[500008],g[500008],gl,a[500008],c,i,x,y,ch[500008],qq,M,tot,j;
int get(int x)
{
	int x1=x,x2;
	while(w[x]!=x)x=w[x];
	while(x1!=x)x2=x1,x1=w[x1],w[x2]=x;
	return x;
}
int fc[500008]; 
struct arr{
	int c,x,y,fc,lca;
}q[500008];
struct arr1{
	int d,nc,i;
}p[1000008];
void insert(int x,int y,int i)
{
	p[++tot]=(arr1){y,fc[x],i};fc[x]=tot;
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	scanf("%d %d",&n,&M);
	for(i=1;i<=M;i++)
	{
		scanf("%d",&q[i].c);
		if(q[i].c==0)
		{
			scanf("%d %d",&q[i].x,&q[i].y);
			for(j=1;j<=q[i].y;j++)
			  scanf("%d",&ch[++qq]);
		}
		else
		{
			scanf("%d %d",&q[i].x,&q[i].y);
			q[i].lca=-1;
			insert(q[i].x,q[i].y,i);
			insert(q[i].y,q[i].x,i);
		}
	}
	for(i=1;i<=n+M;i++)
	  w[i]=i;
	qq=0;
	for(i=1;i<=M;i++)
	{
		c=q[i].c;
		if(c==0)
		{
			a[++n]=q[i].x;m=q[i].y;
			for(j=1;j<=m;j++)
			  w[ch[++qq]]=n;
			for(int z=fc[n];z;z=p[z].nc)
			  if(get(p[z].d)==n)q[p[z].i].lca=n;
		}
		else
		{
			x=q[i].x;y=q[i].y;
			if(x==y)puts("1");
			else if(y==q[i].lca)
			{
				if(a[y]==1)puts("1");
				else puts("0");
			}
			else if(x==q[i].lca){
				if(a[x]==0)puts("1");
				else puts("0");
			}
			else puts("0");
		}
	}
	return 0;
}
/*
��������������
�������������� 
*/
