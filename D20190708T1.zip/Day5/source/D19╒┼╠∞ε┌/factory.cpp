#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
struct  arr{
	int f,d,i;
}a[100008];
bool cmp(arr a,arr b)
{
	if(a.d==b.d)return a.i<b.i;
	return a.d<b.d;
}
bool cmp1(arr a,arr b)
{
	return a.i<b.i;
}
int n,m,i,j,k,x,y,z,g[100008][20],f[100008];
int gcd(int a,int b)
{
	if(a==0||b==0)return 1;
	while(b^=a^=b^=a%=b);return a;
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
	  scanf("%d",&a[i].d);
	  a[i].i=i;
	}
	sort(a+1,a+1+n,cmp);
	for(i=2;i<=n;i++)
	  if(a[i-1].d==a[i].d)a[i].f=a[i-1].i;
	sort(a+1,a+1+n,cmp1);
	for(i=n;i>=2;i--)
	  a[i].d=abs(a[i].d-a[i-1].d);
	for(i=2;i<=n;i++)
	{
	  g[i][0]=a[i].d;
	  for(j=1;(1<<j)<i;j++)
	    g[i][j]=gcd(g[i][j-1],g[i-(1<<(j-1))][j-1]);
	}
	memset(f,100,sizeof(f));
	f[0]=0;f[1]=1;int mf=0;
	for(i=2;i<=n;i++)
	{
		int i1=i,gg=a[i].d;
		mf=max(mf,a[i].f);
		for(j=20;j>=0;j--)
		  if((i1-(1<<j)>=max(mf+1,1))&&gcd(gg,g[i1][j])!=1)
		    gg=gcd(gg,g[i1][j]),i1-=1<<j;
		f[i]=f[i1-1]+1;
	}
	printf("%d\n",f[n]);
	return 0;
}
/*
7
1 5 11 2 6 4 7
*/
