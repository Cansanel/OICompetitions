#include<bits/stdc++.h>
using namespace std;
int n,a[100001],tot,las1,las2;
int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=2;i<=n;i++){
		las1=gcd(abs(a[i]-a[i-1]),las2);
		if(las1==1)tot++,las2=0;else las2=las1;
		//printf("%d:%d %d %d\n",i,las1,las2,tot);
	}
	printf("%d\n",tot+1);
	return 0;
}
/*
10
10 6 12 8 2 4 3 190 100 10 
(3)

10
3 10 6 12 8 2 4 190 100 10 
(3)

10
3 10 6 12 8 2 4 190 100 10 
(2)
*/
