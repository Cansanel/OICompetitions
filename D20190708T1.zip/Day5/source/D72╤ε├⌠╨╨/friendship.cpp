#include<bits/stdc++.h>
using namespace std;
int n,m,head[500001],cnt,t1,t2,t3,t4;
struct node{
	int to,next;
}edge[1000001];
inline void ae(int u,int v){
	edge[cnt].to=v,edge[cnt].next=head[u],head[u]=cnt++;
}
bool vis[500001];
inline bool fd(int x,int y){
	queue<int>q;
	memset(vis,false,sizeof(vis));
	q.push(x);
	vis[x]=true;
	while(!q.empty()){
		int t=q.front();q.pop();
		for(register int i=head[t];i!=-1;i=edge[i].next){
			if(edge[i].to==y)return true;
			if(vis[edge[i].to])continue;
			vis[edge[i].to]=true,q.push(edge[i].to);
		}
	}
	return false;
}
void read(int &x){
	x=0;
	char c=getchar();
	while(c>'9'&&c<'0')c=getchar();
	while(c<='9'&&c>='0')x=(x<<3)+(x<<1)+(c^48),c=getchar();
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	read(n),read(m),memset(head,-1,sizeof(head));
	while(m--){
		read(t1);
		if(!t1){
			read(t2),read(t3),n++;
			if(t3==1){
				read(t4),ae(t4,n),ae(n,t4);
				continue;
			}
			for(register int i=1;i<=t3;i++){
				read(t4);
				if(t2)ae(t4,n);
				else ae(n,t4);
			}
		}else{
			read(t2),read(t3);
			puts(fd(t2,t3)?"1":"0");
		}
	}
	return 0;
}
/*
4 12
1 2 4
0 1 2 1 2
1 2 5
1 5 2
0 0 3 3 4 5
1 5 6
1 6 2
0 1 1 6
1 7 3
1 7 5
1 7 6
1 6 7

0
1
0
0
0
1
1
1
1
*/
