#include<bits/stdc++.h>
using namespace std;
const long long MAXN=1e18;
const long long O=0;
long long n,k,s[500001],b[500001],f[500001];
bool all=true;
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for(register long long i=0;i<n;i++)scanf("%lld",&s[i+1]),s[i+1]+=s[i],f[i+1]=MAXN;
	for(register long long i=0;i<n;i++)scanf("%lld",&b[i]),all&=(b[i]<=s[i+1]-s[i]);
	if(all){
		printf("%lld\n",s[n]);
		//puts("IN");
		return 0;
	}
	if(n==k){
		printf("%lld\n",max(b[0],s[n]));
		//puts("IN");
		return 0;
	}
//	for(long long i=1;i<=n;i++)printf("%lld ",b[i]);puts("");
	for(register long long i=0;i<=n;i++)for(register long long j=max(O,i-k);j<i;j++)f[i]=min(f[i],f[j]+max(s[i]-s[j],b[j]));
	//for(long long i=1;i<=n;i++)printf("%lld %lld %lld\n",s[i],b[i],f[i]);
	printf("%lld\n",f[n]);
	return 0;
}
/*
6 2
2 3 6 4 9 8
10 1 2 5 3 7
37

15 1
3242 2354235 234235 123424 1425 124215 123425 1425 142 124 58678 45647 346478 2353 2142
1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
3421190

15 1
3242 2354235 234235 123424 1425 124215 123425 1425 142 124 58678 45647 346478 2353 2142
123 32 123 34 46 456 3 43 54 65 89 68 56 34 1
3421190

10 34
1 23 456 7890 12345 123456 1234567 12345678 98765432 19999999
1 23 456 7890 12345 123456 1234567 12345678 98765432 19999999
132489847

10 10
1231 2535 234 252 4634 256 25 2536 235 234
13141524 142 5425 24536 25347 25367 2456457 235 324 245
13141524
*/
