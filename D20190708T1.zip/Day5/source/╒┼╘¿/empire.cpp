#include<bits/stdc++.h>
using namespace std;

int a[500500], b[500500];


int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	int n, k, s = 0;
	cin >> n >> k;
	for (int i = 1; i <= n; ++ i)
	{
		cin >> a[i];
		s += a[i];
	}
	for (int i = 1; i <= n; ++ i) cin >> b[i];
	cout << max(s, b[1]) << endl;
	return 0;
}
