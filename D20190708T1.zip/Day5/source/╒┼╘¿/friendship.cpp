#include<bits/stdc++.h>
using namespace std;

int a[500500], b[500500], c[250500];

int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	int n, m, k, x, op, js = 0, jb = 0, Y, Z;
	cin >> n >> m;
	for (int i = 1; i <= m; ++ i)
	{
		cin >> x;
		if (x == 0)
		{
			js ++;
			cin >> op >> k;
			c[js] = c[js - 1] + k;
			for (int j = 1; j <= k; ++ j)
			{
				cin >> a[j];
				if (a[j] > n)
				{
					for (int l = c[a[j] - n - 1]; l <= c[a[j] - n]; ++ l)
					{
						jb ++;
						b[jb] = b[l];
					}
				}
				else
				{
					jb ++;
					b[jb] = a[j];
				}
			}
			sort(b + c[js - 1] + 1, b + c[js] + 1);
		}
		else
		{
			
			cin >> Y >> Z;
			if (Y > n && Z > n)
			{
				int p = 0;
				for (int l = c[Y - n - 1]; l <= c[Y - n]; ++ l)
				{
					for (int j = c[Z - n - 1]; j <= c[Z - n]; ++ j)
						if (b[l] == b[j]) p ++;
				}
				if (p == c[Y - n] - c[Y - n - 1]) cout << "1" << endl;
				else cout << "0" << endl;
			}
			else if (Y > n && Z <= n)
				{
					int jk = 1;
					for (int l = c[Y - n - 1]; l <= c[Y - n]; ++ l)
						if (Z == b[l]) {cout << "1" << endl; jk = 0;}
					if (jk == 0) cout << "0" << endl;
				}
				else if (Y <=n && Z > n)
					{
						int jk = 1;
						for (int l = c[Z - n - 1]; l <= c[Z - n]; ++ l)
							if (Y == b[l]) {cout << "1" << endl; jk = 0;}
						if (jk == 0) cout << "0" << endl;
					}
					else if (Y <= n && Z <= n)
						{
							if (Y == Z) cout << "1" << endl;
							else cout << "0" << endl;
						}
		}
	}
	return 0;
}

