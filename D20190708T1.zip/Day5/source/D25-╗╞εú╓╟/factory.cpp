#include<bits/stdc++.h>
using namespace std;
int A[100001],B[100001];
int N,Ans=1,Now;
int GCD(int a,int b){
	return b==0?a:GCD(b,a%b);
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	scanf("%d",&N);
	for(int i=1;i<=N;++i)
		scanf("%d",&A[i]);
	for(int i=1;i<N;++i)
		B[i]=abs(A[i+1]-A[i]);
	for(int i=1;i<N;++i){
//		printf("%d ",B[i]);
		if(B[i]==0||B[i]==1){
			++Ans;
			Now=0;
			continue;
		}
		Now=GCD(B[i],Now);
		if(Now==1){
			Now=0;
			++Ans;
		}
	}
//	puts("");
	printf("%d\n",Ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
7
1 5 11 2 6 4 7
*/
/*
8
4 2 6 8 5 3 1 7 
*/
/*
8
1 1 1 1 1 1 1 1
*/
/*
8
1 2 3 4 5 6 7 8
*/
/*
8
1 2 4 6 2 7 5 9
*/
