#include<bits/stdc++.h>
using namespace std;
struct Xjh{
	int Ver,Next;
}E[1000001];
int N,M,Head[500001],Cnt,Ins,Op,k;
void Add_Edge(int x,int y){
	E[++Cnt].Ver=y;
	E[Cnt].Next=Head[x];
	Head[x]=Cnt;
}
bool Find(int u,int f,int Goal){
	if(u==Goal)
		return true;
	for(int i=Head[u],v;i;i=E[i].Next){
		if((v=E[i].Ver)==f)continue;
		if(Find(v,u,Goal))return true;
	}
	return false;
}
void Work_70(){
	for(int i=1;i<=M;++i){
		scanf("%d",&Ins);
		if(Ins==0){
			scanf("%d%d",&Op,&k);
			++N;
			int u;
			if(k==1){
				scanf("%d",&u);
				Add_Edge(u,N);
				Add_Edge(N,u);
				continue;
			}
			if(Op==0)
				for(int j=1;j<=k;++j){
					scanf("%d",&u);
					Add_Edge(u,N);
				}
			if(Op==1)
				for(int j=1;j<=k;++j){
					scanf("%d",&u);
					Add_Edge(N,u);
				}
		}
		if(Ins==1){
			int x,y;
			scanf("%d%d",&x,&y);
			if(Find(y,y,x))
				puts("1");
			else
				puts("0");
		}
	}
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	scanf("%d%d",&N,&M);
	if(M<=5000)
		Work_70();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
3 5
0 0 2 1 2
1 1 4
0 1 2 3 4
1 4 5
1 4 2
*/
