#include<bits/stdc++.h>
#define LL long long
using namespace std;
int N,K;
bool Flag1=1,Flag2=1,Flag3=1;
LL A[500001],B[500001],S[500001],Opt[500001];
void Work_50(){
	for(int i=1;i<=N;++i)
		Opt[i]=LONG_LONG_MAX;
	for(int i=1;i<=N;++i)
		for(int j=max(0,i-K);j<i;++j)
			Opt[i]=min(Opt[i],Opt[j]+max(B[j],S[i]-S[j]));
	printf("%lld\n",Opt[N]);
}
void Work_20(){
	LL Ans=0;
	for(int i=1;i<=N;++i)
		Ans+=A[i];
	printf("%lld\n",Ans);
}
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	scanf("%d%d",&N,&K);
	for(int i=1;i<=N;++i)
		scanf("%lld",&A[i]);
	for(int i=0;i<N;++i)
		scanf("%lld",&B[i]);
	for(int i=1;i<=N;++i)
		S[i]=S[i-1]+A[i];
	if(N<=10000){
		Work_50();
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	Flag3=(N==K);
	for(int i=1;i<=N;++i){
		if(B[i-1]!=1)Flag1=0;
		if(A[i]!=B[i-1])Flag2=0;
	}
	if(Flag1||Flag2){
		Work_20();
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
4 2
4 3 2 1
1 2 4 4
*/
/*
4 2
4 3 2 1
1 2 10 3
*/
/*
2 2
10 1
100 10000
*/
