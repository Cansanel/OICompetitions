#include<cstdio>
#include<cctype>
#include<map>
#include<algorithm>
#define MaxN 100010

std::map<int, int> Hash;
int n, a[MaxN], g, ans;

inline int read() {
	int x = 0, f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
	return x * f;
}

inline int gcd(int x, int y) {
	return x % y == 0 ? y : gcd(y, x % y);
}

int main() {
	freopen("factory.in", "r", stdin);
	freopen("factory.out", "w", stdout);
	
	n = read();
	for (int i = 1; i <= n; ++i) a[i] = read();
	int l = 1, r;
	for (; l <= n; l = r) {
		r = l + 1;
		Hash[a[l]] = 1;
		g = abs(a[r] - a[l]);
		while (r <= n && gcd(g, abs(a[r] - a[l])) != 1 && Hash.count(a[r]) == 0) {
			Hash[a[r]] = 1;
			g = gcd(g, abs(a[++r] - a[l]));
		}
		++ans;
		Hash.clear();
	}
	printf("%d\n", ans);
	return 0;
}
