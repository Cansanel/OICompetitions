#include<cstdio>
#include<cctype>
#define MaxN 2000010

struct edge {int v, nxt;} e[MaxN];
struct query {int x, y;} q[MaxN];

int dfn[MaxN], low[MaxN], head[MaxN], a[MaxN], degree[MaxN], f[MaxN][2], dep[MaxN];
int n, m, op, k, tot, cnt_q, tim, t, x;

inline int read() {
	int x = 0, f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
	return x * f;
}

void addedge(int x, int y) {
	e[++tot] = (edge) {y, head[x]};
	head[x] = tot;
}

void dfs(int x) {
	dfn[x] = ++tim;
	for (int i = head[x]; i; i = e[i].nxt) {
		int y = e[i].v;
		if (a[x] == 0 || degree[x] == 1) f[y][0] = f[x][0] + 1;
		else f[y][0] = 0;
		if (a[x] == 1 || degree[x] == 1) f[y][1] = f[x][1] + 1;
		else f[y][1] = 0;
		dep[y] = dep[x] + 1;
		dfs(y);
	}
	low[x] = tim;
}

int main() {
	freopen("friendship.in", "r", stdin);
	freopen("friendship.out", "w", stdout);
	n = read(); m = read();
	for (int i = 1; i <= m; ++i) {
		t = read();
		if (t == 0) {
			op = read(); k = read();
			++n;
			for (int j = 1; j <= k; ++j) {
				x = read();
				addedge(n, x);
			}
			a[n] = op;
			degree[n] = k;
		}
		else q[++cnt_q] = (query) {read(), read()};
	}
	for (int i = n; i; --i) if (!dfn[i]) dfs(i);
	for (int i = 1; i <= cnt_q; ++i) {
		int u = q[i].x, v = q[i].y;
		if (dfn[u] <= dfn[v] && low[v] <= low[u]) {
			if (f[v][0] >= dep[v] - dep[u]) puts("1");
			else puts("0");
		}
		else
		if (dfn[v] <= dfn[u] && low[u] <= low[v]) {
			if (f[u][1] >= dep[u] - dep[v]) puts("1");
			else puts("0");
		}
		else puts("0");
	}
	return 0;
}
