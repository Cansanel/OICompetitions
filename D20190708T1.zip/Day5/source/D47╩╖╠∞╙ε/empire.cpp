#include<cstdio>
#include<queue>
#include<cstring>
#include<cctype>
#include<algorithm>
#define MaxN 500010

typedef long long LL;

const LL INF = 0x7fffffffffffffff;

struct node {
	int idx; LL num;
	bool operator < (const node &rhs) const {
		return num > rhs.num;
	}
};

std::priority_queue<node> heap1, heap2;

int n, k, a[MaxN], b[MaxN];
LL sum[MaxN], f[MaxN];

inline int read() {
	int x = 0, f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
	return x * f;
}

int main() {
	freopen("empire.in", "r", stdin);
	freopen("empire.out", "w", stdout);
	n = read(); k = read();
	for (int i = 1; i <= n; ++i) a[i] = read(), sum[i] = sum[i - 1] + 1LL * a[i];
	for (int i = 1; i <= n; ++i) b[i - 1] = read();
	memset(f, 0x3f, sizeof f);
	f[0] = 0;
	for (int i = 1; i <= n; ++i) {
		heap1.push((node) {i - 1, f[i - 1] + b[i - 1]});
		while (!heap1.empty()) {
			node x = heap1.top();
			if (i - x.idx > k) heap1.pop();
			else break;
		}
		while (!heap2.empty()) {
			node x = heap2.top();
			if (i - x.idx > k) heap2.pop();
			else break;
		}
		while (!heap1.empty()) {
			node x = heap1.top();
			if (x.num > f[x.idx] + sum[i] - sum[x.idx]) break;
			heap1.pop();
			heap2.push((node) {x.idx, f[x.idx] - sum[x.idx]});
		}
		while (!heap1.empty()) {
			node x = heap1.top();
			if (i - x.idx > k) heap1.pop();
			else break;
		}
		while (!heap2.empty()) {
			node x = heap2.top();
			if (i - x.idx > k) heap2.pop();
			else break;
		}
		LL tmp = INF;
		if (!heap1.empty()) tmp = std::min(tmp, heap1.top().num);
		if (!heap2.empty()) tmp = std::min(tmp, heap2.top().num + sum[i]);
		f[i] = tmp;
	}
	printf("%lld\n", f[n]);
	return 0;
}
