#include<bits/stdc++.h>
using namespace std;
int n,k,ycf[500005],cf[500005],sq[500005],dpp[500005];
long long dp(int x){
	if(dpp[x]!=-1)
	return dpp[x];
	if(x==n+1)
	return 0LL;
	long long ans=9223372036854775807LL;
	for(int i=x+1;i<=min(x+k,n+1);i++){
		ans=min(ans,dp(i)+max(sq[x],cf[i-1]-cf[x-1]));
	}
	return dpp[x]=ans;
}
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	memset(dpp,-1,sizeof dpp);
	memset(cf,0,sizeof cf);
	bool shifen1=true,shifen2=true;
	cin>>n>>k;
	cf[0]=0;
	for(int i=1;i<=n;i++){
		cin>>ycf[i];
		if(i)
		cf[i]=cf[i-1]+ycf[i];
	}
	for(int i=1;i<=n;i++){
		cin>>sq[i];
		if(sq[i]!=1)
		shifen1=false;
	}
	for(int i=1;i<=n;i++){
		if(ycf[i]!=sq[i-1])
		shifen2=false;
	}
	if(n==k){
		cout<<max(sq[1],cf[n])<<endl;
	}else if(shifen1){
		cout<<cf[n]<<endl;
	}else if(shifen2)
	cout<<cf[n]<<endl;
	else
	cout<<dp(1)<<endl;
	return 0;
}
