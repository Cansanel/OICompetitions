#include<bits/stdc++.h>
using namespace std;
int a[100005],gc=0,ans=0;
set<int>pcc;
int gcd(int n,int m){
	if(m==0)
	return n;
	return gcd(m,n%m);
}
bool pc(int x){
	int cnt=pcc.size();
	pcc.insert(x);
	if(pcc.size()==cnt)
	return true;
	return false;
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	for(int i=0;i<n;i++){
		if(i==0||pc(a[i])||gcd(abs(a[i]-a[i-1]),gc)<=1){
			pcc.clear();
			gc=0;
			ans++;
			i++;
		}else
		gc=gcd(abs(a[i]-a[i-1]),gc);
	}
	cout<<ans<<endl;
	return 0;
}
