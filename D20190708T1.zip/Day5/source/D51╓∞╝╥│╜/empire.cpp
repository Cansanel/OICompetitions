#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define maxn 500010
#define ll long long
using namespace std;
int sum[maxn],b[maxn];
int dp[maxn];
int n,k;
void fread(int &x)
{
	x=0;
	char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9')
	{
		x=x*10+c-48;
		c=getchar();
	}
}
int main()
{
	freopen("empire.in","r",stdin);
    freopen("empire.out","w",stdout);
    fread(n),fread(k);
    for(int i=1;i<=n;i++)
    {
    	int x;
    	fread(x);
    	sum[i]=sum[i-1]+x;
    }
    for(int i=0;i<n;i++)
    fread(b[i]);
    for(int i=1;i<=n;i++)
    {
    	dp[i]=inf;
    	for(int j=max(i-k,0);j<i;j++)
    	dp[i]=min(dp[i],dp[j]+max(sum[i]-sum[j],b[j]));
    }
    printf("%d",dp[n]);
}

