#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define maxn 500010
#define ll long long
using namespace std;
int a[maxn][3],b[maxn];
int n,m,tot,p[maxn],f[maxn][20],t[maxn],num[maxn],d[maxn];
bool g1[maxn][20],g2[maxn][20];
int o[maxn][3],s;
void fread(int &x)
{
	x=0;
	char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9')
	{
		x=x*10+c-48;
		c=getchar();
	}
}
void add(int x,int y)
{
	tot++;
	a[tot][0]=x;
	a[tot][1]=y;
	a[tot][2]=b[x];
	b[x]=tot;
	tot++;
	a[tot][0]=y;
	a[tot][1]=x;
	a[tot][2]=b[y];
	b[y]=tot;
}
void dfs(int x,int fa)
{
	for(int i=b[x];i;i=a[i][2])
	{
		int y=a[i][1];
		if(y==fa) continue; 
		if(p[x]==1&&num[x]>1)
		g1[y][0]=false;
		else
		g1[y][0]=true;
		if(p[x]==2&&num[x]>1)
		g2[y][0]=false;
		else
		g2[y][0]=true;
		f[y][0]=x;
		d[y]=d[x]+1;
		dfs(y,x);
	}
}
void swp(int &x,int &y)
{
	int t=x;
	x=y;
	y=t;
}
bool lca(int x,int y,int q)
{
	if(d[x]>d[y])
	{
		for(int i=19;i>=0;i--)
		{
			if(d[f[x][i]]>=d[y])
			{
				if(!g1[x][i]) return false;
				x=f[x][i];
			}
		}
	}
	else
	{
		for(int i=19;i>=0;i--)
		{
			if(d[f[y][i]]>=d[x])
			{
				if(!g2[y][i]) return false;
				y=f[y][i];
			}
		}
	}
	if(x==y)
	{
		if(t[x]<q) return true;
		return false; 
	}
	for(int i=19;i>=0;i--)
	{
		if(f[x][i]!=f[y][i])
		{
			if(!g1[x][i]) return false;
			if(!g2[y][i]) return false;
			x=f[x][i];
			y=f[y][i];
		}
	}
	if(t[f[x][0]]<q&&g1[x][0]&&g2[y][0]) return true;
	else return false;
}
int main()
{
	freopen("friendship.in","r",stdin);
    freopen("friendship.out","w",stdout);
    fread(n),fread(m);
    for(int i=1;i<=n;i++)
    num[i]=t[i]=0;
    int cnt=0;
    while(m--)
    {
    	int QAQ;
    	cnt++;
    	fread(QAQ);
    	if(QAQ==0)
    	{
    		int op,k;
    		fread(op),fread(k);
    		n++;
    		t[n]=cnt;
    		for(int i=1;i<=k;i++)
    		{
    			int x;
    			fread(x);
    			add(x,n);
    		}
    		num[n]=k;
    		if(op==0)
    		p[n]=1;
    		else
    		p[n]=2;
    	}
    	else
    	{
    		int x,y;
    		fread(x),fread(y);
    		s++;
    		o[s][0]=x,o[s][1]=y;
    		o[s][2]=cnt;
    	}
    }
    f[n][0]=0;
    g1[n][0]=g2[n][0]=true;
    d[n]=1;
    dfs(n,0);
    for(int k=1;k<=19;k++)
    {
    	for(int i=1;i<=n;i++)
    	{
    		f[i][k]=f[f[i][k-1]][k-1];
    		g1[i][k]=(g1[i][k-1]&&g1[f[i][k-1]][k-1]);
    		g2[i][k]=(g2[i][k-1]&&g2[f[i][k-1]][k-1]);
    	}
    }
    for(int i=1;i<=s;i++)
    {
    	if(lca(o[i][0],o[i][1],o[i][2]))
    	printf("1\n");
    	else
    	printf("0\n");
    }
}

