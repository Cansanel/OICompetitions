#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define maxn 100010
#define ll long long
using namespace std;
int n,a[maxn];
void fread(int &x)
{
	x=0;
	char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9')
	{
		x=x*10+c-48;
		c=getchar();
	}
}
int gcd(int a,int b)
{
	if(b==0) return a;
	return gcd(b,a%b);
}
int main()
{
	freopen("factory.in","r",stdin);
    freopen("factory.out","w",stdout);
    int lasg=0,ans=1;
    fread(n);
    for(int i=1;i<=n;i++)
    fread(a[i]);
    for(int i=2;i<=n;i++)
    {
    	int t=abs(a[i]-a[i-1]);
    	if(gcd(t,lasg)==1||t==0)
    	{
    		lasg=0;
    		ans++;
    	}
    	else lasg=gcd(t,lasg);
    }
    printf("%d",ans);
}

