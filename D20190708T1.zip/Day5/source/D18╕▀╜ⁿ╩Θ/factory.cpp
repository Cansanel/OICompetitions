#include<bits/stdc++.h>
using namespace std;
int n,k,a[200010],p[200010],ans;
bool f;
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	cin>>n;
	for (int i=1;i<=n;i++) cin>>a[i];
	f=true;
	memset(p,0,sizeof(p));
	ans=1;
	for (int i=1;i<=n;i++)
	{
		if (f)
		{
			k=a[i]%2;
			f=false;
			p[a[i]]=1;
		}
		else
		{
			if (a[i]%2==k&&!p[a[i]]) p[a[i]]=0;
			else
			{
				ans++;
				memset(p,0,sizeof(p));
				k=1-k;
			}
		}
	}
	cout<<ans<<endl;
}
