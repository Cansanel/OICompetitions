#include<bits/stdc++.h>
using namespace std;
int n,k,a[600010],b[600010],f[600010],ans;
int p(int l,int r)
{
	int sum=0;
	for (int i=l;i<=r;i++) sum+=a[i];
	return sum;
}
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	cin>>n>>k;
	for (int i=1;i<=n;i++) cin>>a[i];
	for (int i=1;i<=n;i++) cin>>b[i];
	if (n*k<=10000000)
	{
	for (int i=1;i<=n;i++) f[i]=2147483647;
	f[0]=0;
	for (int i=1;i<=n;i++)
		for (int j=max(1,i-k+1);j<=i;j++)
			f[i]=min(f[i],f[j-1]+max(b[j],p(j,i)));
	cout<<f[n]<<endl;
	}
	else
	{
		int tot=0;
		bool flag=true;
		for (int i=1;i<=n;i++) if (b[i]!=1) flag=false;
		if (flag)
		{
			for (int i=1;i<=n;i++) tot+=a[i];
			cout<<tot<<endl;
		}
		else
		{
			while(tot<flag)
			{
				tot+=k;
				ans+=k*a[tot];
			}
			cout<<ans<<endl;
		}
	}
}
