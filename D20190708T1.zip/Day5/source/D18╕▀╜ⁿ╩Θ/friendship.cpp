#include<bits/stdc++.h>
using namespace std;
int n,m,k,a[500010],op,z,dep[500010],fa[500010],son[500010];
int get(int x)
{
	if (x==fa[x]) return x;
	return fa[x]=get(fa[x]);
}
int find(int x)
{
	if (x==son[x]) return x;
	return son[x]=get(son[x]);
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=n;i++) fa[i]=i,son[i]=i;
	for (int i=1;i<=m;i++)
	{
		cin>>z;
		if (z==0)
		{
			cin>>op>>k;
			n++;
			for (int j=1;j<=k;j++)
			{
				int x;
				cin>>x;
				if (op==0) son[x]=n,fa[n]=n,son[n]=n;
				else fa[x]=n,fa[n]=n,son[n]=n;
			}
		}
		else
		{
			int x,y;
			cin>>x>>y;
			int xx=x,yy=y;
			bool p=false;
			while(fa[x]!=x)
			{
				if (fa[x]==yy)
				{
					p=true;
					break;
				}
				x=fa[x];
			}
			while(son[y]!=y)
			{
				if (son[y]==xx)
				{
					p=true;
					break;
				}
				y=son[y];
			}
			if (p) cout<<"1"<<endl;
			else cout<<"0"<<endl;
		}
	}
}
