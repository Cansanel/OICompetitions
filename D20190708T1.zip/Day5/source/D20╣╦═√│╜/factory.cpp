#include<stdio.h>
int n,a[100010],d,f[100010],p;
bool WA;
int gcd(int a,int b)
{
	if(!a&&!b) return 1;
	return b? gcd(b,a%b):a;
}
int abs(int x)
{
	return x>0? x:-x;
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	f[0]=0;
	f[1]=1;
	for(int i=2;i<=n;i++)
	{
		WA=false;
		if(d==-1)
		{
			d=abs(a[p+1]-a[p]);
			for(int j=i-1;j>p;j--)
			{
				if(gcd(d,abs(a[j+1]-a[j]))==1)
				{
					WA=true;
					break;
				}
				d=gcd(d,abs(a[j+1]-a[j]));
			}
		}
		else
		{
			if(gcd(d,abs(a[i]-a[i-1]))==1) WA=true;
			d=gcd(d,abs(a[i]-a[i-1]));
		}
		if(WA) goto FUCK;
		for(int j=1;j<i;j++)
			if(a[j]==a[i]) WA=true;
		FUCK:;
		f[i]=f[i-1]+WA;
		if(WA)
		{
			p=i;
			d=-1;
		}
	}
	printf("%d\n",f[n]);
	return 0;
}
