#include<stdio.h>
#include<string.h>
int n,m,f,x,y,cnt;
bool is,ak[20010];
struct _ops
{
	int op,k,a[1010],id;
}ops[10010];
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	scanf("%d%d",&n,&m);
	while(m--)
	{
		scanf("%d",&f);
		if(f==0)
		{
			cnt++;
			scanf("%d%d",&ops[cnt].op,&ops[cnt].k);
			printf("%d\n",ops[cnt].k);
			for(int i=1;i<=ops[cnt].k;i++) scanf("%d",&ops[cnt].a[i]);
			ops[cnt].id=n+cnt;
		}
		if(f==1)
		{
			scanf("%d%d",&x,&y);
			is=false;
			memset(ak,false,sizeof(ak));
			ak[x]=true;
			for(int i=1;i*i<=n;i++)
			{
				for(int j=1;j<=cnt;j++)
				{
					if(ops[j].op==0&&!ak[ops[j].id])
					{
						bool fk=true;
						for(int k=1;k<=ops[j].k;k++)
						{
							if(!ak[ops[j].a[k]])
							{
								fk=false;
								break;
							}
						}
						if(fk) ak[ops[j].id]=true;
					}
					if(ops[j].op==0&&ak[ops[j].id])
						for(int k=1;k<=ops[j].k;k++) ak[ops[j].a[k]]=true;
					if(ops[j].op==1&&!ak[ops[j].id])
					{
						bool fk=false;
						for(int k=1;k<=ops[j].k;k++)
						{
							if(ak[ops[j].a[k]])
							{
								fk=true;
								break;
							}
						}
						if(fk) ak[ops[j].id]=true;
					}
					else if(ops[j].op==1&&ak[ops[j].id])
					{
						int ct=0,id;
						for(int k=1;k<=ops[j].k;k++)
						{
							if(!ak[ops[j].a[k]])
							{
								ct++;
								id=k;
							}
						}
						if(ct==1) ak[ops[j].a[id]]=true;
					}
				}
			}
			printf("%d\n",ak[y]);
		}
	}
	return 0;
}
