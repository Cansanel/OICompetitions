#include<bits/stdc++.h>
using namespace std;
int read(){
	int r=0,f=1;
	char ch=getchar();
	while (!isdigit(ch)&&ch!='-') ch=getchar();
	if (ch=='-') f=-1,ch=getchar();
	while (isdigit(ch)) r=r*10+ch-'0',ch=getchar();
	return r*f;
}
bitset<10005> a[5005],ls;
int n,m,x,op,k,d,y,t;
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=m;i++){
		x=read();
		if (x==0){
			op=read();
			k=read();
			if (op==0){
				ls.set();
				for (int i=1;i<=k;i++){
					d=read();
					if (d<=n){
						if (ls[d]==0) ls.reset();
						else {ls.reset();ls[d]=1;}
					}
					else ls=ls&a[d-n];
				}
			}
			else {
				ls.reset();
				for (int i=1;i<=k;i++){
					d=read();
					if (d<=n) if (ls[d]==1) ls[d]=1;
					else ls=ls|a[d-n];
				}
			}
			a[++t]=ls;
		} 
		else {
			y=read();
			x=read();
			if (x<=n) {
				if  (y<=n){
				if (x==y){
					puts("1");
					continue;
				}
				puts("0");
				continue;
				}
				else {
					y-=n;
					if ((a[y].count()==1&&a[y][x]==1)||a[y].count()==0){
						puts("1");
						continue;
					}
					puts("0");
					continue;
				}
			}
			else {
				x-=n;
				if (y<=n){
					if (a[x][y]) {
						puts("1");
						continue;
					}
					else {
						puts("0");
						continue;
					}
				}
				else {
					y-=n;
					ls=a[x]&a[y];
					if (ls.count()<a[y].count()){
						puts("0");
						continue;
					}
					puts("1");
					continue;
				}
			}
			ls.reset();
			ls=a[x]&a[y];
			if (ls.count()<a[x].count()) puts("0");
			else puts("1");
		}
	}
	return 0;
}

