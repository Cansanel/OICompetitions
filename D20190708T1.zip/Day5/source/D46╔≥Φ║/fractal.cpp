#include<bits/stdc++.h>
using namespace std;
int yc,xc;
double sy,sx,p,q;
int read(){
	int r=0,f=1;
	char ch=getchar();
	while (!isdigit(ch)&&ch!='-') ch=getchar();
	if (ch=='-') f=-1,ch=getchar();
	while (isdigit(ch)) r=r*10+ch-'0',ch=getchar();
	return r*f;
}
struct Fractal{
	double x,y;
};
Fractal operator +(Fractal d,Fractal e) {
	Fractal ans;
	ans.x=d.x+e.x;
	ans.y=d.y+e.y;
	return ans;
}
Fractal operator -(Fractal d,Fractal e) {
	Fractal ans;
	ans.x=d.x-e.x;
	ans.y=d.y-e.y;
	return ans;
}
Fractal operator *(Fractal d,Fractal e) {
	Fractal ans;
	ans.x=d.x*e.x-d.y*e.y;
	ans.y=d.x*e.y+d.y*e.x;
	return ans;
}
double mod(Fractal d){
	double ans=sqrt(d.x*d.x+d.y*d.y);
	return ans;
}
Fractal z[101];
bool get(Fractal d,double x,double y){
	Fractal c;
	c.x=x;
	c.y=y;
	z[0].x=d.x;
	z[0].y=d.y;
	if (mod(z[0])>=10) return 1;
	for (int i=1;i<=100;i++){
		z[i]=(z[i-1]*z[i-1])+c;
		double t=mod(z[i]);
		if (t>=10) return 0;
	}
	return 1;
}
void init(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx>>p>>q;
	return ;
}
void work(){
	for (int j=0;j<yc;j++) {
		for (int i=0;i<xc;i++) {
			Fractal d;
			d.x=sy+i*0.005;
			d.y=sx+j*0.01;
			if (get(d,p,q)) putchar('a');
			else putchar(' ');
		}
		puts("");
	}
	return ;
}
int main(){
	init();
	work();
	return 0;
}

