#pragma GCC optimmize(2)
#include<bits/stdc++.h>
using namespace std;
int read(){
	int f=1,r=0;
	char ch=getchar();
	while (!isdigit(ch)&&ch!='-') ch=getchar();
	if (ch=='-') f=-1,ch=getchar();
	while (isdigit(ch)) r=r*10+ch-'0',ch=getchar();
	return r*f;
}
void write(int x){
	 printf("%d",x);
}
void writeln(int x){
	 write(x);
	 puts("");
}
struct node{
	int x,y,z,num;
}a[1000001],c[1000001];
int fa[1000001],n,m,ans[1000001],sizeans,t[1000001],b[1000001];
bool operator <(node d,node e){
	return d.z<e.z;
}
int get(int x){
	if (x==fa[x]) return x;
	return fa[x]=get(fa[x]);
}
int MST(){
	memset(ans,0,sizeof(ans));
	sizeans=0;
	for (int i=1;i<=m;i++) c[i].x=a[i].x,c[i].y=a[i].y,c[i].z=a[i].z,c[i].num=a[i].num;
	sort(c+1,c+m+1);
	for (int i=1;i<=n;i++) fa[i]=i;
	for (int i=1;i<=m;i++) {
		int x=get(c[i].x),y=get(c[i].y);
		if (x==y) continue;
		fa[x]=y;
		ans[++sizeans]=c[i].num;
	}
	sort(ans+1,ans+sizeans+1);
	for (int i=1;i<n;i++) if (t[i]!=ans[i]) return 0;
	return 1;
}
int main(){
	freopen("hack.in","r",stdin);
	freopen("hack.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=m;i++) a[i].x=read(),a[i].y=read(),b[i]=i,a[i].num=i;
	for (int i=1;i<n;i++) t[i]=read();
	if (n<=8&&m<=8){
	sort(t+1,t+n);
	while (next_permutation(b+1,b+m+1)){
		for (int i=1;i<=m;i++) a[i].z=b[i];
		if (MST()) {
			for (int i=1;i<m;i++) printf("%d ",b[i]);
			printf("%d\n",b[m]);
			return 0; 
		}
	}
	return 0;
}
for (int i=1;i<n;i++) printf("%d ",i);
printf("%d\n",n);
	return 0;
}

