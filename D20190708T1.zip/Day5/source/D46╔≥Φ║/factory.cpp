#include<bits/stdc++.h>
using namespace std;
int read(){
	int r=0,f=1;
	char ch=getchar();
	while (!isdigit(ch)&&ch!='-') ch=getchar();
	if (ch=='-') f=-1,ch=getchar();
	while (isdigit(ch)) r=r*10+ch-'0',ch=getchar();
	return r*f;
}
int n,a[100005],ans,x;
map<int,bool> m;
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	cin>>n;
	for (int i=1;i<=n;i++) a[i]=read();
	for (int i=1;i<=n;i=x) {
		x=i+1;
		m[a[i]]=1;
		int y=abs(a[i+1]-a[i]);
		while (x<=n){
			if (__gcd(y,abs(a[x]-a[i]))==1) break;
			if (m[a[x]]==1) break;
			m[a[x]]=1;
			y=__gcd(y,abs(a[++x]-a[i]));
		}
		ans++;
		m.clear();
	} 
	cout<<ans<<endl;
	return 0;
}
