#include<bits/stdc++.h>
using namespace std;
int read(){
	int r=0,f=1;
	char ch=getchar();
	while (!isdigit(ch)&&ch!='-') ch=getchar();
	if (ch=='-') f=-1,ch=getchar();
	while (isdigit(ch)) r=r*10+ch-'0',ch=getchar();
	return r*f;
}
int n,m,a[505][10086],b[505][10086];
bool check(int mid){
	memset(b,0,sizeof(b));
	for (int i=1;i<=n;i++)
	for (int j=1;j<=m;j++) 
		if (a[i][j]>0) {
			if (a[i][j]<mid) continue;
			else {
				b[i][max(1,j-mid+1)]++;
				if (j+mid>m) continue;
				b[i][j+mid]--;
				b[i][j]++;
				if (j==m) continue;
				b[i][j+1]--;
			}
		}
	for (int i=1;i<=n;i++){
		int s=0;
		for (int j=1;j<=m;j++) {
			s+=b[i][j];
			if (s<=0) return 0;
		}
	}
	memset(b,0,sizeof(b));
	for (int i=1;i<=m;i++)
	for (int j=1;j<=n;j++) 
		if (a[j][i]>0) {
			b[max(1,j-mid+1)][i]++;
			if (j+mid>n) continue;
			b[j+mid][i]--;
			b[j][i]++;
			if (j==n) continue;
			b[j+1][i]--;
		}
	for (int i=1;i<=m;i++){
		int s=0;
		for (int j=1;j<=n;j++) {
			s+=b[j][i];
			if (s<=0) return 0;
		}
	}
	return 1;
}
void init(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=n;i++) 
	for (int j=1;j<=m;j++) a[i][j]=read();
	return ;
}
void work(){
	for (int i=0;i<=max(n,m);i++) if (check(i)) {
		cout<<i<<endl;
		exit(0);
	}
	cout<<-1<<endl;
	return ;
}
int main(){
	init();
	work();
	return 0;
}

