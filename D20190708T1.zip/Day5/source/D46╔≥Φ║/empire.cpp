#include<bits/stdc++.h>
#define int long long
using namespace std;
int read(){
	int r=0,f=1;
	char ch=getchar();
	while (!isdigit(ch)&&ch!='-') ch=getchar();
	if (ch=='-') f=-1,ch=getchar();
	while (isdigit(ch)) r=r*10+ch-'0',ch=getchar();
	return r*f;
}
int n,m,a[1000005],b[1000005],s[1000005],f[1000005],spe1,spe2;
signed main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=n;i++) cin>>a[i],s[i]=s[i-1]+a[i];
	for (int i=1;i<=n;i++) {cin>>b[i-1];if (b[i-1]!=1) spe1=1;if (b[i-1]!=a[i]) spe2=1;}
	if (n<=10000&&m<=5000){
	f[0]=0;
	for (int i=1;i<=n;i++) {
		f[i]=INT_MAX;
		for (int j=i-1;j>=max((int)0,i-m);j--) f[i]=min(f[i],f[j]+max(s[i]-s[j],b[j]));
	}
	cout<<f[n]<<endl;
	return 0;
	}
	if (n==m) {
		cout<<max(s[n],b[0])<<endl;
		return 0;
	}
	if (!(spe1&&spe2)) {
		cout<<s[n]<<endl;
		return 0;
	}
	return 0;
}
