#include<bits/stdc++.h>
using namespace std;
const int dx[8]={1,1,2,2,-1,-1,-2,-2},dy[8]={2,-2,1,-1,2,-2,1,-1};
bool vis[105][105];
int a[105][105],n,m,sx,sy,ex,ey,ans1=INT_MAX,ans2=INT_MAX,start;
int read(){
	int r=0,f=1;
	char ch=getchar();
	while (!isdigit(ch)&&ch!='-') ch=getchar();
	if (ch=='-') f=-1,ch=getchar();
	while (isdigit(ch)) r=r*10+ch-'0',ch=getchar();
	return r*f;
}
void init(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=n;i++)
	for (int j=1;j<=m;j++) {
		cin>>a[i][j];
		if (a[i][j]==3) sx=i,sy=j,a[i][j]=1;
		if (a[i][j]==4) ex=i,ey=j,a[i][j]=1;
	}
	return ;
}
bool check(int x,int y){
	if (x<1||x>n||y<1||y>m) return 1;
	if (vis[x][y]) return 1;
	if (a[x][y]==2) return 1;
	return 0;
}
int f;
void dfs1(int sum,int x,int y){
	if (f==1) return ;
	if (clock()-start>1300) 
		if (ans1==INT_MAX){puts("-1 -1");exit(0);}
		else {f=1;return ;}
	if (sum>ans1) return ;
	vis[x][y]=1;
	if (x==ex&&y==ey){
		ans1=min(ans1,sum);
		vis[x][y]=0;
		return ;
	}
	for (int i=0;i<8;i++){
		int tx=x+dx[i],ty=y+dy[i];
		if (check(tx,ty)) continue;
		if (a[tx][ty]==0) dfs1(sum+1,tx,ty);
		else dfs1(sum,tx,ty);
	}
	vis[x][y]=0;
	return ;
}
void dfs2(int dep,int sum,int x,int y){
	if (sum>ans1) return ;
	if (dep>ans2) return ;
	vis[x][y]=1;
	if (x==ex&&y==ey&&sum==ans1){
		ans2=min(ans2,dep);
		vis[x][y]=0;
		return ;
	}
	for (int i=0;i<8;i++){
		int tx=x+dx[i],ty=y+dy[i];
		if (check(tx,ty)) continue;
		if (a[tx][ty]==0) dfs2(dep+1,sum+1,tx,ty);
		else dfs2(dep+1,sum,tx,ty);
	}
	vis[x][y]=0;
	return ;
}
void work(){
	dfs1(0,sx,sy);
	if (ans1==INT_MAX) {
		puts("-1 -1");
		exit(0);
	}
	f=0;
	memset(vis,0,sizeof(vis));
	dfs2(0,0,sx,sy);
	return ;
}
void outit(){
	cout<<ans1<<' '<<ans2<<endl;
	return ;
}
int main(){
	init();
	work();
	outit();
	return 0;
}
/*
4 8
0 0 0 1 0 0 0 0
0 0 0 0 0 2 0 1
0 0 0 0 0 4 0 0
3 0 0 0 0 0 1 0

8 11
0 0 4 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0
0 0 0 1 0 1 0 0 0 0 0
0 0 0 0 0 0 0 1 0 0 0
3 0 0 0 0 0 0 0 0 0 0
0 0 1 0 0 0 1 0 0 0 0
0 0 0 0 1 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0

8 11
0 0 4 0 1 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0
0 0 0 1 0 1 0 0 0 0 0
0 0 0 0 0 0 0 1 0 0 0
3 0 0 0 0 0 0 0 0 0 0
0 0 1 0 0 0 1 0 0 0 0
0 0 0 0 1 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0

8 11
0 0 4 0 2 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0
0 2 0 1 0 1 0 0 0 0 0
0 0 0 0 0 0 0 1 0 0 0
3 0 0 0 2 0 0 0 0 0 0
0 0 1 0 0 0 1 0 0 0 0
0 0 0 0 1 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0

8 11
0 0 4 0 2 0 2 0 0 0 0
0 0 0 0 2 0 0 0 0 0 0
0 2 2 2 0 1 0 0 0 0 0
0 2 0 2 0 2 0 1 0 0 0
3 0 0 0 2 0 0 0 0 0 0
0 0 1 0 0 0 1 0 0 0 0
0 0 0 0 1 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0
*/
