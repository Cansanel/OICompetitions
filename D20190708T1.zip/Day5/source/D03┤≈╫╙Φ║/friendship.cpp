#include<cstdio>
#include<cstring>
#include<queue>
#include<iostream>
#include<algorithm>
using namespace std;
int n,m,op,k,x,y,a,end,to[1000000],next[1000000],head[1000000],tot;
bool v[1000000];
void add(int x,int y)
{
	tot++;
	to[tot]=y;
	next[tot]=head[x];
	head[x]=tot;
}
bool dfs(int x)
{
	v[x]=1;
	for (int i=head[x];i;i=next[i])
	{
		
		int c;
		c=to[i];
		if (c==end) return 1;
		if (v[c]) continue;
		dfs(c); 
	}
	return 0;
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=m;i++)
	{
		scanf("%d",&x);
		if (x==0) 
		{
			scanf("%d%d",&op,&k);
			n++;
			for (int i=1;i<=k;i++) 
			{
				scanf("%d",&a);
				if (op==0) add(n,a);
				if (op!=0) add(a,n); 
			}
		}
		if (x==1)
		{ 
			scanf("%d%d",&x,&end);
			if (dfs(x)) cout<<1<<endl;
			else cout<<0<<endl;
		}
	}
	
}
