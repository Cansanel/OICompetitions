#include<cstdio>
#include<algorithm>
#include<iostream>
using namespace std;
int n,a[1000000],b[1000000],c[1000000],k,tot;
int gcd(int x,int y)
{
	if (y==0) return x;
	else return gcd(y,x%y);
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++) 
	{
		scanf("%d",&a[i]);
		b[i]=abs(a[i]-a[i-1]);
	}
	for (int i=2;i<=n;i++) c[i]=gcd(b[i],b[i-1]);
	for (int i=2;i<=n;i++) if (c[i]==1) tot++;
	printf("%d",tot);
	
}
