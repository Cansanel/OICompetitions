#include<bits/stdc++.h>
using namespace std;
int a[500005];
int b[500005];
long long _min(long long a,long long b)
{
	return a<b?a:b;
}
long long _max(long long a,long long b)
{
	return a>b?a:b;
}
long long sum[500050],F[500050];
int p[500050];
int read()
{
	int a=0;char c=getchar();
	for  (;!isdigit(c);c=getchar());
	for  (;isdigit(c);a=a*10+c-48,c=getchar());
	return a;
}
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	int N=read(),K=read();
	for  (int i=1;i<=N;i++)
		a[i]=read();
	for  (int i=0;i<N;i++)
		b[i]=read();
	for  (int i=1;i<=N;i++)
		sum[i]=sum[i-1]+a[i];
	int left_=1,right_=2; p[1]=N;
	F[N-1]=_max(a[N-1],b[N-1]); p[2]=N-1;
	//cout<<N-1<<':'<<F[N-1]<<endl;
	for  (int i=N-2;i>=0;i--)
		{
			while  (p[left_]-i>K&&left_<=right_)	left_++;
			int j=p[left_];
			F[i]=F[j]+_max(b[i],sum[j]-sum[i]);
			//cout<<i<<':'<<j<<' '<<F[i]<<endl;
			while  (F[i]<F[p[right_]]&&right_>=left_)	right_--;
			right_++;
			p[right_]=i;
		}
	cout<<F[0]<<endl;
    return 0;
}

