#include<bits/stdc++.h>
using namespace std;
struct abc{
	int data_,id_; 
} b[100005];
int a[100005];
int c[100005];
int gcd(int a,int b)
{
	if  (b==0)
		return a;
	else
		return gcd(b,a%b);
}
int read()
{
	int a=0;char c=getchar();
	for  (;!isdigit(c);c=getchar());
	for  (;isdigit(c);a=a*10+c-48,c=getchar());
	return a;
}
bool cmp(abc xx,abc yy)
{
	if  (xx.data_!=yy.data_)
		return  xx.data_<yy.data_;
	else
		return xx.id_<yy.id_;
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	int N=read();
	for  (int i=1;i<=N;i++)
		{
			a[i]=read();
			b[i].id_=i;
			b[i].data_=a[i];
		}
	sort(b+1,b+N+1,cmp);
	for  (int i=2;i<=N;i++)
		if  (b[i].data_==b[i-1].data_)
			c[b[i].id_]=b[i-1].id_;
	int now=0,Ans=1,begin_=1;
	for  (int i=2;i<=N;i++)
		{
			int new_=gcd(now,abs(a[i]-a[i-1]));
			if  (new_==1||begin_<=c[i])
				{
					Ans++;
					begin_=i;
					now=0;
				}
			else
				now=new_;
			//cout<<now<<endl;
		}
	printf("%d\n",Ans);
    return 0;
}

