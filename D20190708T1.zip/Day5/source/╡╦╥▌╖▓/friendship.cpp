#include<bits/stdc++.h>
using namespace std;
int read()
{
	int a=0;char c=getchar();
	for  (;!isdigit(c);c=getchar());
	for  (;isdigit(c);a=a*10+c-48,c=getchar());
	return a;
}
/*int head[500005];
struct edge{
	int colour_,to_,next_;
} e[500005];
int tot;
void Add(int x,int y,int z)
{
	e[++tot].to_=y;
	e[tot].colour_=z;
	e[tot].next_=head[x];
	head[x]=tot;
}*/
int son[500005],co[500005];
int TN;
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	int N=read(),M=read();
	TN=N;
	for  (int i=1;i<=M;i++)
		{
			int cs=read();
			if  (cs==0)
				{
					TN++;
					int op=read(),K=read();
					if  (K==1)
						{
							int xx=read();
							son[xx]=TN;
							co[xx]=2;
							//Add(TN,xx,1);
							continue;
						}
					for  (int i=1;i<=K;i++)
						{
							int  xx=read();
							son[xx]=TN;
							co[xx]=op;
							//Add(TN,xx,op);
						}
				}
			else
				{
					int X=read(),Y=read();
					if  (X==Y)
						{
							printf("1\n");
							continue;
						}
					if  (X<Y)
						{
							int ii;
							for  (ii=X;i&&ii!=Y&&co[ii];ii=son[ii]);
							if  (ii==Y)
								printf("1\n");
							else
								printf("0\n");
							continue;
						}
					else
						{
							int ii;
							bool f1=false,f2=true;
							for  (ii=Y;ii!=X&&ii;ii=son[ii])
								if  (co[ii]==1)
									f2=false;
							if  (ii==X)
								f1=true;
							if  (f1&&f2)
								printf("1\n");
							else
								printf("0\n");
							continue;
						}
				}
		}
    return 0;
}
