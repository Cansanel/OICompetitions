#include<bits/stdc++.h>
using namespace std;
long long a[500001],b[500001];
long long f[10001];
inline void read(long long &X)
{
    X=0;long long w=0; char ch=0;
    while(!isdigit(ch)) {w|=ch=='-';ch=getchar();}
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    X=w?-X:X;
}
inline void writen(long long x)
{
     if(x<0) putchar('-'),x=-x;
     if(x>9) writen(x/10);
     putchar(x%10+'0');
}
inline void write(int x)
{
   writen(x);
   putchar(' ');
}
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	int n,m;
	cin>>n>>m;long long ans;
	for(int i=1;i<=n;i++){
		read(a[i]);
		
		a[i]+=a[i-1];
		f[i]=1e18+7;
	}
	for(int i=0;i<n;i++)read(b[i]);

	if(n<=10000&&m<=1000){
		for(int i=1;i<=n;i++){
			for(int j=max(i-m,0);j<=i;j++){
				f[i]=min(f[i],max(a[i]-a[j],b[j])+f[j]);
			}
			
		}
		cout<<f[n];
	}
	
	else {
		cout<<a[n];
	}
	return 0;
}


