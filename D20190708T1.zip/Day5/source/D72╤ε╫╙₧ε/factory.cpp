#include<bits/stdc++.h>
using namespace std;
int a[100001];
set<int> pc;
inline void read(int &X)
{
    X=0;int w=0; char ch=0;
    while(!isdigit(ch)) {w|=ch=='-';ch=getchar();}
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    X=w?-X:X;
}
inline void writen(int x)
{
     if(x<0) putchar('-'),x=-x;
     if(x>9) writen(x/10);
     putchar(x%10+'0');
}
inline void write(int x)
{
   writen(x);
   putchar(' ');
}
int gcd(int n,int m){
	if(n==0)return m;
	if(m==0)return n;
	else return gcd(m,n%m);
}
bool pcc(int x){
	int ans=pc.size();
	pc.insert(x);
	if(pc.size()==ans){
		pc.clear();
		return true;
	}return false;
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	int n;
	cin>>n;
	int f,r;
	for(int i=1;i<=n;i++){
		read(a[i]);
	}
	int ans;int last=0;int cha;int gc=0;
	ans=1;
	for(int i=1;i<=n;i++){
		cha=abs(a[i]-last);
		last=a[i];
		if(!pcc(a[i])&&gcd(gc,cha)==1){
			ans++;
			gc=0;pc.insert(a[i]);
		}else {
			gc=gcd(gc,cha);	
		}
	}
	cout<<ans;
	return 0;
}


