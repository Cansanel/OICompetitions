#include<bits/stdc++.h>
using namespace std;
template<typename T>inline void read(T &x){
	long long f=1;x=0;char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	x*=f;
}
template<typename T>inline void write(T x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
}
template<typename T>inline void writeln(T x){
	write(x);
	putchar('\n');
}
long long f[500010];
int n,k,a[500010],b[500010],s[500010];
void baoli(){
	for(int i=1;i<=n;i++)f[i]=LLONG_MAX;
	f[0]=0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=k;j++){
			if(i-j<0)break;
			f[i]=min(f[i],f[i-j]+max(b[i-j],s[i]-s[i-j]));
		}
	}
	writeln(f[n]);
}
bool issame(){
	for(int i=1;i<=n;i++){
		if(a[i]!=b[i-1])return 0;
	}
	return 1;
}
bool isone(){
	for(int i=1;i<=n;i++){
		if(b[i-1]!=1)return 0;
	}
	return 1;
}
void doit3(){
	int res=0;
	for(int i=0;i<=n;i++){
		if(i%k==0){
			res+=max(b[i],s[min(i+k,n)]-s[i]);
		}
	}
	writeln(res);
}
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);

	read(n);read(k);
	for(int i=1;i<=n;i++)read(a[i]);
	for(int i=1;i<=n;i++)read(b[i-1]);
	for(int i=1;i<=n;i++)s[i]=s[i-1]+a[i];
	
	if(n<=10000&&k<=1000){
		baoli();
	}else if(issame()||isone()){
		writeln(s[n]);
	}else if(n==k){
		writeln(max(s[n],b[0]));
	}else{
		doit3();
	}
	return 0;
}
/*
4 2
4 3 2 1
1 2 4 4

4 2
4 3 2 1
1 2 10 3

2 2
10 1
100 1000

4 4
4 3 2 1
1 2 4 4

4 4
4 3 2 1
1 2 10 3

*/
