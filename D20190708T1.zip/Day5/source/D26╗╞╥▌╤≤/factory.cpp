#include<bits/stdc++.h>
using namespace std;
template<typename T>inline void read(T &x){
	long long f=1;x=0;char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	x*=f;
}
template<typename T>inline void write(T x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
}
template<typename T>inline void writeln(T x){
	write(x);
	putchar('\n');
}
int n,a[200000],b[200000];
int gcd(int x,int y){
	if(y==0)return x;
	return gcd(y,x%y);
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	
	read(n);
	for(int i=1;i<=n;i++)read(a[i]);
	for(int i=1;i<n;i++){
		b[i]=abs(a[i+1]-a[i]);
	}
	
	int num=0,tot=1;
	for(int wz=1;wz<n;wz++){
		if(b[wz]==0||b[wz]==1){
			tot++;
			num=0;
			continue;
		}
		num=gcd(num,b[wz]);
		if(num==1){
			tot++;
			num=0;
		}
	}
	writeln(tot);
	return 0;
}
/*
7
1 5 11 2 6 4 7

8
4 2 6 8 5 3 1 7

*/
