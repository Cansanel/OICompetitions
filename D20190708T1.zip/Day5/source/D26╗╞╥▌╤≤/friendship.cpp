#include<bits/stdc++.h>
using namespace std;
template<typename T>inline void read(T &x){
	long long f=1;x=0;char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	x*=f;
}
template<typename T>inline void write(T x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
}
template<typename T>inline void writeln(T x){
	write(x);
	putchar('\n');
}
vector<int>v[2][1000010];
int n,m,ndnum=n,flg=0;
int k[500010];
void Add(int opt){
	ndnum++;
	if(k[0]==1){
		v[0][ndnum].push_back(k[1]);
		v[1][k[1]].push_back(ndnum);
	}
	for(int i=1;i<=k[0];i++){
		if(opt==0)v[0][ndnum].push_back(k[i]);
		else v[1][k[i]].push_back(ndnum);
	}
}
void dfs(int x,int des,int opt){
	if(flg)return;
	if(x==des){
		flg=1;
		return;
	}
	for(int i=0;i<v[opt][x].size();i++){
		int y=v[opt][x][i];
		dfs(y,des,opt);
	}
}
void baoli(){
	ndnum=n;
	for(int i=1;i<=m;i++){
		int tmp;
		read(tmp);
		if(tmp==0){
			int opt;
			read(opt);read(k[0]);
			for(int i=1;i<=k[0];i++){
				read(k[i]);
			}
			
			Add(opt);
		}else{
			int X,Y;
			read(X);read(Y);
			
			flg=0;
			dfs(X,Y,(X<=Y));
			writeln(flg);
		}
	}
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);

	read(n);read(m);
	baoli();
	return 0;
}
/*
3 5
0 0 2 1 2
1 1 4
0 1 2 3 4
1 4 5
1 4 2

*/
