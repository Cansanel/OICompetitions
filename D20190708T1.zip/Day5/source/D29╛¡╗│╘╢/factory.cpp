#include<bits/stdc++.h>
#define min(a,b) a<b?a:b
#define max(a,b) a>b?a:b
#define swap(a,b) a=a+b,b=a-b,a=a-b
#define N 100001
using namespace std;
inline void read(int &x){
	char c;x=0;int b=1;
	while(!isdigit(c=getchar())) if(c=='-') b=-1;
	x+=c-'0';
	while(isdigit(c=getchar())) x=x*10+c-'0';
	x*=b;
	return;
}
inline void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>=10) write(x/10),putchar('0'+x%10);
	else putchar('0'+x);
	return;
}
int n,st[N][21],lit[N];
int gcd(int x,int y){
	x<y?swap(x,y):0;
	if(y==0) return x;
	else return gcd(y,x%y);
}
int get(int s,int t){
	int p=(int)log(t-s+1)/log(2);
	return gcd(st[s][p],st[t-(1<<p)+1][p]);
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	read(n);
	int t=(int)(log(n-1)/log(2))+1;
	for(register int i=1;i<=n;++i){
		read(lit[i]);
		i>=2?st[i-1][0]=abs(lit[i]-lit[i-1]):0;
		i>=2&&st[i-1][0]==0?st[i-1][0]=1:0;
	}
	for(register int j=1;j<=t;++j)
	    for(register int i=1;i+(1<<j)-1<=n-1;++i)
	        st[i][j]=gcd(st[i][j-1],st[i+(1<<(j-1))][j-1]);
	int tag=1,ans=1;
	for(register int i=1;i<=n-1;++i)
		get(tag,i)==1?++ans,tag=i+1:0;
	write(ans),putchar('\n');
	return 0;
}

