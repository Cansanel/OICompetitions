#include<bits/stdc++.h>
#define N 500001
#define ink 2147483647
using namespace std;
inline void read(int &x){
	char c;x=0;int b=1;
	while(!isdigit(c=getchar())) if(c=='-') b=-1;
	x+=c-'0';
	while(isdigit(c=getchar())) x=x*10+c-'0';
	x*=b;
	return;
}
inline void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>=10) write(x/10),putchar('0'+x%10);
	else putchar('0'+x);
	return;
}
int n,k;
int a[N],b[N],f[N];
bool now=0;
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	read(n),read(k);
	a[0]=0;
	for(register int i=1;i<=n;++i) read(a[i]),a[i]+=a[i-1];
	for(register int i=0;i<=n-1;++i) read(b[i]);
	f[0]=0;
	for(register int i=1;i<=n;++i){
		f[i]=ink;
		for(register int j=max(0,i-k);j<=i-1;++j)
		    f[i]=min(f[i],f[j]+max(b[j],a[i]-a[j]));
	}
	write(f[n]),putchar('\n');
	return 0;
}

