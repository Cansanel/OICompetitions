#include<bits/stdc++.h>
#define min(a,b) a<b?a:b
#define max(a,b) a>b?a:b
#define swap(a,b) a=a+b,b=a-b,a=a-b
using namespace std;
inline void read(int &x){
	char c;x=0;int b=1;
	while(!isdigit(c=getchar())) if(c=='-') b=-1;
	x+=c-'0';
	while(isdigit(c=getchar())) x=x*10+c-'0';
	x*=b;
	return;
}
inline void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>=10) write(x/10),putchar('0'+x%10);
	else putchar('0'+x);
	return;
}
#define N 250001
int n,m,ver[N*4],next[N*4],head[N*2],tot=0;
int vis[N*2];
int tag;
bool edge[N*4],ifond;
void add(int x,int y){
	ver[++tot]=y,next[tot]=head[x],head[x]=tot;
	return;
}
void work(int x){
	++vis[x];
	for(register int i=head[x];i;i=next[i]) 
	    work(ver[i]);
	return;
}
void check(int x){
	if(x==tag){ifond=1;return;}
	for(register int i=head[x];i&&!ifond;i=next[i])
	    check(ver[i]);
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	read(n),read(m);
	memset(head,0,sizeof(head));
	for(register int i=1;i<=m;++i){
		int T;read(T);
		if(!T){
			int P,k;read(P),read(k);
			++n;
			if(P)
				for(register int j=1;j<=k;++j){
					int tmp;read(tmp);
					add(n,tmp);
				}
			else{
				memset(vis,0,sizeof(vis));
				for(register int j=1;j<=k;++j){
					int tmp;read(tmp);
				    work(tmp);
				    add(tmp,n);
				}
				for(register int j=1;j<=n-1;++j)
				    if(vis[j]==k)
				        add(n,j);
			}
		}
		else{
			int x,y;read(x),read(y);
			tag=x,ifond=0;check(y);
			write(ifond),putchar('\n');
		}
	}
	return 0;
}

