#include<bits/stdc++.h>
#define LL long long
using namespace std;
LL n,k,a[500010],b[500010],dp[500010],sum[500010];
inline LL rd(){
	char ch=getchar();
	LL x=0;
	while(ch<'0'||ch>'9'){
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x;
}
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	n=rd();k=rd();
	bool is_b1=1,is_ab=1;
	for(LL i=1;i<=n;i++){
		a[i]=rd();
		sum[i]=sum[i-1]+a[i];
	}
	for(LL i=1;i<=n;i++){
		b[i-1]=rd();
		if(a[i]!=b[i-1]){
			is_ab=0;
		}
		if(b[i-1]!=1){
			is_b1=0;
		}
	}
	if(n<=10000&&k<=1000){
		for(LL i=1;i<=n;i++){
			dp[i]=500000000010;
		}
		for(LL i=1;i<=n;i++){
			for(LL j=max((LL)0,i-k);j<i;j++){
				dp[i]=min(dp[i],dp[j]+max(b[j],sum[i]-sum[j]));
			}
		}
		cout<<dp[n]<<endl;
		return 0;
	}
	if(is_b1||is_ab||n==k){
		LL ans=0;
		for(LL i=1;i<=n;i++){
			ans+=a[i];
		}
		cout<<ans<<endl;
		return 0;
	}
	for(LL i=1;i<=n;i++){
		dp[i]=500000000010;
	}
	for(LL i=1;i<=n;i++){
		for(LL j=max((LL)0,i-k);j<i;j++){
			dp[i]=min(dp[i],dp[j]+max(b[j],sum[i]-sum[j]));
		}
	}
	cout<<dp[n]<<endl;
	return 0;
}

