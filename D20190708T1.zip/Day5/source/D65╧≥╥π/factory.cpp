#include<bits/stdc++.h>
using namespace std;
int n,a[100010];
map<int,int>mp;
inline int rd(){
	char ch=getchar();
	int x=0;
	while(ch<'0'||ch>'9'){
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x;
}
int gcd(int x,int y){
	return x%y?gcd(y,x%y):y;
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	n=rd();
	for(int i=1;i<=n;i++){
		a[i]=rd();
	}
	int ans=0,tmp=0,i=2;
	while(i<=n){
		if(a[i]-a[i-1]==0){
			ans++;
			tmp=0;
		}else{
			if(tmp){
				if(mp[a[i]]==0){
					mp[a[i]]=1;
					int k=gcd(tmp,abs(a[i]-a[i-1]));
					if(k>1){
						tmp=k;
					}else{
						tmp=0;
						ans++;
					}
				}else{
					ans++;
					tmp=0;
				}
			}else{
				mp.clear();
				mp[a[i]]=mp[a[i-1]]=1;
				tmp=abs(a[i]-a[i-1]);
			}
		}
		i++;
	}
	ans++;
	cout<<ans<<endl;
	return 0;
}

