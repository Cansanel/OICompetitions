#include<bits/stdc++.h>
using namespace std;
struct node{
	int to,nxt;
}edge[500010];
int n,m,head[500010],tot,tmp,vis[500010];
inline int rd(){
	char ch=getchar();
	int x=0;
	while(ch<'0'||ch>'9'){
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x;
}
void add(int from,int to){
	edge[++tot]=(node){to,head[from]};
	head[from]=tot;
}
void dfs(int u){
	for(int i=head[u];i;i=edge[i].nxt){
		int v=edge[i].to;
		if(!vis[v]){
			vis[v]=1;
			dfs(v);
		}
	}
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	n=rd();m=rd();
	tmp=n;
	for(int i=1;i<=m;i++){
		int t=rd();
		if(t==0){
			int op=rd(),k=rd();
			tmp++;
			if(op==0){
				for(int j=1;j<=k;j++){
					int x=rd();
					add(tmp,x);
				}
			}else{
				for(int j=1;j<=k;j++){
					int x=rd();
					add(x,tmp);
				}
			}
		}else{
			memset(vis,0,sizeof(vis));
			int x=rd(),y=rd();
			vis[x]=1;
			dfs(x);
			if(vis[y]){
				cout<<"1"<<endl;
			}else{
				cout<<"0"<<endl;
			}
		}
	}
	return 0;
}

