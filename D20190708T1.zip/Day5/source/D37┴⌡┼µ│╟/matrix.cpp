#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ak;
#define im INT_MAX
#define F(i,j,k) for(int i=j;i<=k;i++)
#define G(i,j,k) for(int i=j;i>=k;i--)
int a[333][333],zdx[33];
bool cxk(int s,int e){//case 3
	F(i,s,e)if(a[i][1]^a[e-i+s][1])
		return 0;
	return 1;
}
bool csk(int s,int e){//case 2
	F(i,1,26)zdx[i]=0;
	F(i,s,e)zdx[a[1][i]]++;
	int lhw=0;F(i,1,26)lhw+=zdx[i]&1;
	if((e-s+1)&1)return(lhw==1);
	return(!lhw);
}
int main(){
	#ifndef lpcak
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	#endif
	int n,m,ans=0;
	ios::sync_with_stdio(0);
	cin>>n>>m;
	F(i,1,n)F(j,1,m){
		char ch;cin>>ch;
		a[i][j]=ch-96; 
	}
	if(m==1){//case 3
		F(i,1,n)F(j,i,n)ans+=cxk(i,j);
		cout<<ans<<"\n";return 0;
	}
	if(n==1){//case 2
		F(i,1,m)F(j,i,m)ans+=csk(i,j);
		cout<<ans<<"\n";return 0;
	}
	return 0;
}
