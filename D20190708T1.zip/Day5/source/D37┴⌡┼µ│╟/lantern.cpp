#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ak;
#define im INT_MAX
#define F(i,j,k) for(int i=j;i<=k;i++)
#define G(i,j,k) for(int i=j;i>=k;i--)
int n,m,r=-im,ans=im,a[555][11111];
bool b[555][11111],c[555][11111];
bool cxk(int r){
	F(i,1,n)F(j,1,m)b[i][j]=c[i][j]=0;
	F(i,1,n)F(j,1,m){
		if(a[i][j]<r)continue;
		F(k,max(1,i-r+1),min(n,i+r-1))
			b[k][j]=1;
		F(k,max(1,j-r+1),min(m,j+r-1))
			c[i][k]=1;
	}
	F(i,1,n)F(j,1,m)
		if(!(b[i][j]&&c[i][j]))
			return 0;
	return 1;
}
int main(){
	#ifndef lpcak
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	#endif
	
	ios::sync_with_stdio(0);
	cin>>n>>m;
	F(i,1,n)F(j,1,m){
		cin>>a[i][j];r=max(r,a[i][j]);
	}
	if(n*m<1000){
		G(i,r+1,0)if(cxk(i))ans=i;
		if(ans==im)ans=-1;
		cout<<ans<<"\n";return 0;
	}
	cout<<"-1\n";
	return 0;
}
/*
4 4
0 2 0 0
3 0 2 0
2 2 0 0
4 4 4 2
*/
