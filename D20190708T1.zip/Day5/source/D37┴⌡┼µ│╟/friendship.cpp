#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ak;
#define im INT_MAX
#define F(i,j,k) for(int i=j;i<=k;i++)
#define G(i,j,k) for(int i=j;i>=k;i--)
int main(){
	#ifndef lpcak
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	#endif
	
	ios::sync_with_stdio(0);
	srand(time(0));cout<<rand()%2<<"\n";
	return 0;
}
