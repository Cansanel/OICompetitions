#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ak;
#define F(i,j,k) for(int i=j;i<=k;i++)
#define G(i,j,k) for(int i=j;i>=k;i--)
#define im INT_MAX
int main(){
	#ifndef lpcak
	freopen("hack.in","r",stdin);
	freopen("hack.out","w",stdout);
	#endif
	
	ios::sync_with_stdio(0);
	while(1)cout<<"IAKIOI\n";
	return 0;
}
