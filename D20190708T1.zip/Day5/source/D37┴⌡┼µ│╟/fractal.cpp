#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ak;
#define im INT_MAX
#define F(i,j,k) for(int i=j;i<=k;i++)
#define G(i,j,k) for(int i=j;i>=k;i--)
int yc,xc;double sy,sx,p,q;char ch[888][888];
struct duck{double shi;double xu;}z[111];
bool cxk(double x,double y){
	z[0].shi=x;z[0].xu=y;
	F(i,1,100){
		z[i].shi=z[i-1].shi*z[i-1].shi-z[i-1].xu*z[i-1].xu;
		z[i].xu=z[i-1].shi*z[i-1].xu+z[i-1].xu*z[i-1].shi;
		z[i].shi+=p;z[i].xu+=q;
		double mc=sqrt(z[i].shi*z[i].shi+z[i].xu*z[i].xu);
		if(mc>=10)return 0;
	}
	return 1;
}
int main(){
	#ifndef lpcak
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	#endif

	ios::sync_with_stdio(0);
	cin>>yc>>xc>>sy>>sx>>p>>q;
	F(j,0,yc-1)F(i,0,xc-1)if(cxk(sy+i*0.005,sx+j*0.01))
		ch[j][i]='a';else ch[j][i]=' ';
	F(j,0,yc-1){F(i,0,xc-1)cout<<ch[j][i];cout<<"\n";}
	return 0;
}
