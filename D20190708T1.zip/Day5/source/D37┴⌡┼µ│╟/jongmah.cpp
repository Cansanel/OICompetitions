#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ak;
#define im INT_MAX
#define F(i,j,k) for(int i=j;i<=k;i++)
#define G(i,j,k) for(int i=j;i>=k;i--)
int ans,n,m,a[111111],h[111111];
void dfs(int sum,int i){
	ans=max(ans,sum);if(i>m)return;
	/*if((i<m-1)&&h[i]&&h[i+1]&&h[i+2]){
		h[i]--;h[i+1]--;h[i+2]--;
		dfs(sum+1,i+1);
		h[i]++;h[i+1]++;h[i+2]++;
	}
	if(h[i]>2)h[i]-=3;dfs(sum+1,i+1);h[i]+=3;*/
	F(k,0,min(h[i],min(h[i+1],h[i+2])))
		F(j,0,h[i]/3)
			if((h[i]>=j*3+k)&&(h[i+1]>=k)&&(h[i+2]>=k)){
				int x=h[i],y=h[i+1],z=h[i+2];
				h[i]-=j*3+k;h[i+1]-=k;h[i+2]-=k;
				dfs(sum+j+k,i+1);
				h[i]=x,h[i+1]=y,h[i+2]=z;
			}
}
int main(){
	#ifndef lpcak
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	#endif
	
	ios::sync_with_stdio(0);
	cin>>n>>m;F(i,1,n)cin>>a[i];F(i,1,n)h[a[i]]++;
	if(n>80){
		F(i,1,m-2){
			int d=min(min(h[i],h[i+1]),h[i+2]);
			ans+=d;h[i]-=d;h[i+1]-=d;h[i+2]-=d;
		}
		cout<<ans<<"\n";return 0;
	}
	dfs(0,1);cout<<ans<<"\n";
	return 0;
}
/*
80 100
2 6 6 6 11 13 18 28 29 30 36 36 36 37 38 76 77 78 78 79
3 7 7 7 11 13 18 29 29 35 39 39 39 47 48 96 97 98 98 99
12 15 15 15 20 23 28 38 39 50 56 56 56 57 58 86 87 88 88 89
44 46 46 46 51 53 68 68 91 92 92 92 92 92 92 93 94 94 95 95
*/
