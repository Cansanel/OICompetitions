#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ak;
#define im INT_MAX
#define F(i,j,k) for(int i=j;i<=k;i++)
#define G(i,j,k) for(int i=j;i>=k;i--)
struct duck{int ord;int val;}a[111111];
int last[111111];
bool lpc(duck i,duck j){
	return(i.val<j.val)||(i.val==j.val)&&(i.ord<j.ord);
}
bool yst(duck i,duck j){return i.ord<j.ord;}
int main(){
	#ifndef lpcak
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	#endif
	int n,gc=0,ans=1,bg=1;
	ios::sync_with_stdio(0);
	cin>>n;F(i,1,n)cin>>a[i].val;F(i,1,n)a[i].ord=i;
	sort(a+1,a+n+1,lpc);last[a[1].ord]=-1;
	F(i,2,n)if(a[i].val==a[i-1].val)
		last[a[i].ord]=a[i-1].ord;
		else last[a[i].ord]=-1;
	sort(a+1,a+n+1,yst);
	F(i,2,n){
		gc=__gcd(abs(a[i].val-a[i-1].val),gc);
		if((bg<=last[i])||(gc==1))ans++,gc=0,bg=i;
	}
	cout<<ans<<"\n";
	return 0;
}
/*
10
24 72 8 45 18 54 108 72 45 96
*/
