#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ak;
#define im 666666666666
#define F(i,j,k) for(int i=j;i<=k;i++)
#define G(i,j,k) for(int i=j;i>=k;i--)
ak dp[555555],a[555555],b[555555],n,k;
bool cxk67()
	{F(i,1,n)if(b[i-1]>a[i]-a[i-1])return 0;return 1;}
int main(){
	#ifndef lpcak
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	#endif
	
	ios::sync_with_stdio(0);
	cin>>n>>k;F(i,1,n)dp[i]=im;
	F(i,1,n){cin>>a[i];a[i]+=a[i-1];}
	F(i,1,n)cin>>b[i-1];
	if(n*k<=20000000){
		F(i,1,n)F(j,max((ak)0,i-k),i-1)
			dp[i]=min(dp[i],dp[j]+max(b[j],a[i]-a[j])); 
		cout<<dp[n]<<"\n";return 0;
	}
	if(cxk67()){cout<<a[n]<<"\n";return 0;}
	if(n==k){cout<<max(b[0],a[n])<<"\n";return 0;}
	return 0;
}
