#include <bits/stdc++.h>

using namespace std;

struct edge{
	int u,v,nxt;
}g[4010];
int head[4010],tot;

struct queries{
	int x,y;
};
vector<queries> qv;

int n,q;
int f[4010][20];
int fa[4010];
bool mk[4010];
int dep[4010];

int find(int x){
	if (fa[x]!=x)fa[x]=find(fa[x]);
	return fa[x];
}

void join(int x,int y){
	x=find(x);y=find(y);
	if (x==y)return ;
	fa[x]=y;return ;
}

void add(int u,int v){
	tot++;
	g[tot]={u,v,head[u]};
	head[u]=tot;
	return ;
}

void dfs(int u){
	mk[u]=1;
	for (int i=head[u];i;i=g[i].nxt){
		int v=g[i].v;
		if (!mk[v])dfs(v);
	}
	dep[u]=dep[f[u][0]]+1;
	return ;
}

bool query(int x,int y){
	if (find(x)!=find(y))return 0;
	if (dep[y]>=dep[x])return 0;
	int cur=x;
	for (int i=0;i<=20;i++){
		if (dep[y]&(1<<i)){
			cur=f[cur][i];
		}
	}
	return (cur==y);
}

int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>q;
	for (int i=1;i<=n*2;i++)fa[i]=i;
	while (q--){
		bool type;
		cin>>type;
		if (type){
			int x,y;
			cin>>x>>y;
			qv.push_back({x,y});
		}
		else{
			bool op;int k;
			cin>>op>>k;
			for (int i=1,x;i<=k;i++){
				cin>>x;
				join(x,n+1);
				if (op)f[x][0]=n+1,add(x,n+1);
				else f[n+1][0]=x,add(n+1,x);
			}
			n++;
		}
	}
	for (int i=1;i<=n;i++){
		if (!mk[i])dfs(i);
	}
	for (int i=1;i<=n;i++){
		for (int j=1;j<20;j++){
			f[i][j]=f[f[i][j-1]][j-1];
		}
	}
	for (int i=0;i<qv.size();i++){
		cout<<query(qv[i].x,qv[i].y)<<endl;
	}
	
	return 0;
}
/*
3 5
0 0 2 1 2
1 1 4
0 1 2 3 4
1 4 5
1 4 2
*/
