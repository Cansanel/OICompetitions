#include <bits/stdc++.h>

using namespace std;

int n;
int ans=1;
map<int,int> mp;

int f(int x){
	if (x<0)return -x;
	return x;
}

int gcd(int x,int y){
	if (y==0)return x;
	return gcd(y,x%y);
}

int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n;
	int g=0,las=0;
	scanf("%d",&las);mp[las]=ans;
	for (int i=2,cur;i<=n;i++){
		scanf("%d",&cur);
		g=gcd(g,f(cur-las));
		if (g==1 || mp[cur]==ans)/*cout<<"1 "<<i<<' '<<cur<<' '<<ans<<' '<<g<<endl,*/g=0,ans++;
//		else cout<<"2 "<<i<<' '<<cur<<' '<<ans<<' '<<g<<endl;
		las=cur;
		mp[cur]=ans;
	}
	
	printf("%d",ans);
	
	return 0;
}
/*
7
1 5 11 2 6 4 7

8
4 2 6 8 5 3 1 7
*/
