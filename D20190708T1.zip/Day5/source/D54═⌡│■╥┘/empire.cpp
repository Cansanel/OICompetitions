#include <bits/stdc++.h>

using namespace std;

int n,k;
int a[500010],b[500010];
int f[10010][5010];
long long sum[500010];

int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>k;
	bool f1=1,f2=1,f3=(n==k);
	for (int i=1;i<=n;i++)scanf("%d",&a[i]),sum[i]=sum[i-1]+a[i];
	for (int i=1;i<=n;i++){
		scanf("%d",&b[i-1]);
		if (a[i]!=b[i-1])f2=0;
		if (b[i-1]!=1)f1=0;
	}
	if (f1 || f2 || f3){
		if (f1 || f2)cout<<sum[n]<<endl;
		else cout<<max(sum[n],(long long)b[0])<<endl;
		return 0;
	}
	for (int i=1;i<=n;i++){
		for (int j=i/k;j<=i;j++){
			for (int l=i-1;l>=max(i-k,1);l--){
				f[i][j]=max((long long)f[i][j],(long long)f[l][j-1]+max(sum[i]-sum[l],(long long)b[l+1]));
			}
		}
	}
	int ans=0;
	for (int i=1;i<=n;i++){
		ans=max(ans,f[n][i]);
	}
	cout<<ans<<endl;
	
	return 0;
}
/*
4 2
4 3 2 1
1 2 4 4

4 2
4 3 2 1
1 2 10 3
*/
