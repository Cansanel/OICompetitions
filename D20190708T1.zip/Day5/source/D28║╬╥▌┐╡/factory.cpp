#include <bits/stdc++.h>
#define open(name) freopen(#name".in", "r", stdin), freopen(#name".out", "w", stdout)
#define LL long long
#define ULL unsigned long long
using namespace std;

vector < int > vec;

int main()
{
	open(factory);
	int n, size = 0, x, Ans = 0;
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)
	{
		int value;
		scanf("%d", &value);
		if (size == 0)
		{
			vec.push_back(value);
			++size;
		}
		else if (size == 1)
		{
			x = abs(value - vec.back());
			vec.push_back(value);
			++size;
		}
			else
			{
				bool flag = true;
				vector < int > :: iterator key = upper_bound(vec.begin(), vec.end(), value);
				if (key != vec.begin() && __gcd(value - *(key - 1), x) == 1)
				{
					flag = false;
				}
				if (key != vec.end() && key + 1 != vec.end() && __gcd(value - *(key + 1), x) == 1)
				{
					flag = false;
				}
				if (flag == true)
				{
					if (key == vec.end()) vec.push_back(value);
					else vec.insert(key, value);
					++size;
				}
				else
				{
					++Ans;
				//	cout << Ans << ':';
					do
					{
						//cout << *vec.begin() << ' ';
						vec.erase(vec.begin());
					}
					while(!vec.empty());
				//	putchar('\n');
					vec.push_back(value);
					size = 1;
				}
			}
	}
	if (!vec.empty()) ++Ans;
	printf("%d\n", Ans);
	return 0;
}
