#include <bits/stdc++.h>
#define open(name) freopen(#name".in", "r", stdin), freopen(#name".out", "w", stdout)
#define LL long long
#define ULL unsigned long long
#define money(begin, end) S[end] - S[begin]
using namespace std;

LL f[500005];

LL S[500005];

LL b[500005];

int main()
{
	open(empire);
	memset(f, 0x3f, sizeof(f));
	int n, k;
	scanf("%d %d", &n, &k);
	for (int i = 1; i <= n; ++i)
	{
		LL value;
		scanf("%lld", &value);
		S[i] = S[i - 1] + value;
	}
	for (int i = 0; i < n; ++i)
		scanf("%lld", &b[i]);
	f[0] = 0;
	for (int i = 0; i < n; ++i)//begin
	{
		for (int j = 1; j <= k && i + j <= n; ++j)//length
		{
			f[i + j] = min(f[i + j], f[i] + max(money(i, i + j), b[i]));
		}
	}
	printf("%lld", f[n]);
	return 0;
}

