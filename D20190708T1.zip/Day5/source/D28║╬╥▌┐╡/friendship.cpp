#include <bits/stdc++.h>
#define open(name) freopen(#name".in", "r", stdin), freopen(#name".out", "w", stdout)
#define LL long long
#define ULL unsigned long long
using namespace std;

class MS_set
{
public:
	void load(int n)
	{
		size = n;
	}
	bool find(int x,int y)
	{
		int fatherx = x, fathery = y;
		do
		{
			fatherx = father[fatherx];
		}
		while(father[fatherx]);
		
		do
		{
			fathery = father[fathery];
		}
		while(father[fathery]);
		
		return fatherx == fathery;
	}
	void marge(int x, int y)
	{
		int fatherx = x;
		do
		{
			fatherx = father[fatherx];
		}
		while(father[fatherx]);
		father[fatherx] = y;
	}
	void insert(int sum, int nums[], int y, bool _op)
	{
		op[y] = _op;
		for (int i = 1; i <= sum; ++i)
		{
			father[nums[i]] = y;
		}
	}
	int create()
	{
		return ++size;
	}
	bool must_in(int x, int y)
	{
		if (x == y) return true;
		else if (x > y)
		{
			int fathery = y;
	    	do
			{
				fathery = father[fathery];
			}
			while(father[fathery] && fathery != x);
			return fathery == x;
		}
			else
			{
				int fatherx = x;
				do
				{
					fatherx = father[fatherx];
				}
				while(father[fatherx] && fatherx != y && op[fatherx]);
				return (fatherx == y && op[fatherx]);
			}
	}
protected:
	int father[500005];
	bool op[500005];
	int size;
}friendship;

int main()
{
	open(friendship);
	int n, m;
	scanf("%d %d", &n, &m);
	friendship.load(n);
	for (int i = 1; i <= m; ++i)
	{
		int cho;
		scanf("%d", &cho);
		if (cho == 0)
		{
			int k, op;
			scanf("%d %d", &op, &k);
			int nums[k + 1];
			for (int j = 1; j <= k; ++j)
			{
				scanf("%d", &nums[j]);
			}
			friendship.insert(k, nums, friendship.create(), op);
		}
		else
		{
			int x, y;
			scanf("%d %d", &x, &y);
			printf("%d\n", friendship.must_in(x, y));
		}
	}
	return 0;
}
