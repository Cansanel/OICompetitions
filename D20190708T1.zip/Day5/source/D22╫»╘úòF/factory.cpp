#include<cstdio>
#include<algorithm>
#include<set>
using namespace std;
int gcd(int a,int b) { return b?gcd(b,a%b):a; }
const int maxn=1e5+5;
int n,a[maxn];
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	int p=1,d,res=0;
	while(p<=n)
	{
		if(p==n) { res++; break; }
		if(a[p]==a[p+1]||abs(a[p+1]-a[p])==1) { res++; p++; continue; }
		set<int> st;
		d=a[p+1]-a[p]; st.insert(a[p]); st.insert(a[p+1]);
		p+=2;
		while(p<=n&&st.find(a[p])==st.end()&&(d=abs(gcd(d,a[p]-a[p-1])))>1) { st.insert(a[p]); p++; }
		res++;
	}
	printf("%d\n",res);
	return 0;
}
