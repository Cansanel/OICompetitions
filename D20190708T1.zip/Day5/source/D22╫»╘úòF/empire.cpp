#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=500000;
int n,k,a[maxn],b[maxn];
long long sa[maxn],f[maxn];
struct Case1
{
	int main()
	{
		for(int i=1;i<=n;i++) sa[i]=sa[i-1]+a[i];
		memset(f,0x3f,sizeof(f)); f[0]=0;
		for(int i=1;i<=n;i++)
			for(int j=max(0,i-k);j<i;j++)
				f[i]=min(f[i],f[j]+max((long long)b[j],sa[i]-sa[j]));
		printf("%lld\n",f[n]);
		return 0;
	}
};
struct Case2
{
	int main()
	{
		long long res=0;
		for(int i=1;i<=n;i++) res+=a[i];
		printf("%lld\n",max(res,(long long)b[0]));
		return 0;
	}
};
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=0;i<n;i++) scanf("%d",&b[i]);
	if(n<=10000&&k<=1000) return (new Case1)->main();
	if(n==k) return (new Case2)->main();
	return 0;
}
