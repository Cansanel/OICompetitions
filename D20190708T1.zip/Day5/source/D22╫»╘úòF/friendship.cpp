#include<cstdio>
#include<cstring>
using namespace std;
const int maxn=500005;
const int blue=0;
const int red=1;
struct Edge { int v,type; Edge *nxt; };
Edge mem[maxn],*G[maxn],*ecnt=mem;
inline void AddEdge(int u,int v,int type) { ecnt->v=v; ecnt->type=type; ecnt->nxt=G[u]; G[u]=ecnt++; }
struct Query { int v,id; Query *nxt; };
Query memq[maxn*2],*Q[maxn],*inv[maxn],*qcnt=memq;
inline void AddQuery(int u,int v,int id)
{
	qcnt->v=v; qcnt->id=id; qcnt->nxt=Q[u]; Q[u]=qcnt++;
	qcnt->v=u; qcnt->id=id; qcnt->nxt=inv[v]; inv[v]=qcnt++;
}
int n,m,fa[maxn],ft[maxn],ct[maxn],idup[maxn],iddown[maxn],IdCnt,NodeId,QueryId,res[maxn],vis[maxn],in[maxn];
void dfs1(int u)
{
	idup[u]=iddown[fa[u]];
	if(ct[u]!=ft[u]) IdCnt++;
	iddown[u]=IdCnt;
	for(Edge *it=G[u];it;it=it->nxt) dfs1(it->v);
}
void dfs2(int u)
{
	vis[u]=true;
	if(ft[u]==red)
	{
		for(Query *it=Q[u];it;it=it->nxt) if(vis[it->v]&&idup[u]==iddown[it->v]) res[it->id]=1;
	}
	else
	{
		for(Query *it=inv[u];it;it=it->nxt) if(vis[it->v]&&idup[u]==iddown[it->v]) res[it->id]=1;
	}
	for(Edge *it=G[u];it;it=it->nxt) dfs2(it->v);
	vis[u]=false;
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	scanf("%d%d",&n,&m);
	NodeId=n;
	for(int i=1;i<=m;i++)
	{
		int type,op,x,y,k; scanf("%d",&type);
		if(type==1) { scanf("%d%d",&x,&y); AddQuery(x,y,++QueryId); res[QueryId]=(x==y); }
		else
		{
			scanf("%d%d",&op,&k);
			NodeId++;
			ct[NodeId]=op;
			for(int j=0;j<k;j++)
			{
				scanf("%d",&x);
				fa[x]=NodeId;
				ft[x]=op;
				in[x]++;
				AddEdge(NodeId,x,op);
			}
		}
	}
	iddown[0]=-1;
	for(int i=1;i<=NodeId;i++) if(!in[i]) { ft[i]=-1; dfs1(i); }
	for(int i=1;i<=NodeId;i++) if(!in[i]) dfs2(i);
	for(int i=1;i<=QueryId;i++) printf("%d\n",res[i]);
	return 0;
}
