#include<bits/stdc++.h>
using namespace std;
int n,m,tot=n;
int bingfa[1000005],jiaofa[1000005];
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	cin>>n>>m;
	int i,j;
	for(i=1;i<=1000003;i++)jiaofa[i]=bingfa[i]=i;
	int ttt,op,kkk,t,flag,x,y;
	for(i=1;i<=m;i++){
		scanf("%d",&flag);
		if(!flag){
			scanf("%d%d",&op,&kkk);
			tot++;
			if(op){//bing
				for(j=1;j<=kkk;j++){
					scanf("%d",&t);
					bingfa[t]=tot;
				}
			}
			else{//jiao
				for(j=1;j<=kkk;j++){
					scanf("%d",&t);
					jiaofa[t]=tot;
				}
			}
		}
		else{
			scanf("%d%d",&x,&y);
			if(jiaofa[y]==x||bingfa[x]==y){
				cout<<1<<endl;
			}
			else cout<<0<<endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
