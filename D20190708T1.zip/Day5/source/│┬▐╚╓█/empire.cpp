#include<bits/stdc++.h>
using namespace std;
int n,k;
long long A[500005],B[500005];
long long dp[500005];
long long sum[500005];
bool flag1=1,flag2=1;
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	cin>>n>>k;
	int i,j;
	for(i=1;i<=n;i++){
		scanf("%d",&A[i]);
		sum[i]=sum[i-1]+A[i];
		dp[i]=4611686018427387904;
	}
	for(i=0;i<n;i++){
		scanf("%d",&B[i]);
		if(B[i]!=1)flag1=0;
		if(B[i]!=A[i+1])flag2=0;
	}
	if(flag1||flag2||n==k){
		cout<<sum[n];
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	dp[0]=0;
	for(i=1;i<=n;i++){
		for(j=max(0,i-k);j<i;j++){
			dp[i]=min(dp[i],dp[j]+max(B[j],sum[i]-sum[j]));
		}
	}
	cout<<dp[n];
	fclose(stdin);
	fclose(stdout);
	return 0;
}
