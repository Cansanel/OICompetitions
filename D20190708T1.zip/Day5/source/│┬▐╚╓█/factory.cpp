#include<bits/stdc++.h>
using namespace std;
int n;
int A[100005];
map<int,bool>vis;
int gcd(int a,int b){
	return b==0?a:gcd(b,a%b);
}
int ans;
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	cin>>n;
	int i,j,GCD=1,last=0;
	for(i=1;i<=n;i++)scanf("%d",&A[i]);
	for(i=1;i<=n;i++){
		if(gcd(GCD,abs(A[i]-A[i-1]))==1||vis[A[i]]){
			ans++;
			vis.clear();
			GCD=abs(A[i+1]-A[i]);
			vis[A[i]]=1;
			continue;
		}
		GCD=gcd(GCD,abs(A[i]-A[i-1]));
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
