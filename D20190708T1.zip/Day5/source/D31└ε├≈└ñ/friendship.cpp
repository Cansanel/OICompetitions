#include<bits/stdc++.h>
using namespace std;
int n,m,pd1,op,k,x,y,a,num,ver[500005],nxt[500005],head[250005],tot;
inline void add(int x,int y)
{
	ver[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}
inline bool pd(int p,int fa)
{
	if(p==y) return 1;
	for(int i=head[p];i;i=nxt[i])
	{
		int to=ver[i];
		if(fa==to)
		continue;
		if(pd(to,p))
		return 1;
	}
	return 0;
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	scanf("%d%d",&n,&m);
	num=n;
	while(m--)
	{
		scanf("%d",&pd1);
		if(!pd1)
		{
			++num;
			scanf("%d%d",&op,&k);
			for(int i=1;i<=k;++i)
			{
				scanf("%d",&a);
				if(k==1)
				{
					add(num,a);
					add(a,num);
					continue;
				}
				if(!op)
				add(num,a);
				else
				add(a,num);
			}
		}
		else
		{
			scanf("%d%d",&x,&y);
			if(pd(x,0))
			printf("1\n");
			else
			printf("0\n");
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

