#include<bits/stdc++.h>
using namespace std;
int n,a[100005],now,last,ans,begin;
map<int,bool> vis;
inline int gcd(int a,int b)
{
	if(!b) return a;
	return gcd(b,a%b);
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	scanf("%d",&a[i]);
	vis[a[1]]=1,begin=1,ans=1;
	for(int i=2;i<=n;++i)
	{
		if(vis[a[i]])
		{
			vis.clear();
			vis[a[i]]=1;
			begin=i;
			++ans;
			last=0;
			continue;
		}
		int g=gcd(abs(a[i]-a[begin]),last);
		if(g==1)
		{
			vis.clear();
			vis[a[i]]=1;
			begin=i;
			++ans;
			last=0;
		}
		else
		{
			vis[a[i]]=1;
			last=g;
		}
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

