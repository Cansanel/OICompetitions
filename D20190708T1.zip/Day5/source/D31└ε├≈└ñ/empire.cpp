#include<bits/stdc++.h>
using namespace std;
int n,k,a[500005],b[500005];
long long sum[500005],dp[500005];
inline int Max(int a,int b)
{
	return a>b?a:b;
}
inline int Min(int a,int b)
{
	return a>b?b:a;
}
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&a[i]);
		sum[i]=sum[i-1]+a[i];
		dp[i]=0x3f3f3f3f;
	}
	for(int i=0;i<n;++i)
	scanf("%d",&b[i]);
	dp[0]=0;
	for(int i=1;i<=n;++i)
	{
		for(int j=Max(0,i-k);j<i;++j)
		{
			dp[i]=min(dp[i],dp[j]+Max(b[j],sum[i]-sum[j]));
		}
	}
	printf("%d",dp[n]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

