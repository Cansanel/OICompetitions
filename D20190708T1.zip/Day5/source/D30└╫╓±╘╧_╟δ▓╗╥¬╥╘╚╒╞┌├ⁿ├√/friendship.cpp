#include<bits/stdc++.h>
using namespace std;
int n,m,mark,op,k,x,y,a[1000005];
int tot,head[1000005],d[1000005];
priority_queue<pair<int,int> >q;
bool v[1000005];
struct node
{
	int to,next;
}e[1000005];
void add(int x,int y)
{
	e[++tot].next=head[x];
	e[tot].to=y;
	head[x]=tot;
}
void dij(int s)
{
	for(int i=1;i<=n;i++) d[i]=10000000;
	memset(v,0,sizeof(v));
	d[s]=0; q.push(make_pair(0,s));
	while(q.size())
	{
		int x=q.top().second; q.pop();
		if(v[x]) continue;
		v[x]=1;
		for(int i=head[x];i;i=e[i].next)
		{
			int y=e[i].to;
			if(d[y]>d[x]+1)
			{
				d[y]=d[x]+1;
				q.push(make_pair(-d[y],y));
			}
		}
	}
}
bool search(int x,int y)
{
	dij(x);
	if(v[y]) return true;
	else return false;
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int tt=1;tt<=m;tt++)
	{
		scanf("%d",&mark);
		if(mark==0)
		{
			scanf("%d%d",&op,&k);
			if(op==0)
			{
				n++;
				for(int i=1;i<=k;i++) 
				{
					scanf("%d",&a[i]);
					add(n,a[i]);
				}
			}
			else
			{
				n++;
				for(int i=1;i<=k;i++) 
				{
					scanf("%d",&a[i]);
					add(a[i],n);
				}
			}
		}
		else
		{
			scanf("%d%d",&x,&y);
			if(search(x,y)) puts("1");
			else puts("0");	
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
