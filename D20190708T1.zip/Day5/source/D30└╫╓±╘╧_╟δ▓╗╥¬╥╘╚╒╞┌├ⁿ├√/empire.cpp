#include<bits/stdc++.h>
using namespace std;
int main()
{
	//freopen("empire.in","r",stdin);
	//freopen("empire.out","w",stdout);
	
	//fclose(stdin);fclose(stdout);
	return 0;
}
