#include<bits/stdc++.h>
using namespace std;
int n,num;
int a[100005],c[100005];
int gcdans(int x,int y)
{
	if(x<y) swap(x,y);
	if(x%y==0) 
	return y;
	gcdans(y,x%y);
}
int main()
{
	freopen("factory.in","r",stdin);
	//freopen("factory.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) 
	{
		scanf("%d",&a[i]);
		c[i]=a[i]-a[i-1];
		if(c[i]<0) c[i]=-c[i];
	}
	int k=2;
	while(k<n)
	{
		int t=0;
		while(k<n&&(gcdans(c[k+1],c[k])>1||c[k+1]==c[k])) 
		{
			k++; t++;
		}
		if(t>1) num++;
		k++;
	}
	printf("%d",num);
	//fclose(stdin);fclose(stdout);
	return 0;
}
