#include<bits/stdc++.h>
using namespace std;
int n,a[100010],now,ans,c;
int gcd(int x,int y){
	return y ? gcd(y,x%y):x;
}
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	cin>>n;now=1;ans=1;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=2;i<=n;i++){
		if(a[i]-a[i-1]==1){
			ans++;now=i;continue;
		}
		if(a[i]-a[i-1]!=1&&now==i-1){
			c=abs(a[i]-a[i-1]);continue;
		}
		if(gcd(abs(a[i]-a[i-1]),c)==1){
			now=i;ans++;
		}
	}
	cout<<ans;
}
