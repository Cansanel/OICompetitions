#include<bits/stdc++.h>
using namespace std;
int n,m,op,k,x,y,a,sdm,b[500010],s,z;
vector<int> v[750010];
bool ok[750010],ch,sdm2;
inline int read()
{
	char c=getchar();unsigned long long num=0,z=1;
	while(c<'0'||c>'9')
	{
		if(c=='-')
		{
			z=-1;c=getchar();
		}
	}
	while(c>='0'&&c<='9')
	{
		num=num*10+c-48;c=getchar();
	}
	return num*z;
}
void dfs(int p){
	if(p==z){
		ch=1;sdm2=1;return;
	}
	for(int i=0;i<v[p].size();i++){
		if(sdm2==1) return;
		if(ok[v[p][i]]==1) continue;
		ok[v[p][i]]=1;dfs(v[p][i]);ok[v[p][i]]=0;
		if(sdm2==1) return;
	}
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;i++){
		sdm=read();
		if(sdm==0){
			op=read();k=read();n++;
				if(op==1){
					for(int j=1;j<=k;j++){
						b[j]=read();
						v[n].push_back(b[j]);
					}
				}
				if(op==0){
					for(int j=1;j<=k;j++){
						a=read();v[a].push_back(n);
					}
				}
		}
		if(sdm==1){
			z=read();s=read();
			sdm2=0;ch=0;ok[s]=1;dfs(s);ok[s]=0;
			if(ch==1) putchar('1');else putchar('0');printf("\n");
		}
	}
}
