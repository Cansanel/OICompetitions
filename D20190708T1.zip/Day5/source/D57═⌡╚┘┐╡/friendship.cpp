#include<bits/stdc++.h>
using namespace std;
int N,M,s,op,K,A[10001],f=1,p=1,X[1000],Y[1000];
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	cin>>N>>M;
	for(int i=1;i<=M;i++)
	  {
	     cin>>s;
	     if(s==0)
	      {
	      	cin>>op>>K;
	      	for(int j=1;j<=K;j++)
	      	  {
	      	  	cin>>A[j];
	      	  	f+=j;         
	          }
          }
	      else
	         {
	         	cin>>X[p]>>Y[p];
	         	  p++;
	         } 
	  }
	  
	 for(int i=2;i<=p;i++)
	  {
          if(A[X[p]]==A[Y[p]])	  
		    cout<<1<<endl;
		  else
		    cout<<0<<endl;
	  }  
}






















