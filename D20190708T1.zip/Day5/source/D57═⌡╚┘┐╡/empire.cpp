#include<bits/stdc++.h>
using namespace std;
int N,K,a,b;
int A[10001],B[10001];
int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	cin>>N>>K;
	for(int i=1;i<N;i++)
	  {
	  	cin>>A[i];
	  }
	 for(int j=0;j<N-1;j++)
	   {
	   	 cin>>B[j];
	   }  
	 for(int i=1;i<N;i++)
	   {
	   	  a+=A[i];
	   	  b+=B[i-1];
	   	  c=i;
	   	  if(a<b) break;
	   	  
	   }  
	   
}
