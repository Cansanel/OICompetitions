#include<bits/stdc++.h>
using namespace std;
int a[10000];
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	int N,ans=1;
	cin>>N;
	for(int i=1;i<N+1;i++)
	  {
	  	cin>>a[i];
	  }
	 for(int i=2;i<N+1;i++)
	   {
	   	 if(a[i]%2!=a[i-1]%2)
	   	   ans++;
	   }  
	  cout<<ans; 
} 
