#include<bits/stdc++.h>
using namespace std;

int n,a[100005],k1,k2,k3=1000005,temp=1;
int prime[100005],v[100005],tail,ans;

void Prime(int n){
	memset(v,0,sizeof(v));
	for(int i=2;i<=n;i++){
		if(v[i])continue;
		tail++;
		prime[tail]=i;
		for(int j=i;j<=n/i;j++)v[i*j]=1;
	}
}

int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	ans=1000005;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		if(a[i]<k3)k3=a[i];
		if(a[i]>k2)k2=a[i];
	}
	k1=k2-k3;
	Prime(k1);
	if(!prime[1])cout<<n;
	else{
	    for(int i=1;i<=tail;i++){
	       for(int j=2;j<=n;j++){
	       	if(a[j]%prime[i]!=a[j-1]%prime[i]||a[j]==a[j-1])temp++;
	       }
	       if(temp<ans)ans=temp;
	       temp=1;
	    }
	cout<<ans;
	}
	return 0;
}
