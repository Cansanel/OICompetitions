#include<bits/stdc++.h>
using namespace std;
int n,k,a[500005],b[500005],opt[500005];
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	cin>>n>>k;
	for(int i=0;i<n;i++) cin>>a[i];
	for(int i=0;i<n;i++) cin>>b[i];
	for(int i=1;i<=n;i++) opt[i]=100000;
	for(int i=1;i<=n;i++)
	{
		int s=0;
		for(int j=i-1;j>=max(0,i-k);j--)
		{
			s+=a[j];
			opt[i]=min(opt[i],opt[j]+max(s,b[j]));
		}
	}
	cout<<opt[n]<<endl;
	return 0;
}
/*
4 2
4 3 2 1 
1 2 4 4
4 2
4 3 2 1
1 2 10 3
*/
