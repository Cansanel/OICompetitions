#include<bits/stdc++.h>
using namespace std;
int gcd(int x,int y){
	if (y==0) return x;
	else return gcd(y,x%y);
}
int n,a[100005],c[100005],ans;
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<n;i++)
		c[i]=abs(a[i]-a[i+1]);
	int x=0;
	for(int i=1;i<n;i++)
	{
		x=gcd(x,c[i]);
		if (x==1) 
		{
			ans++;
			x=0;
		}
	}
	cout<<ans+1<<endl;
	return 0;
}
/*
7
1 5 11 2 6 4 7
8
4 2 6 8 5 3 1 7
*/
