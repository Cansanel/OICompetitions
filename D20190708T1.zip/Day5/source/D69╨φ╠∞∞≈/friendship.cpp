#include<bits/stdc++.h>
using namespace std;
int n,m,len,flag;
int head[500005],tot;
struct node{
	int to,nxt;
}edge[500005];
void add(int x,int y){
	edge[++tot].to=y;
	edge[tot].nxt=head[x];
	head[x]=tot;
}
void build(){
	int opt,k;
	len++;
	cin>>opt>>k;
	for(int i=1;i<=k;i++)
	{
		int a;
		cin>>a;
		if (opt==0) add(len,a);
		else add(a,len);
	}
}
void dfs(int s,int t){
	if (s==t) flag=1;
	if (flag==1) return;
	for(int i=head[s];i;i=edge[i].nxt)
		dfs(edge[i].to,t);
}
void check(){
	int a,b;
	cin>>a>>b;
	flag=0;
	dfs(a,b);
	cout<<flag<<endl;
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	cin>>n>>m;
	len=n;
	for(int i=1;i<=m;i++)
	{
		int x;
		cin>>x;
		if (x==0) build();
		else check();
	}
	return 0;
}
/*
3 5
0 0 2 1 2
1 1 4
0 1 2 3 4
1 4 5
1 4 2
*/
