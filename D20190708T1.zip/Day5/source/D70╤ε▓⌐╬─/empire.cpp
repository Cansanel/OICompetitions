#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pqq priority_queue
#define itt ::iterator
void setIO(string y)
{
    if(y=="")
        return ;
#ifndef ybw
    freopen((y+".in").c_str(),"r",stdin);
    freopen((y+".out").c_str(),"w",stdout);
#endif
}
#define endl '\n'
struct ins{
    template<typename T>inline void read1(T &n){n=0;int f=1;char c=getchar();for(;!(c>='0'&&c<='9');c=getchar())if(c=='-')f=-1;for(;(c>='0'&&c<='9');c=getchar())n=n*10+c-'0';if(c!='.')return ;T x=0.1;for(;(c>='0'&&c<='9');c=getchar(),x*=0.1)n=n+(c-'0')*x;n*=f;}
    inline void write1(const char *n){int len=strlen(n);for(register int i=0;i<len;++i)putchar(n[i]);}
    inline void write1(char n){putchar(n);}
    inline void write1(double n){printf("%lf",n);}
    inline void write1(long double n){printf("%Lf",n);}
    template<typename T>inline void write1(T n)
    {
        if(n<0)putchar('-'),n=-n;
        if(n>=10)write1(n/10);
        putchar('0'+n%10);

    }
    template<typename T> ins operator <<(T n){write1(n);return *this;}
    template<typename T> ins operator >>(T &n){read1(n);return *this;}
}yin,yout;
const int maxn=1e5+10;
long long n,k,a[maxn],sum[maxn],b[maxn],f[maxn];
priority_queue<pair<int,int> > qq;
deque<pair<long long,int> > q,q1;
int main()
{
    setIO("empire");
    yin>>n>>k;
    for(int i=1;i<=n;i++)
        yin>>a[i],sum[i]=sum[i-1]+a[i];
    for(int i=1;i<=n;i++)
        yin>>b[i-1];
    if(n==k)
    {
    	cout<<max(b[0],sum[n])<<endl;
    	return 0;
    }
    if(n*k<=(int)(1e8)>>1)
    {
    	
    	for(int i=1;i<=n;i++)
   		{
   	    	f[i]=LLONG_MAX>>1;
   	  	    for(int j=i-1;j>=max(i-k,0ll);j--)
   	    	     f[i]=min(f[i],f[j]+max(sum[i]-sum[j],b[j]));
    	}
 	   cout<<f[n]<<endl; 
       return 0;
    }
    int last=0;
    q.push_back(make_pair(b[0],0));
    qq.push(make_pair(-b[0],0));
    for(int i=1;i<=n;i++)
    {
        while(!qq.empty()&&(-qq.top().first)<=sum[i])
        {
        	int last=qq.top().second;
        	if(last<i-k)
        	{
        		qq.pop();
        		continue;
        	}
            while(!q1.empty()&&q1.back().first>f[last]-sum[last])q1.pop_back();
            q1.push_back(make_pair(f[last]-sum[last],last));
            qq.pop();
        }
        qq.push(make_pair(-b[i]-sum[i],i));
        while(!q1.empty()&&q1.front().second<i-k)q1.pop_front();
        while(!q.empty()&&q.front().second<i-k)q.pop_front();
        while(!q.empty()&&b[q.front().second]+sum[q.front().second]<sum[i])q.pop_front();
        long long q1f=q1.front().first,qf=q.front().first;
        	if(q.empty())f[i]=q1f+sum[i];
        	else if(q1.empty())f[i]=qf;else
        		f[i]=min(q1f+sum[i],qf);
        while(!q.empty()&&q.back().first>f[i]+b[i])q.pop_back();
        q.push_back(make_pair(f[i]+b[i],i));
    }
    cout<<f[n]<<endl; 
    return 0;
}
