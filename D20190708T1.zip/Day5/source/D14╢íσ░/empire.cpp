#include<bits/stdc++.h>
using namespace std;
const long long inf=0x7ffffffffff;
int n,k,a[500010],b[500010];
long long cmp,f[500010],sum[500010];
/*inline int read(){//����dp�϶��Ῠ��emmmm�� 
	int x=0;
	bool w=false;
	char c=getchar();
	while (c>'9'||c<'0'){
		w|=c=='-';
		c=getchar();
	}
	while (c>='0'&&c<='9'){
		x=(x<<1)+(x<<3)+c^48;
		c=getchar();
	}
	return w?x:-x;
}*/
struct p{
	int q;
	long long val;
	bool operator < (const p &x) const {
		return val>x.val;	
	}//���ȶ�������С������� 
};
p tmp;
priority_queue<p> q1,q2;//���Ż�dp 
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);	
	memset(f,0x3f,sizeof(f)); 
	scanf("%d%d",&n,&k);
	sum[0]=0;
	for (int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		sum[i]=sum[i-1]+(long long)a[i];//ǰ׺�� ǿ��ת���������� ��ֹ������ 
	}
	for (int i=0;i<=n-1;i++) scanf("%d",&b[i]);
	//for (int i=1;i<=n;i++) cout<<a[i]<<endl<<sum[i]<<endl<<b[i]<<endl; 
	f[0]=0;
	for (int i=1;i<=n;i++){
		tmp.q=i-1;
		tmp.val=f[i-1]+b[i-1];
		//cout<<tmp.q<<endl<<tmp.val<<endl; 
		q1.push(tmp);
		while (!q1.empty()){
			tmp=q1.top();
		//	cout<<tmp.q<<endl<<tmp.val<<endl; 
			if (i-tmp.q>k) q1.pop();
			else break;
		} 
		while (!q2.empty()){
			tmp=q2.top();
		//	cout<<tmp.q<<endl<<tmp.val<<endl; 
			if (i-tmp.q>k) q2.pop();
			else break;
		} 
		while (!q1.empty()){
			tmp=q1.top();
		//	cout<<tmp.q<<endl<<tmp.val<<endl; 
			if (tmp.val>f[tmp.q]+sum[i]-sum[tmp.q]) break;
			q1.pop();
			tmp.val=f[tmp.q]-sum[tmp.q];			
			q2.push(tmp); 
		} 
		while (!q1.empty()){
			tmp=q1.top();
		//	cout<<tmp.q<<endl<<tmp.val<<endl; 
			if (i-tmp.q>k) q1.pop();
			else break;
		} 
		while (!q2.empty()){
			tmp=q2.top();
		//	cout<<tmp.q<<endl<<tmp.val<<endl; 
			if (i-tmp.q>k) q2.pop();
			else break;
		} 
		cmp=inf;
		if (!q1.empty()) cmp=min(cmp,q1.top().val);
		if (!q2.empty()) cmp=min(cmp,q2.top().val+sum[i]);
		f[i]=cmp;
	}
	printf("%lld\n",f[n]); 
	fclose(stdin);
	fclose(stdout);
	return 0;
}
