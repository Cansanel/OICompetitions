#include<bits/stdc++.h>
using namespace std; 
int dfn[2200000],last[2200000],f[2200000][4],low[2200000],du[2200000],a[2200000],dep[2200000];
int n,m,tot,x,y,z,flag,op,k,cnt,tim,u,v;
struct edge{
	int v,next;
}e[2200000];;
struct P{
	int x,y;
}query[2200000];
void add(int u,int v){
	e[++tot].v=v;
	e[tot].next=last[u];
	last[u]=tot;
}
//e[i].v
//������dfs����� 
void dfs(int x){
	dfn[x]=++tim;
	for (int i=last[x];i;i=e[i].next){
		if(a[x]==0||du[x]==1)
			f[e[i].v][0]=f[x][0]+1;
		else f[e[i].v][0]=0;
		if(a[x]==1||du[x]==1)
			f[e[i].v][1]=f[x][1]+1;
		else f[e[i].v][1]=0;
		dep[e[i].v]=dep[x]+1;
		dfs(e[i].v);
	}	
	low[x]=tim;
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=m;i++){
		scanf("%d",&flag);
		if (!flag){
			n+=1;
			scanf("%d%d",&op,&k);
			for (int j=1;j<=k;j++){
				scanf("%d",&u);
				add(n,u);
			}
			a[n]=op;
			du[n]=k;
		}
		else {
			scanf("%d%d",&x,&y);
			query[++cnt].x=x;
			query[cnt].y=y;
		}
	}
	for (int i=n;i>=1;i--) 
		if (!dfn[i]) dfs(i);
	for (int i=1;i<=cnt;i++){
		u=query[i].x;
		v=query[i].y;
		if (dfn[u]<=dfn[v]&&low[v]<=low[v]){
			if (f[v][0]>=dep[v]-dep[u]) printf("1\n");
			else printf("0\n");
		}
		else if (dfn[v]<=dfn[u]&&low[u]<=low[v]){
			if (f[u][1]>=dep[u]-dep[v]) printf("1\n");
			else printf("0\n");
		}
		else printf("0\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
