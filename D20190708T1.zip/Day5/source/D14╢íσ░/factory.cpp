#include<bits/stdc++.h>
using namespace std;
const long long maxn=1e5+10;
long long n,a[maxn],ans,l=1,r,p;
map <long long,long long> mp;//����  
long long gcd(long long a,long long b){
	if (b==0) return a;
	return gcd(b,a%b);
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	scanf("%lld",&n);
	for (int i=1;i<=n;i++) scanf("%lld",&a[i]);
	while (l<=n){
		r=l+1;
		p=abs(a[r]-a[l]);
		mp[a[l]]=1;
		while (r<=n&&gcd(abs(a[r]-a[l]),p)!=1&&mp.count(a[r])==0) {
			mp[a[r]]=1;
			r++;
			p=gcd(abs(a[r]-a[l]),p);
		} 
		r--;
		l=r+1;
		ans++;
		mp.clear();
	}
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
