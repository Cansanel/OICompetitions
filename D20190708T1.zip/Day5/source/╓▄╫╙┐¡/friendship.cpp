#include <bits/stdc++.h>
using namespace std;
#define maxn 500005
#define maxm 1000005
int n,m;
struct Edge{
	int f,t,nxt;
}edge[maxm];
int etot=1,head[maxn];
void add_edge(int f,int t){
	edge[++etot]=(Edge){f,t,head[f]};
	head[f]=etot;
}
template <typename Tp>
void read(Tp &x){x=0;int f=1;char c=getchar();
	while((c>'9'||c<'0')){if(c=='-'){f=-1;}c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+(c&15);c=getchar();}x*=f;
}
int vis[maxn];
int query(int x,int y){
	int cur;
	memset(vis,0,sizeof(vis));
	queue<int>q;
	q.push(y);
	while(!q.empty()){
		cur=q.front();q.pop();
		vis[cur]=1;
		for(int i=head[cur];i;i=edge[i].nxt){
			int ne=edge[i].t;
			if(!vis[ne])vis[ne]=1,q.push(ne);
		}
	}
	return vis[x];
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	int cz,op,k,x,y;
	read(n);read(m);
	for(int i=1;i<=m;i++){
		read(cz);
		if(cz==1){
			read(x);read(y);
			printf("%d\n",query(x,y));
		}
		else{
			read(op);read(k);
			for(int i=1;i<=k;i++){
				read(x);
				if(op==0)add_edge(x,n+1);
				else add_edge(n+1,x);
			}
			n++;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

