#include <bits/stdc++.h>
using namespace std;
#define maxn 500005
#define maxm 1000005
#define linf 0x3f3f3f3f3f3f3f3fll
#define LL long long int
LL n,k,a[maxn],b[maxn],dp[maxn],s[maxn];
template <typename Tp>
void read(Tp &x){x=0;int f=1;char c=getchar();
	while((c>'9'||c<'0')){if(c=='-'){f=-1;}c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+(c&15);c=getchar();}x*=f;
}
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	int fl1=1,fl2=1,fl3=1;
	read(n);read(k);
	if(n!=k)fl3=0;
	for(int i=2;i<=n+1;i++){
		read(a[i]),s[i]=s[i-1]+a[i];
	}
	for(int i=1;i<=n;i++){
		read(b[i]);
		if(a[i+1]!=b[i])fl2=0;
		if(b[i]!=1)fl1=0;
	}
	if(fl1||fl2||fl3){
		if(fl3)printf("%lld\n",max(b[0],s[n+1]));
		else printf("%lld\n",s[n+1]);
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	memset(dp,0x3f,sizeof(dp));
	dp[1]=0;
	for(int i=2;i<=n+1;i++){
		for(int j=i-1;j>=1&&j>=i-k;j--){
			dp[i]=min(dp[i],dp[j]+max(s[i]-s[j],b[j]));
		}
	}
	printf("%lld\n",dp[n+1]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
