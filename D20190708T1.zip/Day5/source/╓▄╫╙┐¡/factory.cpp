#include <bits/stdc++.h>
using namespace std;
#define maxn 100005
#define maxm 100005
#define int long long
#define its set<int>::iterator
int n,m;
template <typename Tp>
void read(Tp &x){x=0;int f=1;char c=getchar();
	while((c>'9'||c<'0')){if(c=='-'){f=-1;}c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+(c&15);c=getchar();}x*=f;
}
int gcd(int x,int y){
	return y?gcd(y,x%y):x;
}
int b[maxn],tot;
int a[maxn],dp[maxn],zx[maxn];
int check(int gg,int p){
	tot=0;
	for(int i=gg;i<=p;i++)b[++tot]=a[i];
	sort(b+1,b+tot+1);
	int tot1=unique(b+1,b+tot+1)-b-1;
	if(tot1!=tot)return 0;
	int ret=0;
	for(int i=1;i<tot;i++){
		ret=gcd(ret,b[i+1]-b[i]);
	}
	return ret>1;
}
int ef(int p){
	int l=zx[p-1],r=p-1,mid;
	while(l<r){
		mid=(l+r)>>1;
		if(check(mid,p))r=mid;
		else l=mid+1;
	}
	return l;
}

signed main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++){
		read(a[i]);
	}
	zx[0]=1;
	for(int i=1;i<=n;i++){
		zx[i]=ef(i);
	}
	memset(dp,0x3f,sizeof(dp));
	dp[0]=0;
	for(int i=1;i<=n;i++){
		for(int j=zx[i];j<i;j++){
			dp[i]=min(dp[i],dp[j-1]+1);
		}
	}
	printf("%lld\n",dp[n]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
