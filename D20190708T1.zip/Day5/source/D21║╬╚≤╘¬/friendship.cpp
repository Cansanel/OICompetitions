#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
#define ld long double
#define F(i,j,k) for(int i=j;i<=k;i++)
#define DF(i,j,k) for(int i=j;i>=k;i--)
#define P pair
#define M make_pair
#define dui priority_queue
template<typename T>inline void read(T &n){
	T w=1;n=0;char ch=getchar();
	while(!isdigit(ch)&&ch!=EOF){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch)&&ch!=EOF){n=(n<<3)+(n<<1)+(ch&15);ch=getchar();}
	n*=w;
}
template<typename T>inline void write(T x){
	T l=0;
	ull y=0;
	if(!x){putchar(48);return;}
	if(x<0){x=-x;putchar('-');}
	while(x){y=y*10+x%10;x/=10;l++;}
	while(l){putchar(y%10+48);y/=10;l--;}
}
template<typename T>inline void writes(T x){
	write(x);
	putchar(' ');
}
template<typename T>inline void writeln(T x){
	write(x);
	puts("");
}
template<typename T>inline void checkmax(T &a,T b){a=max(a,b);}
template<typename T>inline void checkmin(T &a,T b){a=min(a,b);}
int a[301000],rd[301000],cd[301000],ans[301000],h[301000],cnt,to[601000],nxt[601000],head[601000];
vector <P<int,int> > ly[301000];
inline void addedge(int x,int y){
	to[++cnt]=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
inline void dfs(int x){
	int l=ly[x].size();
	F(i,0,l-1)ans[ly[x][i].second]|=h[ly[x][i].first];
	h[x]=1;
	for(int i=head[x];i;i=nxt[i])dfs(to[i]);
	h[x]=0;
}
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	int n,m;read(n);read(m);
	F(i,1,n){addedge(0,i);rd[i]++;}
	cd[0]=n;
	int s=n,s2=0;
	F(i,1,m){
		int opt;read(opt);
		if(opt==0){
			int op,k;read(op);read(k);
			s++;
			F(j,1,k)read(a[j]);
			if(k==1){addedge(a[1],s);addedge(s,a[1]);rd[a[1]]++;cd[a[1]]++;rd[s]++;cd[s]++;continue;}
			F(j,1,k)if(op==0)addedge(s,a[j]);else addedge(a[j],s);
		}
		else {
			s2++;
			int x,y;read(x);read(y);
			ly[y].push_back(M(x,s2));
		}
	}
	F(i,n+1,s)if(rd[i]==0){rd[i]++;cd[s+1]++;addedge(s+1,i);}
	dfs(0);
	dfs(s+1);
	F(i,1,s2)writeln(ans[i]);
	return 0;
}

