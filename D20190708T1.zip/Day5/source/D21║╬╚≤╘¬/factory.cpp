#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int long long
#define ull unsigned long long
#define ld long double
#define F(i,j,k) for(int i=j;i<=k;i++)
#define DF(i,j,k) for(int i=j;i>=k;i--)
#define P pair<double,double>
#define M make_pair
#define dui priority_queue
template<typename T>inline void read(T &n){
	T w=1;n=0;char ch=getchar();
	while(!isdigit(ch)&&ch!=EOF){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch)&&ch!=EOF){n=(n<<3)+(n<<1)+(ch&15);ch=getchar();}
	n*=w;
}
template<typename T>inline void write(T x){
	T l=0;
	ull y=0;
	if(!x){putchar(48);return;}
	if(x<0){x=-x;putchar('-');}
	while(x){y=y*10+x%10;x/=10;l++;}
	while(l){putchar(y%10+48);y/=10;l--;}
}
template<typename T>inline void writes(T x){
	write(x);
	putchar(' ');
}
template<typename T>inline void writeln(T x){
	write(x);
	puts("");
}
template<typename T>inline void checkmax(T &a,T b){a=max(a,b);}
template<typename T>inline void checkmin(T &a,T b){a=min(a,b);}
int n,s,f[101000],a[101000];
inline int gcd(int x,int y){if(x==0)return y;if(y==0)return x;return gcd(y,x%y);}
signed main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	read(n);
	F(i,1,n)read(a[i]);
	f[0]=0;s++;
	F(i,1,n-1){
		int c=abs(a[i]-a[i+1]);
		int g=gcd(f[i-1],c);
		if(g==1){s++;f[i]=0;}
		else f[i]=g;
	}
	writeln(s);
	return 0;
}

