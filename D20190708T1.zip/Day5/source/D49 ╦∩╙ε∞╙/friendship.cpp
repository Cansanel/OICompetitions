#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,tot,cnt,head[700005];
inline int read() {
	int x(0),neg(1);char ch(getchar());
	while(!isdigit(ch)) {
		if (ch=='-') neg=-1;
		ch=getchar();
	}
	while(isdigit(ch)) {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*neg;
}
struct node{
	int to,next;
}edge[700005];
inline void add(int u,int v) {
	edge[++cnt]=(node){v,head[u]};
	head[u]=cnt;
}
inline bool dfs(int u,int fa,int st) {
	if (u==st) return true;
	bool flag(false);
	for (int i=head[u];i;i=edge[i].next) {
		int v(edge[i].to);
		if (v==fa) continue;
		if (dfs(v,u,st)) {
			flag=true;
			break;
		}
	}
	return flag;
}

signed main() {
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	
	n=read(),m=read();
	tot=n;
	while(m--) {
		int opt(read());
		if (!opt) {
			opt=read();
			int k(read());
			++tot;
			if (k==1) {
				int x(read());
				add(x,tot);
				add(tot,k);
			}
			if (opt) {
				for (register int i=1;i<=k;++i) {
					int x(read());
					add(x,tot);
				}
			}
			else {
				for (register int i=1;i<=k;++i) {
					int x(read());
					add(tot,x);
				}
			}
		}
		else {
			int x(read()),y(read()); 
			puts(dfs(x,x,y)?"1":"0");
		}
	}
	return 0;
} 
