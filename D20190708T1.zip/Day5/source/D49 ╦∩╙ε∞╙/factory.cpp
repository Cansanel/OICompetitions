#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,num[200005],x,cnt;
map <int,bool> mp; 
inline int read() {
	int x(0),neg(1);char ch(getchar());
	while(!isdigit(ch)) {
		if (ch=='-') neg=-1;
		ch=getchar();
	}
	while(isdigit(ch)) {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*neg;
}
inline int gcd(int a,int b) {return !b?a:gcd(b,a%b);}
signed main() {
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	
	n=read();
	for (int i=1;i<=n;++i) num[i]=read();
	int l=1,x=0;
	while(l<=n) {
		int r=l+1,zuida=abs(num[r]-num[l]);
		mp[num[l]]=true;
		while(r<=n && gcd(zuida,abs(num[r]-num[l]))!=1 && !mp.count(num[r])) {
			mp[num[r]]=true;
			++r;
			zuida=gcd(zuida,abs(num[r]-num[l]));
		}
		l=r;
		++cnt;
		mp.clear();
	}
	printf("%lld\n",cnt);
	return 0;
}
