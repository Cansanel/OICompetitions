#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,l,r,q[500005],a[500005],b[500005],dp[500005],pre[500005];
inline int read() {
	int x(0),neg(1);char ch(getchar());
	while(!isdigit(ch)) {
		if (ch=='-') neg=-1;
		ch=getchar();
	}
	while(isdigit(ch)) {
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x*neg;
}
struct node{
	int j,sum;
	bool operator < (const node &x) const{
		return sum>x.sum;
	}
};
priority_queue<node> q1,q2;

signed main() {
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	
	memset(dp,0x3f,sizeof(dp));
	n=read(),m=read();
	for (int i=1;i<=n;++i) {
		a[i]=read();
		pre[i]=pre[i-1]+a[i]; 
	}
	for (int i=0;i<n;++i) 	b[i]=read();
	dp[0]=0;
	for (int i=1;i<=n;++i) {
		node tmp=(node){i-1,dp[i-1]+b[i-1]};
		q1.push(tmp);
		while(!q1.empty()&&i-q1.top().j>m) q1.pop();
		while(!q2.empty()&&i-q2.top().j>m) q2.pop();
		while(!q1.empty()&&q1.top().sum<=dp[q1.top().j]+pre[i]-pre[q1.top().j]) {
			int jj=q1.top().j;
			q1.pop();
			node tmp=(node){jj,dp[jj]-pre[jj]};
			q2.push(tmp);
		}
		while(!q2.empty()&&i-q2.top().j>m) q2.pop();
		dp[i]=0x3f3f;
		if (!q1.empty()) dp[i]=min(dp[i],q1.top().sum);
		if (!q2.empty()) dp[i]=min(dp[i],q2.top().sum+pre[i]);
	}
	printf("%lld\n",dp[n]);
	return 0; 
} 
