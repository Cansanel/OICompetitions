#include <iostream>
#include <string.h>
#include <fstream>
#include <queue>
using namespace std;
const int MAXN=500005;
int read(){
	int f=1,ans=0;
	char ch=getchar();
	if (ch=='-') f=-1;
	while ('0'<=ch&&ch<='9'){ans=ans*10+(ch-'0');ch=getchar();}
	return f*ans;
}

int n,k;
int a[MAXN],b[MAXN];
int dp[MAXN];
int sum[MAXN];
int addsum(int now,int pos){
	return max(sum[now]-sum[pos],b[pos])+dp[pos];
}

int main()

{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	memset(dp,0x3f3f3f3f,sizeof(dp));
	n=read();k=read();
	for (int i=1;i<=n;i++)
		a[i]=read();

	for (int i=0;i<n;i++)
		b[i]=read();

	for (int i=1;i<=n;i++){
		sum[i]=sum[i-1]+a[i];
	}

	dp[0]=0;
	deque<int> q;
	q.push_back(0);
	for (int i=1;i<=n;i++){
		while (!q.empty()&&q.front()+k<i) q.pop_front();

		dp[i]=addsum(i,q.front());

		while (!q.empty()&&(addsum(i,q.back())>=addsum(i,i))){
			q.pop_back();
		}
		q.push_back(i);
	}

	cout<<dp[n]<<endl;
	return 0;
}
