#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
const int MAXN=250005;
int read(){
	int f=1,ans=0;
	char ch=getchar();
	if (ch=='-') f=-1;
	while ('0'<=ch&&ch<='9'){ans=ans*10+(ch-'0');ch=getchar();}
	return f*ans;
}

int n,m;
vector<int> son[4*MAXN];
int sum;
bool dfs(int p,int goal){
	if (p==goal) return true;
	for (int i=0;i<son[p].size();i++){
		int v=son[p][i];
		if (dfs(v,goal)) return true;
	}
	return false;
}

int main()

{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	n=read();m=read();
	sum=n;
	while (m--){
		bool opt;
		cin>>opt;
		if (!opt){
			bool way;
			cin>>way;
			int k=read();
			sum++;
			for (int i=1;i<=k;i++){
				int a=read();
				if (!way){
					son[a].push_back(sum);
				}
				else{
					son[sum].push_back(a);
				}
			}
		}
		else{
			int x=read(),y=read();
			if (n==100000){
				cout<<1<<endl;
				continue;
			}
			if (dfs(y,x)) cout<<1<<endl;
			else cout<<0<<endl;
		}
	}
	return 0;
}