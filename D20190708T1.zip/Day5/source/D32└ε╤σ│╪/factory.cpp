#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;
int read(){
	int f=1,ans=0;
	char ch=getchar();
	if (ch=='-') f=-1;
	while ('0'<=ch&&ch<='9'){ans=ans*10+(ch-'0');ch=getchar();}
	return f*ans;
}

int gcd(int a,int b){
	if (a<b) swap(a,b);
	if (b==0) return a;
	return gcd(b,a%b);
}
int n;
int a[100005];
int ans=1;

int main()

{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++){
		a[i]=read();
	}

	int last=abs(a[2]-a[1]);
	for (int i=2;i<=n;i++){
		if (last==1) {ans++;last=abs(a[i+1]-a[i]);}
		else last=gcd(last,abs(a[i+1]-a[i]));
	}

	cout<<ans<<endl;
	return 0;
}
