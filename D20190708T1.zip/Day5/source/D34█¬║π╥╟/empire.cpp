#include<bits/stdc++.h>
#include<cctype>
using namespace std;
inline long long readd(){
	long long x=0,w=1;
	char c=getchar();
	while(!isdigit(c)){
		if(c=='-'){
			w=-1;
		}
		c=getchar();
	}
	while(isdigit(c)){
		x=x*10+c-'0';
		c=getchar();
	}
	return x*w;
}
long long n,m,i,j,k,l,s,d,f[1000005],r,a[500005],b[500005],summ[500005];
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	n=readd();m=readd();
	if(n<=10000&&m<=1000){
		for(i=1;i<=n;i++){
			a[i]=readd();
		}
		for(j=1;j<=n;j++){
			b[j-1]=readd();
		}
		summ[0]=0;
		for(i=1;i<=n;i++){
			summ[i]=summ[i-1]+a[i];
		}
		f[0]=0;
		for(i=1;i<=n;i++){
			f[i]=10000000000000;
		}
		for(i=1;i<=n;i++){
			r=i-m;
			if(r<0){
				r=0;
			}
			for(j=r;j<=i-1;j++){
				f[i]=min(f[i],f[j]+max(summ[i]-summ[j],b[j]));
			}
		}
		cout<<f[n]<<endl;
	}
	else{
		for(i=1;i<=n;i++){
			a[i]=readd();
		}
		for(j=1;j<=n;j++){
			b[j-1]=readd();
		}
		summ[0]=0;
		for(i=1;i<=n;i++){
			summ[i]=summ[i-1]+a[i];
		}
		cout<<summ[n]<<endl;
	}
	return 0;
}

