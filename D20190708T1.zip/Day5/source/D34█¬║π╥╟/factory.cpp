#include<bits/stdc++.h>
#include<cctype>
using namespace std;
inline int readd(){
	int x=0,w=1;
	char c=getchar();
	while(!isdigit(c)){
		if(c=='-'){
			w=-1;
		}
		c=getchar();
	}
	while(isdigit(c)){
		x=x*10+c-'0';
		c=getchar();
	}
	return x*w;
}
int n,m,i,j,k,l,s,d,f,r,a[10000005];
int gcd(int a,int b){
	if(a==0||b==0){
		return a+b;
	}
	int r=a%b;
	while(r!=0){
		a=b;
		b=r;
		r=a%b;
	}
	return b;
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	n=readd();
	for(i=1;i<=n;i++){
		a[i]=readd();
	}
	s=1;
	f=0;
	for(i=2;i<=n;i++){
		if(abs(a[i]-a[i-1])==1){
			s++;
			f=0;
		}
		else
		if(a[i]==a[i-1]){
			s++;
			f=0;
		}
		else{
			r=gcd(f,abs(a[i]-a[i-1]));
			if(r==1){
				s++;
				f=0;
			}
			else{
				f=r;
			}
		}
	}
	cout<<s<<endl;
	return 0;
}

