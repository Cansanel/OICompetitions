#include<bits/stdc++.h>
#include<cctype>
#include<vector>
using namespace std;
inline int readd(){
	int x=0,w=1;
	char c=getchar();
	while(!isdigit(c)){
		if(c=='-'){
			w=-1;
		}
		c=getchar();
	}
	while(isdigit(c)){
		x=x*10+c-'0';
		c=getchar();
	}
	return x*w;
}
int n,m,i,j,k,l,s,d,f,r,pr[250050],h[250005],t[250005],ff,rr;
vector<int>a[250005],b[250005];
int main(){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	n=readd();m=readd();
	memset(t,0,sizeof(t));
	memset(h,0,sizeof(h));
	for(i=1;i<=m;i++){
		l=readd();
		if(l==0){
			f=readd();
			r=readd();
			for(j=1;j<=r;j++){
				pr[j]=readd();
			}
			if(r==1){
				a[n+1].push_back(pr[1]);
				a[pr[1]].push_back(n+1);
				n++;
				continue;
			}
			if(f==0){
				for(j=1;j<=r;j++){
					a[n+1].push_back(pr[j]);
				}
				
			}
			else{
				for(j=1;j<=r;j++){
					a[pr[j]].push_back(n+1);
				}
			}
			n++;
		}
		else{
			f=readd();
			r=readd();
			ff=1;rr=1;
			t[1]=f;
			d=0;
			while(ff<=rr){
				for(j=0;j<a[t[ff]].size();j++){
					if(a[t[ff]][j]==r){
						d=1;
						break;
					}
					else{
						if(h[a[t[ff]][j]]==i){
							continue;
						}
						else{
							rr++;
							t[rr]=a[t[ff]][j];
							h[t[rr]]=i;
						}
					}
				}
				if(d==1){
					break;
				}
				ff++;
			}
			cout<<d<<endl;
		}
	}
	/*for(i=1;i<=n;i++){
		cout<<i<<":";
		for(j=0;j<a[i].size();j++){
			cout<<a[i][j]<<",";
		}
		cout<<endl;
	}*/
	return 0;
}

