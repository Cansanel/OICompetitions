#include<cstdio>
#include<map>
using namespace std;
#define abs(x) (x<0?-(x):x)
int n,x,y;
int a[100011];
int cur;
map<int,int> mp;
inline int read()
{
int x=0;char ch=getchar();
while(ch>'9'||ch<'0')ch=getchar();
while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+ch-48,ch=getchar();
return x;
}
int gcd(int x,int y)
{
if(x<y){x^=y;y^=x;x^=y;}
if(!y)return x;else return gcd(y,x%y);
}
int main()
{
freopen("factory.in","r",stdin);
freopen("factory.out","w",stdout);
n=read();
for(int i=1;i<=n;++i)
a[i]=read();
int l=1;
while(l<=n)
	{
	int r=l+1;
	int tmp=abs(a[r]-a[l]);
	mp[a[l]]=1;
	while(r<=n&&(gcd(abs(a[r]-a[l]),tmp)!=1)
	&&(mp.count(a[r])==0))mp[a[r]]=1,++r,tmp=gcd(tmp,abs(a[r]-a[l]));
	l=r;
	++cur;
	mp.clear();
	}
printf("%d\n",cur);
fclose(stdin);
fclose(stdout);
return 0;
}
