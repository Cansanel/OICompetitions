#include<cstdio>
#include<cstring>
int n,m,cur,x,y,flag;
int opt,k,sig;
struct edge
{
int to,nxt;
}a[800001];
int head[750011],tot=0;
int vis[750011];
inline int read()
{
int x=0;char ch=getchar();
while(ch>'9'||ch<'0')ch=getchar();
while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+ch-48,ch=getchar();
return x;
}
inline void addedge(int x,int y)
{a[++tot].to=y;a[tot].nxt=head[x];head[x]=tot;}
void dfs(int p)
	{
	vis[p]=1;
	if(p==y){flag=1;return;}
	for(int i=head[p];i;i=a[i].nxt)
		{
		if(!vis[a[i].to])dfs(a[i].to);
		if(flag)return;
		}
	if(flag)return;
	}
int main()
{
freopen("friendship.in","r",stdin);
freopen("friendship.out","w",stdout);
cur=n=read();m=read();
for(;m;--m)
	{
	sig=read();
	if(sig)
		{
		std::memset(vis,0,sizeof(vis));
		flag=0;
		x=read();y=read();
		dfs(x);
		printf("%d\n",flag);
		}
	else
		{
		opt=read();
		k=read();
		if(k==1){x=read();++cur;addedge(x,cur);addedge(cur,x);}
		if(!opt)	
			{
			++cur;
			for(int i=1;i<=k;++i)
			x=read(),addedge(cur,x);
			}
		else
			{
			++cur;
			for(int i=1;i<=k;++i)
			x=read(),addedge(x,cur);
			}
		}
	}
fclose(stdin);
fclose(stdout);
return 0;
}
