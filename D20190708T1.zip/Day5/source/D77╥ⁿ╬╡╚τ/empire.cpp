#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
#define ll long long
#define inf 
#define max(x,y) (x>y?x:y)
#define min(x,y) (x<y?x:y)
int n,k,flag1=1,flag2=1; 
ll a[500001],b[500001];
ll f[500001];
inline int read()
{
int x=0;char ch=getchar();
while(ch>'9'||ch<'0')ch=getchar();
while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+ch-48,ch=getchar();
return x;
}
int main()
{
freopen("empire.in","r",stdin);
freopen("empire.out","w",stdout);
n=read(),k=read();
for(int i=1;i<=n;++i)
a[i]=read(),a[i]+=a[i-1];
for(int i=0;i<n;++i)
{
b[i]=read();
if(b[i]!=a[i]-a[i-1])flag1=0;
if(b[i]!=1)flag2=0;
}
if(flag1||flag2||n==k)
	{
	cout<<a[n]<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
	}
std::memset(f,-0x9f,sizeof(f));
f[0]=0;
for(int i=1;i<=n;++i)
for(register int j=1;j<=min(k,i);++j)
f[i]=min(f[i],max(b[i-j],a[i]-a[i-j])+f[i-j]);
cout<<f[n]<<endl;
fclose(stdin);
fclose(stdout);
return 0;
}
