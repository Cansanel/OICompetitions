#include<bits/stdc++.h>
using namespace std;
inline void read(int &x)
{
	char ch=getchar();
	int p=0;
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) p=p*10+ch-48,ch=getchar();
	x=p;
}
int gcd(int a,int b){if(a%b==0) return b;else return gcd(b,a%b);}
int a[100001];
int la[100001];
map<int,int> mp;
int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	int n,m;
	read(n);
	for(int i=1;i<=n;i++)
		{
			read(a[i]);
			if(mp.count(a[i])) la[i]=mp[a[i]];
			else la[i]=-1;
			mp[a[i]]=i;
		}
	int l=1,now=-1,ans=1;
	for(int i=2;i<=n;i++)
		{
//			cout<<l<<" "<<now<<" "<<ans<<" "<<i<<endl;
			if(l<=la[i]) {l=i;now=-1;ans++;continue;}
			if(now==-1)
				{
					now=abs(a[i]-a[i-1]);
					if(now==1) 
						{
							l=i;
							now=-1;
							ans++;
							continue;
						}
				}
			else
				{
					int p=gcd(now,abs(a[i]-a[i-1]));
					if(p==1)
						{
							now=-1;
							l=i;
							ans++;
						}
					else now=p;
				}
		}
	cout<<ans<<endl;
	return 0;
}

