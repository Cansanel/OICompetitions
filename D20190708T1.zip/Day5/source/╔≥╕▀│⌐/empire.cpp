#include<bits/stdc++.h>
#define int long long
using namespace std;
int cf[100001];
int ss[100001];
int dp[100001];
int pre[100001];
inline void read(int &x)
{
	char ch=getchar();
	int p=0;
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) p=p*10+ch-48,ch=getchar();
	x=p;
}
signed main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	int n,k;
	read(n);
	read(k);
	for(int i=1;i<=n;i++) read(cf[i]);
	for(int i=1;i<=n;i++) read(ss[i-1]);
	for(int i=1;i<=n;i++) pre[i]=pre[i-1]+cf[i];
	if(n*k<=5000*5000*15)
		{
			dp[0]=0;
			for(int i=1;i<=n;i++)
			{
				dp[i]=INT_MAX;
				for(int j=i-1;j>=max((int)0,i-k);j--)
					{
						int dick=max(pre[i]-pre[j],ss[j]);
						dp[i]=min(dp[i],dick+dp[j]);
//						cout<<dick<<" "<<j<<endl;
//						system("pause");
					}
//				cout<<dp[i]<<endl<<endl;
			}
			cout<<dp[n]<<endl;
			return 0;
		}
	if(n==k)
		{
			cout<<max(ss[0],pre[n])<<endl;
			return 0;
		}
	cout<<pre[n]<<endl;
	return 0;
}

