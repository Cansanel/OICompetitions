#include<bits/stdc++.h>
using namespace std;
bitset<5005> bs[5005];
bitset<5005> ls;
inline void read(int &x)
{
	char ch=getchar();
	int p=0;
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) p=p*10+ch-48,ch=getchar();
	x=p;
}
int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	int n,m;
	int t=0;
	read(n);
	read(m);
	while(m--)
		{
			int xxoo;
			read(xxoo);
			if(xxoo==1)
				{
					int x,y;
					read(y);
					read(x);
					if(x<=n)
						if(y<=n)
							{
								if(x==y)
									{
										putchar('1');
										putchar('\n');
										continue;
									}
								else
									{
										putchar('0');
										putchar('\n');
										continue;
									}
							}
						else
							{
								y-=n;
								if((bs[y].count()==1&&bs[y][x]==1)||bs[y].count()==0)
									{
										putchar('1');
										putchar('\n');
										continue;
									}
								else
									{
										putchar('0');
										putchar('\n');
										continue;
									}
							}
					else
						{
							x-=n;
							if(y<=n)
							{
								if(bs[x][y])
									{
										putchar('1');
										putchar('\n');
										continue;
									}
								else	
									{
										putchar('0');
										putchar('\n');
										continue;
									}
							}
							else
							{
								y-=n;
								ls=bs[x]&bs[y];if(ls.count()<bs[y].count()) putchar('0');
								else putchar('1');
								putchar('\n');
							}
						}
						
					
				}
			else
				{
					int op,k;
					read(op);
					read(k);
					if(op==0)
						{
							ls.set();
							for(int i=1;i<=k;i++)
							{
								int d;
								read(d);
								if(d<=n)
									{
										if(ls[d]==0)
											{
												ls.reset();
											}
										else
											{
												ls.reset();
												ls[d]=1;
											}
									}
								else
									{
										ls=ls&bs[d-n];
									}
							}
						}
					else
						{
							ls.reset();
							for(int i=1;i<=k;i++)
							{
								int d;
								read(d);
								if(d<=n)
									{
										if(ls[d]==1) ls[d]=1;
									}
								else
									{
										ls=ls|bs[d-n];
									}
							}
						}
					bs[++t]=ls;
				}
		}
	return 0;
}

