#include <bits/stdc++.h>
#define maxN 100005

using namespace std;

int read (){
	int ret=0;char c=getchar();
	while (c>'9'||c<'0')c=getchar();
	while (c<='9'&&c>='0')ret=ret*10+c-'0',c=getchar();
	return ret;
	
}

int n,a[maxN],tot,f[maxN];
bool book[1000005];

int gcd (int n,int m){
	if (n%m==0)return m;
	else return gcd(m,n%m);
}

void sol1 (){
	
	for (int i=1;i<=n;i++){
		f[i]=f[i-1]+1;
		book[a[i]]=1;
		int cur=abs(a[i]-a[i-1]);
		int j;
		for ( j=i-1;j>=1;j--){
			if (book[a[j]]||gcd(cur,abs(a[i]-a[j]))==1)break;
			book[a[j]]=1;
			f[i]=min(f[i],f[j-1]+1);
		}
		for (;j<=i;j++){
			book[a[j]]=0;
		}
	}
}

int main (){
	freopen ("factory.in","r",stdin);
	freopen ("factory.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++){
		a[i]=read();
	}
//	if (n<=1000){
		sol1();
		cout<<f[n];
//	}
	return 0;
}
