#include <bits/stdc++.h>
#define maxN 10005

using namespace std;

int read (){
	int ret=0;char c=getchar();
	while (c>'9'||c<'0')c=getchar();
	while (c<='9'&&c>='0')ret=ret*10+c-'0',c=getchar();
	return ret;

}

int n,m,v[2*maxN],head[maxN],nxt[maxN],tot,sum,f[maxN][20],h,d[maxN],from[maxN],to[maxN];
bool vis[maxN],book[maxN];

void add (int x,int y){
	v[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
	
}

void mix (int op,int k){
	n++;
	for (int i=1;i<=k;i++){
		int x=read();
		if (op== 0)add (n,x);
		else add (x,n); 
	}
	
}

bool ask (int x,int y){
	if (x==y)return 1;
	bool ret=0;
	for (int i=head[x];i;i=nxt[i]){
		if (vis[v[i]])continue;
		vis[v[i]]=1;
		ret|=ask(v[i],y);
		vis[v[i]]=0;
	}
	return ret;
}

void sol1 (){
	for (int i=1;i<=m;i++){
		int x=read(),op,k,s,t;
		switch(x){
			case 0: op=read();k=read();mix(op,k);break;
			case 1: s=read(),t=read();cout<<ask(s,t)<<endl;break;
		}
	}
}

void dfs (int x,int dep,int fa){
	d[x]=dep;
	f[x][0]=fa;
	for (int i=head[x];i;i=nxt[i]){
		if (v[i]==fa)continue;
		dfs (v[i],dep+1,x);
	}
}

int lca (int x,int y){
	if (d[x]>d[y])swap(x,y);
	for (int i=h;i>=0;i--)if (d[f[y][i]]>=d[x])y=f[y][i];
	if (x==y)return x;
	else return 0;
//	for (int i=h;i>0;i--)if (f[x][i]!=f[y][i])x=f[x][i],y=f[y][i];
//	return f[x][0];
}

void sol2 (){
	
	int op;
	for (int i=1;i<=m;i++){
		int x=read(),k,s,t;
		switch(x){
			case 0: op=read();k=read();mix(0,k);break;
			case 1: from[++sum]=read(),to[sum]=read();if (from[sum]>n||to[sum]>n)book[sum]=1;break;
		}
	}
	h=(int)log2(n)+1;
	dfs (n,1,0);
	for (int k=1;k<=h;k++){
		for (int i=1;i<=sum;i++){
			f[i][k]=f[f[i][k-1]][k-1];
		}
	}
	for (int i=1;i<=sum;i++){
		if (book[i]){cout<<0<<endl;continue;}
		if (op==0){
			if (lca(from[i],to[i])==from[i])cout<<1<<endl;
			else cout<<0<<endl;
		}
		else {
			if (lca(from[i],to[i])==to[i])cout<<1<<endl;
			else cout<<0<<endl;
		}
	}
//	cout<<lca(4,5)<<endl;
}

int main (){
	freopen ("friendship.in","r",stdin);
	freopen ("friendship.out","w",stdout);
	n=read(),m=read();
	if (n<=2000&&m<=2000){
		sol1();
		return 0;
	}
	else {
		if (n<=5000&&m<=5000){
			sol2();
			return 0;
		}
	}
	return 0;
}

