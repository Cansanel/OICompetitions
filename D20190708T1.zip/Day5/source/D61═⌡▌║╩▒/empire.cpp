#include <bits/stdc++.h>
#define maxN 500005

using namespace std;

typedef long long ll;

ll read (){
	ll ret=0;char c=getchar();
	while (c>'9'||c<'0')c=getchar();
	while (c<='9'&&c>='0')ret=ret*10+c-'0',c=getchar();
	return ret;

}

ll n,k,a[maxN],b[maxN],train[maxN],q[maxN],f[maxN];

bool istrain (int i,int j){
	return (train[j]-train [i])>b[i];
}

ll cost (int i,int j){
	return max(train[j]-train [i],b[i]);
}

int main (){
	freopen ("empire.in","r",stdin);
	freopen ("empire.out","w",stdout);
	n=read();
	k=read();
	for (int i=1;i<=n;i++){
		a[i]=read();
		train[i]=train[i-1]+a[i];
	}
	for (int i=0;i<n;i++){
		b[i]=read();
	}
	int l=1,r=1;
	for (int i=1;i<=n;i++){
		while (i-q[l]>k)l++;
		
//		while (istrain(q[l+1],i))cout<<q[l]<<endl,l++;
		while (cost(q[l+1],i)<cost(q[l],i))l++;
		f[i]=f[q[l]]+cost(q[l],i);
		while (b[q[r]]>b[i])r--;
		q[++r]=i;
	}
	cout<<f[n];
	return 0;
}

