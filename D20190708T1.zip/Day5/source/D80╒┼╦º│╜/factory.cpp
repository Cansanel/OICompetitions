#include <bits/stdc++.h>
using namespace std;
int n,g,cnt = 1;
int a[200000];

inline void zread(int &x)
{
	char ch = getchar();	x = 0;
	while(!isdigit(ch))	ch = getchar();
	while(isdigit(ch))	x = (x << 1) + (x << 3) + (ch ^ 48),ch = getchar();
}

inline int gcd(int x,int y)
{
	if(y ^ 0)	return gcd(y,x % y);
	return x;
}

int main()
{
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	zread(n);
	for(int i = 1; i <= n; ++i)	zread(a[i]);
	for(int i = 1; i ^ n; ++i)
	{
		int d = abs(a[i] - a[i + 1]),gg = gcd(d,g);
		if(gg ^ 1)	g = gg;
		else	++cnt,g = 0;
	}
	cout << cnt << endl;
	return 0;
}
