#include <bits/stdc++.h>
using namespace std;
int n,m,zj,tp,x,y,cnt,k;
bool vis[560000];
int h[560000];

inline void zread(int &x)
{
	char ch = getchar();	x = 0;
	while(!isdigit(ch))	ch = getchar();
	while(isdigit(ch))	x = (x << 1) + (x << 3) + (ch ^ 48),ch = getchar();
}

struct handsome
{
	int x,nxt;
}a[1020000];

inline void zadd(int x,int y)	{a[++cnt] = (handsome) {y,h[x]},h[x] = cnt;}

bool zdfs(int x,int t)
{
//	cout << "zdfs(" << x << ',' << t << ")\n";
	if(x == t)	return true;
	vis[x] = true;
	for(int i = h[x]; i; i = a[i].nxt)
		if(!vis[a[i].x])
			if(zdfs(a[i].x,t))
				return true;
	return (vis[x] = false);
}

int main()
{
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	zread(n),zread(m);
//	for(int i = 1; i <= n + m; ++i)	s[i] = i;
	for(int i = 1; i <= m; ++i)
	{
		zread(zj);
		if(zj == 0)
		{
			zread(tp),++n;
			if(tp == 1)
			{
				zread(k);
				for(int t = 1; t <= k; ++t)	zread(x),zadd(x,n);
			}
			if(tp == 0)
			{
				zread(k);
				if(k == 1)	zread(x),zadd(x,n),zadd(n,x);
				else
					for(int t = 1; t <= k; ++t)
						zread(x),zadd(n,x);
			}
		}
		if(zj == 1)
		{
			zread(x),zread(y);
//			for(int t = 1; t <= n; ++t)	cout << "h[" << t << "] = " << h[t] << ' ';
//			cout << endl;
			cout << zdfs(x,y) << endl;
		}
	}
}
