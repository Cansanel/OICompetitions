#include <bits/stdc++.h>
using namespace std;
long long n,k,ans;
long long s[600000],b[600000],f[600000];

inline void zread(long long &x)
{
	char ch = getchar();	x = 0;
	while(!isdigit(ch))	ch = getchar();
	while(isdigit(ch))	x = (x << 1) + (x << 3) + (ch ^ 48),ch = getchar();
}

int main()
{
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	zread(n),zread(k);
	for(long long i = 1; i <= n; ++i)	f[i] = 2147483647;
	for(long long i = 1; i <= n; ++i)	zread(s[i]),s[i] += s[i - 1];
	for(long long i = 1; i <= n; ++i)	zread(b[i]);
	if(n == k)
	{
		cout << b[1] + s[n] << endl;
		return 0;
	}
	if(n > 10000 || k > 10000)
	{
		for(long long i = 0; i <= n; i += k)	ans += max(b[i + 1],s[i + k] - s[i]);
		cout << ans << endl;
		return 0;
	}
	for(long long i = 1; i <= n; ++i)
		for(long long j = 1; j <= min(k,j); ++j)
			f[i] = min(f[i],f[i - j] + max(s[i] - s[i - j],b[i - j + 1]));
//	for(long long i = 1; i <= n; ++i)	cout << f[i] << ' ';
//	cout << endl;
	cout << f[n] << endl;
	return 0;
}
