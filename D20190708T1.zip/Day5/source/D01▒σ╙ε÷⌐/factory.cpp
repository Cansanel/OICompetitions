#include<cstdio>
#include<algorithm>
#define cy(tmp,x,y) for(int tmp=x;tmp<=y;++tmp)
using namespace std;
int n,t,x,ans,a[100007];
int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
int fabs(int x){
	return x>=0?x:0-x;
}
int main(){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	scanf("%d",&n);
	cy(i,1,n) scanf("%d",&a[i]);
	cy(i,1,n){
		ans++;
		x=fabs(a[i+1]-a[i]);
		if(x<=1) continue;
		t=i+1;
		while(t+1<=n){
			if(a[t]==a[t+1]) break;
			else{
				x=gcd(x,fabs(a[t+1]-a[t]));
				if(x<=1) break;
			}
			t++;
		}
		i=t;
	}
	printf("%d",ans);
	return 0;
}
