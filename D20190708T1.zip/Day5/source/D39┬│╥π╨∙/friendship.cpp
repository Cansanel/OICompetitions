#include<bits/stdc++.h>
using namespace std;
int n,m,f,op,k,x,y;
int flag[500005];
vector<int> g[500005];
bool dfs(int x,int y){
	if(x==y) return 1;flag[x]=1;
	for(int i=0;i<g[x].size();i++){
		if(flag[g[x][i]]) continue;
		flag[g[x][i]]=1;if(dfs(g[x][i],y)) return 1;
	}
}
int main( ){
	freopen("friendship.in","r",stdin);
	freopen("friendship.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>f;if(f==0){
			cin>>op>>k;n++;
			if(op==0){
				if(k==1){cin>>x;g[n].push_back(x);g[x].push_back(n);} 
				else{for(int i=1;i<=k;i++){cin>>x;g[n].push_back(x);}}
			} else{
				if(k==1){cin>>x;g[n].push_back(x);g[x].push_back(n);} 
				else{for(int i=1;i<=k;i++){cin>>x;g[x].push_back(n);}}
			}
		} else{
			cin>>x>>y;memset(flag,0,sizeof(flag));
			if(!dfs(x,y)) cout<<0<<endl;
			else cout<<1<<endl;
		}
	}
}
/*
3 5
0 0 3 1 2 3
1 1 4
0 1 1 4
1 5 1
1 4 1
*/

