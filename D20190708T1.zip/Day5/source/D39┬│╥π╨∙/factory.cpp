#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,a[100005],b[100005],ans=1,cnt;set<ll> s;
ll gcd(ll x,ll y){
	if(y==0) return x;
	return gcd(y,x%y);
}
int main( ){
	freopen("factory.in","r",stdin);
	freopen("factory.out","w",stdout);
	cin>>n;for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=2;i<=n;i++) b[i]=abs(a[i]-a[i-1]);
	cnt=b[2];s.insert(a[1]);s.insert(a[2]);if(s.size()==1) ans++;
	for(int i=3;i<=n;i++){
		cnt=gcd(b[i],cnt);//cout<<cnt<<" "<<b[i]<<" "<<i<<endl;
		if(cnt<=1 || s.find(a[i])!=s.end()){ans++;cnt=b[i+1];i++;}
		s.insert(a[i]);
	}
	cout<<ans<<endl;return 0;
}
/*
8
13 45 18 54 108 72 45 96
output:3
*/
