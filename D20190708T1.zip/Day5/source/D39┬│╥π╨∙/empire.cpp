#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a[500005],dp[500005],n,k,x,b[100005];
int main( ){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){cin>>x;a[i+1]=a[i]+x;}
	for(int i=1;i<=n;i++) cin>>b[i];
	if(n>10000){cout<<a[n+1]<<endl;return 0;}
	for(int i=1;i<=n+1;i++){
		dp[i]=0x3f3f3f3f;
		for(int j=i-1;j>=0 && j>=i-k;j--)
			dp[i]=min(dp[i],dp[j]+max(a[i]-a[j],b[j]));
	}
	cout<<dp[n+1]<<endl;return 0;
}
/*
4 2
4 3 2 1
1 2 10 3
*/
