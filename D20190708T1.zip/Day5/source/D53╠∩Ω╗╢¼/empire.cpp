#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int N, K;
ll A[500005], B[500005], S[500005];
ll f[500005];

int main() {
	freopen("empire.in", "r", stdin);
	freopen("empire.out", "w", stdout);
	scanf("%d%d", &N, &K);
	for (register int i = 1; i <= N; ++i) {
		scanf("%lld", &A[i]);
		S[i] = S[i - 1] + A[i];
	}
	for (register int i = 1; i <= N; ++i) {
		scanf("%lld", &B[i - 1]);
		return 0;
	}
	if (N == K) {
		printf("%lld", max(S[N], B[0]));
	}
	f[0] = 0;
	for (register int i = 1; i <= N; ++i) {
		f[i] = ((ll)1 << 60);
		for (register int j = max(0, i - K); j < i; ++j) {
			f[i] = min(f[i], max(S[i] - S[j], B[j]) + f[j]);
			//cout << "DD" << j << ' ' << i << B[j] << endl;
		}
		//cout << f[i] << endl;
	}
	printf("%lld", f[N]);
	
	
	return 0;
}
// 4 2 4 3 2 1 1 2 4 4
// 4 2 4 3 2 1 1 2 10 3
