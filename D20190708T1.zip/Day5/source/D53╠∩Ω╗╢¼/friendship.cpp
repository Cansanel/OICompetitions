#pragma GCC optimize(2)
#include <bits/stdc++.h>
using namespace std;
int N, M;
struct Tree {
	int id[500005], id_index;
	vector<int> G[500005];
	inline void AddEdge(int u, int v) {
		G[u].push_back(v);
		G[v].push_back(u);
	}
	int f[500005][20];
	int dep[500005];
	inline void dfs(int u, int fa) {
		id[u] = id_index;
		dep[u] = dep[fa] + 1;
		f[u][0] = fa;
		for (register int i = 1; i <= 19; ++i)
			f[u][i] = f[f[u][i - 1]][i - 1];
		for (vector<int>::iterator it = G[u].begin(); it != G[u].end(); it++) {
			int v = *it;
			if (v == fa) continue;
			dfs(v, u);
		}
	}
	inline void prework() {
		memset(id, 0, sizeof(id));
		id_index = 0;
		memset(f, 0, sizeof(f));
		dep[0] = 0;
		for (register int i = N; i >= 1; --i) {
			if (id[i] == 0) {
				id_index++;
				dfs(i, 0);
			}
		}	
	}
	inline bool check(int u, int v) {
		if (id[u] != id[v]) return 0;
		for (register int i = 19; i >= 0; --i) {
			if (dep[f[u][i]] >= dep[v])
				u = f[u][i];
		} 
		if (u != v) return 0;
		return 1;
	}
}T1, T2;
struct query {int x, y;};
vector<query> Q;
int main() {
	freopen("friendship.in", "r", stdin);
	freopen("friendship.out", "w", stdout); 
	scanf("%d%d", &N, &M);
	int opt, op, k, x, y;
	for (register int i = 1; i <= M; ++i) {
		scanf("%d", &opt);
		if (opt == 0) {
			N++;
			scanf("%d%d", &op, &k);
			if (k == 1) {
				scanf("%d", &x);
				T1.AddEdge(x, N);
				T2.AddEdge(x, N);
			}
			else {
				for (register int j = 1; j <= k; ++j) {
					scanf("%d", &x);
					if (op == 0) T2.AddEdge(x, N);
					else T1.AddEdge(x, N);
				}
			}
		}
		else {
			scanf("%d%d", &x, &y);
			Q.push_back((query){x, y});
		}
	}
	T1.prework(); T2.prework();
	for (vector<query>::iterator it = Q.begin(); it != Q.end(); it++) {
		int x = it -> x, y = it -> y;
		if (x == y) puts("1");
		else if (x < y) {
			if (T1.check(x, y)) puts("1");
			else puts("0");
		}
		else {
			if (T2.check(y, x)) puts("1");
			else puts("0");
		}
	}
	return 0;
}
