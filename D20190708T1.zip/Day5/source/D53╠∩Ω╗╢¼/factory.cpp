#pragma GCC optimize(2)
#include <bits/stdc++.h>
using namespace std;
map<int, int> mp;
inline int gcd(int a, int b) {
	if (b == 0) return a;
	return gcd(b, a%b);
}
int N;
int main() {
	freopen("factory.in", "r", stdin);
	freopen("factory.out", "w", stdout);
	scanf("%d", &N);
	int cur, las, lastgcd = 0, ans = 0;
	scanf("%d", &las);
	mp[las] = 1;
	for (register int i = 2; i <= N; ++i) {
		scanf("%d", &cur);
		lastgcd = gcd(lastgcd, abs(cur - las));
		if (lastgcd <= 1 || mp[cur] == ans + 1) lastgcd = 0, ans++;
		mp[cur] = ans + 1;
		las = cur;
	}
	ans++;
	printf("%d", ans);
	return 0;
}
/*
8
4 2 6 8 5 3 1 7
*/


/*
9
6 9 3 10 4 2 5 30 25
*/
