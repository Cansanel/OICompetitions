#include<cstring>
#include<cstdio>
const int MAXM = 2*750010;
const int MAXN = 2*750010;
int n,m,k,p,c,x,y,e,u[MAXM],v[MAXM],fst[MAXN],nxt[MAXM],vis[MAXN];
void addedge(int x,int y){
	u[++e]=x; v[e]=y;
	nxt[e]=fst[u[e]];
	fst[u[e]]=e;
}
bool dfs(int x,int ed){
	if (x==ed) return true;
	bool f=false;
	vis[x]=c;
	for(register int i=fst[x];i!=-1 && !f;i=nxt[i])
		if (vis[v[i]]!=c){
			vis[v[i]]=c;
			f|=dfs(v[i],ed);
		}
	return f;
}
int main(){
	freopen("friendship.out","w",stdout);
	freopen("friendship.in","r",stdin);
	memset(fst,255,sizeof fst);
	scanf("%d%d",&n,&m);
	while(m--){
		scanf("%d",&p);
		if (!p){
			scanf("%d%d",&p,&k);
			n++;
			for(register int i=1;i<=k;i++){
				scanf("%d",&x);
				if (p){
					addedge(x,n);
				}else{
					addedge(n,x);
				}
			}
		}else{
			scanf("%d%d",&x,&y);
			c++;
			printf("%d\n",dfs(x,y));
		}
	}
	return 0;
}
