#include<cstdio>
const int inf  = 2147483647;
const int MAXN = 500010;
int n,k,ans=inf,a[MAXN],b[MAXN];
inline int read(){
	int x=0; char c=0;
	while(c<'0'||c>'9')c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	return x;
}
inline int max(int x,int y){
	return x>y?x:y;
}
inline int min(int x,int y){
	return x<y?x:y;
}
inline void dfs(int dep,int cost){
	if (cost>=ans) return;
	if (dep==n){
		ans=cost;
	}else{
		for(register int i=1;i<=k && dep+i<=n;i++)
			dfs(dep+i,cost+max(b[dep+1],a[dep+i]-a[dep]));
	}
}
int main(){
	freopen("empire.in","r",stdin);
	freopen("empire.out","w",stdout);
	n=read(); k=read();
	for(register int i=1;i<=n;a[i++]=read()+a[i-2]);
	for(register int i=1;i<=n;b[i++]=read());
	dfs(0,0);
	printf("%d",ans);
	return 0;
}
