#include<cstdio>
const int inf  = 2147483647;
const int MAXN = 100010;
int ans,PartGCD,a[MAXN];
inline int read(){
	int x=0; char c=0;
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	return x;
}
inline int max(int x,int y){
	return x>y?x:y;
}
inline int min(int x,int y){
	return x<y?x:y;
}
inline int abs(int x){
	return x>0?x:-x;
}
inline int gcd(int x,int y){
	return y?gcd(y,x%y):x;
}
int main(){
	freopen("factory.out","w",stdout);
	freopen("factory.in","r",stdin);
	a[0]=read();
	for(register int i=1;i<=a[0];a[i++]=read());
	for(register int i=2;i<=a[0];i++){
		PartGCD = gcd(PartGCD,abs(a[i]-a[i-1]));
		if (PartGCD==1){
			PartGCD=0;
			ans++;
		}
	}
	printf("%d",ans+1);
	return 0;
}
