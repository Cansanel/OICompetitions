#include<bits/stdc++.h>

using namespace std;
const int MAXN = 1e6 + 10;
int gcd(int a, int b){
	if(b == 0)
		return a;
	return gcd(b, a%b);
}
set<int>s;
int n, a[MAXN], now_gcd;
inline void init(void){
	scanf("%d", &n);
	
	for(int i = 1; i <= n; ++ i){
		scanf("%d", &a[i]);
		
	}
}
int ans, now_size;
set<int>::iterator it, l, r;
int Front, Back;
inline bool check(){
	if(r == s.end() && gcd(Front, now_gcd) > 1)
		return true;
	if(it == s.begin() && gcd(Back, now_gcd) > 1)
		return true;
	if(r != s.end() && it != s.begin()){
		if(gcd(gcd(Back, Front), now_gcd) > 1)
			return true;
	}
	return false;
}
void Push(int i){
	s.insert(a[i]);
	now_gcd = gcd(a[i], now_gcd);
	++ now_size;
}

void Renew(int &i){
	while(abs(a[i] - a[i + 1]) == 1){
		++ ans; ++ i;
}
	s.clear(); s.insert(a[i]); s.insert(a[i + 1]);
	now_gcd = abs(a[i] - a[i + 1]); now_size = 1; ++ i;
	++ ans;
}

void Update(void){
	++ now_size;
	if(r == s.end()){
		now_gcd = gcd(Front, now_gcd);return;
	}
	if(it == s.begin()){
		now_gcd = gcd(Back, now_gcd); return;
	}
	now_gcd = gcd(gcd(Back, Front), now_gcd);
}
inline void work(void){
	int i = 1;
	a[n + 1] = INT_MAX;
	while(a[i] == a[i + 1]){
		++ i; ans ++;
	}
	Renew(i); ++ i;
	for(; i <= n; ++ i){
		if(s.count(a[i]) != 0){
			Renew(i); continue;
		}
		s.insert(a[i]);
		it = s.lower_bound(a[i]);
		l = -- it; it ++;r = ++ it; it --;
		Front = a[i] - (*l), Back = (*r) - a[i];
		if(check() == false){
			s.erase(it);
			//printf("now     is     #%d  ", ans);
			//for(set<int>::iterator point = s.begin(); point != s.end(); point++){
			//	printf(" %d", (*point));
			//}
			//printf("\n");
			Renew(i);
		}
		else 
			Update();
	}
	cout << ans;
}

int main(){
	freopen("factory.in", "r", stdin);
	freopen("factory.out", "w", stdout);
	init();
	work();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
