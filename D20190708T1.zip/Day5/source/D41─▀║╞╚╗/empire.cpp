#include<bits/stdc++.h>

using namespace std;
const int MAXN = 5e6 + 10;
const int INF = 0x3f3f3f3f;
#define sum(l, r) (pre[r] - pre[l - 1])
#define ll long long 
ll a[MAXN], b[MAXN], pre[MAXN];
int n, k;
inline void init(void){
	scanf("%d%d", &n, &k);
	for(int i = 1; i <= n; ++ i){
		scanf("%d", &a[i]); pre[i] = pre[i - 1] + a[i];
	}
	for(int i = 1;i <= n; ++ i){
		scanf("%d", &b[i - 1]);
	}
	
}
ll dp[MAXN];
inline void work(void){
	memset(dp, INF, sizeof(dp));
	dp[0] = 0;
	for(int i = 1; i <= n; ++ i){
		ll minn = min(n, i);
		for(int j = max(0, i - k); j < minn; ++ j){
				dp[i] = min(dp[i], dp[j] + max(sum(j, i), b[j]));
		}
	}
	cout << dp[n];
}

int main(){
	freopen("empire.in", "r", stdin);
	freopen("empire.out", "w", stdout);
	init();
	work();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
