#include<bits/stdc++.h>

using namespace std;
const int MAXN = 250000 + 10;
const int MAXK = 500000 + 10;
int head[MAXN], nxt[MAXK], to[MAXK], ind;
inline void add_edge(int u, int v){
	nxt[++ ind] = head[u];
	head[u] = ind;
	to[ind] = v;
}
int n, m, cnt, u, v;
bool flag;
void dfs(int node, int fa){
	if(node == v){
		flag = true;
		return;
	}
	for(int i = head[node]; i; i = nxt[i]){
		int j = to[i];
		if(j == fa) continue;
		dfs(j, node);
	}
}
inline void init(void){
	scanf("%d%d", &n, &m);
	int t, op, k;
	cnt = n;
	for(int i = 1; i <= m; ++ i){
		scanf("%d", &t);
		if(t == 0){
			++ cnt;
			scanf("%d%d", &op, &k);
			if(k == 1){
				scanf("%d", &v);
				add_edge(v, cnt); add_edge(cnt, v);
				continue;
			}
			for(int j = 1; j <= k; ++ j){
				scanf("%d", &v);
				if(op == 1)
					add_edge(v, cnt);
				else
				 	add_edge(cnt, v);
			}
		}
		if(t == 1){
			flag = false;
			scanf("%d%d", &u, &v);
			dfs(u, -1);
			if(flag == true)
				printf("1\n");
			else
				printf("0\n");
		}
	}
}

inline void work(void){
	
}

int main(){
	freopen("friendship.in", "r", stdin);
	freopen("friendship.out", "w", stdout);
	init();
	work();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
