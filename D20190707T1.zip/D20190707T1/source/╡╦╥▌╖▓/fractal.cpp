#include<bits/stdc++.h>
using namespace std;
struct fushu{
	long double xx,yy;
} z[101],cc;
fushu cheng(fushu aa,fushu bb)
{
	fushu cc;
	cc.xx=aa.xx*bb.xx-aa.yy*bb.yy;
	cc.yy=aa.xx*bb.yy+aa.yy*bb.xx;
	return cc;
}
fushu jia(fushu aa,fushu bb)
{
	fushu cc;
	cc.xx=aa.xx+bb.xx;
	cc.yy=aa.yy+bb.yy;
	return cc;
}
fushu jian(fushu aa,fushu bb)
{
	fushu cc;
	cc.xx=aa.xx-bb.xx;
	cc.yy=aa.yy-bb.yy;
	return cc;
}
bool shoulian(fushu cc)
{
	return cc.xx*cc.xx+cc.yy*cc.yy<=100;
}
char c[802][802];
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	int yc,xc;
	double sy,sx,P,Q;
	scanf("%d%d%lf%lf",&yc,&xc,&sy,&sx);
	scanf("%lf%lf",&P,&Q);
	cc.xx=P,cc.yy=Q;
	for  (int j=0;j<yc;j++)
		for  (int i=0;i<xc;i++)
			{
				z[0].xx=sy+i*0.005,z[0].yy=sx+j*0.01;
				c[j][i]='a';
				if  (!shoulian(z[0]))
					{
						c[j][i]=' ';
						continue;
					}
				for  (int k=1;k<=100;k++)
					{
						z[k]=jia(cheng(z[k-1],z[k-1]),cc);
						if  (!shoulian(z[k]))
							{
								c[j][i]=' ';
								break;
								continue;
							}
					}
			}
	char ccc=10;
	for  (int i=0;i<yc;i++)
		{
			for  (int j=0;j<xc;j++)
				putchar(c[i][j]);
			putchar(ccc);
		}
    return 0;
}

