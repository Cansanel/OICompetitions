#include<bits/stdc++.h>
using namespace std;
int a[105][105];
void read(int &a)
{
	a=0;char c=getchar();
	for  (;!isdigit(c);c=getchar());
	for  (;isdigit(c);a=a*10+c-48,c=getchar());
}
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	int N,M;
	read(N),read(M);
	for  (int i=1;i<=N;i++)
		for  (int j=1;j<=M;j++)
			read(a[i][j]);
	printf("-1 -1\n");
    return 0;
}

