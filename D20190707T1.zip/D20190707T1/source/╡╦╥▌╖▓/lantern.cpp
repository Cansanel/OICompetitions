#include<bits/stdc++.h>
using namespace std;
struct  dlc{
	int num,xx,yy;
}aa[5000004];
int num1[55],num2[10005];
int cf1[55][10005],cf2[55][10005];
int z1[55][10005],z2[55][10005];
void read(int &a)
{
	a=0;char c=getchar();
	for  (;!isdigit(c);c=getchar());
	for  (;isdigit(c);a=a*10+c-48,c=getchar());
}
bool cmp(dlc aa,dlc bb)
{
	return aa.num<bb.num;
}
int left_=1;
int cnt1=0;
int N,M;
bool check(int x)
{
	for  (;aa[left_].num<x&&left_<=cnt1;left_++)
		{
			num1[aa[left_].xx]--;
			num2[aa[left_].yy]--;
			if  (num1[aa[left_].xx]==0||num2[aa[left_].yy]==0)
				{
					//cout<<x<<' '<<"NO LAN\n";
					printf("-1\n");
					exit(0);
				}
		}
	if  (left_>cnt1)
		{
			printf("-1\n");
			exit(0);
		}
	memset(cf1,0,sizeof(cf1));
	memset(cf2,0,sizeof(cf2));
	memset(z1,0,sizeof(z1));
	memset(z2,0,sizeof(z2));
	for  (int i=left_;i<=cnt1;i++)
		{
			int xxx=aa[i].xx,yyy=aa[i].yy;
			int ll1=xxx-x+1,rr1=xxx+x;
			int ll2=yyy-x+1,rr2=yyy+x;
			if  (ll1<1)	ll1=1; if  (rr1>N)	rr1=N+1;
			if  (ll2<1)	ll2=1; if  (rr2>M)	rr2=M+1;
			//cout<<ll1<<' '<<rr1<<' '<<ll2<<' '<<rr2<<endl;
			cf1[ll1][yyy]++;cf1[rr1][yyy]--;
			cf2[xxx][ll2]++;cf2[xxx][rr2]--;
		}
	for  (int j=1;j<=M;j++)
		for  (int i=1;i<=N;i++)
			{
				z1[i][j]=z1[i-1][j]+cf1[i][j];
				if  (!z1[i][j])	return false;
			}
	
	for  (int i=1;i<=N;i++)
		for  (int j=1;j<=M;j++)
			{
				z2[i][j]=z2[i][j-1]+cf2[i][j];
				if  (!z2[i][j])	return false;
			}
	return true;
}
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	read(N),read(M);
	for  (int i=1;i<=N;i++)
		for  (int j=1;j<=M;j++)
			{
				int  zz;
				read(zz);
				if  (zz)
					{
						aa[++cnt1].num=zz;
						aa[cnt1].xx=i;
						aa[cnt1].yy=j;
						num1[i]++;
						num2[j]++;		
					}
			}
	sort(aa+1,aa+cnt1+1,cmp);
	if  (cnt1==N*M)
		{
			printf("%d\n",1);
			return 0;
		}
	int Ans=2;
	while  (!check(Ans)) Ans++;
	printf("%d\n",Ans);
    return 0;
}

