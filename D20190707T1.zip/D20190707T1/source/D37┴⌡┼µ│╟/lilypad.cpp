#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ak;
#define im INT_MAX
#define F(i,j,k) for(int i=j;i<=k;i++)
#define G(i,j,k) for(int i=j;i>=k;i--)
ak n,m,s,t,b[111][111],a[11111],dis[11111];
vector<ak>way[11111],dist[11111];
queue<ak>q;bool vis[11111];
ak pt(ak i,ak j){return (i-1)*m+j;}
int main(){
	#ifndef lpcak
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	#endif
	
	ios::sync_with_stdio(0);
	cin>>n>>m;F(i,1,n)F(j,1,m)cin>>b[i][j];
	F(i,1,n)F(j,1,m)a[pt(i,j)]=b[i][j];
	F(i,1,n)F(j,1,m){
		if(a[pt(i,j)]==2)continue;
		if(a[pt(i,j)]==3)s=pt(i,j);
		if(a[pt(i,j)]==4)t=pt(i,j);
		F(k,1,1)if((i>2)&&(j>1)){
			ak x=pt(i,j),y=pt(i-2,j-1);
			if(a[y]==2)break;way[x].push_back(y);
			if(a[y]==0)dist[x].push_back(n*m*2+1);
			else dist[x].push_back(1);
		}
		F(k,1,1)if((i>1)&&(j>2)){
			ak x=pt(i,j),y=pt(i-1,j-2);
			if(a[y]==2)break;way[x].push_back(y);
			if(a[y]==0)dist[x].push_back(n*m*2+1);
			else dist[x].push_back(1);
		}
		F(k,1,1)if((i<n)&&(j>2)){
			ak x=pt(i,j),y=pt(i+1,j-2);
			if(a[y]==2)break;way[x].push_back(y);
			if(a[y]==0)dist[x].push_back(n*m*2+1);
			else dist[x].push_back(1);
		}
		F(k,1,1)if((i<n-1)&&(j>1)){
			ak x=pt(i,j),y=pt(i+2,j-1);
			if(a[y]==2)break;way[x].push_back(y);
			if(a[y]==0)dist[x].push_back(n*m*2+1);
			else dist[x].push_back(1);
		}
		F(k,1,1)if((i<n-1)&&(j<m)){
			ak x=pt(i,j),y=pt(i+2,j+1);
			if(a[y]==2)break;way[x].push_back(y);
			if(a[y]==0)dist[x].push_back(n*m*2+1);
			else dist[x].push_back(1);
		}
		F(k,1,1)if((i<n)&&(j<m-1)){
			ak x=pt(i,j),y=pt(i+1,j+2);
			if(a[y]==2)break;way[x].push_back(y);
			if(a[y]==0)dist[x].push_back(n*m*2+1);
			else dist[x].push_back(1);
		}
		F(k,1,1)if((i>1)&&(j<m-1)){
			ak x=pt(i,j),y=pt(i-1,j+2);
			if(a[y]==2)break;way[x].push_back(y);
			if(a[y]==0)dist[x].push_back(n*m*2+1);
			else dist[x].push_back(1);
		}
		F(k,1,1)if((i>2)&&(j<m)){
			ak x=pt(i,j),y=pt(i-2,j+1);
			if(a[y]==2)break;way[x].push_back(y);
			if(a[y]==0)	dist[x].push_back(n*m*2+1);
			else dist[x].push_back(1);
		}
	}
	F(i,1,n*m)dis[i]=im;dis[s]=0;q.push(s);vis[s]=1;
	while(q.size()){
		ak u=q.front();q.pop();vis[u]=0;
		F(i,0,way[u].size()-1){
			ak v=way[u][i],w=dist[u][i];
			if(dis[v]>dis[u]+w){
				dis[v]=dis[u]+w;
				if(!vis[v])q.push(v),vis[v]=1;
			}
		}
	}
	if(dis[t]==im){cout<<"-1 -1\n";return 0;}
	cout<<dis[t]/(n*m*2)<<" "<<dis[t]%(n*m*2)<<"\n";
	return 0;
}
/*
4 8
0 0 0 1 2 0 2 0
0 0 0 2 2 2 0 2
0 0 0 0 2 4 0 0
3 0 0 2 0 0 1 0
*/
