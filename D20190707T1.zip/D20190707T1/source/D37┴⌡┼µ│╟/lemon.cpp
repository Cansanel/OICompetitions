#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ak;
#define F(i,j,k) for(int i=j;i<=k;i++)
#define G(i,j,k) for(int i=j;i>=k;i--)
#define im INT_MAX
bool cxk(int n){
	int nn=n;
	while(nn>1){
		if(nn&1)return 0;nn>>=1;
	}
	return 1;
}
int main(){
	#ifndef lpcak
	freopen("lemon.in","r",stdin);
	freopen("lemon.out","w",stdout);
	#endif
	int t,n;
	ios::sync_with_stdio(0);
	cin>>t;
	F(i,1,t){
		cin>>n;
		if(cxk(n))cout<<"Yes\n";
			else cout<<"No\n";
	}
	return 0;
}
