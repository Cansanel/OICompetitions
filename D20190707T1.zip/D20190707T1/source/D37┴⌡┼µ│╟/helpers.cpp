#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ak;
#define F(i,j,k) for(int i=j;i<=k;i++)
#define G(i,j,k) for(int i=j;i>=k;i--)
#define im INT_MAX
#define mo (ak)998244353
ak a[11111111];
ak qp(ak n,ak p){
	if(!p)return 1;if(p==1)return n;
	ak mid=qp(n,p>>1)%mo;
	if(p&1)return mid*mid%mo*n%mo;
	return mid*mid%mo;
}
int main(){
	//#ifndef lpcak
	freopen("helpers6.in","r",stdin);
	freopen("helpers.out","w",stdout);
	//#endif
	ak n,sum=0;
	ios::sync_with_stdio(0);
	cin>>n;
	F(i,1,n)cin>>a[i];
	F(i,1,n)sum+=a[i];
	ak ans=qp(sum,mo-2);
	F(i,1,n)cout<<a[i]*ans%mo<<" ";
	cout<<"\n";
	return 0;
}
