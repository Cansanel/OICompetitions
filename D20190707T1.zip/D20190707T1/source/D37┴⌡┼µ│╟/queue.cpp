#pragma GCC optimize(3)
#include<bits/stdc++.h>
using namespace std;
typedef long long ak;
#define im INT_MAX
#define F(i,j,k) for(int i=j;i<=k;i++)
#define G(i,j,k) for(int i=j;i>=k;i--)
struct duck{int l;int r;}a[555555];
bool lpc(duck i,duck j){
	return i.l-i.r>j.l-j.r;
}
int main(){
	#ifndef lpcak
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	#endif
	int n,sum=0;
	ios::sync_with_stdio(0);
	cin>>n;
	F(i,1,n)cin>>a[i].l>>a[i].r;
	sort(a+1,a+n+1,lpc);
	F(i,1,n)
		sum+=a[i].l*(i-1)+a[i].r*(n-i);
	cout<<sum<<"\n";
	return 0;
}
