#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,startx,starty,endx,endy;
inline int read() {
	int x=0,neg=1;char ch=getchar();
	while(!isdigit(ch)) {
		if (ch=='-') neg=-1;
		ch=getchar();
	}
	while(isdigit(ch)) {
		x=x*10+(ch-'0');
		ch=getchar(); 
	}
	return x*neg;
}
bool vis[105][105];
int mp[105][105];
int fx[8]={2,2,-2,-2,1,1,-1,-1},
    fy[8]={1,-1,1,-1,2,-2,2,-2};
struct node{
	int x,y,step,lily;
};
struct yyy{
	int heye,dis;
}now[105][105];
queue<node> q;
inline void bfs() {
	node p=(node){startx,starty,0,0};
	q.push(p);
	now[startx][starty]=(yyy){0,0};
	while(!q.empty()) {
//		cout<<11111111<<'\n';
		int x=q.front().x,
			y=q.front().y,
			st=q.front().step+1,
			li=q.front().lily;
			q.pop();
//		cout<<x<<' '<<y<<' '<<st-1<<' '<<li<<'\n';
		if (x==endx&&y==endy) continue;
		if (mp[x][y]!=2) {
			for (int i=0;i<8;++i) {
				int flag=0;
				int xx=x+fx[i],yy=y+fy[i];
				if (mp[xx][yy]!=1) flag=1;
				if (xx>=1&&xx<=n&&yy>=1&&yy<=m) {
					if (li<now[xx][yy].heye||li==now[xx][yy].heye&&st<now[xx][yy].dis) {
						now[xx][yy].heye=li,now[xx][yy].dis=st;
						node p=(node){xx,yy,st,li+flag};
						q.push(p);
					}
				}
			}
		}
	}
}
signed main() {
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	
	for (int i=1;i<=100;++i) {
		for (int j=1;j<=100;++j) {
			now[i][j].heye=INT_MAX;
			now[i][j].dis=INT_MAX;
		}
	}
	n=read(),m=read();
	for (int i(1);i<=n;++i) {
		for (int j(1);j<=m;++j) {
			mp[i][j]=read();
			if (mp[i][j]==3) {
				startx=i;
				starty=j;
			}
			else if (mp[i][j]==4) {
				endx=i;
				endy=j;
			}
		}
	}
	bfs();
	if (now[endx][endy].heye!=INT_MAX) printf("%lld %lld\n",now[endx][endy].heye,now[endx][endy].dis);
	else puts("-1 -1");
//	system("pause");
	return 0; 
}
