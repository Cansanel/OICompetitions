#include<bits/stdc++.h>
using namespace std;
#define int long long
int maxv,n,m,cf1[505][10005],cf2[505][10005],num[505][10005];
inline int read() {
	int x=0,neg=1;char ch=getchar();
	while(!isdigit(ch)) {
		if (ch=='-') neg=-1;
		ch=getchar();
	}
	while(isdigit(ch)) {
		x=x*10+(ch-'0');
		ch=getchar(); 
	}
	return  x*neg;
}
inline void cf(int i,int j,int x) {
	++cf1[max((long long)1,(long long)i-x+1)][j];
	--cf1[min((long long)n+1,(long long)i+x)][j];
	++cf2[i][max((long long)1,(long long)j-x+1)];
	--cf2[i][min((long long)m+1,(long long)j+x)];
}
inline bool solve(int value) {
	for (int i=1;i<=n;++i) {
		for (int j=1;j<=m;++j) {
			cf1[i][j]=cf2[i][j]=0;
		}
	}
	for (int i=1;i<=n;++i) {
		for (int j=1;j<=m;++j) {
			if (num[i][j]>=value) {
				cf(i,j,value);
			}
		} 
	}
	for (int i=1;i<=n;++i) {
		for (int j=1;j<=m;++j) {
			cf1[i][j]+=cf1[i-1][j];
			cf2[i][j]+=cf2[i][j-1];
			if (cf1[i][j]==0||cf2[i][j]==0) {
				return false;
			}
		}
	}
	return true;
} 
signed main() {
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	
	n=read(),m=read();
	for (int i(1);i<=n;++i) {
		for (int j(1);j<=m;++j) {
			int x=read();
			num[i][j]=x;
			maxv=max(maxv,x);
		}
	} 
	maxv=min(maxv,max(n,m));
//	cout<<maxv<<'\n'; 
	for (int i=1;i<=maxv;++i) {
		if (solve(i)) {
			printf("%lld\n",i);
			return 0;
		}
	}
	puts("-1");
	return 0;
}
