#include<bits/stdc++.h>
using namespace std;
double yc,xc,sy,sx,p,q;
struct node{
	double x,y;
	node operator + (const node &a) const {
		node b=(node){x+a.x,y+a.y};
		return b;
	}  
	node operator - (const node &a) const {
		node b=(node){x-a.x,y-a.y};
		return b;
	}  
	node operator * (const node &a) const {
		node b=(node){x*a.x-y*a.y,x*a.y+y*a.x};
		return b;
	}
	double now() {
		return sqrt(x*x+y*y);
	}
}z[105],c;
inline bool check (double a,double b) {
	z[0]=(node){a,b};
	for (int i=1;i<=100;++i) {
		z[i]=(z[i-1]*z[i-1])+c;
		if (z[i].now()>=10) return false;
	}
	return true;
}
int main() {
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	
	cin>>yc>>xc>>sy>>sx;
	cin>>p>>q;
	c=(node){p,q};
	for (int j=0;j<yc;++j) {
		for (int i=0;i<xc;++i) {
			double x=sy+i*0.005,y=sx+j*0.01;
			printf("%c",check(x,y)==true?'a':' ');
		}
		puts("");
	}
	return 0;
}
