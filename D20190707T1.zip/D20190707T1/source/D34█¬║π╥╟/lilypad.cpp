#include<bits/stdc++.h>
#include<cctype>
using namespace std;
inline int readd(){
	int x=0,w=1;
	char c=getchar();
	while(!isdigit(c)){
		if(c=='-'){
			w=-1;
		}
		c=getchar();
	}
	while(isdigit(c)){
		x=x*10+c-'0';
		c=getchar();
	}
	return x*w;
}
const int dx[9]={1,2,1,2,-1,-2,-1,-2};
const int dy[9]={2,1,-2,-1,2,1,-2,-1};
int a[1006][1005],h[105][108],asstep,ass,zhongx,zhongy,ansstep,tx,ty,qix,qiy,n,m,ff,rr,i,j,k,l,ans,s,d,r,midd,f[102][102][3002],ste[105][105],x[100005],y[1000005],t;
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	n=readd();
	m=readd();
	for(i=1;i<=n;i++){
		for(j=1;j<=m;j++){
			a[i][j]=readd();
			if(a[i][j]==3){
				qix=i;
				qiy=j;
			}
			if(a[i][j]==4){
				zhongx=i;
				zhongy=j;
			}
		}
	}
	ff=1;
	rr=1;
	x[1]=qix;
	y[1]=qiy;
	memset(ste,0,sizeof(ste));
	memset(h,0,sizeof(h));
	ansstep=135443543;
	ans=534563554;
	h[qix][qiy]=-1;
	while(ff<=rr){
		int rrr=rr;
//		cout<<ff<<" "<<rr<<endl;
		for(i=ff;i<=rrr;i++){
			//cout<<x[i]<<" "<<y[i]<<" "<<ste[x[i]][y[i]]<<" "<<f[x[i]][y[i]][ste[x[i]][y[i]]]<<endl;
			for(j=0;j<=7;j++){
				tx=x[i]+dx[j];
				ty=y[i]+dy[j];
				if(tx>=1&&ty>=1&&tx<=n&&ty<=m){
					if(h[tx][ty]==0){
						if(a[tx][ty]==1){
							f[tx][ty][ste[x[i]][y[i]]+1]=f[x[i]][y[i]][ste[x[i]][y[i]]];
							rr++;
							x[rr]=tx;
							y[rr]=ty;
							ste[x[rr]][y[rr]]=ste[x[i]][y[i]]+1;
							h[tx][ty]=1;
						}
						else						
						if(a[tx][ty]==0){
							f[tx][ty][ste[x[i]][y[i]]+1]=f[x[i]][y[i]][ste[x[i]][y[i]]]+1;
							rr++;
							x[rr]=tx;
							y[rr]=ty;
							ste[x[rr]][y[rr]]=ste[x[i]][y[i]]+1;
							h[tx][ty]=1;
						}
						else
						if(a[tx][ty]==2){
							continue;
						}
						else
						if(a[tx][ty]==4){
							h[tx][ty]=-2;
							if(ansstep>f[x[i]][y[i]][ste[x[i]][y[i]]]){
								ansstep=f[x[i]][y[i]][ste[x[i]][y[i]]];
								ans=ste[x[i]][y[i]]+1;
							}
							else
							if(ansstep==f[x[i]][y[i]][ste[x[i]][y[i]]]){
								ans=min(ans,ste[x[i]][y[i]]+1);
							}
							else{
								continue;
							}
							//cout<<ansstep<<" "<<ans<<endl;
						}
					}
					else
					if(h[tx][ty]==-1){
						continue;
					}
					else
					if(h[tx][ty]==-2){
						if(ansstep>f[x[i]][y[i]][ste[x[i]][y[i]]]){
							ansstep=f[x[i]][y[i]][ste[x[i]][y[i]]];
							ans=ste[x[i]][y[i]]+1;
							}
						else
						if(ansstep==f[x[i]][y[i]][ste[x[i]][y[i]]]){
							ans=min(ans,ste[x[i]][y[i]]+1);
						}
						else{
							continue;
						}
						//cout<<ansstep<<" "<<ans<<endl;
					}
					else{
						if(a[tx][ty]==0){
							if(f[x[i]][y[i]][ste[x[i]][y[i]]]+1<f[tx][ty][ste[x[i]][y[i]]+1]){
								rr++;
								x[rr]=tx;
								y[rr]=ty;
								ste[x[rr]][y[rr]]=ste[x[i]][y[i]]+1;
							}
							f[tx][ty][ste[x[i]][y[i]]+1]=min(f[x[i]][y[i]][ste[x[i]][y[i]]]+1,f[tx][ty][ste[x[i]][y[i]]+1]);
						}
						if(a[tx][ty]==1){
							if(f[x[i]][y[i]][ste[x[i]][y[i]]]<f[tx][ty][ste[x[i]][y[i]]+1]){
								rr++;
								x[rr]=tx;
								y[rr]=ty;
								ste[x[rr]][y[rr]]=ste[x[i]][y[i]]+1;
							}
							f[tx][ty][ste[x[i]][y[i]]+1]=min(f[tx][ty][ste[x[i]][y[i]]+1],f[x[i]][y[i]][ste[x[i]][y[i]]]);
						}
						if(a[tx][ty]==2){
							continue;
						}
					}
				}
			}
		}
		ff=rrr+1;
	}
	cout<<ansstep<<" "<<ans<<endl;
	return 0;
}

