#include<bits/stdc++.h>
#include<cctype>
using namespace std;
inline int readd(){
	int x=0,w=1;
	char c=getchar();
	while(!isdigit(c)){
		if(c=='-'){
			w=-1;
		}
		c=getchar();
	}
	while(isdigit(c)){
		x=x*10+c-'0';
		c=getchar();
	}
	return x*w;
}
double sy,sx,p,q;
int n,m,i,j,k,l,s,d,f,r,yc,xc;
double z1[10005],z2[10005];
char c[1005][1050];
double moc(double a,double b){
	return sqrt(a*a+b*b);
}
bool check(double x,double y){
	z1[0]=x;
	z2[0]=y;
	double mochang=moc(x,y);
	int dd=0;
	if(mochang>=10){
		dd=1;
	}
	if(dd==1){
		return false;
	}
	for(int i=1;i<=100;i++){
		double aa=z1[i-1]*z1[i-1]-z2[i-1]*z2[i-1];
		double bb=z1[i-1]*z2[i-1]*2;
		aa=aa+p;
		bb=bb+q;
		mochang=moc(aa,bb);
		if(mochang>=10){
			dd=1;
			break;
		}
		z1[i]=aa;
		z2[i]=bb;
	}
	if(dd==1){
		return false;
	}
	else{
		return true;
	}
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	yc=readd();xc=readd();
	cin>>sy>>sx;
	cin>>p>>q;
	for(j=0;j<yc;j++){
		for(i=0;i<xc;i++){
			if(check(sy+i*0.005,sx+j*0.01)){
				c[j][i]='a';
			}
			else{
				c[j][i]=' ';
			}
		}
	}
	for(i=0;i<yc;i++){
		for(j=0;j<xc;j++){
			cout<<c[i][j];
		}
		cout<<endl;
	}
	return 0;
}

