/*
  	�����е�����ѧ ��˧
*/

#include <bits/stdc++.h>
using namespace std;

int yc, xc;

double sy, sx, p, q;

inline long long read()
{
	int a = 0;
	char c = getchar();
	int	f = 1;
	while (!isdigit(c)) {if (c == '-') f = -1; c = getchar();}
	while (isdigit(c)) {a = a * 10 + c - '0'; c = getchar();}
	return a * f;
}

inline long long write(long long x)
{
	if (x < 0)
	{
		putchar('-');
		x = -x;
	}
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}

struct node
{
	int x, y;
};

node add(node f, node g)
{
	node e;
	e.x = f.x + g.x;
	e.y = f.y + g.y;
	return (node) e;
}

node multi(node f, node g)
{
	node e;
	e.x = f.x * g.x - f.y * g.y;
	e.y = f.y * g.x + f.x * g.y;
	return (node) e; 
}

double mod(node e)
{
	return sqrt(e.x * e.x + e.y * e.y);
}

node z[101];

char a[801][801];

bool pd(int m, int n)
{
	node c;
	c.x = p;
	c.y = q;
	if (mod(c) >= 10) return 0;
	z[0].x = m;
	z[0].y = n;
	for (int i = 1; i <= 100; i++)
	{
		z[i] = add(multi(z[i - 1], z[i - 1]), c);
		if (mod(z[i]) >= 10) return 0;	
	}
	return 1;
}

int main()
{
	freopen("fractal.in", "r", stdin);
	freopen("fractal.out", "w", stdout); 
	yc = read();
	xc = read();
	scanf("%lf%lf%lf%lf", &sy, &sx, &p, &q);
	for (int j = 1; j <= yc; j++)
	{
		for (int i = 1; i <= xc; i++)
		{
			int m = sy + i * 0.005, n = sx + j * 0.01;
			if (pd(m, n)) a[j][i] = 'a';
			else a[j][i] = ' ';
		}
	}
	for (int j = 1; j <= yc; j++)
	{
		for (int i = 1; i <= xc; i++)
		{
			putchar(a[j][i]);
		}
		puts("");
	}
	return 0;
}
