/*
  	�����е�����ѧ ��˧
*/

#include <bits/stdc++.h>
using namespace std;

inline long long read()
{
	int a = 0;
	char c = getchar();
	int	f = 1;
	while (!isdigit(c)) {if (c == '-') f = -1; c = getchar();}
	while (isdigit(c)) {a = a * 10 + c - '0'; c = getchar();}
	return a * f;
}

inline long long write(long long x)
{
	if (x < 0)
	{
		putchar('-');
		x = -x;
	}
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}

bool vis[505][10005];

int b[505][10005], n, m;

int a[505][10005];

bool check(int mid)
{
	memset(vis, 0, sizeof(vis));
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
		{
			b[i][j] = a[i][j];
			if (b[i][j] < mid) b[i][j] = 0;
			else b[i][j] = mid;
		}
	}
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
		{
			for (int k = 0; k < b[i][j]; k++)
			{
				vis[i + k][j + k] = 1;
				if (i > k && j > k) vis[i - k][j - k] = 1;
				if (i > k) vis[i - k][j + k] = 1;
				if (j > k) vis[i + k][j - k] = 1; 
			}
		}
	} 
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
		{
			if (!vis[i][j]) return 0; 
		}
	}
	return 1;
}

int main()
{
	freopen("lantern.in", "r", stdin);
	freopen("lantern.out", "w", stdout);
	n = read(), m = read();
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
		{
			a[i][j] = read();
		}
	}
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
		{
			for (int k = 0; k < a[i][j]; k++)
			{
				vis[i + k][j + k] = 1;
				if (i > k && j > k) vis[i - k][j - k] = 1;
				if (i > k) vis[i - k][j + k] = 1;
				if (j > k) vis[i + k][j - k] = 1; 
			}
		}
	} 
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
		{
			if (!vis[i][j])
			{
				write(-1);
				putchar('\n');
				return 0;
			} 
		}
	}
	int l = 0, r = m * n;
	int ans = 0;
	while (l <= r)
	{
		int mid = (l + r) >> 1;
		if (check(mid)) ans = mid, r = mid - 1;
		else l = mid + 1;
	}
	if (ans == 0) return printf("%d\n", -1), 0;
	write(ans);
	putchar('\n');
	return 0;
}
