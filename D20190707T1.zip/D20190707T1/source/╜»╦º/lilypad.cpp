/*
  	�����е�����ѧ ��˧
*/

#include <bits/stdc++.h>
using namespace std;

inline long long read()
{
	int a = 0;
	char c = getchar();
	int	f = 1;
	while (!isdigit(c)) {if (c == '-') f = -1; c = getchar();}
	while (isdigit(c)) {a = a * 10 + c - '0'; c = getchar();}
	return a * f;
}

inline long long write(long long x)
{
	if (x < 0)
	{
		putchar('-');
		x = -x;
	}
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}

int dx[9] = {0, 1, 1, 2, 2, -2, -2, -1, -1},
	dy[9] = {0, 2, -1, 1, -1, 1, -1, 2, -2};
	
int n, m, bx, by, ex, ey;	

struct node
{
	int x, y, step, hy;
};

queue <node> q;

bool vis[101][101][2001];

int a[105][105];

int ans = 0, ans2 = INT_MAX;

void bfs()
{
	node s;
	s.x = bx;
	s.y = by;
	s.hy = 0;
	s.step = 0;
	q.push(s);
	vis[bx][by][0] = 1;
	while (!q.empty())
	{
		node u = q.front();
		q.pop();
		for (int i = 1; i <= 8; i++)
		{
			int tx = dx[i] + u.x;
			int ty = dy[i] + u.y;
			if (tx >= 1 && tx <= n && ty >= 1 && ty <= m && !vis[tx][ty][u.hy] && a[tx][ty] != 0 && a[tx][ty] != 2)
			{
				node ux;
				ux.x = tx;
				ux.y = ty;
				ux.hy = u.hy;
				ux.step = u.step + 1;
				q.push(ux);
				vis[tx][ty][ux.hy] = 1;
				if (tx == ex && ty == ey)
				{
					if (ux.hy < ans2)
					{
						ans = ux.step;
						ans2 = ux.hy;
					}
				}
			}
			else
			{
				if (tx >= 1 && tx <= n && ty >= 1 && ty <= m && !vis[tx][ty][u.hy + 1] && a[tx][ty] == 0)
				{
					node xx;
					xx.x = tx;
					xx.y = ty;
					xx.step = u.step + 1;
					xx.hy = u.hy + 1;
					q.push(xx);
					vis[tx][ty][xx.hy] = 1;
				}
			}
		}
	}
}

int main()
{
	freopen("lilypad.in", "r", stdin);
	freopen("lilypad.out", "w", stdout);
	n = read(), m = read();
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
		{
			a[i][j] = read();
			if (a[i][j] == 3) bx = i, by = j;
			if (a[i][j] == 4) ex = i, ey = j; 
		}
	}
	bfs();
	if (ans == 0) cout << "-1 -1" << endl;
	else
	{
		write(ans2);
		putchar(' ');
		write(ans);
		putchar('\n');
	} 
	return 0;
}
