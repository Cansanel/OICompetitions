#include <bits/stdc++.h>
using namespace std;
#define maxn 105
#define maxm 105
#define inf 0x3f3f3f3f
int n,m;
struct node{
	int x,y,hy,step;
	bool operator <(node b)const{
		return hy==b.hy?step>b.step:hy>b.hy;
	}
};
bool cmp(node c,node d){
	return c.hy==d.hy?c.step<d.step:c.hy<d.hy;
}
int a[maxn][maxn],sx,sy,ex,ey;
int dx[]={-1,-2,-2,-1,1,2,2,1};
int dy[]={-2,-1,1,2,-2,-1,1,2};
template <typename Tp>
void read(Tp &x){x=0;int f=1;char c=getchar();
	while((c>'9'||c<'0')){if(c=='-'){f=-1;}c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+(c&15);c=getchar();}x*=f;
}
node dis[maxn][maxn];
priority_queue<node>q;
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	read(n);read(m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			read(a[i][j]);
			if(a[i][j]==3)sx=i,sy=j,a[i][j]=1;
			if(a[i][j]==4)ex=i,ey=j,a[i][j]=1;
			dis[i][j]=(node){i,j,inf,inf};
		}
	}
	node cur,ne;
	dis[sx][sy].hy=dis[sx][sy].step=0;
	q.push(dis[sx][sy]);
	while(!q.empty()){
		cur=q.top();q.pop();
		if(cmp(dis[cur.x][cur.y],cur))continue;
		for(int i=0;i<8;i++){
			ne.x=cur.x+dx[i];
			ne.y=cur.y+dy[i];
			if(ne.x>n||ne.x<1||ne.y>m||ne.y<1||a[ne.x][ne.y]==2)continue;
			if(a[ne.x][ne.y]==1)ne.hy=cur.hy;
			if(a[ne.x][ne.y]==0)ne.hy=cur.hy+1;
			ne.step=cur.step+1;
			if(cmp(ne,dis[ne.x][ne.y])){
				dis[ne.x][ne.y]=ne;
				q.push(dis[ne.x][ne.y]);
			}
		}
	}
	if(dis[ex][ey].hy==inf)puts("-1 -1");
	else printf("%d %d\n",dis[ex][ey].hy,dis[ex][ey].step);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
