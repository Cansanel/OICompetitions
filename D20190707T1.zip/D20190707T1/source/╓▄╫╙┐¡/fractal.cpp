#include <bits/stdc++.h>
using namespace std;
#define maxn 1005
#define maxm 1005
int yc,xc;
double Sy,Sx,P,Q;
template <typename Tp>
void read(Tp &x){x=0;int f=1;char c=getchar();
	while((c>'9'||c<'0')){if(c=='-'){f=-1;}c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+(c&15);c=getchar();}x*=f;
}
struct fu{
	double x,y;
};
fu add(fu a,fu b){
	fu c;
	c.x=a.x+b.x;
	c.y=a.y+b.y;
	return c;
}
fu dec(fu a,fu b){
	fu c;
	c.x=a.x-b.x;
	c.y=a.y-b.y;
	return c;
}
fu mul(fu a,fu b){
	fu c;
	c.x=a.x*b.x-a.y*b.y;
	c.y=a.x*b.y+a.y*b.x;
	return c;
}
double mo(fu a){
	return sqrt(a.x*a.x+a.y*a.y);
}
fu z[101],C;
int check(double x,double y){
	z[0]=(fu){x,y};
	C=(fu){P,Q};
	if(mo(z[0])>=10)return 0;
	for(int i=1;i<=100;i++){
		z[i]=add(mul(z[i-1],z[i-1]),C);
		if(mo(z[i])>=10)return 0;
	}
	return 1;
}
char c[maxn][maxn];
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	read(yc);read(xc);
	scanf("%lf%lf%lf%lf",&Sy,&Sx,&P,&Q);
	for(int j=0;j<yc;j++){
		for(int i=0;i<xc;i++){
			if(check(Sy+i*0.005,Sx+j*0.01))c[j][i]='a';
			else c[j][i]=' ';
		}
	}
	for(int i=0;i<yc;i++){
		for(int j=0;j<xc;j++){
			putchar(c[i][j]);
		}
		puts("");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

