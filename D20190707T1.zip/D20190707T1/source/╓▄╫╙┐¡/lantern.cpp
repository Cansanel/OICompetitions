#include <bits/stdc++.h>
using namespace std;
#define maxn 505
#define maxm 10005
int n,m;
template <typename Tp>
void read(Tp &x){x=0;int f=1;char c=getchar();
	while((c>'9'||c<'0')){if(c=='-'){f=-1;}c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+(c&15);c=getchar();}x*=f;
}
struct node{
	int x,y,R;
	bool operator <(node b)const{
		return R<b.R;
	}
}d[maxn*maxm];
int a[maxn][maxm],b[maxn][maxm][2],tot;
int check(int g){
	memset(b,0,sizeof(b));
	for(int i=1;i<=tot;i++){
		int x=d[i].x,y=d[i].y,r=d[i].R;
		if(r<g)continue;
		else r=g;
		b[max(x-r+1,1)][y][0]++;
		b[min(x+r-1+1,n+1)][y][0]--;
		b[x][max(y-r+1,1)][1]++;
		b[x][min(y+r-1+1,m+1)][1]--;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			b[i][j][1]+=b[i][j-1][1];
		}
	}
	for(int j=1;j<=m;j++){
		for(int i=1;i<=n;i++){
			b[i][j][0]+=b[i-1][j][0];
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(!(b[i][j][0]&&b[i][j][1]))return 0;
		}
	}
	return 1;
}
double st;
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	st=clock();
	int l=1,r=0;
	read(n);read(m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			read(a[i][j]);
			r=max(r,a[i][j]);
			if(a[i][j])d[++tot]=(node){i,j,a[i][j]};
		}
	}
	r=min(r,max(n,m));
	sort(d+1,d+tot+1);
	for(int i=l;i<=r;i++){
		if(check(i)){
			printf("%d\n",i);
			fclose(stdin);
			fclose(stdout);
			return 0;
		}
	}
	puts("-1");
	fclose(stdin);
	fclose(stdout);
	return 0;
}

