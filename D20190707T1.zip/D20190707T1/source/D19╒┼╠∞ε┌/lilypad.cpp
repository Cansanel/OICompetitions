#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int ff[8][2]={{-1,-2},{-2,-1},{-2,1},{-1,2},{1,2},{2,1},{2,-1},{1,-2}};
int n,i,j,m,w[10008][2],ans[108][108][2],x2,y2,a[108][108],l,r;
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++)
	  for(j=1;j<=m;j++)
	  {
	    scanf("%d",&a[i][j]);
	    if(a[i][j]==3)w[1][0]=i,w[1][1]=j;
	    if(a[i][j]==4)x2=i,y2=j,a[i][j]=1;
	  }
	l=0,r=1;
	memset(ans,122,sizeof(ans));
	ans[w[1][0]][w[1][1]][0]=0;ans[w[1][0]][w[1][1]][1]=0;
	while(l<r)
	{
		l++;
	    for(i=l;(ans[w[i][0]][w[i][1]][0]==ans[w[l][0]][w[l][1]][0])&&(i<=r);i++)
	      for(j=0;j<8;j++)
		  {
			  int x1=w[i][0]+ff[j][0],y1=w[i][1]+ff[j][1];
			  if((x1<1)||(x1>n)||(y1<1)||(y1>m))continue;
			  if(a[x1][y1]!=1)continue;
			  int a1=ans[w[i][0]][w[i][1]][0],a2=ans[w[i][0]][w[i][1]][1];
			  if(ans[x1][y1][0]>a1)ans[x1][y1][0]=a1,ans[x1][y1][1]=a2+1,w[++r][0]=x1,w[r][1]=y1;
			  else if((ans[x1][y1][0]==a1)&&(ans[x1][y1][1]>a2+1))ans[x1][y1][1]=a2+1,w[++r][0]=x1,w[r][1]=y1;  
		  }
		int r1=r;
		for(i=l;i<=r1;i++)
		  for(j=0;j<8;j++)
		  {
			int x1=w[i][0]+ff[j][0],y1=w[i][1]+ff[j][1];
			if((x1<1)||(x1>n)||(y1<1)||(y1>m))continue;
			if(a[x1][y1]!=0)continue;
			int a1=ans[w[i][0]][w[i][1]][0],a2=ans[w[i][0]][w[i][1]][1];
			if(ans[x1][y1][0]>a1+1)ans[x1][y1][0]=a1+1,ans[x1][y1][1]=a2+1,w[++r][0]=x1,w[r][1]=y1;
			else if((ans[x1][y1][0]==a1+1)&&(ans[x1][y1][1]>a2+1))ans[x1][y1][1]=a2+1,w[++r][0]=x1,w[r][1]=y1;  
		  }
		if(ans[x2][y2][0]<1e9)break;
		l=r1+1;
	}
	/*for(i=1;i<=n;i++)
	{
		for(j=1;j<=m;j++)
		  printf("%d,%d  ",ans[i][j][0],ans[i][j][1]);
		printf("\n");
	}*/
	if(ans[x2][y2][0]<1e9)printf("%d %d\n",ans[x2][y2][0],ans[x2][y2][1]);
	else puts("-1 -1");
	return 0;
}
/*
4 8
0 0 0 1 0 0 0 0
0 0 0 0 0 2 0 1
0 0 0 0 0 4 0 0
3 0 0 0 0 0 1 0

*/
