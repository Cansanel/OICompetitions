#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
struct arr{
	double x,y;
}z[102],c;
arr operator +(arr a,arr b){return (arr){a.x+b.x,a.y+b.y};}
arr operator -(arr a,arr b){return (arr){a.x-b.x,a.y-b.y};}
arr operator *(arr a,arr b){return (arr){a.x*b.x-a.y*b.y,a.x*b.y+a.y*b.x};}
bool sl(double x,double y)
{
	z[0]=(arr){x,y};
	for(int i=1;i<=100;i++)
	{
		z[i]=(z[i-1]*z[i-1])+c;
		if(z[i].x*z[i].x+z[i].y*z[i].y>=100)return false;
	}
	return true;
}
int yc,xc,i,j;
double Sx,Sy;
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d %d %lf %lf",&yc,&xc,&Sy,&Sx);
	scanf("%lf %lf",&c.x,&c.y);
	for(j=0;j<yc;j++)
	{
		for(i=0;i<xc;i++)
		{
			if(sl(Sy+i*0.005,Sx+j*0.01))putchar('a');
			else putchar(' ');
		}
		printf("\n");
	}
	return 0;
}
