#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
void read(int &x)
{
	char ch=getchar();
	for(;(ch<'0')||(ch>'9');ch=getchar());
	for(;(ch>='0')&&(ch<='9');ch=getchar())
	  x=x*10+ch-'0';
}
bool v[508][10008];
int a[508][10008];
int n,m,i,j,tot,ma,pp;
struct arr{
	int l,r,d; 
}h[508][10008],l[10008][508];
struct arr1{
	int x,y,d;
}q[5000008];
bool cmp(arr1 a,arr1 b)
{
	return a.d<b.d;
}
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++)
	  for(j=1;j<=m;j++)
	  {
	    read(a[i][j]);
	    q[++tot].d=a[i][j];
		q[tot].x=i;q[tot].y=j;
	  }
	for(i=1;i<=n;i++)
	  for(j=1;j<=m;j++)
	    h[i][j].l=j-1,h[i][j].r=j+1,
		l[j][i].l=i-1,l[j][i].r=i+1;
	ma=0;
	sort(q+1,q+1+tot,cmp);
	bool t=true;i=1;
	for(pp=1;pp<=m+3;pp++)
	{
		for(;q[i].d==pp-1;i++)
		{
			int x1=q[i].x,y1=q[i].y;
			h[x1][h[x1][y1].l].r=h[x1][y1].r;
			h[x1][h[x1][y1].r].l=h[x1][y1].l;
			if(h[x1][y1].l==0)ma=max(ma,h[x1][y1].r);
			else if(h[x1][y1].r==m+1)ma=max(ma,m-h[x1][y1].l+1);
			else ma=max(ma,(h[x1][y1].r-h[x1][y1].l+1+1)/2);
			if(h[x1][0].r==m+1)t=false;
			l[y1][l[y1][x1].l].r=l[y1][x1].r;
			l[y1][l[y1][x1].r].l=l[y1][x1].l;
			if(l[y1][x1].l==0)ma=max(ma,l[y1][x1].r);
			else if(l[y1][x1].r==n+1)ma=max(ma,n-l[y1][x1].l+1);
			else ma=max(ma,(l[y1][x1].r-l[y1][x1].l+1+1)/2);
			if(l[y1][0].r==n+1)t=false;
		}
		if(!t||ma<=pp)break;
	}
	if(t)printf("%d\n",pp);
	else printf("-1\n");
	return 0;
}
