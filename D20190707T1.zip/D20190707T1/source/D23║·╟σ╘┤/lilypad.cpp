#include<bits/stdc++.h>
#define re register
using namespace std;
template <typename T>void read(T &x)
{
	x=0;char str=getchar();
	while(!isdigit(str))str=getchar();
	while(isdigit(str)){x=(x<<3)+(x<<1)+str-48;str=getchar();}
}
int buf[100],top;
template <typename T>void print(T x)
{
	if (!x)putchar('0');
	while(x)buf[++top]=x%10,x/=10;
	while(top)putchar(buf[top--]+48);
	putchar(' ');
}
const int maxn=110;
const int z1[8]={-2,-1,1,2,2,1,-1,-2};
const int z2[8]={1,2,2,1,-1,-2,-2,-1};
int n,m,sx,sy,fx,fy,a[maxn][maxn];
struct cdt
{
	int x,y,t,ts;
}ns,k;
bool p[maxn][maxn];
int s[maxn][maxn],ls[maxn][maxn];
int ans1,ans2;
deque<cdt>dq;
queue<cdt>q;
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	read(n);read(m);
	for (re int i=1;i<=n;i++)
	{
		for (re int j=1;j<=m;j++)
		{
			read(a[i][j]);
			if (a[i][j]==3)sx=i,sy=j;
			if (a[i][j]==4)fx=i,fy=j;
		}
	}
	memset(s,0x7f,sizeof(s));
	ns.x=sx;
	ns.y=sy;
	ns.t=0;
	dq.push_front(ns);
	while(!dq.empty())
	{
		k=dq.front();dq.pop_front();
		p[k.x][k.y]=1;s[k.x][k.y]=k.t;
		for (re int i=0;i<8;i++)
		{
			ns.x=k.x+z1[i];
			ns.y=k.y+z2[i];
			if (ns.x<1||ns.y<1||ns.x>n||ns.y>m)continue;
			if (p[ns.x][ns.y])continue;
			if (a[ns.x][ns.y]==2)continue;
			if (a[ns.x][ns.y]==0)
			{
				ns.t=k.t+1;
				dq.push_back(ns);
			}
			else
			{
				ns.t=k.t;
				dq.push_front(ns);
			}
		}
	}
	if (s[fx][fy]==s[0][0])
	{
		printf("-1 -1\n");
		return 0;
	}
	memset(ls,0x7f,sizeof(ls));
	ns.x=sx;
	ns.y=sy;
	ns.t=0;
	ns.ts=0;
	ls[sx][sy]=0;
	q.push(ns);
	while(!q.empty())
	{
		k=q.front();q.pop();
		for (re int i=0;i<8;i++)
		{
			ns.x=k.x+z1[i];
			ns.y=k.y+z2[i];
			if (ns.x<1||ns.y<1||ns.x>n||ns.y>m)continue;
			if (a[ns.x][ns.y]==2)continue;
			ns.t=k.t+(a[ns.x][ns.y]?0:1);
			if (ns.t>s[ns.x][ns.y])continue;
			ns.ts=k.ts+1;
			if (ns.ts>=ls[ns.x][ns.y])continue;
			ls[ns.x][ns.y]=ns.ts;
			q.push(ns);
		}
	}
	print(s[fx][fy]);
	print(ls[fx][fy]);
	puts("");
	return 0;
}
