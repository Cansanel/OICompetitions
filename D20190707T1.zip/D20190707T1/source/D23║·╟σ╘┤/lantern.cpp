#include<bits/stdc++.h>
#define re register
using namespace std;
template <typename T>void read(T &x)
{
	x=0;char str=getchar();
	while(!isdigit(str))str=getchar();
	while(isdigit(str)){x=(x<<3)+(x<<1)+str-48;str=getchar();}
}
int buf[100],top;
template <typename T>void print(T x)
{
	if (!x)putchar('0');
	while(x)buf[++top]=x%10,x/=10;
	while(top)putchar(buf[top--]+48);
	putchar('\n');
}
const int inf=2147483647;
int n,m,a[510][10010],ans,maxR;
int cf1[510][10010],cf2[10010][510];
struct cdt
{
	int x,y;
}f[5000010];
int tp;
bool pd(int xx)
{
	bool pd=1;
	for (re unsigned i=1;i<=tp;i++)
	{
		if (a[f[i].x][f[i].y]>=xx)
		{
			cf1 [f[i].x] [f[i].y-xx+1]++;
			cf1 [f[i].x] [f[i].y+xx]--;
			cf2 [f[i].y] [f[i].x-xx+1]++;
			cf2 [f[i].y] [f[i].x+xx]--;
		}
	}
	for (re int i=1;i<=n;i++)
	{
		for (re int j=1;j<=m;j++)
		{
			cf1[i][j]+=cf1[i][j-1];
			if (!cf1[i][j])return 0;
		}
	}
	for (re int i=1;i<=m;i++)
	{
		for (re int j=1;j<=n;j++)
		{
			cf2[i][j]+=cf2[i][j-1];
			if (!cf2[i][j])return 0;
		}
	}
}
bool cmp(cdt fa,cdt fb){return a[fa.x][fa.y]<a[fb.x][fb.y];}
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	read(n);read(m);
	for (re int i=1;i<=n;i++)
	{
		for (re int j=1;j<=m;j++)
		{
			read(a[i][j]);
			if (a[i][j])f[++tp]=(cdt){i,j};
			maxR=max(maxR,a[i][j]);
		}
	}
	if (maxR>1000)
	{
		puts("-1");
		return 0;
	}
	for (re int i=1;i<=maxR;i++)
	{
		if (pd(i))
		{
			print(i);
			return 0;
		}
	}
	puts("-1");
	return 0;
}
