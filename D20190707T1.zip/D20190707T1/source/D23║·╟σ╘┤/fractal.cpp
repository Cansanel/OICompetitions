#include<bits/stdc++.h>
#define re register
#define ld long double
using namespace std;
template <typename T>void read(T &x)
{
	x=0;char str=getchar();
	while(!isdigit(str))str=getchar();
	while(isdigit(str)){x=(x<<3)+(x<<1)+str-48;str=getchar();}
}
int buf[100],top;
template <typename T>void print(T x)
{
	if (!x)putchar('0');
	while(x)buf[++top]=x%10,x/=10;
	while(top)putchar(buf[top--]+48);
	putchar('\n');
}
int yc,xc;
ld sy,sx,p,q,molen;
bool pd(ld a,ld b)
{
	ld c,d;
	for (re int i=1;i<=100;i++)
	{
		c=a*a-b*b;
		d=a*b+b*a;
		c+=p;d+=q;
		molen=sqrt(c*c+d*d);
		if (molen>=10)return 0;
		a=c;b=d;
	}
	return 1;
}
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc;
	cin>>sy>>sx>>p>>q;
	for (re int i=0;i<yc;i++)
	{
		for (re int j=0;j<xc;j++)
		{
			if ( pd( sy+(ld)(0.005*j) , sx+(ld)(0.01*i) ) )putchar('a');
			else putchar(' ');
		}
		puts("");
	}
	return 0;
}
