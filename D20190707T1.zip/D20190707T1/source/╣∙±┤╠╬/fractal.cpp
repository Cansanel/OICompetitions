#include<bits/stdc++.h>
#define f(a,b,c) for(int a=b;a<=c;a++)
#define ld long double
using namespace std;
ld P,Q;
inline bool mo(ld x,ld y)
{
	if(sqrt(x*x+y*y)>=10)return 1;
	else return 0;
}
inline bool shoulian(ld x,ld y)
{
	ld Zx[101],Zy[101];
	Zx[0]=x;Zy[0]=y;
	f(i,1,100)
	{
		Zx[i]=Zx[i-1]*Zx[i-1]-Zy[i-1]*Zy[i-1]+P;
		Zy[i]=Zx[i-1]*Zy[i-1]+Zy[i-1]*Zx[i-1]+Q;
		if(mo(Zx[i],Zy[i]))return 0;
	}
	return 1;
}
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	int Xc,Yc;
	ld Sy,Sx;
	char c[807][807];
	cin>>Yc>>Xc;
	cin>>Sy>>Sx;
	cin>>P>>Q;
	f(j,0,Yc-1)
	f(i,0,Xc-1)
	if(shoulian(Sy+i*0.005,Sx+j*0.01))
	c[j][i]='a';
	else c[j][i]=' ';
	f(i,0,Yc-1)
	{
		f(j,0,Xc-1)
		printf("%c",c[i][j]);
		printf("\n");
	}
	return 0;
}
