#include<bits/stdc++.h>
using namespace std;
int n,m,a[507][10007],r;
bool v1[507][10007],v2[507][10007];
inline int read()
{
	int x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	ch=getchar();
	while(ch>='0'&&ch<='9')
	x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x;
}
inline bool check(int x)
{
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		if(a[i][j]>=x)
		{
			for(int k=i-x+1;k<=i+x-1;k++)
			v1[k][j]=1;
			for(int k=j-x+1;k<=j+x-1;k++)
			v2[i][k]=1;
		}
	}
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		if(!v1[i][j]||!v2[i][j])return 0;
		v1[i][j]=0;
		v2[i][j]=0;
	}
	return 1;
}
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		a[i][j]=read();
		r=max(r,a[i][j]);
	}
	for(int i=1;i<=r;i++)
	if(check(i))
	{
		cout<<i<<endl;
		return 0;
	}
	cout<<"-1"<<endl;
	return 0;
}
