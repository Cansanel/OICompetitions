#include<bits/stdc++.h>
using namespace std;
priority_queue< pair<int,int> > q;
int ma[107][107],tot,v[160007],w,next[160007],head[10007],dis[10007],a,b,ans[10007];
int dx[9]={0,-2,-2,-1,-1,1,1,2,2},dy[9]={0,-1,1,-2,2,-2,2,-1,1};
bool vis[10007],vi[107][107],heye[10007];
inline int read()
{
	int x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	ch=getchar();
	while(ch>='0'&&ch<='9')
	x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x;
}
inline void build(int x,int y)
{
	v[++tot]=y;
	next[tot]=head[x];
	head[x]=tot;
}
inline void dijkstra()
{
	memset(dis,0x3f,sizeof(dis));
	dis[a]=0;
	q.push(make_pair(0,a));
	while(q.size())
	{
		int x=q.top().second;q.pop();
		if(x==b)break;
		if(vis[x])continue;
		vis[x]=1;
		for(int i=head[x];i;i=next[i])
		{
			if(heye[v[i]])w=0;
			else w=1;
			if(dis[x]+w<dis[v[i]])
			{
				dis[v[i]]=dis[x]+w;
				ans[v[i]]=ans[x]+1;
				q.push(make_pair(-dis[v[i]],v[i]));
			}
		}
	}
}
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	int x1,y1,x2,y2,x,y;
	int n=read(),m=read();
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		ma[i][j]=read();
		if(ma[i][j]==3)ma[i][j]=1,a=m*(i-1)+j;
		if(ma[i][j]==4)ma[i][j]=1,b=m*(i-1)+j;
		if(ma[i][j]==1)
		heye[m*(i-1)+j]=1;
	}
	for(int x1=1;x1<=n;x1++)
	for(int y1=1;y1<=m;y1++)
	{
		vi[x1][y1]=1;
		if(ma[x1][y1]==2)continue;
		for(int i=1;i<=8;i++)
		{
			x2=x1+dx[i];y2=y1+dy[i];
			if(vi[x2][y2])continue;
			if(x2<=0||x2>n||y2<=0||y2>m)continue;
			if(ma[x2][y2]==2)continue;
			x=m*(x1-1)+y1;y=m*(x2-1)+y2;
			build(x,y),build(y,x);
		}
	}
	dijkstra();
	if(dis[b]==0x3f)
	cout<<"-1"<<" "<<"-1"<<endl;
	else
	cout<<dis[b]<<" "<<ans[b]<<endl;
	return 0;
}
