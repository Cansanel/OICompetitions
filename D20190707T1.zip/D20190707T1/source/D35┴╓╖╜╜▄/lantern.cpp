#include<bits/stdc++.h>
using namespace std;

int n,m,a[505][10005],vis1[505][10005],vis2[505][10005];
int ans;

int search(int x){
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++){
	  	if(a[i][j]>=x)
		  for(int k=1-x;k<=x-1;k++){
		  	if(j+k>=1&&j+k<=m)vis1[i][j+k]=1;
		  	if(i+k>=1&&i+k<=n)vis2[i+k][j]=1;
		  }
	  }
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++){
	  	  if(vis1[i][j]!=1||vis2[i][j]!=1){
	  	  	memset(vis1,0,sizeof(vis1));
	  	    memset(vis2,0,sizeof(vis2));
	  	    return search(x+1);
	  	  }
	  }
	return x;
}

int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++)cin>>a[i][j];
	ans=search(1);
	cout<<ans;
	return 0;
}
