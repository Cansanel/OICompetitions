#include<bits/stdc++.h>
using namespace std;

int yc,xc;
double sy,sx,p,q;

char pd(double x0,double y0){
	struct fushu{
		double x,y;
		double score;
	}z[101];
	z[0].x=x0;z[0].y=y0;
	if(sqrt(x0*x0+y0*y0)>=10)return ' ';
	else{
		for(int i=1;i<=100;i++){
			z[i].x=z[i-1].x*z[i-1].x-z[i-1].y*z[i-1].y+p;
			z[i].y=2*z[i-1].x*z[i-1].y+q;
			z[i].score=sqrt(z[i].x*z[i].x+z[i].y*z[i].y);
			if(z[i].score<10)continue;
			return ' ';
		}
		return 'a';
	}
}

int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx;
	cin>>p>>q;
	char c[yc][xc];
	for(int j=0;j<yc;j++)
	   for(int i=0;i<xc;i++)c[j][i]=pd(sy+i*0.005,sx+j*0.01);
	for(int i=0;i<yc;i++){
		for(int j=0;j<xc;j++)cout<<c[i][j];
		cout<<endl;
	}
	return 0;
}
