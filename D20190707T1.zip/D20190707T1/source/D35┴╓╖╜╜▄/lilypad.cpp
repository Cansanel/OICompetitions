#include<bits/stdc++.h>
using namespace std;
int n,m;int a[105][105];
int main(){
		freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
		cin>>n>>m;
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++)cin>>a[i][j];
	cout<<-1;
	return 0;
}
