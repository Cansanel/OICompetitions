#include <iostream>
#include <cstdio>
#include <algorithm>
#include <queue>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
priority_queue<pair<int,int> >q; 
int X[9]={0,-2,-1,1,2,2,1,-1,-2},Y[9]={0,-1,-2,-2,-1,1,2,2,1};
int a[1001][1001];
int dist[10001],v[10001],pass[10001],edge[100001],ver[100001],next[100001],head[100001];
int i,j,k,n,m,bgn,nd,tot;
void add(int x,int y,int z){
	ver[++tot]=y,edge[tot]=z;
	next[tot]=head[x],head[x]=tot;
}
void dijkstra(){
	rep(i,1,n*m) dist[i]=214748364;
	dist[bgn]=0;
	q.push(make_pair(-dist[bgn],bgn));
	while (q.size()){
		int x=q.top().second;q.pop();
		if (v[x]) continue;
		v[x]=1;
		if (x==nd) return;
		for (int i=head[x];i;i=next[i]){
			int y=ver[i],z=edge[i];
			if (dist[y]>dist[x]+z){
				dist[y]=dist[x]+z;
				q.push(make_pair(-dist[y],y));
				pass[y]=pass[x]+1;
			}
		}
	}
}
int main(){
	freopen("lilipad.in","r",stdin);
	freopen("lilipad.out","w",stdout);
	cin>>n>>m;
	rep(i,1,n)
		rep(j,1,m){
			cin>>a[i][j];
			if (a[i][j]==3) bgn=m*(i-1)+j;
			if (a[i][j]==4) nd=m*(i-1)+j,a[i][j]=1;
		}
	rep(i,1,n)
		rep(j,1,m){
			if (a[i][j]==2) continue;
			int x,y;
			rep(k,1,8){
				x=i+X[k],y=j+Y[k];
				if (x>0&&x<=n&&y>0&&y<=m)
					add(m*(i-1)+j,m*(x-1)+y,(a[x][y]+1)%2);
			}
		}
	dijkstra();
	if (dist[nd]==214748364) cout<<"-1 -1"<<endl;
	else cout<<dist[nd]<<' '<<pass[nd]<<endl;
	return 0;
}
/*
4 8
0 0 0 1 0 0 0 0
0 0 0 0 0 2 0 1
0 0 0 0 0 4 0 0
3 0 0 0 0 0 1 0


25 19 4 21 31 16 22

*/
