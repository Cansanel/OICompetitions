#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
struct arr{
	double x;
	double y;
};
int n,m,j,i;
double x,y,p,q;
char a[1001][1001];
arr cf(arr a,arr b){
	arr c;
	c.x=a.x*b.x-a.y*b.y,c.y=a.x*b.y+a.y*b.x;
	return c;
}
char solve(double a,double b){
	arr z[101];
	z[0].x=a,z[0].y=b;
	int i;
	rep(i,1,100){
		z[i]=cf(z[i-1],z[i-1]);
		z[i].x+=p,z[i].y+=q;
		double t=sqrt(z[i].x*z[i].x+z[i].y*z[i].y);
		if (t>=10) return ' ';
	}
	return 'a';
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>n>>m>>x>>y>>p>>q;
	rep(i,0,n-1)
		rep(j,0,m-1)
			a[i][j]=solve(x+j*0.005,y+i*0.01);
	rep(i,0,n-1) {
		rep(j,0,m-1) 
			putchar(a[i][j]);
		cout<<endl;
	}
	return 0;
}
/*
400 800 -2 -2
-0.53 0.53

*/
