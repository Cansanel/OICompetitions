#include <iostream>
#include <cstdio>
#include <algorithm>
#include <queue>
#define rep(i,j,k) for (i=j;i<=k;i++)
using namespace std;
int a[1001][1001],b[1001][1001],c[2100][1001];
int i,j,k,n,m,t,p;
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	cin>>n>>m;
	rep(i,1,n) rep(j,1,m){
		cin>>a[i][j];
		if (a[i][j]>0){
			rep(k,i-a[i][j]+1,i+a[i][j]-1) if (k>0&&k<=n) b[k][j]++;
			rep(k,j-a[i][j]+1,j+a[i][j]-1) if (k>0&&k<=m) b[i][k]++;
		}
	}
	rep(i,1,n) rep(j,1,m) {
		if (b[i][j]!=2){
			cout<<"-1"<<endl;
			return 0;
		}
		b[i][j]=a[i][j];
	}
	rep(p,1,10){
		rep(i,1,n)
			rep(j,1,m){
				if (b[i][j]<p) b[i][j]=0;
				else b[i][j]=p;
			}
	rep(i,1,n) rep(j,1,m){
		if (b[i][j]>0){
			rep(k,i-b[i][j]+1,i+b[i][j]-1) if (k>0&&k<=n) c[k][j]++;
			rep(k,j-b[i][j]+1,j+b[i][j]-1) if (k>0&&k<=m) c[i][k]++;
		}
	}
	t=0;
	rep(i,1,n) rep(j,1,m) {
		if (c[i][j]!=2)
			t=1;
		c[i][j]=0;
	}
	if (t==0) cout<<p;
		rep(i,1,n)
			rep(j,1,m)
			 b[i][j]=a[i][j];
	}
	return 0;
}
