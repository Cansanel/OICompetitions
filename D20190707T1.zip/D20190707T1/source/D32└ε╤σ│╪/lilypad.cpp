#include <iostream>
#include <queue>
#include <string.h>
#include <fstream>
using namespace std;
int dx[]={-2,-1,1,2,2,1,-1,-2};
int dy[]={1,2,2,1,-1,-2,-2,-1};
int n,m;
int a[105][105];
int sx,sy;
int ans1=1e9,ans2=1e9;

int read(){
	int f=1,ans=0;char ch=getchar();
	if (ch=='-') f=-1;
	while ('0'<=ch&&ch<='9'){ans=ans*10+(ch-'0');ch=getchar();}
	return f*ans;
}

struct node{
	int x,y;
	int lis,steps;
};

void bfs(){
	int dp1[105][105],dp2[105][105];
	memset(dp1,0x3f3f3f3f,sizeof(dp1));
	memset(dp2,0x3f3f3f3f,sizeof(dp2));
	queue<node> q;
	node tmp;
	tmp.x=sx;tmp.y=sy;
	tmp.lis=0;tmp.steps=0;
	dp1[sx][sy]=0;
	dp2[sx][sy]=0;
	q.push(tmp);
	while (!q.empty()){
		node now=q.front();
		q.pop();
		dp1[now.x][now.y]=now.lis;
		dp2[now.x][now.y]=now.steps;
		if (a[now.x][now.y]==4){
			if (now.lis<ans1){
				ans1=now.lis;
				ans2=now.steps;
			}
			else if (now.lis==ans1){
				ans2=min(ans2,now.steps);
			}
			continue;
		}

		for (int i=0;i<8;i++){
			int ax=now.x+dx[i],ay=now.y+dy[i];
			if (a[ax][ay]!=2&&ax>=1&&ax<=n&&ay>=1&&ay<=m){
				node ans;
				ans.x=ax;
				ans.y=ay;
				ans.lis=now.lis;
				ans.steps=now.steps+1;
				if (a[ax][ay]==0){
					ans.lis++;
				}
				if (dp1[ax][ay]>ans.lis) q.push(ans);
				else if (dp1[ax][ay]==ans.lis){
					if (dp2[ax][ay]>ans.steps) q.push(ans);
				}
			}
		}
	}
}

int main()

{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	n=read();m=read();
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			a[i][j]=read();
			if (a[i][j]==3){
				sx=i;
				sy=j;
			}
		}
	}

	bfs();
	cout<<ans1<<" "<<ans2<<endl;
	return 0;
}