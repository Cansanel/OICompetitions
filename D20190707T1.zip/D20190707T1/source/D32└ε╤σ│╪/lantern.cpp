#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
int n,m;
int map[505][10005];
int l=1,r=1e9;

int read(){
	int f=1,ans=0;
	char ch=getchar();
	if (ch=='-') f=-1;
	while ('0'<=ch&&ch<='9'){ans=ans*10+(ch-'0');ch=getchar();}
	return f*ans;
}

bool check(int x){
	vector<int> mx[105];
	vector<int> my[10005];
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			if (map[i][j]>=x){
				mx[i].push_back(j);
				my[j].push_back(i);
			}
		}
	}

	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			if (map[i][j]>=x) continue;
			bool okx=false,oky=false;
			for (int k=0;k<mx[i].size();k++){
				if (j>=mx[i][k]-x+1&&j<=mx[i][k]+x-1){
					okx=true;
					break;
				}
			}
			for (int k=0;k<my[j].size();k++){
				if (i>=my[j][k]-x+1&&i<=my[j][k]+x-1){
					oky=true;
					break;
				}
			}
			if (!okx||!oky){
				return false;
			}
		}
	}
	return true;
}

int main()

{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	n=read();m=read();
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			map[i][j]=read();
		}
	}

	for (int r=1;r<=1001;r++){
		if (check(r)){
			cout<<r<<endl;
			return 0;
		}
	}
	cout<<-1<<endl;
	return 0;
}