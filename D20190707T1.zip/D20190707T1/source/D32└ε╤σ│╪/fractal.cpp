#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;
double n,m;
double P,Q,Sy,Sx;

struct node{
	double x;
	double y;
};

node add(node a,node b){
	node ans;
	ans.x=a.x+b.x;
	ans.y=a.y+b.y;
	return ans;
}

node jian(node a,node b){
	node ans;
	ans.x=a.x-b.x;
	ans.y=a.y+b.y;
	return ans;
}

node mul(node a,node b){
	node ans;
	ans.x=a.x*b.x-a.y*b.y;
	ans.y=a.x*b.y+a.y*b.x;
	return ans;
}

double modl(node x){
	return sqrt(x.x*x.x+x.y*x.y);
}

bool in(double x,double y){
	node c;
	c.x=P;
	c.y=Q;
	node z[105];
	z[0].x=x;z[0].y=y;
	if (modl(z[0])>=10.0) return false;
	for (int i=1;i<=100;i++){
		z[i]=add(mul(z[i-1],z[i-1]),c);
		if (modl(z[i])>=10.0) return false;
	}
	return true;
}
int main()

{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m>>Sy>>Sx;
	cin>>P>>Q;

	for (double i=1.0;i<=n;i+=1.0){
		for (double j=1.0;j<=m;j+=1.0){
			if (in(Sy+j*0.005,Sx+i*0.01)) cout<<'a';
			else cout<<" ";
		}
		cout<<endl;
	}
	return 0;
}
/*
400 800 -2 -2
-0.53 -0.53
*/