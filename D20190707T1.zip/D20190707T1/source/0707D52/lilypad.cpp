#include <bits/stdc++.h>
using namespace std;
int ex,ey,tx,ty,nans1=0x3f3f3f3f,nans2=0x3f3f3f3f;
int n,m,l,r,ans,arr=0;
int p[105][105];
int fx[]={2,2,-2,-2,1,1,-1,-1},
	fy[]={1,-1,1,-1,2,-2,2,-2};
struct Node{
	int x,y,cst,stp;
};
queue<Node>q;
int now[105][105],step[105][105];

int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	memset(now,0x3f3f3f3f,sizeof now);
	memset(step,0x3f3f3f3f,sizeof step);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;++i){
		for (int j=1;j<=m;++j){
			scanf("%d",&p[i][j]);
			if (p[i][j]==3){
				ex=i;
				ey=j;
			}
			if (p[i][j]==4){
				tx=i;
				ty=j;
			}
		}
	}
	while (!q.empty())q.pop();
	q.push((Node){ex,ey,0,0});
	now[ex][ey]=0;
	step[ex][ey]=0;
	while (!q.empty()){
		Node tmp=q.front();
		q.pop();
		int nx=tmp.x,ny=tmp.y,tct=tmp.cst,nstp=tmp.stp;
//		printf("%d %d %d %d\n",nx,ny,tct,nstp);
//		system("PAUSE");
		if (nx==tx && ny==ty){
//				printf("%d %d\n",now[tx][ty],step[tx][ty]);
//				system("PAUSE");
				continue;
		}
		for (int i=0;i<8;++i){
			int ax=nx+fx[i],ay=ny+fy[i];
			if (ax<1||ax>n||ay<1||ay>m)continue;
			if (p[ax][ay]==2)continue;
			if (p[ax][ay]==1 || p[ax][ay]==4){
				if (now[ax][ay] < tct)continue;
				if (now[ax][ay] == tct){
					if (step[ax][ay]<=nstp+1)continue;
					step[ax][ay]=nstp+1;
					q.push((Node){ax,ay,tct,nstp+1});
				}
				if (now[ax][ay]>tct){
					step[ax][ay]=nstp+1;
					now[ax][ay]=tct;
					q.push((Node){ax,ay,tct,nstp+1});
				}
			}
			if (p[ax][ay]==0){
				if (now[ax][ay]<tct+1)continue;
				if (now[ax][ay]==(tct+1)){
					if (step[ax][ay] <= (nstp+1))continue;
					step[ax][ay]=nstp+1;
					q.push((Node){ax,ay,tct+1,nstp+1});
				}
				if (now[ax][ay]>(tct+1)){
					step[ax][ay]=nstp+1;
					now[ax][ay]=tct+1;
					q.push((Node){ax,ay,tct+1,nstp+1});
				}
			}
			
		}
	}
	printf("%d %d\n",now[tx][ty],step[tx][ty]);
	return 0;
}
