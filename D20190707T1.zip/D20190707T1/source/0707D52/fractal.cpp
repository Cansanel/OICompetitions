#include <bits/stdc++.h>
using namespace std;

int yc,xc;
double Sy,Sx,P,Q;

const double eps=1e-7;

struct Node {
	double x,y;
	Node operator + (const Node &a)const{
		Node c;
		c=(Node){x+a.x,y+a.y};
		return c;
	}
	Node operator -(const Node &a)const{
		Node c;
		c=(Node){x-a.x,y-a.y};
		return c;
	}
	Node operator *(const Node &a)const{
		Node c;
		c=(Node){x*a.x-y*a.y,x*a.y+y*a.x};
		return c;
	}
}c,z[101];

double get(Node a){
	double pre=a.x*a.x+a.y*a.y;
	pre=sqrt(pre);
	return pre;
}

bool check(Node a){
	z[0]=a;
	if (get(a)-10>eps)return 0;
	for (int i=1;i<=100;++i){
		z[i]=(z[i-1]*z[i-1])+c;
		if (get(z[i])-10>eps)return 0;
	}
	return 1;
}

int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);	
//	scanf("%d%d",&yc,&xc);
	cin>>yc>>xc>>Sy>>Sx>>P>>Q;
	c=(Node){P,Q};
	for (int j=0;j<yc;++j){
		for (int i=0;i<xc;++i){
			double fx=Sy+i*0.005;
			double fy=Sx+j*0.01;
			Node uc=(Node){fx,fy};
			if (check(uc))printf("a");else printf(" ");
		}
		puts("");
	}
	return 0;
}
