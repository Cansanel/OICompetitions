#include <bits/stdc++.h>
using namespace std;

int n,m,R;
int usedh[505][505],usedl[505][505];
int p[505][10006];

int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;++i){
		for (int j=1;j<=m;++j){
			scanf("%d",&p[i][j]);
		}
	}
	for(int r=1;r<=max(n,m);++r){
		memset(usedh,0,sizeof usedh);
		memset(usedl,0,sizeof usedl);
		for (int i=1;i<=n;++i){
			for (int j=1;j<=m;++j){
				if (p[i][j]<r)continue;	
				for (int k=1;k<r;++k){
					if (i-k>0)usedl[i-k][j]=1;
					if (i+k<=n)usedl[i+k][j]=1;
					if (j-k>0)usedh[i][j-k]=1;
					if (j+k<=m)usedh[i][j+k]=1;
				} 
			}
		}
		bool cando=1;
		for (int i=1;i<=n;++i){
			for (int j=1;j<=m;++j){
				if (p[i][j]>=r){
					if (usedh[i][j] && usedl[i][j])cando=0;
				}else if (!usedh[i][j] || !usedl[i][j])cando=0;
			}
		}
		if (cando){
			printf("%d\n",r);
			return 0;
		}
	}
	puts("-1");
	return 0;
}
