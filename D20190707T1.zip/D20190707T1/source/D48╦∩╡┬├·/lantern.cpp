#include<bits/stdc++.h>
using namespace std;
int n,m,l,ans;
long long c[510][10010],d[510][10010][2];
void check(int a)
{   
	int i,j,k;
	for(i=1;i<=n;i++)
	for(j=1;j<=m;j++)
	d[i][j][0]=d[i][j][1]=0;
	for(i=1;i<=n;i++)
	for(j=1;j<=m;j++)
	{
	if(c[i][j]>=a)
	for(k=i-a+1;k<=i+a-1;k++)d[k][j][0]=1;
	for(k=j-a+1;k<=j+a-1;k++)d[i][k][1]=1;
    }
    for(i=1;i<=n;i++)
	for(j=1;j<=m;j++)
	if(d[i][j][0]==0||d[i][j][1]==0)
    {
    	return;
    }
    if(ans!=0)ans=min(a,ans);
    else ans=a;
    return;
}
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	cin>>n>>m;
	int i,j;
	for(i=1;i<=n;i++)
	for(j=1;j<=m;j++)
	cin>>c[i][j];
	l=max(n,m);
    while(l>0)
	{check(l);l--;}
    if(ans!=0)cout<<ans;else cout<<-1;
    return 0;
    fclose(stdin);
    fclose(stdout);
}
