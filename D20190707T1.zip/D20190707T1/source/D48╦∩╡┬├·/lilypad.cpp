#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("lilypad.in","r",stdin);
    freopen("lilypad.out","w",stdout);
    cout<<-1<<" "<<-1;
    fclose(stdin);
    fclose(stdout);
}
