#include<bits/stdc++.h>
using namespace std;
char c[810][810];	
int yc,xc;
double sy,sx,p,q;
bool oj8k(double a,double b)
{
	 int i,j;
     double z[101][3];
     z[0][1]=a;z[0][2]=b;
     for(i=1;i<=100;i++)
     {
     	z[i][1]=z[i-1][1]*z[i-1][1]-z[i-1][2]*z[i-1][2];
     	z[i][2]=z[i-1][1]*z[i-1][2]*2;
     	z[i][1]+=p;
     	z[i][2]+=q;
     	if(sqrt(z[i][1]*z[i][1]+z[i][2]*z[i][2])>=10)return 0;
     }
     return 1;
}
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	int i,j;
    cin>>yc>>xc>>sy>>sx>>p>>q;
	for(j=0;j<yc;j++)
	for(i=0;i<xc;i++)
	if(oj8k(sy+i*0.005,sx+j*0.01))c[j][i]='a';
	else c[j][i]=' ';
	for(j=0;j<yc;j++)
	{
	for(i=0;i<xc;i++)cout<<c[j][i];
	cout<<endl;
    }
    fclose(stdin);
    fclose(stdout);
}
