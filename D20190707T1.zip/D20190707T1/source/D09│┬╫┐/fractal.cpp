#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <bitset>
#include <string>
#include <cstdio>
#include <vector>
#include <queue>
#include <stack>
#include <cmath>
#include <map>

#define submit

struct Complex
{
    long double x, y, mod;
    
    Complex(long double x = 0, long double y = 0) : x(x), y(y) { mod = std::sqrt(x * x + y * y); }
    
    const Complex operator +(const Complex& z) const
    {
        return Complex(x + z.x, y + z.y);
    }
    
    const Complex operator-(const Complex& z) const
    {
        return Complex(x - z.x, y - z.y);
    }
    
    const Complex operator*(const Complex& z) const
    {
        return Complex(x * z.x - y * z.y, x * z.y + y * z.x);
    }
};

long double xc, yc, sx, sy, P, Q;
char c[900][900];
Complex constCom;
Complex z[110];

int lim(long double x, long double y)
{
    memset(z, 0, sizeof z);
    
    z[0] = Complex(x, y);
    for (int i = 1; i <= 100; ++i)
    {
        z[i] = (z[i - 1] * z[i - 1]) + constCom;
        if (z[i].mod >= 10)
            return 0;
    }
    return 1;
}

int main()
{
#ifdef submit
    freopen("fractal.in", "r", stdin);
    freopen("fractal.out", "w", stdout);
#endif
    std::cin >> yc >> xc >> sy >> sx >> P >> Q;
    constCom = Complex(P, Q);
    for (int j = 0; j < yc; ++j)
    {
        for (int i = 0; i < xc; ++i)
        {
            if (lim(sy + (long double)i * 0.005, sx + (long double)j * 0.01))
                c[j][i] = 'a';
            else
                c[j][i] = ' ';
        }
    }
    for (int i = 0; i < yc; ++i)
    {
        for (int j = 0; j < xc; ++j)
            putchar(c[i][j]);
        putchar('\n');
    }
    return 0;
}
