#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <bitset>
#include <string>
#include <cstdio>
#include <vector>
#include <queue>
#include <stack>
#include <cmath>
#include <map>

#define submit

template <typename T>
void read(T& x)
{
    char c = getchar();
    for (x = 0; !isdigit(c); c = getchar());
    for (; isdigit(c); x = x * 10 + (c ^ 48), c = getchar());
}

#define max(a, b) (a > b ? a : b)
#define min(a, b) (a < b ? a : b)

int n, m;
int a[510][10010], pre[510][10010];

int judge(int x)
{
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= m; ++j)
        {
            pre[i][j] = pre[i - 1][j] + pre[i][j - 1] - pre[i - 1][j - 1] + (a[i][j] >= x);
        }
    }
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= m; ++j)
        {
            int uLim = max(1, i - x + 1), lLim = max(1, j - x + 1), rLim = min(m, j + x - 1), dLim = min(n, i + x - 1);
            int cntL = pre[i][rLim] - pre[i][lLim - 1] - pre[i - 1][rLim] + pre[i - 1][lLim - 1];
            int cntR = pre[dLim][j] - pre[dLim][j - 1] - pre[uLim - 1][j] + pre[uLim - 1][j - 1];
            if (cntL < 1 || cntR < 1)
                return 0;
        }
    }
    return 1;
}

int main()
{
#ifdef submit
    freopen("lantern.in", "r", stdin);
    freopen("lantern.out", "w", stdout);
#endif
    read(n), read(m);
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= m; ++j)
            read(a[i][j]);
    }
    
    for (int i = 1, lim = max(n, m); i <= lim; ++i)
    {
        if (judge(i))
        {
            std::cout << i << std::endl;
            return 0;
        }
    }
    std::cout << -1 << std::endl;
    return 0;
}
