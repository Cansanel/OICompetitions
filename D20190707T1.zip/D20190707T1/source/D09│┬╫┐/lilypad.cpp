#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <bitset>
#include <string>
#include <cstdio>
#include <vector>
#include <queue>
#include <stack>
#include <cmath>
#include <map>

#define submit

const int di[8] = { -2, -1, 1, 2, 2, 1, -1, -2 };
const int dj[8] = { -1, -2, -2, -1, 1, 2, 2, 1 };

template <typename T>
void read(T& x)
{
    char c = getchar();
    for (x = 0; !isdigit(c); c = getchar());
    for (; isdigit(c); x = x * 10 + (c ^ 48), c = getchar());
}

struct Data
{
    int pos;
    long long dis;
    
    Data(int pos = 0, long long dis = 0) : pos(pos), dis(dis) {}
    
    const bool operator <(const Data& x) const
    {
        return dis > x.dis;
    }
};

#define calcPos(x, y) ((x - 1) * m + y)

int n, m, staPos, endPos;
int a[110][110];
long long dist[100010];
std::vector <int> g[100010], w[100010];

void dijkstra()
{
    std::priority_queue <Data> q;
    memset(dist, 0x7f, sizeof dist);
    dist[staPos] = 0;
    q.push(Data(staPos, 0));
    while (q.size())
    {
        Data x = q.top(); q.pop();
        for (int i = 0, limit = g[x.pos].size(); i < limit; ++i)
        {
            int _t = g[x.pos][i], _w = w[x.pos][i];
            if (x.dis + _w < dist[_t])
            {
                q.push(Data(_t, dist[_t] = x.dis + _w));
            }
        }
    }
}

int main()
{
#ifdef submit
    freopen("lilypad.in", "r", stdin);
    freopen("lilypad.out", "w", stdout);
#endif
    read(n), read(m);
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= m; ++j)
        {
            read(a[i][j]);
            if (a[i][j] == 4)
                endPos = calcPos(i, j);
            else if (a[i][j] == 3)
                staPos = calcPos(i, j);
        }
    }
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= m; ++j)
        {
            int curPos = calcPos(i, j);
            for (int k = 0; k < 8; ++k)
            {
                int ti = i + di[k], tj = j + dj[k];
                if (ti > 0 && tj > 0 && ti <= n && tj <= m && a[ti][tj] != 2)
                {
                    int nxtPos = calcPos(ti, tj);
                    if (a[ti][tj] == 0)
                        g[curPos].push_back(nxtPos), w[curPos].push_back(100000);
                    else
                        g[curPos].push_back(nxtPos), w[curPos].push_back(1);
                }
            }
        }
    }
    
    dijkstra();
    
    if (dist[endPos] == 0x7f)
        std::cout << -1 << " " << -1 << std::endl;
    else
        std::cout << dist[endPos] / (long long)100000 << " " << dist[endPos] / (long long)100000 + dist[endPos] % (long long)100000 << std::endl;
    
    return 0;
}
