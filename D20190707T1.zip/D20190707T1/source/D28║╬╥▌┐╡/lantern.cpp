#include <bits/stdc++.h>
#define open(name) freopen(#name".in", "r", stdin), freopen(#name".out", "w", stdout)
#define LL long long
#define ULL unsigned long long
using namespace std;

const int Maxn = 500 + 5, Maxm = 10000 + 5;

int dx[4] = {0, 1, 0, -1},
	dy[4] = {1, 0, -1, 0};

int n, m, minn = INT_MAX;
int field[Maxn][Maxm];
bool vis[Maxn][Maxm];

void init()
{
	memset(field, 0x3f, sizeof(field));
	scanf("%d %d", &n, &m);
	for (int i = 1; i <= n; ++i)
	{
		for (int j = 1; j <= m; ++j)
		{
			int r;
			scanf("%d", &r);
			if (r)
			{
				vis[i][j] = 1;
				field[i][j] = 1;
			}
			else continue;
			for (int k = 0; k < 4; ++k)
			{
				for (int o = 1; o < r; ++o)
				{
					int tx = i + dx[k] * o;
					int ty = j + dy[k] * o;
					if (tx >= 1 && tx <= n && ty >= 1 && ty <= m)
					{
						field[tx][ty] = min(o + 1, field[tx][ty]);
						vis[tx][ty] = 1;
					}
					else goto Break;
				}
				Break:;
				
			}
		}
	}
}

int main()
{
	open(lantern);
	init();
	int Ans = INT_MIN;
	for (int i = 1; i <= n; ++i)
	{
		for (int j = 1; j <= m; ++j)
		{
			Ans = max(Ans, field[i][j]);
			if (!vis[i][j])
			{
				printf("-1");
				return 0;
			}
		}
	}
	printf("%d", Ans);
	return 0;
}
