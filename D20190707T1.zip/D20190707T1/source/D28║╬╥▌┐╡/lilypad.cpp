#include <bits/stdc++.h>
#define open(name) freopen(#name".in", "r", stdin), freopen(#name".out", "w", stdout)
#define LL long long
#define ULL unsigned long long
using namespace std;

int dx[8] = {1, 2, 1, 2, -1, -2, -1, -2},
	dy[8] = {2, 1, -2, -1, -2, -1, 2, 1};

int n, m, beginx, beginy, endx, endy;

int hy[105][105];

void init()
{
	memset(hy, -1, sizeof(hy));
	cin >> n >> m;
	for (int i = 1; i <= n; ++i)
	{
		for (int j = 1; j <= m; ++j)
		{
			int r;
			cin >> r;
			if (r == 0) hy[i][j] = 0;
			else if (r == 1) hy[i][j] = 1;
				else if (r == 3)
				{
					beginx = i;
					beginy = j;
					hy[i][j] = 1;
				}
					else if (r == 4)
					{
						endx = i;
						endy = j;
						hy[i][j] = 1;	
					}
		}
	}
}

bool finish;
int finish_temp;
bool vis[105][105];

void load()
{
	finish = false;
	memset(vis, 0, sizeof(vis));
	vis[beginx][beginy] = true;
}

void dfs_find(int x, int y, int dep)
{
	if (x == endx && y == endy)
	{
		finish_temp = dep;
		finish = true;
		return;
	}
	for (int i = 0; i < 8; ++i)
	{
		int tx = x + dx[i];
		int ty = y + dy[i];
		if (tx >= 1 && tx <= n && ty >= 1 && ty <= m && !vis[tx][ty])
		{
			if (!hy[tx][ty] && dep != 0)
			{
				vis[tx][ty] = true;
				dfs_find(tx, ty, dep - 1);
				if (finish) return;
				vis[tx][ty] = false;
			}
			else if (hy[tx][ty] == 1)
			{
				vis[tx][ty] = true;
				dfs_find(tx, ty, dep);
				if (finish) return;
				vis[tx][ty] = false;
			}
		}
	}
}

int hy_max, minn;

struct node
{
	int x, y;
	int temp;
	int hy;
};

void bfs_search()
{
	memset(vis, 0, sizeof(vis));
	vis[beginx][beginy] = true;
	queue < node > q;
	q.push({beginx, beginy, 0, 0});
	while(!q.empty())
	{
		node now = q.front();
		q.pop();
		if (now.x == endx && now.y == endy)
		{
			minn = now.temp;
			return;
		}
		for (int i = 0; i < 8; ++i)
		{
			int tx = now.x + dx[i];
			int ty = now.y + dy[i];
			if (tx >= 1 && ty >= 1 && tx <= n && ty <= m && !vis[tx][ty])
			{
				if (!hy[tx][ty] && now.hy < hy_max)
				{
					vis[tx][ty] = true;
					q.push({tx, ty, now.temp + 1, now.hy + 1});
				}
				else if (hy[tx][ty] == 1)
				{
					vis[tx][ty] = true;
					q.push({tx, ty, now.temp + 1, now.hy});
				}
			}
		}
	}
	cout << -1 << " " << -1 << endl;
	exit(0);
}

bool mid_vis[5055];

int main()
{
	open(lilypad);
	init();
	int left = 0, right = n * m;
	while(left <= right)
	{
		int mid = (left + right) / 2;
		if (!mid_vis[mid]) mid_vis[mid] = true;
		else 
		{
			cout << -1 << " " << -1 << endl;
			exit(0);
		}
		load();
		dfs_find(beginx, beginy, mid);
		if (finish)
		{
			right = mid - finish_temp - 1;
		}
		else
		{
			left = mid + 1;
		}
	}
	hy_max = left;
	bfs_search();
	cout << hy_max << ' ' << minn << endl;
	return 0;
}

