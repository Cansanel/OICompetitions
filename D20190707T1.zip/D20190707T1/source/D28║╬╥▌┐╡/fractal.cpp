#include <bits/stdc++.h>
#define open(name) freopen(#name".in", "r", stdin), freopen(#name".out", "w", stdout)
#define LL long long
#define ULL unsigned long long
using namespace std;

typedef double type;

class Vnum
{
public:
	Vnum()
	{
		num_x = 0;
		num_y = 0;
	};
	Vnum(type _x, type _y)
	{
		num_x = _x;
		num_y = _y;
	};
	
	type& x()
	{
		return num_x;
	}
	type& y()
	{
		return num_y;
	}
	
	friend Vnum operator+( Vnum a,  Vnum b)
	{
		Vnum c(a.x() + b.x(), a.y() + b.y());
		return c;
	}
	friend  Vnum operator-( Vnum a,  Vnum b)
	{
		Vnum c(a.x() - b.x(), a.y() - b.y());
		return c;
	}
	friend  Vnum operator*( Vnum a,  Vnum b)
	{
		Vnum c(a.x() * b.x() - a.y() * b.y(), a.x() * b.y() + a.y() * b.x());
		return c;
	}
	friend  type operator*( Vnum a)
	{
		return sqrt(a.x() * a.x() + a.y() * a.y());
	}
protected:
	type num_x, num_y;
};

ostream& operator<<(ostream &out, Vnum &a)
{
	out << a.x() << "." << a.y();
	return out;
}

type P, Q;
Vnum c;

bool check(Vnum x)
{
	Vnum z[101];
	z[0] = x;
	for (int i = 1; i <= 100; ++i)
	{
		z[i] = z[i - 1] * z[i - 1] + c;
		if (*z[i] >= 10) return false;
	}
	return true;
}

int main()
{
	open(fractal);
	type yc, xc;
	double sy, sx;
	cin >> yc >> xc >> sy >> sx;
	cin >> P >> Q;
	c.x() = P, c.y() = Q;
	for (int j = 0; j < yc; ++j)
	{
		for (int i = 0; i < xc; ++i)
		{
			putchar(check(Vnum(sy + i * 0.005, sx + j * 0.01)) ? 'a' : ' ');
		}
		putchar('\n');
	}
	return 0;
}
