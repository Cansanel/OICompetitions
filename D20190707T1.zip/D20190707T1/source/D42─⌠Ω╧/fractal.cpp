#include<bits/stdc++.h>
using namespace std;
double yc,xc,sy,sx,p,q;
char a[810][810];
void yn(double x,double y,int xx,int yy)
{
	for(int i=1;i<=100;i++)
	{
		double x1=x,y1=y;
		x=x1*x1-y1*y1+p,y=2*x1*y1+q;
		if(sqrt(x*x+y*y)>=10)
		{
			a[xx][yy]=' ';
			return;
		}
	}
	a[xx][yy]='a';
}
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);	
	cin>>yc>>xc>>sy>>sx>>p>>q;
	for(double j=0;j<yc;j++)
	for(double i=0;i<xc;i++)
	yn(sy+i*0.005,sx+j*0.01,j,i);
	for(int i=0;i<yc;i++)
	{
		for(int j=0;j<xc;j++)
		cout<<a[i][j];
		cout<<endl;
	}
	return 0;
}
