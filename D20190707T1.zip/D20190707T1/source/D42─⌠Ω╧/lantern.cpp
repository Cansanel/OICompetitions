#include<bits/stdc++.h>
using namespace std;
int n,m,a[1001][1001],maxn,t,b[1001][1001];
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);	
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		cin>>a[i][j];
		maxn=max(maxn,a[i][j]);
	}
	t=1;
	while(t<=maxn)
	{
		int ans=0;
		memset(b,0,sizeof(b));
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		if(a[i][j]>=t)
		{
			for(int ii=0;ii<t;ii++)
			{
				if(i-ii>0)
				if(!b[i-ii][j])
				{
					b[i-ii][j]=1;
					ans++;
				}
				if(i+ii<=n)
				if(!b[i+ii][j])
				{
					b[i+ii][j]=1;
					ans++;
				}	
				if(j-ii>0)
				if(!b[i][j-ii])
				{
					b[i][j-ii]=1;
					ans++;
				}
				if(j+ii<=m)
				if(!b[i][j+ii])
				{
					b[i][j+ii]=1;
					ans++;
				}								
			}
		}
		if(ans==n*m)
		{
			cout<<t<<endl;
			return 0;
		}
		t++;
	}
	cout<<-1;
	return 0;
}
