#include<bits/stdc++.h>
using namespace std;
const int dx[8]={2,1,-1,-2,-2,-1,1,2};
const int dy[8]={1,2,2,1,-1,-2,-2,-1};
int xc,yc,xm,ym,n,m,b[110][110],a[110][110],bb,d[3][1000010],b1[110][110],ans2=99999999,ans1;
void bfs(int x,int y,int t,int tt)
{
	memset(b,0,sizeof(b));
	memset(d,0,sizeof(d));
	d[0][1]=x;d[1][1]=y;d[2][1]=tt;
	b[x][y]=1;
	int f=1,r=1;
	while(f<=r)
	{
		if(d[0][f]==xm&&d[1][f]==ym)
		{
			bb=1;
			ans1=t;
			if(d[2][f]<=ans2)ans2=d[2][f];
			return;
		}
		for(int i=0;i<8;i++)
		{
			int xx=d[0][f]+dx[i],yy=d[1][f]+dy[i];
			if(xx>0&&yy>0&&xx<=n&&yy<=m)
			if((a[xx][yy]==1||a[xx][yy]==4)&&!b[xx][yy]&&!b1[xx][yy])
			{
				r++;
				d[0][r]=xx;d[1][r]=yy;d[2][r]=d[2][f]+1;
				b[xx][yy]=1;
			}
		}
		f++;
	}	
}
void dfs(int x,int y,int t,int tt,int pd,int pp)
{	
	if(bb&&t>ans1)
	return;
	if(pp)
	bfs(x,y,t,tt);	
	if(pd<7)
	return;	
	for(int i=0;i<8;i++)
	{
		int xx=x+dx[i],yy=y+dy[i];
		if(xx>0&&yy>0&&xx<=n&&yy<=m)
		if(a[xx][yy]==1&&!b1[xx][yy])
		{
			b1[x][y]=1;
			dfs(xx,yy,t,tt+1,7,0);
			b1[x][y]=0;	
		}
	}
	for(int i=0;i<8;i++)
	{
		int xx=x+dx[i],yy=y+dy[i];
		if(xx>0&&yy>0&&xx<=n&&yy<=m)
		if(!a[xx][yy])
		{
			a[xx][yy]=1;
			a[x][y]=2;
			b1[x][y]=1;
			dfs(xx,yy,t+1,tt+1,1,1);
			b1[x][y]=0;
			a[x][y]=1;
			a[xx][yy]=0;
		}
	}
	for(int i=0;i<8;i++)
	{
		int xx=x+dx[i],yy=y+dy[i];
		if(xx>0&&yy>0&&xx<=n&&yy<=m)
		if(!a[xx][yy])
		{
			a[xx][yy]=1;
			a[x][y]=2;
			b1[x][y]=1;
			dfs(xx,yy,t+1,tt+1,7,0);
			b1[x][y]=0;
			a[x][y]=1;
			a[xx][yy]=0;
		}
	}		
}
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);		
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		cin>>a[i][j];
		if(a[i][j]==3)
		xc=i,yc=j;
		if(a[i][j]==4)
		xm=i,ym=j;
	}
	dfs(xc,yc,0,0,7,1);
	if(!bb)
	cout<<-1<<endl;
	else
	cout<<ans1<<" "<<ans2<<endl;
	return 0;
}
