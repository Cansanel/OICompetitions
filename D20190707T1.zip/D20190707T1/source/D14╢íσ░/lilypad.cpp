#include<bits/stdc++.h>
using namespace std;
//ˮ�濴��1 ��Ҷ����0 �ӱ���һ�����· 
//�ڽ���spfa������ʱ��˳��ͳ�Ʋ��� 
int n,m,px,py,qx,qy,sx,sy,tx,ty,a[105][105],f[105][105],g[105][105];
int b[800000][5],head,tail;
bool q[105][105]; 
int dx[]={1,1,2,2,-1,-1,-2,-2};
int dy[]={2,-2,1,-1,2,-2,1,-1};
void add(int x,int y,int z,int d){
	if (x>0&&x<=n&&y>0&&y<=m&&a[x][y]!=2){
		if (a[x][y]==0) z++;
		if (z>f[x][y]||z==f[x][y]&&d>g[x][y]) return;
		f[x][y]=z;
		g[x][y]=d;
		if (!q[x][y]){
			b[++tail][0]=x;
			b[tail][1]=y;
			q[x][y]=true;
		}
	} 
}
void spfa(){
	int i,j,k,xx,yy,nx,ny;
	head=tail=0;
	add(sx,sy,0,0);
	while(head++<tail){
		xx=b[head][0];
		yy=b[head][1];
		for (int i=0;i<8;i++)
			add(xx+dx[i],yy+dy[i],f[xx][yy],g[xx][yy]+1); 
		q[xx][yy]=false;
	}
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	memset(f,127,sizeof(f));
	memset(g,127,sizeof(g));
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
	{
		scanf("%d",&a[i][j]);
		if (a[i][j]==3) sx=i,sy=j;
		if (a[i][j]==4) tx=i,ty=j;
	}
	spfa();
	if (f[tx][ty]<2000000000) printf("%d %d\n",f[tx][ty],g[tx][ty]);
	else printf("-1 -1\n"); 
	fclose(stdin);
	fclose(stdout);
	return 0;
}
