#include<bits/stdc++.h>
using namespace std;
int n,m,a[505][10005],f[505][10005];
bool check_1(){
	//�ж��� 
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
	if (a[i][j]) {
		int l=max(1,j-a[i][j]+1);
		int r=min(m,j+a[i][j]-1);
		for (int k=l;k<=r;k++) f[i][k]=1;
	} 
	//�ж��� 
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
	if (a[i][j]) {
		int l=max(1,i-a[i][j]+1);
		int r=min(n,i+a[i][j]-1);
		for (int k=l;k<=r;k++) 
			if (f[k][j]=1) f[k][j]=2;
	} 
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
	if (f[i][j]!=2) return false;//��ֱ�����ˮƽ����Ҫ�й����յ� �ж�f[i][j]�Ƿ�Ϊ2 
	return true; 
}
bool check(int x){
	//��ʼ��
	memset(f,0,sizeof(f)); 
	//�ж��� 
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
	if (a[i][j]>=x) {
		int l=max(1,j-x+1);
		int r=min(m,j+x-1);
		for (int k=l;k<=r;k++) f[i][k]=1;
	} 
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
	if (a[i][j]>=x) {
		int l=max(1,i-x+1);
		int r=min(n,i+x-1);
		for (int k=l;k<=r;k++) 
			if (f[k][j]=1) f[k][j]=2;
	} 
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
	if (f[i][j]!=2) return false;
	return true; 
}
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
	scanf("%d",&a[i][j]);
	if (!check_1()) printf("-1\n");
	else {
		for (int t=1;t<=1e9;t++)
		{
			if (check(t)) {
				printf("%d\n",t);
				break;
			}
		} 
	}
	fclose(stdin);
	fclose(stdout);	
	return 0;
}
