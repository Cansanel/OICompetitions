#include<bits/stdc++.h>
using namespace std;
struct p{
	double x,y;
}s[150];
void add(p a,p b,p &tmp){
	tmp.x=a.x+b.x;
	tmp.y=a.y+b.y;
} 
void minus(p a,p b,p &tmp){
	tmp.x=a.x-b.x;
	tmp.y=a.y-b.y;
} 
void mul(p a,p b,p &tmp){
	tmp.x=a.x*b.x-a.y*b.y;
	tmp.y=a.x*b.y+a.y*b.x;
}
bool dis(p a){
	double len=sqrt(a.x*a.x+a.y*a.y);
	if (len>=10) return false;
	return true;
} 
int yc,xc;
char ans[805][805];
double pq,q,sy,sx;
p flag;
void check(int px,int py,double x,double y){
	s[0].x=x;
	s[0].y=y;
	if (!dis(s[0])) {
		ans[px][py]=' ';
		return;
	}
	for (int i=1;i<=100;i++){
		mul(s[i-1],s[i-1],s[i]);
		add(s[i],flag,s[i]);
		if (!dis(s[i])) {
		ans[px][py]=' ';
		return;
		}
	}
	ans[px][py]='a';
	return;
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d%d",&yc,&xc);
	scanf("%lf%lf%lf%lf",&sy,&sx,&pq,&q);
	flag.x=pq;
	flag.y=q;
	for (int i=0;i<yc;i++)
		for (int j=0;j<xc;j++)
	check(i,j,sy+j*0.005,sx+i*0.01);
	for (int i=0;i<yc;i++){
		for (int j=0;j<xc;j++) cout<<ans[i][j];	
		printf("\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
