#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define maxn 310
#define ll long long
using namespace std;
double p,q,sx,sy;
int xc,yc;
bool check(double x,double y)
{
	double z[105][2];
	z[0][0]=x;
	z[0][1]=y;
	for(int i=1;i<=100;i++)
	{
		z[i][0]=z[i-1][0]*z[i-1][0]-z[i-1][1]*z[i-1][1]+p;
		z[i][1]=2.0*z[i-1][0]*z[i-1][1]+q;
		if(sqrt(z[i][0]*z[i][0]+z[i][1]*z[i][1])>=10)
		return false;
	}
	return true;
}
int main()
{
	freopen("fractal.in","r",stdin);
    freopen("fractal.out","w",stdout);
	scanf("%d%d%lf%lf",&yc,&xc,&sy,&sx);
	scanf("%lf%lf",&p,&q);
	for(int j=0;j<yc;j++)
	{
		for(int i=0;i<xc;i++)
		{
			double m=i*0.005,n=j*0.01;
			if(check(sy+m,sx+n)) printf("a");
			else printf(" ");
		}
		printf("\n");
	}
}

