#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define maxn 10010
#define ll long long
using namespace std;
int q[maxn],l;
int a[maxn<<3][5],b[maxn],d[maxn][2];
int dirx[8]={-2,-2,-1,-1,1,1,2,2},diry[8]={1,-1,2,-2,2,-2,1,-1};
int c[110][110];
int m,n,s,t,tot;
bool vis[maxn];
void fread(int &x)
{
	x=0;
	char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9')
	{
		x=x*10+c-48;
		c=getchar();
	}
}
bool cmp(int i,int j)
{
	if(d[i][0]<d[j][0]) return true;
	if(d[i][0]>d[j][0]) return false;
	return d[i][1]<d[j][1];
}
void swp(int &x,int &y)
{
	int t=x;
	x=y;
	y=t;
}
void pushin(int x)
{
	q[++l]=x;
	int now=l;
	while(now/2>=1&&cmp(q[now],q[now/2]))
	{ 
		swp(q[now],q[now/2]);
		now=now/2;
	}
}
void gettop()
{
	q[1]=q[l];
	l--;
	int now=1,mc;
	if(cmp(q[now<<1|1],q[now<<1])) mc=now<<1|1;
	else mc=now<<1;
	while(mc<=l&&cmp(q[mc],q[now]))
	{
		swp(q[now],q[mc]);
		now=mc;
		if(cmp(q[now<<1|1],q[now<<1])) mc=now<<1|1;
		else mc=now<<1;
	}
}
void add(int x,int y,int z1,int z2)
{
	tot++;
	a[tot][0]=x;
	a[tot][1]=y;
	a[tot][2]=z1;
	a[tot][3]=z2;
	a[tot][4]=b[x];
	b[x]=tot;
}
int calc(int x,int y)
{
	return (x-1)*n+y;
}
void dijstra()
{
	for(int i=1;i<=n*m;i++)
	d[i][0]=d[i][1]=inf;
	d[s][0]=d[s][1]=0;
	pushin(s);
	while(l>=1)
	{
		int u=q[1];
		gettop();
		if(vis[u]) continue;
		vis[u]=true;
		for(int i=b[u];i;i=a[i][4])
		{
			int v=a[i][1];
			if(d[v][0]>d[u][0]+a[i][2])
			{
				d[v][0]=d[u][0]+a[i][2];
				d[v][1]=d[u][1]+a[i][3];
				pushin(v);
			}
			if(d[v][0]==d[u][0]+a[i][2]&&d[v][1]>d[u][1]+a[i][3])
			{
				d[v][0]=d[u][0]+a[i][2];
				d[v][1]=d[u][1]+a[i][3];
				pushin(v);
			}
		}
	}
}
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	fread(m),fread(n);
	for(int i=1;i<=m;i++)
	for(int j=1;j<=n;j++)
	fread(c[i][j]);
	for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(c[i][j]==3) s=calc(i,j);
			if(c[i][j]==4) t=calc(i,j);
			for(int l=0;l<8;l++)
			{
				if(i+dirx[l]<1||i+dirx[l]>m||j+diry[l]<1||j+diry[l]>n) continue;
				if(c[i+dirx[l]][j+diry[l]]==2||c[i][j]==2) continue;
				if(c[i+dirx[l]][j+diry[l]]==0)
				add(calc(i,j),calc(i+dirx[l],j+diry[l]),1,1);
				else
				add(calc(i,j),calc(i+dirx[l],j+diry[l]),0,1);
			}
		}
	}
	dijstra();
	if(d[t][0]==inf) printf("-1 -1");
	else printf("%d %d",d[t][0],d[t][1]);
}

