#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define ll long long
using namespace std;
int n,m;
int c[510][10010][2];
int l[5000010][3],tot,mx;
void fread(int &x)
{
	x=0;
	char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9')
	{
		x=x*10+c-48;
		c=getchar();
	}
}
bool check(int x)
{
	memset(c,0,sizeof(c));
	for(int i=1;i<=tot;i++)
	{
		if(l[i][2]>=x)
		{
			int p=l[i][0],q=l[i][1];
			c[p][max(q-x+1,1)][0]+=1;
			c[p][min(q+x,m+1)][0]-=1;
			c[max(p-x+1,1)][q][1]+=1;
			c[min(p+x,n+1)][q][1]-=1;
		}
	}
	for(int i=1;i<=n;i++)
	{
		int t=0;
		for(int j=1;j<=m;j++)
		{
			t+=c[i][j][0];
			if(t<=0) return false;
		}
	}
	for(int i=1;i<=m;i++)
	{
		int t=0;
		for(int j=1;j<=n;j++)
		{
			t+=c[j][i][1];
			if(t<=0) return false;
		}
	}
	return true;
}
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	fread(n),fread(m);
	mx=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			int x;
			fread(x);
			if(x!=0)
			{
				mx=max(x,mx);
				l[++tot][0]=i;
				l[tot][1]=j;
				l[tot][2]=x;
			}
		}
	}
	for(int i=1;i<=mx;i++)
	{
		if(check(i))
		{
			printf("%d",i);
			return 0;
		}
	}
	printf("-1");
}

