#include<bits/stdc++.h>
#define rep(i,j,k) for(int (i)=(j);(i)<=(k);(i)++)
#define pb push_back
using namespace std;
typedef long long ll;
int n,m,a[105][105],sx,sy,ex,ey,f[105][105];bool vis[105][105];
int dx[8]={1,2,2,1,-1,-2,-2,-1},dy[8]={-2,-1,1,2,-2,-1,1,2},a1,a2;
struct node{
	int x,y,c;
	bool operator <(node s)const{
		return c>s.c;
	}
};
priority_queue<node> p;
int bfs1(int x,int y){
	p.push((node){x,y,0});int ans=99999;
	vis[x][y]=1;
	while(!p.empty()){
		node s=p.top();p.pop();
		if(s.x==ex&&s.y==ey) ans=min(ans,s.c);
		rep(i,0,7){
			node g=(node){s.x+dx[i],s.y+dy[i],s.c+(a[g.x][g.y]==0)};
			if(g.x<1||g.x>n||g.y<1||g.y>m||vis[g.x][g.y]||a[g.x][g.y]==2) continue;
			p.push(g);vis[g.x][g.y]=1;f[g.x][g.y]=f[s.x][s.y]+(a[g.x][g.y]==0);
		}
	}
	return ans==99999?-1:ans;
}
queue<node> q;
int bfs2(int x,int y){
	q.push((node){x,y,0});
	rep(i,0,n) rep(j,0,m) vis[i][j]=0;
	while(!q.empty()){
		node s=q.front();q.pop();
		if(s.x==ex&&s.y==ey) return s.c;
		rep(i,0,7){
			node g=(node){s.x+dx[i],s.y+dy[i],s.c+1};
			if(g.x<1||g.x>n||g.y<1||g.y>m||vis[g.x][g.y]||a[g.x][g.y]==2) continue;
			if(!((f[g.x][g.y]==f[s.x][s.y]&&a[g.x][g.y]!=0)||(f[g.x][g.y]==f[s.x][s.y]+1&&a[g.x][g.y]==0))) continue;
			q.push(g);vis[g.x][g.y]=1;
		}
	}
	return 0;
}
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,n) rep(j,1,m) {
		scanf("%d",&a[i][j]);
		if(a[i][j]==3) sx=i,sy=j;
		if(a[i][j]==4) ex=i,ey=j;
	}
	a1=bfs1(sx,sy);
	if(a1==-1){
		printf("-1 -1");
		return 0;
	}
	a2=bfs2(sx,sy);
	printf("%d %d",a1,a2);
	return 0;
}
