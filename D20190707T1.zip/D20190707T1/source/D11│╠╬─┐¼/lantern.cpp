#include<bits/stdc++.h>
#define rep(i,j,k) for(int (i)=(j);(i)<=(k);(i)++)
#define pb push_back
using namespace std;
typedef long long ll;
int a[505][10005],n,m,mx;bool h[505][10005],l[505][10005];
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,n)
	rep(j,1,m) scanf("%d",&a[i][j]),mx=max(mx,a[i][j]);
	rep(ans,1,mx){
		rep(i,1,n)
		rep(j,1,m)
		h[i][j]=l[i][j]=0;
		rep(i,1,n)
		rep(j,1,m){
			if(a[i][j]<ans) continue;
			rep(k,0,ans-1) h[i][max(j-k,1)]=h[i][min(j+k,m)]=1;
			rep(k,0,ans-1) l[max(i-k,1)][j]=l[min(i+k,n)][j]=1;
		}
		bool ok=1;
		rep(i,1,n)
		rep(j,1,m)
		ok&=(h[i][j]&l[i][j]);
		if(ok) {printf("%d\n",ans);return 0;}
	}
	printf("-1");
	return 0;
}
