#include<bits/stdc++.h>
#define rep(i,j,k) for(int (i)=(j);(i)<=(k);(i)++)
#define pb push_back
using namespace std;
typedef long long ll;
int yc,xc;
double p,q,sy,sx;char c[805][805];
struct comp{
	double x,y;
	comp operator +(comp r){
		return (comp){x+r.x,y+r.y};
	}
	comp operator -(comp r){
		return (comp){x-r.x,y-r.y};
	}
	comp operator *(comp r){
		return (comp){x*r.x-y*r.y,x*r.y+y*r.x};
	}
	double mc(){
		return sqrt(x*x+y*y);
	}
	bool sl(){
		comp z[105],c;
		c.x=p;c.y=q;
		z[0].x=x;z[0].y=y;
		rep(i,1,100){
			z[i]=z[i-1]*z[i-1]+c;
			if(z[i].mc()>=10) return 0;
		}
		return 1;
	}
};
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d%d%lf%lf%lf%lf",&yc,&xc,&sy,&sx,&p,&q);
	rep(j,0,yc-1)
	rep(i,0,xc-1){
		comp r=(comp){sy+i*0.005,sx+j*0.01};
		if(r.sl()) c[i][j]='a';
		else c[i][j]=' ';
		putchar(c[i][j]);if(i==xc-1) putchar('\n');
	}
	return 0;
}
