#include<bits/stdc++.h>
using namespace std;
int n,m,a[505][10005],r;
bool f[505][10005],flag[505][10005],f1[505][10005];
void ys(int x,int y,int z){
	for(int i=x-1;i>=x-z;i--){if(i<=0) break;flag[i][y]=1;}
	for(int i=x+1;i<=x+z;i++){if(i>n) break;flag[i][y]=1;}
	for(int i=y-1;i>=y-z;i--){if(i<=0) break;f[x][i]=1;}
	for(int i=y-1;i<=x+z;i++){if(i>m) break;f[x][i]=1;}
}
bool check(int x){
	memset(f,1,sizeof(f));
	memset(flag,1,sizeof(flag));
	memset(f1,0,sizeof(f1));
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(a[i][j]<x){
				f[i][j]=0;flag[i][j]=0;
			} else f1[i][j]=1;
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(f1[i][j]) ys(i,j,x-1);
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(!f[i][j] || !flag[i][j]) return 0;
		}
	}
	return 1;
}
int main( ){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>a[i][j];r=max(r,a[i][j]);
		}
	}
	int l=1,mid;
	while(l<=r){
		mid=(l+r)/2;
		if(check(mid)) r=mid-1;
		else l=mid+1;
	}
	cout<<l<<endl;return 0;
}
