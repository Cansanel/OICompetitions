#include<bits/stdc++.h>
using namespace std;
int m,n,a[105][105],aa,b,c,d;
int dx[8]={1,2,2,1,-1,-2,-2,-1},
	dy[8]={2,1,-1,-2,-2,-1,1,2};
bool f[105][105];
struct Node{
	int x,y,step,put;
	friend bool operator <(const Node &x,const Node &y){
		if(x.put==y.put) return x.step>y.step;return x.put>y.put;
	}
};
int main( ){
	freopen("lilypad.in","r",stdin);freopen("lilypad.out","w",stdout);
	cin>>m>>n;
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			cin>>a[i][j];if(a[i][j]==3){aa=i;b=j;}
		}
	}
	memset(f,0,sizeof(f));priority_queue<Node> q; q.push(Node{aa,b,0,0});
	while(!q.empty()){
		Node node=q.top();q.pop();//cout<<node.x<<" "<<node.y<<" "<<node.put<<" "<<node.step<<endl;
		if(f[node.x][node.y]) continue;f[node.x][node.y]=1;
		if(a[node.x][node.y]==4){cout<<node.put<<" "<<node.step<<endl;return 0;}
		for(int i=0;i<8;i++){
			int xx=node.x+dx[i],yy=node.y+dy[i];
			if(xx>0 && yy>0 && xx<=m && yy<=n && a[xx][yy]!=2){
				if(a[xx][yy]==0) q.push(Node{xx,yy,node.step+1,node.put+1});
				if(a[xx][yy]==1 || a[xx][yy]==4) q.push(Node{xx,yy,node.step+1,node.put});
			}
		}
	}
	cout<<-1<<" "<<-1<<endl;return 0;
}
/*
4 8
0 0 0 1 0 0 0 0
0 0 0 0 0 2 0 1
0 0 0 0 0 4 0 0
3 0 0 0 0 0 1 0
*/
