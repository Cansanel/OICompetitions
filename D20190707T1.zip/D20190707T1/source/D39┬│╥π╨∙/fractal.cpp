#include<bits/stdc++.h>
using namespace std;
int yc,xc;
double sy,sx,p,q;
char cc[805][805];
struct xs{double x,y;};
xs add(xs x,xs y){
	xs z;z.x=x.x+y.x;
	z.y=x.y+y.y;return z;
}
xs mul(xs x,xs y){
	xs z;z.x=x.x*y.x-x.y*y.y;
	z.y=x.x*y.y+x.y*y.x;return z;
}
double mc(xs x){return (double(sqrt(x.x*x.x+x.y*x.y)));}
bool sl(double x,double y){
	xs z[105],c;z[0]=xs{x,y};
	c.x=p;c.y=q;
	for(int i=1;i<=100;i++){
		z[i]=add(mul(z[i-1],z[i-1]),c);
		if(mc(z[i])>=(double(10))) return 0;
	}
	return 1;
}
int main( ){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx>>p>>q;
	for(int j=0;j<=yc;j++){
		for(int i=0;i<=xc;i++){
			if(sl(double(sy+double(i*0.005)),double(sx+double(j*0.01)))) cc[j][i]='a';
			else cc[j][i]=' ';
		}
	}
	for(int j=1;j<=yc;j++){
		for(int i=1;i<=xc;i++){
			cout<<cc[j-1][i-1];
		}
		cout<<endl;
	}
	return 0;
}
