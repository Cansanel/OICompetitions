#include <bits/stdc++.h>
#define ll long long
#define RG register
#define U(x, y, z) for(RG int x = y; x <= z; ++x)
#define D(x, y, z) for(RG int x = y; x >= z; --x)
using namespace std;
const int dx[8] = {-2, -2, -1, 1, -1, 1, 2, 2};
const int dy[8] = {1, -1, -2, -2, 2, 2, -1, 1}; 
inline void FO(string s){
	freopen((s + ".in").c_str(), "r", stdin);
	freopen((s + ".out").c_str(), "w", stdout);
}
template <typename T> inline void read(T &n){
	n = 0; char c; T f = 1;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) n = (n << 1) + (n << 3) + (c ^ 48);
	n *= f;
}
template <typename T> inline void write(T n){
	if (n < 0){
		n = -n;
		putchar('-');
	}
	if (n > 9) write(n / 10);
	putchar('0' + n % 10);
}
template <typename T> inline void chkmin(T &x, T y){
	x = x < y ? x : y;
}
template <typename T> inline void chkmax(T &x, T y){
	x = x > y ? x : y;
}
int a[110][110], n, m, head[500010], cnt, S, T, dist[500010], step[500010];
struct edge{
	int nxt, v, w;
}e[1000010];
inline void add_edge(int u, int v, int w){
	++cnt;
	e[cnt].v = v;
	e[cnt].w = w;
	e[cnt].nxt = head[u];
	head[u] = cnt;
}
int ans1;
priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > > Q, Q1;
int main(){
	//FO("");
	read(n), read(m);
	U(i, 1, n)
		U(j, 1, m)
			read(a[i][j]);
	U(i, 1, n)
		U(j, 1, m){	
			if (a[i][j] == 2) continue;
			int u = (i - 1) * m + j;
			if (a[i][j] == 3)  S = u;
			else if (a[i][j] == 4) T = u;
			U(k, 0, 7){
				int tx = i + dx[k];
				int ty = j + dy[k];
				int v = (tx - 1) * m + ty;
				if (a[tx][ty] != 2 && tx > 0 && tx <= n && ty > 0 && ty <= m){
					add_edge(u, v, a[tx][ty] != 0 ? 0 : 1);
					add_edge(v, u, a[i][j] != 0 ? 0 : 1);
				}
			}
		}
	memset(dist, 0x7f, sizeof dist);
	Q.push(make_pair(0, S));
	dist[S] = 0;
	while (!Q.empty()){
		pair<int, int> x = Q.top();
		Q.pop();
		if (x.first != dist[x.second]) continue ;
		if (x.second == T){
			ans1 = x.first;
			cout << x.first << " ";
			break;
		}
		for (int i = head[x.second]; i; i = e[i].nxt){
			int v = e[i].v;
			if (x.first + e[i].w < dist[v]){
				dist[v] = x.first + e[i].w;
				Q.push(make_pair(dist[v], v)); 
			}
		}
	}
	memset(step, 0x7f, sizeof step);
	Q1.push(make_pair(0, S));
	step[S] = 0;
	while (!Q1.empty()){
		pair<int, int> x = Q1.top();
		Q1.pop();
		if (x.first != step[x.second]) continue;
		if (x.second == T){
			cout << x.first << endl;
			return 0;
		}
		for (int i = head[x.second]; i; i = e[i].nxt){
			int v = e[i].v;
			if (x.first + 1 < step[v] && dist[v] <= ans1){
				step[v] = x.first + 1;
				Q1.push(make_pair(step[v], v)); 
			}
		}
	}
	return 0;
}
