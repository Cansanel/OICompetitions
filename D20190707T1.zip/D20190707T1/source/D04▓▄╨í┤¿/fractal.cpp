#include <bits/stdc++.h>
#define ll long long
#define RG register
#define U(x, y, z) for(RG int x = y; x <= z; ++x)
#define D(x, y, z) for(RG int x = y; x >= z; --x)
using namespace std;
inline void FO(string s){
	freopen((s + ".in").c_str(), "r", stdin);
	freopen((s + ".out").c_str(), "w", stdout);
}
template <typename T> inline void read(T &n){
	n = 0; char c; T f = 1;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) n = (n << 1) + (n << 3) + (c ^ 48);
	n *= f;
}
template <typename T> inline void write(T n){
	if (n < 0){
		n = -n;
		putchar('-');
	}
	if (n > 9) write(n / 10);
	putchar('0' + n % 10);
}
template <typename T> inline void chkmin(T &x, T y){
	x = x < y ? x : y;
}
template <typename T> inline void chkmax(T &x, T y){
	x = x > y ? x : y;
}
int yc, xc;
double sy, sx, P, Q;
struct fs{
	double x, y;
};	
fs Mat(fs a, fs b){
	fs c;
	c.x = a.x * b.x - a.y *b.y;
	c.y = a.x * b.y + a.y * b.x;
	return c;
}
fs Add(fs a, fs b){
	fs c;
	c.x = a.x + b.x;
	c.y = a.y + b.y;
	return c;
}
fs jian(fs a, fs b){
	fs c;
	c.x = a.x - b.x;
	c.y = a.y - b.y;
	return c;
}
double mc(fs a){
	return sqrt(a.x * a.x + a.y * a.y);
}
bool check(fs a){
	fs z[101];
	z[0] = a; 
	fs c;
	c.x = P;
	c.y = Q;
	if (mc(z[0]) > 10) return 0;
	U(i, 1, 100){
		z[i] = Add(Mat(z[i - 1], z[i - 1]), c);
		if (mc(z[i]) > 10) return 0;
	}
	return 1;
}
int main(){
	FO("fractal");
	cin >>  yc >> xc >> sy >> sx >> P >> Q;
	U(j, 0, yc - 1){
		U(i, 0, xc - 1){
			fs y;
			y.x = sy + i * 0.005;
			y.y = sx + j * 0.01;
			if (check(y)) putchar('a');
			else putchar(' ');
		}
		putchar('\n');
	}
	return 0;
}

