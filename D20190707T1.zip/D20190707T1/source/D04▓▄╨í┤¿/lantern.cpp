#include <bits/stdc++.h>
#define ll long long
#define RG register
#define U(x, y, z) for(RG int x = y; x <= z; ++x)
#define D(x, y, z) for(RG int x = y; x >= z; --x)
using namespace std;
inline void FO(string s){
	freopen((s + ".in").c_str(), "r", stdin);
	freopen((s + ".out").c_str(), "w", stdout);
}
template <typename T> inline void read(T &n){
	n = 0; char c; T f = 1;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) n = (n << 1) + (n << 3) + (c ^ 48);
	n *= f;
}
template <typename T> inline void write(T n){
	if (n < 0){
		n = -n;
		putchar('-');
	}
	if (n > 9) write(n / 10);
	putchar('0' + n % 10);
}
template <typename T> inline void chkmin(T &x, T y){
	x = x < y ? x : y;
}
template <typename T> inline void chkmax(T &x, T y){
	x = x > y ? x : y;
}
int n, m;
int a[510][10010];
int up[510][10010], dn[510][10010], lf[510][10010], rg[510][10010], ne[510][10010];
int main(){
	FO("lantern");
	read(n), read(m);
	U(i, 1, n)    	
		U(j, 1, m)
			read(a[i][j]);
	U(i, 1, n){
		int lalt = INT_MIN / 2;
		U(j, 1, m){
			if (a[i][j]) lalt = j;
			lf[i][j] = j - lalt + 1;
		}
	}
	U(i, 1, n){
		int lalt = INT_MAX;
		D(j, m, 1){
			if (a[i][j]) lalt = j;
			rg[i][j] = lalt - j + 1;
		}
	}
	U(j, 1, m){
		int lalt = INT_MIN / 2;
		U(i, 1, n){
			if (a[i][j]) lalt = i;
			up[i][j] = i - lalt + 1;
		}
	}
	U(j, 1, m){
		int lalt = INT_MAX;
		D(i, n, 1){
			if (a[i][j]) lalt = i;
			dn[i][j] = lalt - i + 1;
		}
	}
	int ans = 0;
	U(i, 1, n)
		U(j, 1, m)
			ne[i][j] = min(min(up[i][j], dn[i][j]), min(lf[i][j], rg[i][j]));
	U(i, 1, n)
		U(j, 1, m)
			chkmax(ans, ne[i][j]);
	cout << ans << endl;
	return 0;
}
