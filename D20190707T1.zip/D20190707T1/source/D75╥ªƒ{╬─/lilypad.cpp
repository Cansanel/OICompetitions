#include<bits/stdc++.h>
using namespace std;
int mp[105][105],n,m,startx,starty,endx,endy,zx[]={-2,-1,+1,+2,-1,-2,+1,+2};
int                                          zy[]={-1,-2,-2,-1,+2,+1,+2,+1},dis[105][105],dist[105][105];
queue<pair<int,int> >q;
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			dist[i][j]=1000005;
			dis[i][j]=1000005;
		}
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			cin>>mp[i][j];
			if(mp[i][j]==3){
				startx=i,starty=j;
				mp[i][j]=1;
			}
			if(mp[i][j]==4){
				endx=i,endy=j;
				mp[i][j]=1;
			}
		}
	}
	dist[startx][starty]=0;
	dis[startx][starty]=0;
	q.push(make_pair(startx,starty));
	while(!q.empty()){
		pair<int,int>u=q.front();
		q.pop();
		int x=u.first,y=u.second;
		for(int i=0;i<8;i++){
			if(x+zx[i]<0||x+zx[i]>=n||y+zy[i]<0||y+zy[i]>=m){
				continue;
			}
			if(mp[x+zx[i]][y+zy[i]]==2)
				continue;
			if(dis[x][y]+(mp[x+zx[i]][y+zy[i]]^1)<dis[x+zx[i]][y+zy[i]]){
				dis[x+zx[i]][y+zy[i]]=dis[x][y]+(mp[x+zx[i]][y+zy[i]]^1);
				dist[x+zx[i]][y+zy[i]]=dist[x][y]+1;
				q.push(make_pair(x+zx[i],y+zy[i]));
			}
			if(dis[x][y]+(mp[x+zx[i]][y+zy[i]]^1)==dis[x+zx[i]][y+zy[i]]&&dist[x][y]+1<dist[x+zx[i]][y+zy[i]]){
				dist[x+zx[i]][y+zy[i]]=dist[x][y]+1;
				q.push(make_pair(x+zx[i],y+zy[i]));
			}
		}
	}
	if(dis[endx][endy]==1000005)
	puts("-1 -1");
	else
	cout<<dis[endx][endy]<<" "<<dist[endx][endy]<<endl;
	return 0;
}
