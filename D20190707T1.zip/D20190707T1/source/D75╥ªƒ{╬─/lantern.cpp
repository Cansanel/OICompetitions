#include<bits/stdc++.h>
using namespace std;
int n,m,r=0,mp[505][10005];
bool pdmpx[505][10005],pdmpy[505][10005];
vector<pair<int,int> >wz;
bool pd(int x){
	for(int y=0;y<wz.size();y++){
		if(mp[wz[y].first][wz[y].second]<x)
		continue;
		for(int i=max(wz[y].first-x+1,0);i<=min(n,wz[y].first+x-1);i++){
			pdmpx[i][wz[y].second]=true;
		}
		for(int i=max(wz[y].second-x+1,0);i<=min(wz[y].second+x-1,n);i++){
			pdmpy[wz[y].first][i]=true;
		}
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			if((!pdmpx[i][j])||(!pdmpy[i][j]))
			return false;
		}
	}
	return true;
}
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			cin>>mp[i][j];
			r=max(r,mp[i][j]);
			if(mp[i][j]>0){
				wz.push_back(make_pair(i,j));
			}
		}
	}
	for(int i=1;i<=r;i++){
		memset(pdmpx,0,sizeof pdmpx);
		memset(pdmpy,0,sizeof pdmpy);
		if(pd(i)){
			cout<<i<<endl;
			return 0;
		}
	}
	cout<<-1<<endl;
	return 0;
}
