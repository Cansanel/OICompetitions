#include<bits/stdc++.h>
using namespace std;
char c[805][805];
long long yc,xc;
long double sy,sx,p,q;
struct cplx{
	long double x,y;
};
cplx ad(cplx a,cplx b){
	cplx c;
	c.x=a.x+b.x,c.y=a.y+b.y;
	return c;
}
cplx ji(cplx a,cplx b){
	cplx c;
	c.x=a.x-b.x,c.y=a.y-b.y;
	return c;
}
cplx ch(cplx a,cplx b){
	cplx c;
	c.x=a.x*b.x-a.y*b.y,c.y=a.x*b.y+a.y*b.x;
	return c;
}
long double mc(cplx a){
	if(a.y==0)
	return abs(a.x);
	return sqrt(a.x*a.x+a.y*a.y);
}
struct point{
	long double p,q;
	cplx c;
	cplx z[101];
};
bool init(long double x,long double y){
	point ans;
	ans.p=p,ans.q=q;
	ans.c.x=p,ans.c.y=q;
	ans.z[0].x=x,ans.z[0].y=y;
	if(mc(ans.z[0])>=10)
	return false;
	for(int i=1;i<=100;i++){
		ans.z[i]=ad(ch(ans.z[i-1],ans.z[i-1]),ans.c);
		if(mc(ans.z[i])>=10){
			return false;
		}
	}
	return true;
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx>>p>>q;
	for(int j=0;j<yc;j++){
		for(int i=0;i<xc;i++){
			if(init(sy+i*0.005,sx+j*0.01)){
				c[j][i]='a';
			}else{
				c[j][i]=' ';
			}
		}
	}
	for(int i=0;i<yc;i++){
		for(int j=0;j<xc;j++){
			putchar(c[i][j]);
		}
		puts("");
	}
	return 0;
}
