#include<bits/stdc++.h>
using namespace std;

int yc, xc;
double sy, sx, p, q;
char c[805][805];
struct fushu{
	double x, y;
	fushu operator +(const fushu &b){
		fushu d;
		d.x = x + b.x;
		d.y = y + b.y;
		return d;
	}
	fushu operator -(const fushu &b){
		fushu d;
		d.x = x - b.x;
		d.y = y - b.y;
		return d;
	}
	fushu operator *(const fushu &b){
		fushu d;
		d.x = x * b.x - y * b.y;
		d.y = x * b.y + y * b.x;
		return d;
	}
};
double molen(fushu a){
	return sqrt(a.x * a.x + a.y * a.y);
}
bool shoulian(double x, double y){
	fushu c, z[105];
	c.x = p; c.y = q;
	z[0].x = x; z[0].y = y;
	for(int i = 1; i <= 100; ++ i){
		z[i] = (z[i-1] * z[i-1]) + c;
		if(molen(z[i]) >= 10)
			return false;
	}
	return true;
}
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d%d%lf%lf%lf%lf", &yc, &xc, &sy, &sx, &p, &q);
	for(int j = 0; j < yc; ++ j){
		for(int i = 0; i < xc; ++ i){
			double y = sy + (double)i * 0.005;
			double x = sx + (double)j * 0.01;
			if(shoulian(y, x)){
				c[j][i] = 'a';
			}
			else {
				c[j][i] = ' ';
			}
		}
	}
	for(int i = 0; i < yc; ++ i){
		for(int j = 0; j < xc; ++ j){
			printf("%c", c[i][j]);
		}
		printf("\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
