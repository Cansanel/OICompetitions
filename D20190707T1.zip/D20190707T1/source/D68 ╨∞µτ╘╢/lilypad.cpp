#include<bits/stdc++.h>
using namespace std;
const int S = 100 + 5;
int m, n, mp[S][S], s, t;
int nx[10] = {0, 1, 2, 2, 1, -1, -2, -2, -1}, ny[10] = {0, 2, 1, -1, -2, -2, -1, 1, 2};
int head[S * S], nxt[S * S * 8 * 2], to[S * S * 8 * 2], val[S * S * 8 * 2], tot;
void add(int x, int y, int z){
	to[++ tot] = y;
	val[tot] = z;
	nxt[tot] = head[x];
	head[x] = tot;
}
struct Node{
	int x, step, cost;
	bool operator < (const Node &b)const{
		return cost > b.cost;
	}
};
priority_queue<Node> q;
int d[S * S], step[S * S];
bool v[S * S];
void Dij(){
	memset(d, 0x3f, sizeof(d));
	memset(step, 0x3f, sizeof(step));
	d[s] = 0; step[s] = 0;
	q.push((Node){s, 0, 0});
	while(!q.empty()){
		int x = q.top().x;
		q.pop();
		if(v[x]) continue;
		v[x] = true;
		for(int i = head[x]; i; i = nxt[i]){
			int y = to[i], z = val[i];
			if(d[x] + z <= d[y]){
				d[y] = d[x] + z;
				if(step[y] > step[x] + 1){
					step[y] = step[x] + 1;
				}
				q.push((Node){y, step[y], d[y]});
				
//				printf("(%d,%d)-->(%d,%d)  %d   %d\n",x/n,x%n,y/n,y%n,step+1,d[y]);
			}
		}
	}
	return;
}
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	scanf("%d%d", &m, &n);
	for(int i = 1; i <= m; ++ i){
		for(int j = 1; j <= n; ++ j){
			scanf("%d", &mp[i][j]);
			if(mp[i][j] == 3){
				s = i * n + j;
			}
			if(mp[i][j] == 4){
				t = i * n + j;
			}
		}
	}
	for(int i = 1; i <= m; ++ i){
		for(int j = 1; j <= n; ++ j){
			for(int k = 1; k <= 8; ++k){
				int x = i + nx[k], y = j + ny[k];
				if(x < 1 || x > m || y < 1 || y > n) continue;
				int num1 = i * n + j, num2 = x * n + y;
				if(mp[x][y] == 0){
					add(num1, num2, 1);
				}
				if(mp[x][y] == 1 || mp[x][y] == 3 || mp[x][y] == 4){
					add(num1, num2, 0);
				}
			}
		}
	}
//	for(int i = head[18]; i; i = nxt[i]){
//		int y = to[i], z = val[i];
//		printf("%d %d    %d\n",y/n,y%n,z);
//	}
	Dij();
	if(d[t] == d[0]){
		printf("-1");
	}
	else {
		printf("%d %d", d[t], step[t]);
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
