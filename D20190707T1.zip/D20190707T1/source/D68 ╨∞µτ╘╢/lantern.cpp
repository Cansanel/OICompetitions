#include<bits/stdc++.h>
using namespace std;
int n, m, a;
int dx[5000005], dy[5000005];
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	printf("-1");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
