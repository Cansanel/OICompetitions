#include <bits/stdc++.h>
using namespace std;
int yc,xc;
double sy,sx,p,q;
char a[805][805];
double z1[101],z2[101];
inline double getnum(double x,double y)
{
	return sqrt(x*x+y*y);
}
inline bool check(double x,double y){
	z1[0]=x;z2[0]=y;
	if(getnum(x,y)>=10)return 0;
	for(int i=1;i<=100;i++){
		z1[i]=z1[i-1]*z1[i-1]-z2[i-1]*z2[i-1]+p;
		z2[i]=z1[i-1]*z2[i-1]*2+q;
		if(getnum(z1[i],z2[i])>=10)return 0;
	}
	return 1;
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx>>p>>q;
	for(int j=0;j<yc;j++)
		for(int i=0;i<xc;i++)
			if(check(sy+i*0.005,sx+j*0.01)==1)a[j][i]='a';
			else a[j][i]=' ';
	for(int j=0;j<yc;j++){
		for(int i=0;i<xc;i++)
			putchar(a[j][i]);
			printf("\n");
	}
	return 0;
		
}
