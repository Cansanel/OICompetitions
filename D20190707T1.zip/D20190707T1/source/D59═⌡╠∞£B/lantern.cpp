#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int num=0,zf=1;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-')zf=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		num=num*10+c-48;
		c=getchar();
	}
	return num*zf;
}
int n,m;
int a[505][10005];
bool h[505][10005];
bool s[505][10005];
inline bool check(int x){
	memset(h,0,sizeof(0));
	memset(s,0,sizeof(s));
	for(register int i=1;i<=n;i++)
	for(register int j=1;j<=m;j++)
	{
		if(a[i][j]<x)continue;
		for(register int k=max(j-x+1,0);k<=min(j+x-1,m);k++)
			h[i][k]=1;
		for(register int k=max(i-x+1,0);k<=min(i+x-1,n);k++)
			s[k][j]=1;
	}
	for(register int i=1;i<=n;i++)
		for(register int j=1;j<=m;j++)
		if(h[i][j]==0||s[i][j]==0)
			return 0;
	return 1;
}
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	n=read();m=read();
	int maxnum=0;
	for(register int i=1;i<=n;i++)
		for(register int j=1;j<=m;j++)
			a[i][j]=read(),maxnum=max(maxnum,a[i][j]);
	int l=1,r=min(max(n,m),maxnum),ans=1e9+10;
	while(l<=r){
		int mid=(l+r)/2;
		if(check(mid)==1)r=mid-1,ans=min(ans,mid);
		else l=mid+1;
	}
	if(ans==1e9+10)ans=-1;
	printf("%d\n",ans);
	return 0;
}

