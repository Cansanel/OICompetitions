#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int num=0,zf=1;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-')zf=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		num=num*10+c-48;
		c=getchar();
	}
	return num*zf;
}
int n,m;
int a[105][105];
int minnum[105][105];
int mindis[105][105];
int xx,yy,tox,toy;
int dx[]={1,-1,1,-1,2,-2,2,-2};
int dy[]={2,2,-2,-2,1,1,-1,-1};
inline void jkl(int x,int y,int num,int dis)
{
	if(num>minnum[x][y]||num>minnum[tox][toy])return ;
	if(minnum[x][y]==num&&dis>=mindis[x][y])return ;
	minnum[x][y]=num;
	mindis[x][y]=dis;
	if(x==tox&&y==toy)return ;
	for(register int i=0;i<8;i++)
	{
		int fx=x+dx[i],fy=y+dy[i];
		if(fx<1||fy<1||fx>m||fy>n)continue;
		if(a[fx][fy]==2)continue;
		if(a[fx][fy]==1)jkl(fx,fy,num,dis+1);
		if(a[fx][fy]==0)jkl(fx,fy,num+1,dis+1);
	}
	return ;
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	memset(minnum,1000001,sizeof(minnum));
	memset(mindis,1000001,sizeof(mindis));
	m=read();n=read();
	for(register int i=1;i<=m;i++)
		for(register int j=1;j<=n;j++)
		{
			a[i][j]=read();
			if(a[i][j]==3)xx=i,yy=j,a[i][j]=2;
			if(a[i][j]==4)tox=i,toy=j,a[i][j]=1;
		}
	jkl(xx,yy,0,0);
	if(mindis[tox][toy]==1000001)mindis[tox][toy]=minnum[tox][toy]=-1;
	printf("%d %d\n",minnum[tox][toy],mindis[tox][toy]);
	return 0;
}
