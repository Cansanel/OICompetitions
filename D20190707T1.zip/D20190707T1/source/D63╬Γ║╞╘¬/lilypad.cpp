#include <bits/stdc++.h>
using namespace std;

#define INF 0x3F3F3F3F

const int dirx[9] = { 0,-2,-2,-1,-1,1,1,2,2 };
const int diry[9] = { 0,-1,1,-2,2,-2,2,-1,1 };

struct position
{
	int x, y;
};
queue<position> q, sav;

int dis[110][110];

bool operator>(position a, position b)
{
	return dis[a.x][a.y] > dis[b.x][b.y];
}

int m, n, stx, sty, finx, finy, ans, nx, ny, cnt;
int a[110][110], f[110][110];
bool vis[110][110];
position pr[110][110];
vector<position> g[110][110];
vector<int> c[110][110];
priority_queue<position, vector<position>, greater<position> > p;

position mp(int x, int y)
{
	position p;
	p.x = x; p.y = y;
	return p;
}

bool inbound(int x, int y)
{
	return x >= 1 && y >= 1 && x <= m && y <= n;
}

int main()
{
	freopen("lilypad.in", "r", stdin);
	freopen("lilypad.out", "w", stdout);
	ios::sync_with_stdio(false);
	
	cin >> m >> n;
	for (int i = 1; i <= m; i++)
		for (int j = 1; j <= n; j++)
		{
			cin >> a[i][j];
			if (a[i][j] == 3)
			{
				stx = i; sty = j;
			}
			if (a[i][j] == 4)
			{
				finx = i; finy = j;
			}
		}
	for (int i = 1; i <= m; i++)
		for (int j = 1; j <= n; j++)
		{
			for (int k = 1; k <= 8; k++)
			{
				nx = i + dirx[k], ny = j + diry[k];
				if (inbound(nx, ny))
				{
					g[i][j].push_back(mp(nx, ny));
					if (a[nx][ny] == 0)
						c[i][j].push_back(1);
					else if (a[nx][ny] == 2)
							 c[i][j].push_back(INF);
						 else c[i][j].push_back(0);
				}
			}
		}
	memset(dis, 0x3F, sizeof(dis));
	p.push(mp(stx, sty));
	dis[stx][sty] = 0;
	nx = 0; ny = 0;
	ans = INF;
	while (!p.empty())
	{
		position now;
		do
		{
			now = p.top();
			p.pop();
		} while (vis[now.x][now.y]);
		vis[now.x][now.y] = true;
		//cout << now.x << " " << now.y << " " << dis[now.x][now.y] << endl;
		if (now.x == finx && now.y == finy)
		{
			ans = dis[now.x][now.y];
			nx = now.x; ny = now.y;
			cout << dis[now.x][now.y] << " ";
			//delete endl
			break;
		}
		for (int i = 0; i < g[now.x][now.y].size(); i++)
		{
			position nxt = g[now.x][now.y][i];
			if (dis[now.x][now.y] + c[now.x][now.y][i] < dis[nxt.x][nxt.y])
			{
				dis[nxt.x][nxt.y] = dis[now.x][now.y] + c[now.x][now.y][i];
				pr[nxt.x][nxt.y] = mp(now.x, now.y);
				p.push(nxt);
			}
		}
	}
	if (ans == INF)
	{
		cout << "-1 -1" << endl;
		return 0;
	}
	while (nx != stx || ny != sty)
	{
		cnt++;
		position nxt = pr[nx][ny];
		nx = nxt.x; ny = nxt.y;
		//cout << nx << " " << ny << endl;
	}
	cout << cnt << endl;
	
	return 0;
}

