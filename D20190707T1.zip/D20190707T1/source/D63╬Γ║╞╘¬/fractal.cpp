#include <bits/stdc++.h>
using namespace std;

double P, Q, Sy, Sx;
int yc, xc;

struct position
{
	double x, y;
};

position mp(double x, double y)
{
	position A;
	A.x = x; A.y = y;
	return A;
}

position operator+(position A, position B)
{
	position C;
	C.x = A.x + B.x;
	C.y = A.y + B.y;
	return C;
}

position operator-(position A, position B)
{
	position C;
	C.x = A.x - B.x;
	C.y = A.y - B.y;
	return C;
}

position operator*(position A, position B)
{
	position C;
	C.x = A.x * B.x - A.y * B.y;
	C.y = A.x * B.y + A.y * B.x;
	return C;
}

double modlen(position A)
{
	return sqrt(A.x * A.x + A.y * A.y);
}

bool check(position A)
{
	position c = mp(P, Q);
	position z[110];
	z[0] = mp(A.x, A.y);
	for (int i = 1; i <= 100; i++)
	{
		z[i] = (z[i - 1] * z[i - 1]) + c;
		if (modlen(z[i]) > 10) return false;
	}
	return true;
}

char c[1010][1010];

int main()
{
	freopen("fractal.in", "r", stdin);
	freopen("fractal.out", "w", stdout);
	ios::sync_with_stdio(false);
	
	cin >> yc >> xc >> Sy >> Sx;
	cin >> P >> Q;
	for (int j = 0; j < yc; j++)
		for (int i = 0; i < xc; i++)
			if (check(mp(Sy + i * 0.005, Sx + j * 0.01)))
				c[j][i] = 'a';
			else c[j][i] = ' ';
	for (int j = 0; j < yc; j++)
	{
		for (int i = 0; i < xc; i++)
			cout << c[j][i];
		cout << endl;
	}
	
	return 0;
}

