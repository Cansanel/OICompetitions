#include <bits/stdc++.h>
using namespace std;

vector<int> gl[10010], gc[10010], ll[10010], lc[10010];
int a[510][10010], d[10010];
int n, m;

bool check(int x)
{
	for (int i = 1; i <= n; i++)
	{
		memset(d, 0, sizeof(d));
		for (int j = 0; j < gl[i].size(); j++)
		{
			int posi = gl[i][j], lvl = ll[i][j];
			if (ll[i][j] >= x)
			{
				d[max(1, posi - x + 1)]++;
				d[min(m + 1, posi + x)]--;
			}
		}
		for (int j = 1; j <= m; j++)
		{
			d[j] += d[j - 1];
			if (d[j] <= 0)
			{
				//cout << "Check: " << x << " Position (Row) " << i << " " << j << " Return false" << endl;
				return false;
			}
		}
		
	}
	for (int i = 1; i <= m; i++)
	{
		memset(d, 0, sizeof(d));
		for (int j = 0; j < gc[i].size(); j++)
		{
			int posi = gc[i][j], lvl = lc[i][j];
			if (lc[i][j] >= x)
			{
				d[max(1, posi - x + 1)]++;
				d[min(n + 1, posi + x)]--;
			}
		}
		for (int j = 1; j <= n; j++)
		{
			d[j] += d[j - 1];
			if (d[j] <= 0) 
			{
				//cout << "Check: " << x << " Position (Column) " << j << " " << i << " Return false" << endl;
				return false;
			}
		}
	}
	return true;
}

int main()
{
	freopen("lantern.in", "r", stdin);
	freopen("lantern.out", "w", stdout);
	ios::sync_with_stdio(false);
	
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
		{
			cin >> a[i][j];
			gl[i].push_back(j);
			ll[i].push_back(a[i][j]);
			gc[j].push_back(i);
			lc[j].push_back(a[i][j]);
		}
	for (int k = 1; k <= max(n, m); k++)
		if (check(k))
		{
			cout << k << endl;
			return 0;
		}
	cout << -1 << endl;
	
	return 0;
}

