#include <bits/stdc++.h>
using namespace std;
int xc,yc;
double sy,sx,p,q;
struct num{
	double l,r;
	num(double x=0,double y=0){l=x,r=y;}
} z[105],c;
inline num operator+(num x,num y){return num(x.l+y.l,x.r+y.r);}
inline num operator-(num x,num y){return num(x.l-y.l,x.r-y.r);}
inline num operator*(num x,num y){return num(x.l*y.l-x.r*y.r,x.l*y.r+x.r*y.l);}
inline void work(double x,double y){
	z[0]=num(x,y);bool a=1;
	if(z[0].l*z[0].l+z[0].r*z[0].r>=100.0){
		cout<<' ';return;
	}
	for(int i=1;i<=100;i++){
		z[i]=z[i-1]*z[i-1],z[i]=z[i]+c;
		if(z[i].l*z[i].l+z[i].r*z[i].r>=100.0){
			a=0;break;
		}
	}
	a?cout<<'a':cout<<' ';
}
int main(){
	int xx,yy,aa=0;
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d%d%lf%lf%lf%lf",&yc,&xc,&sy,&sx,&p,&q);
	c=num(p,q);
	for(double j=1;j<=yc;j+=1.0){
		for(double i=1;i<=xc;i+=1.0)
			work(sy+0.005*i,sx+0.01*j);
		puts("");
	}
	return 0;
}
