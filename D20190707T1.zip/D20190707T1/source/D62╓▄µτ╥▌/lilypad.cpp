#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,y=1;char c=getchar();
	while((c<'0'||c>'9')&&c!='-') c=getchar();
	if(c=='-') y=-1,c=getchar();
	while(c>='0'&&c<='9') x=(x<<3)+(x<<1)+c-'0',c=getchar();
	return x*y;
}
const int N=100005;
int n,m,p[105][105],dis[N],mid,s,t,len[N],ans;
int ver[N<<1],nxt[N<<1],edge[N<<1],head[N],tot=1;
inline void add(int x,int y,int z){
	ver[++tot]=y;edge[tot]=z;nxt[tot]=head[x];head[x]=tot;
	ver[++tot]=x;edge[tot]=z;nxt[tot]=head[y];head[y]=tot;
}
inline void work(int x0,int y0,int x,int y){
	if(x<1||y<1||x>n||y>m||p[x][y]==2) return;
	if(p[x][y]==0)
		add((x0-1)*m+y0,(x-1)*m+y,1);
	else add((x0-1)*m+y0,(x-1)*m+y,0);
}
queue<int> q;bool vis[N];
void spfa(){
	memset(vis,0,sizeof(vis));
	memset(dis,0x3f,sizeof(dis));
	while(!q.empty()) q.pop();
	q.push(s);vis[s]=1;dis[s]=0;
	while(!q.empty()){
		int x=q.front();q.pop();vis[x]=0;
		for(int i=head[x];i;i=nxt[i]){
			int y=ver[i];
			if(dis[x]+edge[i]<dis[y]){
				dis[y]=dis[x]+edge[i];
				if(vis[y]) continue;
				vis[y]=1;q.push(y);
			}
		}
	}
}
void spfa2(){
	memset(vis,0,sizeof(vis));
	memset(dis,0x3f,sizeof(dis));
	memset(len,0x3f,sizeof(len));
	while(!q.empty()) q.pop();
	q.push(s);vis[s]=1;dis[s]=0;len[s]=0;
	while(!q.empty()){
		int x=q.front();q.pop();vis[x]=0;
		for(int i=head[x];i;i=nxt[i]){
			int y=ver[i];
			if(dis[x]+edge[i]>ans) continue;
			if(len[y]>len[x]+1){
				len[y]=len[x]+1;
				dis[y]=dis[x]+edge[i];
				if(vis[y]) continue;
				vis[y]=1,q.push(y);
			}
		}
	}
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			p[i][j]=read();
			if(p[i][j]==2) continue;
			work(i,j,i-1,j-2);
			work(i,j,i-2,j-1);
			work(i,j,i-1,j+2);
			work(i,j,i-2,j+1);
			if(p[i][j]==3) s=(i-1)*m+j;
			if(p[i][j]==4) t=(i-1)*m+j;
		}
	spfa();ans=dis[t];
	if(ans>100000){
		puts("-1 -1");
		return 0;
	}
	printf("%d ",ans);
	spfa2();
	printf("%d\n",len[t]);
	return 0;
}
