#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,y=1;char c=getchar();
	while((c<'0'||c>'9')&&c!='-') c=getchar();
	if(c=='-') y=-1,c=getchar();
	while(c>='0'&&c<='9') x=(x<<3)+(x<<1)+c-'0',c=getchar();
	return x*y;
}
int n,m,p[10005][505],cx[10005][505],cy[10005][505];
int sumx[10005],sumy[10005];
inline void lit1(int x1,int x2,int y){
	if(x1<1) x1=1; if(x2>m) x2=m;
	cx[x1][y]++;
	if(x2+1<=m) cx[x2+1][y]--;
	if(y+1<=n) cx[x1][y+1]--;
	if(x2+1<=m&&y+1<=n) cx[x2+1][y+1]++;
}
inline void lit2(int x,int y1,int y2){
	if(y1<1) y1=1; if(y2>n) y2=n;
	cy[x][y1]++;
	if(x+1<=m) cy[x+1][y1]--;
	if(y2+1<=n) cy[x][y2+1]--;
	if(x+1<=m&&y2+1<=n) cy[x+1][y2+1]++;
}
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			p[j][i]=read();
	if(m>1000){
		puts("-1");return 0;
	}
	for(int mid=1;mid<=m;mid++){
		memset(cx,0,sizeof(cx));
		memset(cy,0,sizeof(cy));
		for(int j=1;j<=n;j++)
			for(int i=1;i<=m;i++){
				if(p[i][j]<mid) continue;
				lit1(i-mid+1,i+mid-1,j);
				lit2(i,j-mid+1,j+mid-1);
			}
		memset(sumx,0,sizeof(sumx));
		memset(sumy,0,sizeof(sumy));
		bool im=1;
		for(int j=1;j<=n;j++){
			for(int i=1;i<=m;i++){
				sumx[i]+=sumx[i-1]+cx[i][j];
				sumy[i]+=sumy[i-1]+cy[i][j];
				if(sumx[i]<1||sumy[i]<1){
					im=0;break;
				}
			}
			if(!im) break;
		}
		if(im){printf("%d\n",mid);return 0;}
	}
	puts("-1");return 0;
}
