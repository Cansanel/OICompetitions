#include <bits/stdc++.h>

using namespace std;

const int maxn = 510, maxm = 1e4 + 10;

int n, m;
int vis1[maxn][maxm], vis2[maxn][maxm];
int a[maxn][maxm];

inline bool check(int x){
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++) vis1[i][j] = vis2[i][j] = 0;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			if (a[i][j] >= x){
				vis1[max(i - x + 1, 1)][j] += 1; vis1[min(i + x, n + 1)][j] -= 1;
				vis2[i][max(j - x + 1, 1)] += 1; vis2[i][min(j + x, m + 1)] -= 1;
			}
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++){
			vis1[i][j] += vis1[i - 1][j];
			vis2[i][j] += vis2[i][j - 1];
			if (!vis1[i][j] || !vis2[i][j]) return 0;
		}
	return 1;
}

int main(){
	freopen("lantern.in", "r", stdin);
	freopen("lantern.out", "w", stdout);
	scanf("%d%d", &n, &m);
	int Max = 0;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++){
			scanf("%d", &a[i][j]);
			Max = max(a[i][j], Max);
		}
	Max = min(Max, max(n, m));
	for (int i = 1; i <= Max; i++)
		if (check(i)){
			printf("%d\n", i);
			return 0;
		}
	printf("-1\n");
	return 0;
}
