#include <bits/stdc++.h>

using namespace std;

const int maxn = 110, maxs = 10010, maxm = 1e6 + 10;
const int dx[] = { 1, 2, 2, 1, -1, -2, -2, -1 }, dy[] = { -2, -1, 1, 2, 2, 1, -1, -2 };

struct node{
	int x, c;
	
	node (int x = 0, int c = 0) : x(x), c(c) {
		
	}
	
	bool operator < (const node &t) const {
		return c > t.c;
	}
};

int n, m, S, T;
int num[maxn][maxn], c[maxs];
int d[maxs], s[maxs], w[maxs];
bool vis[maxs];
int to[maxm], nxt[maxm], head[maxs], tot;

void addedge(int u, int v){
	to[++tot] = v;
	nxt[tot] = head[u];
	head[u] = tot;
}

void dij(int S){
	priority_queue<node> q;
	q.push(node(S, 0));
	memset(vis, 0, sizeof vis);
	memset(d, 0x7f, sizeof d);
	d[S] = 0; s[S] = 1;
	while (q.size()){
		node top;
		do {
			top = q.top();
			q.pop();
		} while (vis[top.x] && q.size());
		vis[top.x] = 1;
		
		for (int i = head[top.x]; i; i = nxt[i]){
			int p = to[i], c = top.c + w[p];
			if (!vis[p] && c < d[p]){
				d[p] = c; s[p] = s[top.x] + 1;
				q.push(node(p, c));
			}
		}
	}
}

int main(){
	freopen("lilypad.in", "r", stdin);
	freopen("lilypad.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++) num[i][j] = (i - 1) * m + j;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++){
			int x;
			scanf("%d", &x);
			if (x == 3) S = num[i][j];
			if (x == 4) T = num[i][j];
			c[num[i][j]] = x;
			if (!x) w[num[i][j]] = 1;
		}
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++){
			if (c[num[i][j]] == 2) continue;
			for (int k = 0; k < 8; k++){
				int tx = i + dx[k], ty = j + dy[k];
				if (tx > 0 && ty > 0 && tx <= n && ty <= m){
					int p = num[tx][ty];
					if (c[p] != 2) addedge(num[i][j], p);
				}
			}
		}
	dij(S);
	if (d[T] == 0x7f7f7f7f) printf("-1 -1\n");
	else printf("%d %d\n", d[T], s[T] - 1);
	return 0;
}

/*
4 8
0 0 0 1 0 0 0 0
0 0 0 0 0 2 0 1
0 0 0 0 0 4 0 0
3 0 0 0 0 0 1 0
*/
