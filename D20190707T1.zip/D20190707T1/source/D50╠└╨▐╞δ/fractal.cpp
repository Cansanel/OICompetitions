#include <bits/stdc++.h>

using namespace std;

const int maxm = 110;

struct node{
	double x, y;
	
	node (double x = 0, double y = 0) : x(x), y(y) {
		
	}
	
	node operator + (const node &t) const {
		return node(x + t.x, y + t.y);
	}
	
	node operator - (const node &t) const {
		return node(x - t.x, y - t.y);
	}
	
	node operator * (const node &t) const {
		return node(x * t.x - y * t.y, x * t.y + y * t.x);
	}
	
	double get(){
		return sqrt(x * x + y * y);
	}
};

int yc, xc;
double Sy, Sx, P, Q;
node z[maxm];

inline bool check(double x, double y){
	node c = node(P, Q);
	z[0] = node(x, y);
	for (int i = 1; i <= 100; i++){
		z[i] = (z[i - 1] * z[i - 1]) + c;
		if (z[i].get() >= 10) return 0;
	}
	return 1;
}

int main(){
	freopen("fractal.in", "r", stdin);
	freopen("fractal.out", "w", stdout);
	scanf("%d%d", &yc, &xc);
	scanf("%lf%lf%lf%lf", &Sy, &Sx, &P, &Q);
	for (int j = 0; j < yc; j++){
		for (int i = 0; i < xc; i++) printf("%c", check(Sy + i * 0.005, Sx + j * 0.01) ? 'a' : ' ');
		printf("\n");
	}
	return 0;
}

/*
400 800 -2 -2 -0.53 0.53
*/
