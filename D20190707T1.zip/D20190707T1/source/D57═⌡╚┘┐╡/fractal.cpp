#include<bits/stdc++.h>
using namespace std;
struct f{
	double x,y;
}z[101];
bool s[double a,double b,double c,double d]
{
	z[0].x=a;
	z[0].y=b;
	for(int i=1;i<=100;i++)
	  {
	  	z[i].x=z[i-1].x*z[i-1].x-z[i-1].y*z[i-1].y+c;
	  	z[i].y=z[i-1].x*z[i-1].y+z[i-1].y*z[i-1].x+d;
	  	if(sqrt(z[i].x*z[i].x+z[i].y*z[i].y)>=10)
	  	{
	  	   return 0;
	  	   break;
        }
        else
          return 1;
	  }
}
int C[1001][800],Sx,Sy,yc,xc;
float P,Q;
int main()
{  
   freopen("fractal.in","r",stdin);
   freopen("fractal.out","w",stdout);
   cin>>yc>>xc>>Sy>>Sx;
   cin>>P>>Q;
   for(int j=0;j<yc;j++)
     for(int i=0;i<xc;i++)
       {
       	if(s[Sy+i*0.005,Sx+j*0.01,P,Q]==0)
       	  {
       	  	 C[j][i]='a';
       	  }
       	else
       	   C[j][i]=' ';
       }
    for(int j=0;j<yc;j++)
     for(int i=0;i<xc;i++)   
      {
      	cout<<C[j][i];
      	if(j==yc-1) cout<<C[j][i]<<endl;
      }
	return 0; 
}
