#include<bits/stdc++.h>
using namespace std;
int a[1001][1001]n,m;
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++)
	    {
	    	cin>>a[i][j];
	    }
	    
}
