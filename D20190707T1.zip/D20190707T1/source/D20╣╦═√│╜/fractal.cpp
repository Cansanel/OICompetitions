#include<stdio.h>
#include<cmath>
int yc,xc;
double Sy,Sx;
struct complex
{
	double x,y;
	double leng_2()
	{
		return x*x+y*y;
	}
}c,zi[110];
complex operator + (complex a,complex b){return (complex){a.x+b.x,a.y+b.y};}
complex operator * (complex a,complex b){return (complex){a.x*b.x-a.y*b.y,a.x*b.y+a.y*b.x};}
bool converge(complex z)
{
	zi[0]=z;
	for(int i=1;i<101;i++)
	{
		zi[i]=(zi[i-1]*zi[i-1])+c;
		if(zi[i].leng_2()>=100.0) return false;
	}
	return true;
}
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d%d%lf%lf%lf%lf",&yc,&xc,&Sy,&Sx,&c.x,&c.y);
	for(int j=0;j<yc;j++)
	{
		for(int i=0;i<xc;i++)
		{
			if(converge((complex){Sy+i*0.005,Sx+j*0.01})) putchar('a');
			else putchar(' ');
		}
		putchar('\n');
	}
	return 0;
}
