#include<stdio.h>
#include<iostream>
#include<string.h>
int n,m,r,a[110][1010],dxy[4][2]={{0,-1},{0,1},{1,0},{-1,0}};
bool vis1[110][1010],vis2[110][1010],vis3[110][1010];
bool check(int x)
{
	memset(vis1,false,sizeof(vis1));
	memset(vis2,false,sizeof(vis2));
	memset(vis3,false,sizeof(vis3));
	int nx,ny;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			if(a[i][j]>=x)
			{
				vis1[i][j]=true;
				for(int k=1;k<x;k++)
				{
					for(int l=0;l<2;l++)
					{
						nx=i+dxy[l][0];
						ny=j+dxy[l][1];
						if(nx<1||ny<1||nx>n||ny>m) continue;
						vis2[nx][ny]=true;
					}
					for(int l=2;l<4;l++)
					{
						nx=i+dxy[l][0];
						ny=j+dxy[l][1];
						if(nx<1||ny<1||nx>n||ny>m) continue;
						vis3[nx][ny]=true;
					}
				}
			}
		}
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(!vis1[i][j]&&!(vis2[i][j]&&vis3[i][j])) return false;
	return true;
}
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	scanf("%d%d",&n,&m);
	r=std::max(n,m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++) scanf("%d",&a[i][j]);
	for(int i=1;i<=r;i++)
	{
		if(check(i))
		{
			printf("%d\n",i);
			return 0;
		}
	}
	printf("-1\n");
	return 0;
}
