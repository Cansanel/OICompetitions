#include<stdio.h>
#include<queue>
#include<string.h>
using namespace std;
int n,m,a[110][110],st[5],ed[5],res=233333333,stepm=233333333,dxy[8][2]={{-2,1},{-1,2},{1,2},{2,1},{2,-1},{1,-2},{-1,-2},{-2,-1}},vis1[110][110],vis2[110][110];
struct node
{
	int x,y,step,placed;
};
void bfs()
{
	memset(vis1,122,sizeof(vis1));
	memset(vis2,122,sizeof(vis2));
	queue<node> q;
	q.push((node){st[0],st[1],0,0});
	node temp;
	vis1[st[0]][st[1]]=0;
	vis2[st[0]][st[1]]=0;
	int nx,ny;
	while(!q.empty())
	{
		temp=q.front();
		q.pop();
		if(temp.x==ed[0]&&temp.y==ed[1])
		{
			if(temp.placed<res)
			{
				res=temp.placed;
				stepm=temp.step;
			}
			if(temp.placed==res)
				if(temp.step<stepm) stepm=temp.step;
			continue;
		}
		++temp.step;
		for(int i=0;i<8;i++)
		{
			nx=temp.x+dxy[i][0];
			ny=temp.y+dxy[i][1];
			if(nx<1||ny<1||nx>n||ny>m||vis1[nx][ny]<temp.placed+(a[nx][ny]==0)||(vis1[nx][ny]==temp.placed+(a[nx][ny]==0)&&vis2[nx][ny]<temp.step)||a[nx][ny]==2||res<temp.placed||(res==temp.placed&&stepm<temp.step)) continue;
			vis1[nx][ny]=temp.placed+(a[nx][ny]==0);
			vis2[nx][ny]=temp.step;
			q.push((node){nx,ny,temp.step,temp.placed+(a[nx][ny]==0)});
		}
	}
	return ;
}
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
			if(a[i][j]==3) st[0]=i,st[1]=j;
			if(a[i][j]==4) ed[0]=i,ed[1]=j;
		}
	}
	bfs();
	if(stepm==233333333) printf("-1 -1\n");
	else printf("%d %d\n",res,stepm);
	return 0;
}
