#include<bits/stdc++.h>
using namespace std;

int s,t,dx[8]={1,2,2,1,-1,-2,-2,-1},dy[8]={2,1,-1,-2,-2,-1,1,2};
int n,m,num=1;
int a[110][110],head[10010],dis[10010],step[10010];

priority_queue < pair < int,int > > q;
struct edge{
	int to,next,dis;
} e[100010];

void add(int a,int b,int c){
	e[++num].to=b;e[num].dis=c;e[num].next=head[a];head[a]=num;
}

int read(){
	int x=0,f=1;char c;
	c=getchar();
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<3)+(x<<1)+c-'0';c=getchar();}
	return x*f;
}

void build(){
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			for(int k=0;k<8;k++){
				int tx=i+dx[k],ty=j+dy[k];
				if(tx>=1&&tx<=m&&ty>=1&&ty<=n&&a[tx][ty]!=2){
					int u=(i-1)*n+j,v=(tx-1)*n+ty;
					if(a[tx][ty]==1||a[tx][ty]==4) add(u,v,0);
					if(!a[tx][ty]) add(u,v,1);
				}
			}
		}
	}
}

void dijkstra(){
	q.push(make_pair(-dis[s],s));
	while(!q.empty()){
		int u=q.top().second;
		q.pop();
		for(int i=head[u];i;i=e[i].next){
			int v=e[i].to;
			if(dis[v]>dis[u]+e[i].dis){
				dis[v]=dis[u]+e[i].dis;
				step[v]=step[u]+1;
				q.push(make_pair(-dis[v],v));
			}
		}
	}
}

int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	m=read();n=read();
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			a[i][j]=read();
			if(a[i][j]==3) s=(i-1)*n+j;
			if(a[i][j]==4) t=(i-1)*n+j;
		}
	}
	build();
	memset(dis,0x3f3f,sizeof(dis));
	memset(step,0x3f3f,sizeof(step));
	
	dis[s]=0;step[s]=0;
	
	dijkstra();
	
	if(dis[t]==1061109567) cout<<"-1 -1";
	else cout<<dis[t]<<' '<<step[t];
	return 0;
}
/*
4 8
0 0 0 1 0 0 0 0
0 0 0 0 0 2 0 1
0 0 0 0 0 4 0 0
3 0 0 0 0 0 1 0
*/
/*
4 4
0 1 0 0
0 4 0 1
3 0 0 0
0 0 0 0
*/
