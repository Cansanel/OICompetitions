#include<bits/stdc++.h>
using namespace std;

int n,m,r,ans=-1;
int a[510][10010];
bool v[510][10010][2];

int read(){
	int x=0,f=1;char c;
	c=getchar();
	while(c>'9'||c<'0'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<3)+(x<<1)+c-'0';c=getchar();}
	return x*f;
}

bool check(int x){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(a[i][j]>=x){
				for(int k=max(1,i-x+1);k<=min(i+x-1,n);k++)
					v[k][j][0]=1;
				for(int k=max(1,j-x+1);k<=min(j+x-1,m);k++)
					v[i][k][1]=1;
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(!(v[i][j][0]&&v[i][j][1])) return false;
		}
	}
	return true;
}

int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			a[i][j]=read();
			r=max(r,a[i][j]);
		}
	}
	for(int x=1;x<=r;x++){
		memset(v,0,sizeof(v));
		if(check(x)){
			ans=x;
			break;
		}
	}
	cout<<ans;
	return 0;
}
