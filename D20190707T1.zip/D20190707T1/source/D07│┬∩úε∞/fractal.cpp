#include<bits/stdc++.h>
using namespace std;

int yc,xc;
double sx,sy,p,q;

char c[810][810];

struct Complex{
	double x,y;
} C;


Complex addc(Complex a,Complex b){
	Complex c;
	c.x=a.x+b.x;c.y=a.y+b.y;
	return c;
}

Complex timec(Complex a,Complex b){
	Complex c;
	c.x=a.x*b.x-a.y*b.y;c.y=a.x*b.y+b.x*a.y;
	return c;
}

double absc(Complex a){
	return sqrt(a.x*a.x+a.y*a.y);
}

bool check(Complex a0){
	Complex z[101];
	z[0].x=a0.x; z[0].y=a0.y;
	for(int i=1;i<=100;i++){
		z[i]=addc(timec(z[i-1],z[i-1]),C);
		double t=absc(z[i]);
		if(t>=10) return false;
	}
	return true;
}

int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx>>p>>q;
	C.x=p;C.y=q;
	for(int i=0;i<yc;i++){
		for(int j=0;j<xc;j++){
			Complex a;
			a.x=sy+0.005*j;a.y=sx+0.01*i;
			if(check(a)) c[i][j]='a';
			else c[i][j]=' ';
		}
	}
	
	for(int i=0;i<yc;i++){
		for(int j=0;j<xc;j++){
			putchar(c[i][j]);
		}
		printf("\n");
	}
	return 0;
}
/*
400 800 -2 -2
-0.53 0.53
*/
