#include<bits/stdc++.h>
#define piiii pair < pair <int, int> , pair <int, int> >
using namespace std;
template <typename T> inline void read(T &x)
{
	int f = 1; x = 0;
	char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}
const int N = 1e2 + 5;
const int dx[8] = {-2, -2, -1, 1, 2, 2, 1, -1};
const int dy[8] = {-1, 1, 2, 2, 1, -1, -2, -2};
int a[N][N];
int n, m;
int sx, sy, ex, ey;
int now = -1;
pair <int, int> dis[N][N];
priority_queue < piiii, vector <piiii>, greater <piiii> > q;
int main(){
	freopen ("lilypad.in", "r", stdin);
	freopen ("lilypad.out", "w", stdout);
	read(n); read(m);
	for (int i = 1; i <= n; i++)
	 for (int j = 1; j <= m; j++)
	 {
	 	read(a[i][j]);
	 	if (a[i][j] == 3)
	 	{
	 		sx = i; sy = j;
	 		a[i][j] = 1;
	 	}
	 	if (a[i][j] == 4)
	 	{
	 		ex = i; ey = j;
	 		a[i][j] = 1;
	 	}
	 }
	 
	 for (int i = 1; i <= n; i++)
	  for (int j = 1; j <= m; j++) 
	   dis[i][j] = make_pair(n * m, n * m);
	   
	dis[sx][sy] = make_pair(0, 0);
	q.push(make_pair(dis[sx][sy], make_pair(sx, sy) ) );
	int fx, fy, num, d;
	while (!q.empty())
	{
		piiii f = q.top(); q.pop();
		fx = f.second.first;
		fy = f.second.second;
		num = f.first.first;
		d = f.first.second;
		if (f.first != dis[fx][fy]) continue;
		for (int i = 0; i < 8; i++)
		{
			int tx = fx + dx[i];
			int ty = fy + dy[i];
			if (tx < 1 || tx > n || ty < 1 || ty > m) continue;
			if (a[tx][ty] == 1)
			{
				if (dis[fx][fy].first < dis[tx][ty].first || (dis[fx][fy].first == dis[tx][ty].first && dis[fx][fy].second + 1 < dis[tx][ty].second))
				{
					dis[tx][ty] = make_pair(dis[fx][fy].first, dis[fx][fy].second + 1);
					q.push(make_pair(dis[tx][ty], make_pair(tx, ty)));
				}
			}
			if (a[tx][ty] == 0)
			{
				if (dis[fx][fy].first + 1 < dis[tx][ty].first || (dis[fx][fy].first + 1 == dis[tx][ty].first && dis[fx][fy].second + 1 < dis[tx][ty].second))
				{
					dis[tx][ty] = make_pair(dis[fx][fy].first + 1, dis[fx][fy].second + 1);
					q.push(make_pair(dis[tx][ty], make_pair(tx, ty)));
				}
			}
			if (tx == ex && ty == ey)
			{
				printf("%d %d\n", dis[ex][ey].first, dis[ex][ey].second);
				return 0;
			}
		}
	}
	puts("-1 -1");
  return 0;
}
