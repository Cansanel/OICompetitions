#include<bits/stdc++.h>
using namespace std;
template <typename T> inline void read(T &x)
{
	int f = 1; x = 0;
	char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}
struct fractal
{
	double a, b;
	fractal (double x = 0, double y = 0) { a = x, b = y; }
	friend fractal operator + (fractal x, fractal y) { return fractal(x.a + y.a, x.b + y.b); }
	friend fractal operator - (fractal x, fractal y) { return fractal(x.a - y.a, x.b - y.b); }
	friend fractal operator * (fractal x, fractal y)
	{
		return fractal(x.a * y.a - x.b * y.b, x.a * y.b + x.b * y.a);
	}
};
inline double calc(fractal x) { return sqrt(x.a * x.a + x.b * x.b); }
int yc, xc;
double sy, sx;
fractal c;
const int N = 8e2 + 5;
char ch[N][N];
fractal z[105];
inline bool isinside(register double x, register double y)
{
	z[0] = fractal(x, y);
	if (calc(z[0]) >= 10) return 0;
	for (register int i = 1; i <= 100; i++)
	{
		z[i] = z[i - 1] * z[i - 1] + c;
		if (calc(z[i]) >= 10) return 0;
	}
	return 1;
}
inline bool check(register int j, register int i)
{
	return isinside((double)sy + i * 0.005, (double)sx + j * 0.01);
}
int main(){
	freopen ("fractal.in", "r", stdin);
	freopen ("fractal.out", "w", stdout);
	read(yc); read(xc);
	scanf("%lf%lf", &sy, &sx);
	scanf("%lf%lf", &c.a, &c.b);
	for (register int j = 0; j < yc; j++)
	 for (register int i = 0; i < xc; i++)
	  if (check(j, i)) ch[j][i] = 'a'; else ch[j][i] = ' ';
	  
	for (register int j = 0; j < yc; j++)
	{
		for (int i = 0; i < xc; i++)
		putchar(ch[j][i]);
		puts("");
	}
  return 0;
}
