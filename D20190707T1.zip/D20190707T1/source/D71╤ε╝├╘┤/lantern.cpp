#include<bits/stdc++.h>
using namespace std;
template <typename T> inline void read(T &x)
{
	int f = 1; x = 0;
	char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}
const int N = 5e2 + 5;
const int M = 1e4 + 5;
int a[N][M];
int h[N][M], l[M][N];
int sum[N][M];
int n, m;
inline int check(int mid)
{
	memset(h, 0, sizeof(h));
	memset(l, 0, sizeof(l));
	memset(sum, 0, sizeof(sum));
	for (int i = 1; i <= n; i++)
	 for (int j = 1; j <= m; j++)
	  if (a[i][j] >= mid)
	  {
	  	h[i][max(1, j - mid + 1)]++; h[i][min(m, j + mid - 1) + 1]--;
	  	l[j][max(1, i - mid + 1)]++; l[j][min(n, i + mid - 1) + 1]--;
	  }
	 
	int now; 
	for (int i = 1; i <= n; i++)
	{
		now = 0;
		for (int j = 1; j <= m; j++)
		{
			now += h[i][j];
			if (now >= 1) sum[i][j]++;
		}
	}
	
	for (int j = 1; j <= m; j++)
	{
		now = 0;
		for (int i = 1; i <= n; i++)
		{
			now += l[j][i];
			if (now >= 1) sum[i][j]++;
		}
	}
	
	int res = 0;
	for (int i = 1; i <= n; i++)
	 for (int j = 1; j <= m; j++)
	  if (sum[i][j] >= 2) res++;
	
	return res;
}
inline void solve_50pts()
{
	for (int i = 1; i <= max(n, m); i++)
	if (check(i) == n * m) 
	{
		printf("%d\n", i);
		return;
	}
	puts("-1");
}
int main(){
	freopen ("lantern.in", "r", stdin);
	freopen ("lantern.out", "w", stdout);
	read(n); read(m);
	for (int i = 1; i <= n; i++)
	 for (int j = 1; j <= m; j++)
	  {
	  	read(a[i][j]);
	  }
	if (n <= 50) solve_50pts();  
	else puts("-1");
  return 0;
}
