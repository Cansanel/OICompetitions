#include <iostream>
#include <iomanip>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
int a[500][10000];
int b[500][10000];
int c[500][10000][2];
using namespace std;
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	memset(a,-1,sizeof(a));
	memset(c,0,sizeof(c));
	int m,n,i,j,max1=0,cu=0,ii,ji,ix,jx,k,co=0,l=0,r,mid;
	cin>>m>>n;
	for(i=0;i<m;i++){
		for(j=0;j<n;j++){
			cin>>a[i][j];
			cu++;
			b[i][j]=a[i][j];
			if(max1<a[i][j]) max1=a[i][j];
			if(b[i][j]>0){
				ji=max(0,j-b[i][j]+1);jx=min(n,j+b[i][j]-1);
				ii=max(0,i-b[i][j]+1);ix=min(n,i+b[i][j]-1);
				for(k=ji;k<=jx;k++) c[i][k][0]++;
				for(k=ii;k<=ix;k++) c[k][j][1]++;
			}
		}
	}
	for(i=0;i<m;i++){
		for(j=0;j<n;j++){
			if(c[i][j][0]>0&&c[i][j][1]>0) co++;
			}
		}
	r=max1;
	while(l!=r){
		mid=(l+r)/2;
		memset(c,0,sizeof(c));
		for(i=0;i<m;i++){
			for(j=0;j<n;j++){
				b[i][j]=a[i][j];
				if(b[i][j]>=mid) b[i][j]=mid;
				if(b[i][j]<mid) b[i][j]=0;
				if(b[i][j]>0){
					ji=max(0,j-b[i][j]+1);jx=min(n,j+b[i][j]-1);
					ii=max(0,i-b[i][j]+1);ix=min(n,i+b[i][j]-1);
					for(k=ji;k<=jx;k++) c[i][k][0]++;
					for(k=ii;k<=ix;k++) c[k][j][1]++;
				}
			}
		}
		co=0;
		for(i=0;i<m;i++){
			for(j=0;j<n;j++){
				if(c[i][j][0]>0&&c[i][j][1]>0) co++;
			}
		}
		if(co<cu) l=mid+1;
		else r=mid;
	}
	if(l==max1){
		memset(c,0,sizeof(c));
		for(i=0;i<m;i++){
			for(j=0;j<n;j++){
				b[i][j]=a[i][j];
				if(b[i][j]>=l) b[i][j]=l;
				if(b[i][j]<l) b[i][j]=0;
				if(b[i][j]>0){
					ji=max(0,j-b[i][j]+1);jx=min(n,j+b[i][j]-1);
					ii=max(0,i-b[i][j]+1);ix=min(n,i+b[i][j]-1);
					for(k=ji;k<=jx;k++) c[i][k][0]++;
					for(k=ii;k<=ix;k++) c[k][j][1]++;
				}
			}
		}
		co=0;
		for(i=0;i<m;i++){
			for(j=0;j<n;j++){
				if(c[i][j][0]>0&&c[i][j][1]>0) co++;
			}
		}
		if(co<cu){
			cout<<"-1";
			return 0;
		}
		else{
			cout<<l;
			return 0;
		}
	}
	cout<<l;
	return 0;
}
