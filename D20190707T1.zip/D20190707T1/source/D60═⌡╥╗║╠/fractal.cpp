#include <iostream>
#include <iomanip>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
struct cplx{
	double r;
	double i;
};
cplx add(cplx a,cplx b){
	cplx c;
	c.r=a.r+b.r;c.i=a.i+b.i;
	return c;
}
cplx sub(cplx a,cplx b){
	cplx c;
	c.r=a.r-b.r;c.i=a.i-b.i;
	return c;
}
cplx mul(cplx a,cplx b){
	cplx c;
	c.r=a.r*b.r-a.i*b.i;c.i=a.r*b.i+a.i*b.r;
	return c;
}
bool check(cplx x,cplx c){
	int i;
	for(i=1;i<=100;i++){
		x=add(mul(x,x),c);
		if(sqrt(x.r*x.r+x.i*x.i)>=10) return 0;
	}
	return 1;
}
char s[800][800];
using namespace std;
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	int yc,xc,i,j;
	double sy,sx,p,q,ii,jj;
	cin>>yc>>xc>>sy>>sx>>p>>q;
	memset(s,0,sizeof(s));
	cplx C,x;
	C.r=p;C.i=q;
	for(i=0;i<yc;i++){
		for(j=0;j<xc;j++){
			ii=i;jj=j;
			x.r=sy+jj*0.005;x.i=sx+ii*0.01;
			if(check(x,C)) s[i][j]='a';
			else s[i][j]=' ';
		}
	}
	for(i=0;i<yc;i++){
		for(j=0;j<xc;j++){
			cout<<s[i][j];
		}
		cout<<endl;
	}
	return 0;
}
