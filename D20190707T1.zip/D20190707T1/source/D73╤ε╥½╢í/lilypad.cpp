#include<iostream>
#include<cstdio>
using namespace std;

bool b[110][110];
struct map2
{
	int s,p;//�������ɻ��� 
}a[110][110];
int s[110][110];
int qx,qy,zx,zy,m,n;
int dx[8]={1,2,2,1,-1,-2,-2,-1};
int dy[8]={2,1,-1,-2,-2,-1,1,2};
int x[250000],y[250000];
int read()
{
	int x=0;
	char ch=getchar();
	while(ch>'9'||ch<'0')	ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return x;
}
bool bfs1()
{
	int f=1,r=1;
	x[f]=qx,y[f]=qy,b[qx][qy]=1;
	while(f<=r)
	{
		for(register int i=0;i<8;++i)
		{
			int nx=x[f]+dx[i],ny=y[f]+dy[i];
			if(nx>0&&nx<=m&&ny>0&&ny<=n&&b[nx][ny]==0&&s[nx][ny]!=2)
			{
				x[++r]=nx;
				y[r]=ny;
				b[nx][ny]=1;
			}
		}
		++f;
	}
	return b[zx][zy];
}
void bfs2()
{
	int f=1,r=1;
	x[f]=qx,y[f]=qy,a[qx][qy].s=a[qx][qy].p=0;
	while(f<=r)
	{
		for(register int i=0;i<8;++i)
		{
			int nx=x[f]+dx[i],ny=y[f]+dy[i];
			if(nx>0&&nx<=m&&ny>0&&ny<=n&&b[nx][ny]==1&&a[x[f]][y[f]].p+1-s[nx][ny]<a[nx][ny].p)
			{
				x[++r]=nx;
				y[r]=ny;
				a[nx][ny].p=a[x[f]][y[f]].p+1-s[nx][ny];
				a[nx][ny].s=a[x[f]][y[f]].s+1;
			}
		}
		++f;
	}
	return;
}
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	m=read(),n=read();
	for(register int i=1;i<=m;++i)
		for(register int j=1;j<=n;++j)
		{
			s[i][j]=read();
			if(s[i][j]==3)	qx=i,qy=j,s[i][j]=1;
			if(s[i][j]==4)	zx=i,zy=j,s[i][j]=1;
		}
	if(bfs1()==0)
	{
		cout<<-1<<" "<<-1<<endl;
		return 0;
	}
	for(register int i=1;i<=m;++i)
		for(register int j=1;j<=n;++j)
			a[i][j].s=a[i][j].p=1e9;
	bfs2();
	cout<<a[zx][zy].p<<" "<<a[zx][zy].s<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
