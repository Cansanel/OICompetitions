#include<iostream>
#include<cmath>
#include<cstdio>
using namespace std;

char c[810][810];
struct thez
{
	double x,y;
}z[110];
int yc,xc;
double sy,sx,p,q;
char shoulian(double x,double y)
{
	z[0].x=x;
	z[0].y=y;
	for(register int i=1;i<=100;++i)
	{
		z[i].x=z[i-1].x*z[i-1].x-z[i-1].y*z[i-1].y;
		z[i].y=z[i-1].x*z[i-1].y+z[i-1].y*z[i-1].x;
		z[i].x+=p;
		z[i].y+=q;
		if(z[i].x*z[i].x+z[i].y*z[i].y>=100)	return ' ';
	}
	return 'a';
}
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx;
	cin>>p>>q;
	for(register int j=0;j<yc;++j)
	{
		for(register int i=0;i<xc;++i)
		{
			c[j][i]=shoulian(sy*1.0+i*0.005,sx*1.0+j*0.01);
			putchar(c[j][i]);
		}
		putchar('\n');
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
