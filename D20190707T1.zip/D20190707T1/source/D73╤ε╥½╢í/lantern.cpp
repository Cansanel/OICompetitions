#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;

int n,m,h[510][10010],z[510][10010],now=1,num=0;
struct light
{
	int x,y,s;
}a[500010];
bool cmp(light u,light v)
{
	return u.s<v.s;
}
int max1(int u,int v)
{
	if(u>v)	return u;
	return v;
}
int min1(int u,int v)
{
	if(u>v)	return v;
	return u;
}
int read()
{
	int x=0;
	char ch=getchar();
	while(ch>'9'||ch<'0')	ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return x;
}
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	n=read(),m=read();
	for(register int i=1;i<=n;++i)
		for(register int j=1;j<=m;++j)
		{
			int x=read();
			if(x>0)
			{
				if(x>10000)	x=10000;
				a[++num].x=i;
				a[num].y=j;
				a[num].s=x;
			}
		}
	sort(a+1,a+1+num,cmp);
	while(now<=a[num].s)
	{
		for(register int i=1;i<=n;++i)
			for(register int j=1;j<=m;++j)
				h[i][j]=z[i][j]=0;
		for(register int i=num;i>=1;--i)
		{
			if(a[i].s>=now)
			{
				++h[a[i].x][max1(1,a[i].y-now+1)];
				--h[a[i].x][min1(m+1,a[i].y+now)];
				++z[max1(1,a[i].x-now+1)][a[i].y];
				--z[min1(n+1,a[i].x+now)][a[i].y];
			}
			else break;
		}
		int x=0;
		for(register int i=1;i<=n;++i)
		{
			int nx=0,v=0;
			for(register int j=1;j<=m;++j)
			{
				v+=h[i][j];
				if(v==0)	++nx;
				else	x=max1(x,nx),nx=0;
			}
			x=max1(x,nx);
		}
		for(register int j=1;j<=m;++j)
		{
			int nx=0,v=0;
			for(register int i=1;i<=n;++i)
			{
				v+=z[i][j];
				if(v==0)	++nx;
				else	x=max1(x,nx),nx=0;
			}
			x=max1(x,nx);
		}
		if(x==0)
		{
			cout<<now<<endl;
			return 0;
		}
		now+=(x+1)/2;
	}
	cout<<-1<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
