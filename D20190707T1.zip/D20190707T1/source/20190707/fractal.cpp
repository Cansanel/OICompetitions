#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pqq priority_queue
#define itt ::iterator
void setIO(string y)
{
    if(y == "")
        return ;
#ifndef ybw
    freopen((y + ".in").c_str(), "r", stdin);
    freopen((y + ".out").c_str(), "w", stdout);
#endif
}
#define endl '\n'
struct ins
{
    template<typename T>inline void read1(T &n)
    {
        n = 0;
        int f = 1;
        char c = getchar();
        for(; !(c >= '0' && c <= '9'); c = getchar())if(c == '-')f = -1;
        for(; (c >= '0' && c <= '9'); c = getchar())n = n * 10 + c - '0';
        if(c != '.')return ;
        T x = 0.1;
        for(; (c >= '0' && c <= '9'); c = getchar(), x *= 0.1)n = n + (c - '0') * x;
        n *= f;
    }
    inline void write1(const char *n)
    {
        int len = strlen(n);
        for(register int i = 0; i < len; ++i)putchar(n[i]);
    }
    inline void write1(char n)
    {
        putchar(n);
    }
    inline void write1(double n)
    {
        printf("%lf", n);
    }
    inline void write1(long double n)
    {
        printf("%Lf", n);
    }
    template<typename T>inline void write1(T n)
    {
        if(n < 0)putchar('-'), n = -n;
        if(n >= 10)write1(n / 10);
        putchar('0' + n % 10);

    }
    template<typename T> ins operator <<(T n)
    {
        write1(n);
        return *this;
    }
    template<typename T> ins operator >>(T &n)
    {
        read1(n);
        return *this;
    }
} yin, yout;
struct com
{
    double x, y;
    com(double xx = 0, double yy = 0)
    {
        x = xx;
        y = yy;
    }
    friend com operator + (const com &a, const com &b)
    {
        return com(a.x + b.x, a.y + b.y);
    }
    friend com operator - (const com &a, const com &b)
    {
        return com(a.x - b.x, a.y - b.y);
    }
    friend com operator * (const com &a, const com &b)
    {
        return com(a.x * b.x - a.y * b.y, a.y * b.x + a.x * b.y);
    }
};
double cc(const com &a)
{
    return sqrt(a.x * a.x + a.y * a.y);
}
int yc, xc;
double sx, sy, q, p;
com t;
bool check(com a)
{
    if(cc(a) >= 10)return 0;
    for(register int i = 1; i <= 100; ++i)
    {
        a = a * a + t;
        if(cc(a) >= 10)return 0;
    }
    return 1;
}
int main()
{
    setIO("fractal");
    cin >> yc >> xc >> sy >> sx;
    cin >> p >> q;
    t = com(p, q);
    for(register int j = 1; j <= yc; ++j)
    {
        for(register int i = 1; i <= xc; ++i)
        {
            if(check(com(sy + (double)(i - 1) * 0.005, sx + (double)(j - 1) * 0.01)))
            {
                putchar('a');
            }
            else
            {
                putchar(' ');
            }
        }
        putchar('\n');
    }
    return 0;
}