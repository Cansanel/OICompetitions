#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pqq priority_queue
#define itt ::iterator
void setIO(string y)
{
    if(y == "")
        return ;
#ifndef ybw
    freopen((y + ".in").c_str(), "r", stdin);
    freopen((y + ".out").c_str(), "w", stdout);
#endif
}
#define endl '\n'
struct ins
{
    template<typename T>inline void read1(T &n)
    {
        n = 0;
        int f = 1;
        char c = getchar();
        for(; !(c >= '0' && c <= '9'); c = getchar())if(c == '-')f = -1;
        for(; (c >= '0' && c <= '9'); c = getchar())n = n * 10 + c - '0';
        if(c != '.')return ;
        T x = 0.1;
        for(; (c >= '0' && c <= '9'); c = getchar(), x *= 0.1)n = n + (c - '0') * x;
        n *= f;
    }
    inline void write1(const char *n)
    {
        int len = strlen(n);
        for(register int i = 0; i < len; ++i)putchar(n[i]);
    }
    inline void write1(char n)
    {
        putchar(n);
    }
    inline void write1(double n)
    {
        printf("%lf", n);
    }
    inline void write1(long double n)
    {
        printf("%Lf", n);
    }
    template<typename T>inline void write1(T n)
    {
        if(n < 0)putchar('-'), n = -n;
        if(n >= 10)write1(n / 10);
        putchar('0' + n % 10);

    }
    template<typename T> ins operator <<(T n)
    {
        write1(n);
        return *this;
    }
    template<typename T> ins operator >>(T &n)
    {
        read1(n);
        return *this;
    }
} yin, yout;
const int maxn = 510, maxm = 10010;
int b[maxn][maxm], r[maxm][maxn], h[maxn][maxm], n, m, a[maxn][maxm];
int check(const int &x)
{
    memset(b, 0, sizeof(b));
    memset(r, 0, sizeof(r));
    memset(h, 0, sizeof(h));

    for(register int i = 1; i <= n; ++i)
    {
        for(register int j = 1; j <= m; ++j)
        {
            if(a[i][j] >= x)
            {
                ++h[i][max(1, j - x + 1)];
                --h[i][min(n, j + x - 1) + 1];
                ++r[j][max(1, i - x + 1)];
                --r[j][min(n, i + x - 1) + 1];
            }
        }
    }
    for(register int i = 1; i <= n; ++i)
    {
        register int sum = 0;
        for(register int j = 1; j <= m; ++j)
        {
            sum += h[i][j];
            if(sum)b[i][j] = 1;
        }
    }
    for(register int j = 1; j <= m; ++j)
    {
        register int sum = 0;
        for(register int i = 1; i <= n; ++i)
        {
            sum += r[j][i];
            if(sum)b[i][j] = 1;
        }
    }
    for(register int i = 1; i <= n; ++i)
        for(register int j = 1; j <= m; ++j)
            if(!b[i][j])
            {
                return 0;
            }
    return 1;
}
int main()
{
    setIO("lantern");
    yin >> n >> m;
    register int r = 0;
    for(register int i = 1; i <= n; ++i)
    {
        for(register int j = 1; j <= m; ++j)
        {
            yin >> a[i][j];
            r = max(r, a[i][j]);
        }
    }
    register int i=1,xx=min(r,max(n,m));
    for(;i<=xx;i+=10)
    {
        if(check(i))
        {
            cout<<i<<endl;
            return 0;
        }
        if(check(i+1))
        {
            cout<<i+1<<endl;
            return 0;
        }
        if(check(i+2))
        {
            cout<<i+2<<endl;
            return 0;
        }
        if(check(i+3))
        {
            cout<<i+3<<endl;
            return 0;
        }
        if(check(i+4))
        {
            cout<<i+4<<endl;
            return 0;
        }
        if(check(i+5))
        {
            cout<<i+5<<endl;
            return 0;
        }
        if(check(i+6))
        {
            cout<<i+6<<endl;
            return 0;
        }
        if(check(i+7))
        {
            cout<<i+7<<endl;
            return 0;
        }
        if(check(i+8))
        {
            cout<<i+8<<endl;
            return 0;
        }
        if(check(i+9))
        {
            cout<<i+9<<endl;
            return 0;
        }
    }
    puts("-1");
    return 0;
}
