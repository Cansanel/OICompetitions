#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pqq priority_queue
#define itt ::iterator
void setIO(string y)
{
    if(y == "")
        return ;
#ifndef ybw
    freopen((y + ".in").c_str(), "r", stdin);
    freopen((y + ".out").c_str(), "w", stdout);
#endif
}
#define endl '\n'
struct ins
{
    template<typename T>inline void read1(T &n)
    {
        n = 0;
        int f = 1;
        char c = getchar();
        for(; !(c >= '0' && c <= '9'); c = getchar())if(c == '-')f = -1;
        for(; (c >= '0' && c <= '9'); c = getchar())n = n * 10 + c - '0';
        if(c != '.')return ;
        T x = 0.1;
        for(; (c >= '0' && c <= '9'); c = getchar(), x *= 0.1)n = n + (c - '0') * x;
        n *= f;
    }
    inline void write1(const char *n)
    {
        int len = strlen(n);
        for(register int i = 0; i < len; ++i)putchar(n[i]);
    }
    inline void write1(char n)
    {
        putchar(n);
    }
    inline void write1(double n)
    {
        printf("%lf", n);
    }
    inline void write1(long double n)
    {
        printf("%Lf", n);
    }
    template<typename T>inline void write1(T n)
    {
        if(n < 0)putchar('-'), n = -n;
        if(n >= 10)write1(n / 10);
        putchar('0' + n % 10);

    }
    template<typename T> ins operator <<(T n)
    {
        write1(n);
        return *this;
    }
    template<typename T> ins operator >>(T &n)
    {
        read1(n);
        return *this;
    }
} yin, yout;
const int maxn = 510, maxm = 10010;
int b[maxn][maxm], n, m, a[maxn][maxm];
priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> >  > h[maxm], r[maxn], q[maxn];
int check(int x)
{
    for(int i = 1; i <= n; i++)
        while(!r[i].empty())r[i].pop();
    for(int i = 1; i <= m; i++)
        while(!h[i].empty())h[i].pop();
    priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> >  > t;
    for(int i = 1; i <= n; i++)
    {
        while(!q[i].empty() && q[i].top().second < x)q[i].pop();
        while(!q[i].empty())t.push(q[i].top()), q[i].pop();
        while(!t.empty())
        {
            int yy = t.top().second;
            // cout<<i<<" "<<yy<<endl;
            h[yy].push(make_pair(i - x + 1, i + x - 1));
            r[i].push(make_pair(yy - x + 1, yy + x - 1));
            q[i].push(t.top());
            t.pop();
        }
    }
    for(int i = 1; i <= n; i++)
    {
        int la = 0;
        // cout<<x<<" "<<r[i].size()<<endl;
        cout<<r[i].top().first<<endl;
        if(r[i].empty())return 0;
        while(!r[i].empty())
        {
            if(la + 1 < r[i].top().first)return 0;
            la = max(la, r[i].top().second);
            r[i].pop();
        }
    }

    for(int i = 1; i <= m; i++)
    {
        int la = 0;
        // cout<<h[i].size()<<endl;
        if(h[i].empty())return 0;
        while(!h[i].empty())
        {
            if(la + 1< h[i].top().first)return 0;
            la = max(la, h[i].top().second);
            h[i].pop();
        }
    }
    return 1;
}
int main()
{
    setIO("lantern");
    yin >> n >> m;
    int l = 1, r = 0;
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= m; j++)
        {
            yin >> a[i][j];
            q[i].push(make_pair(j, a[i][j]));
            r = max(r, a[i][j]);
        }
    }
    for(int i = 1; i <= min(r, max(n, m)); i++)
    {
        if(check(i))
        {
            cout << i << endl;
            return 0;
        }
        // cout<<i<<" "<<check(i)<<endl;
    }

    puts("-1");
    return 0;
}