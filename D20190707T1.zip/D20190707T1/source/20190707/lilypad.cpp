#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pqq priority_queue
#define itt ::iterator
void setIO(string y)
{
    if(y == "")
        return ;
#ifndef ybw
    freopen((y + ".in").c_str(), "r", stdin);
    freopen((y + ".out").c_str(), "w", stdout);
#endif
}
typedef pair<int, int> pii;
#define endl '\n'
struct ins
{
    template<typename T>inline void read1(T &n)
    {
        n = 0;
        int f = 1;
        char c = getchar();
        for(; !(c >= '0' && c <= '9'); c = getchar())if(c == '-')f = -1;
        for(; (c >= '0' && c <= '9'); c = getchar())n = n * 10 + c - '0';
        if(c != '.')return ;
        T x = 0.1;
        for(; (c >= '0' && c <= '9'); c = getchar(), x *= 0.1)n = n + (c - '0') * x;
        n *= f;
    }
    inline void write1(const char *n)
    {
        int len = strlen(n);
        for(register int i = 0; i < len; ++i)putchar(n[i]);
    }
    inline void write1(char n)
    {
        putchar(n);
    }
    inline void write1(double n)
    {
        printf("%lf", n);
    }
    inline void write1(long double n)
    {
        printf("%Lf", n);
    }
    template<typename T>inline void write1(T n)
    {
        if(n < 0)putchar('-'), n = -n;
        if(n >= 10)write1(n / 10);
        putchar('0' + n % 10);

    }
    template<typename T> ins operator <<(T n)
    {
        write1(n);
        return *this;
    }
    template<typename T> ins operator >>(T &n)
    {
        read1(n);
        return *this;
    }
} yin, yout;
const int maxn = 110;
int n, m;
int a[maxn][maxn], sx, sy, ttx, tty;
pii mind[maxn][maxn];
bool used[maxn][maxn];
const int dx[9]={0,1,2,2,1,-1,-2,-2,-1},dy[9]={0,2,1,-1,-2,2,-1,1,-2};
int check(int x,int y,int xx,int yy)
{
    if(xx>0&&xx<=n&&yy>0&&yy<=m&&a[xx][yy]!=2)
    {
        int mx=mind[x][y].first,mmx=mind[x][y].second;
        ++mmx;
        if(a[xx][yy]==0)++mx;
        pair<int,int> ttt=pii(mx,mmx);
        if(ttt<mind[xx][yy])
        {
            mind[xx][yy].first=mx;
            mind[xx][yy].second=mmx;
            return 1;
        }
        return 0;
    }
    else
        return 0;
}
int main()
{
    setIO("lilypad");
    yin >> n >> m;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= m; j++)
        {
            yin >> a[i][j];
            if(a[i][j] == 3)sx = i, sy = j;
            if(a[i][j] == 4)ttx = i, tty = j;
        }
    priority_queue<pair<pair<int, int>, pair<int, int> >,vector<pair<pair<int, int>, pair<int, int> > >,greater<pair<pair<int, int>, pair<int, int> > > > q;
    q.push(make_pair(pii(0, 0), pii(sx, sy)));
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= m; j++)
            mind[i][j].first = mind[i][j].second = INT_MAX >> 2;
    mind[sx][sy].first = mind[sx][sy].second=0;
    while(!q.empty())
    {
        pair<pii, pii> t = q.top();
        q.pop();
        int x = t.second.first, y = t.second.second;
        if(used[x][y])continue;
        for(int i = 1; i <= 8; i++)
        {
            int tx = x + dx[i], ty = y + dy[i];
            if(check(x, y, tx, ty))
            {
                q.push(make_pair(mind[tx][ty], make_pair(tx, ty)));
            }
        }
        used[x][y]=1;
    }
    if(mind[ttx][tty].first != INT_MAX >> 2)
        cout << mind[ttx][tty].first << " " << mind[ttx][tty].second << endl;
    else
        cout << "-1 -1" << endl;
    return 0;
}