#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
using namespace std;
template<typename T> void read(T &num){
	char c=getchar();T f=1;num=0;
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){num=(num<<3)+(num<<1)+(c^48);c=getchar();}
	num*=f;
}
template<typename T> void qwq(T x){
	if(x>9)qwq(x/10);
	putchar(x%10+'0');
}
template<typename T> void write(T x){
	if(x<0){x=-x;putchar('-');}
	qwq(x);putchar('\n');
}
template<typename T> void chkmin(T &x,T y){x=x<y?x:y;}
template<typename T> void chkmax(T &x,T y){x=x>y?x:y;}
int n,m,cnt;
int num[510][10010];int c1[510][10010];int c2[10010][510];
struct wzy{
	int xi,yi,si;
}d[1000010];
inline bool cmp(wzy a,wzy b){
	return a.si<b.si;
}
inline void Did(int x,int y,int pos){
	if(x<1||y<1||x>n||y>m)return;
	if(pos==1){cnt+=(!c1[x][y]);c1[x][y]++;}
	else{cnt+=(!c2[y][x]);c2[y][x]++;}
}

int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);

	read(n);read(m);int len=0;
	int tmp1=INT_MAX;int tmp2=INT_MAX;
	rep(i,1,n){
		int mx=0;
		rep(j,1,m){
			read(num[i][j]);chkmin(num[i][j],max(n,m));
			chkmax(mx,num[i][j]);
			if(num[i][j]){
				d[++len].xi=i;d[len].yi=i;d[len].si=num[i][j];
			}
		}
		chkmin(tmp1,mx);
	}
	rep(i,1,n){
		int mx=0;
		rep(j,1,m)chkmax(mx,num[i][j]);
		chkmin(tmp2,mx);
	}
	sort(d+1,d+len+1,cmp);
	
	cnt=len*2;int tmp=0;
	rep(i,1,len)c1[d[i].xi][d[i].yi]=c2[d[i].yi][d[i].xi]=1;
	if(cnt==n*m*2){write(1);return 0;}
	rep(i,2,min(tmp1,tmp2)){
		int nop=tmp;
		while(d[nop+1].si<i&&nop!=len)nop++;
		rep(j,tmp+1,nop){
			rep(k,max(1,d[j].yi-i+2),min(m,d[j].yi+i-2)){
				c1[d[j].xi][k]--;cnt-=(!c1[d[j].xi][k]);
			}
			rep(k,max(1,d[j].xi-i+2),min(n,d[j].xi+i-2)){
				c2[d[j].yi][k]--;cnt-=(!c2[d[j].yi][k]);
			}
		}
		tmp=nop;
		if(tmp==len)break;
		rep(j,tmp+1,len){
			Did(d[j].xi,d[j].yi-i+1,1);Did(d[j].xi,d[j].yi+i-1,1);
			Did(d[j].xi-i+1,d[j].yi,2);Did(d[j].xi+i-1,d[j].yi,2);
		}
		if(cnt==n*m*2){write(i);return 0;}
	}
	write(-1);
	return 0;
}
