#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
using namespace std;
const int dir[8][2]={{-2,1},{-1,2},{1,2},{2,1}
					,{2,-1},{1,-2},{-1,-2},{-2,-1}};
template<typename T> void read(T &num){
	char c=getchar();T f=1;num=0;
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){num=(num<<3)+(num<<1)+(c^48);c=getchar();}
	num*=f;
}
template<typename T> void qwq(T x){
	if(x>9)qwq(x/10);
	putchar(x%10+'0');
}
template<typename T> void write(T x){
	if(x<0){x=-x;putchar('-');}
	qwq(x);putchar('\n');
}
template<typename T> void chkmin(T &x,T y){x=x<y?x:y;}

int m,n;int sx,sy,ex,ey;
int mp[110][110];int f[110][110];int dis[110][110];
queue<pair<int,int> >v;bool in[110][110];
inline void SPFA(){
	memset(f,127,sizeof(f));memset(dis,127,sizeof(127));
	v.push(make_pair(sx,sy));
	f[sx][sy]=dis[sx][sy]=0;in[sx][sy]=1;
	while(!v.empty()){
		int n1=v.front().first;int n2=v.front().second;v.pop();
		in[n1][n2]=0;
		if(n1==ex&&n2==ey)continue;
		rep(i,0,7){
			int tx=n1+dir[i][0];int ty=n2+dir[i][1];
			if(tx<1||tx>m||ty<1||ty>n||mp[tx][ty]==2)continue;
			if(mp[tx][ty]==0){
				if(f[tx][ty]>f[n1][n2]+1||(f[tx][ty]==
				f[n1][n2]+1&&dis[tx][ty]>dis[n1][n2]+1)){
					f[tx][ty]=f[n1][n2]+1;dis[tx][ty]=dis[n1][n2]+1;
					if(!in[tx][ty]){
						v.push(make_pair(tx,ty));in[tx][ty]=1;
					}
				}
			}else{
				if(f[tx][ty]>f[n1][n2]||(f[tx][ty]==f[n1][n2]
				&&dis[tx][ty]>dis[n1][n2]+1)){
					f[tx][ty]=f[n1][n2];dis[tx][ty]=dis[n1][n2]+1;
					if(!in[tx][ty]){
						v.push(make_pair(tx,ty));in[tx][ty]=1;
					}
				}
			}
		}
	}
	return;
}

int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);

	read(m);read(n);
	rep(i,1,m){
		rep(j,1,n){
			read(mp[i][j]);
			if(mp[i][j]==3){sx=i;sy=j;}
			if(mp[i][j]==4){ex=i;ey=j;}
		}
	}
	
	SPFA();
	if(f[ex][ey]>n*m){printf("%d %d\n",-1,-1);return 0;}
	qwq(f[ex][ey]);putchar(' ');write(dis[ex][ey]);
	return 0;
}
