#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
using namespace std;
template<typename T> void read(T &num){
	char c=getchar();T f=1;num=0;
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){num=(num<<3)+(num<<1)+(c^48);c=getchar();}
	num*=f;
}
template<typename T> void qwq(T x){
	if(x>9)qwq(x/10);
	putchar(x%10+'0');
}
template<typename T> void write(T x){
	if(x<0){x=-x;putchar('-');}
	qwq(x);putchar('\n');
}
bool num[810][810];double Sy,Sx,P,Q;
double z[101][2];
inline bool MC(int pos){
	double nop=sqrt(z[pos][0]*z[pos][0]+z[pos][1]*z[pos][1]);
	if(fabs(nop-10.0)<=(1e-10)||nop>10.0)return true;
	return false;
}
inline bool SL(double x,double y){
	z[0][0]=x;z[0][1]=y;
	if(MC(0))return false;
	rep(i,1,100){
		double n1=z[i-1][0]*z[i-1][0]-z[i-1][1]*z[i-1][1];
		double n2=z[i-1][0]*z[i-1][1]+z[i-1][1]*z[i-1][0];
		z[i][0]=n1+P;z[i][1]=n2+Q;
		if(MC(i))return false;
	}
	return true;
}

int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	
	int yc,xc;read(yc);read(xc);
	scanf("%lf%lf%lf%lf",&Sy,&Sx,&P,&Q);
	
	rep(j,0,yc-1){
		rep(i,0,xc-1){
			num[j][i]=SL(Sx+(double)(i*0.005),Sx+(double)(j*0.01));	
		}
	}
	rep(j,0,yc-1){
		rep(i,0,xc-1)putchar((!num[j][i])?' ':'a');
		putchar('\n');
	}
	return 0;
} 
