#include<bits/stdc++.h>
using namespace std;
int read(){
	int f=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(ch>='0'&&ch<='9')s=s*10+ch-'0',ch=getchar();
	return s*f;
}int yc,xc;	double sy,sx,p,q;
struct F{
	double x;
	double y;
}z[101];
bool check(){
	F c;c.x=p,c.y=q;
	for(int i=1;i<=100;i++){
		z[i].x=z[i-1].x*z[i-1].x-z[i-1].y*z[i-1].y;
		z[i].y=z[i-1].x*z[i-1].y+z[i-1].y*z[i-1].x;
		z[i].x+=c.x;z[i].y+=c.y;
		if(sqrt(z[i].x*z[i].x+z[i].x+z[i].y*z[i].y)>=10)return 0;
	}
	return 1;
}
char c[801][801];
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx;
	cin>>p>>q;
	for(int j=1;j<=yc;j++){
		for(int i=1;i<=xc;i++){
			z[0].x=sy+i*0.005;
			z[0].y=sx+j*0.01;
			if(check())c[j][i]='a';
			else c[j][i]=' ';
		}
	}
	for(int j=1;j<=yc;j++){
		for(int i=1;i<=xc;i++){
			putchar(c[j][i]);
		}
		cout<<endl;
	}
	return 0;
}

