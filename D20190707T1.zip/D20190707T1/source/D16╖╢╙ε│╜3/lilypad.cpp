#include<bits/stdc++.h>
using namespace std;
int read(){
	int f=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(ch>='0'&&ch<='9')s=s*10+ch-'0',ch=getchar();
	return s*f;
}int n,m,s,t;
int a[666][666];
int dx[8]={-2,-1,1,2,2,1,-1,-2};
int dy[8]={1,2,2,1,-1,-2,-2,-1};
int head[10001],cnt=0;
struct F{
	int w,t;
	int nxt;
}nxt[100001];
void addedge(int x,int y,int w)
{
	nxt[++cnt].t=y;nxt[cnt].w=w;
	nxt[cnt].nxt=head[x];
	head[x]=cnt;
}int dis[10001];
int q[1000001];int v[10001];
int h[1000001],fa[1000001],g[1000001];
void SPFA(){
	int l=1,r=2;
	q[1]=s;v[s]=1;
	while(l<r){
		for(int i=head[q[l]];i;i=nxt[i].nxt){
			if(dis[q[l]]+nxt[i].w<dis[nxt[i].t]){
				dis[nxt[i].t]=dis[q[l]]+nxt[i].w;
				if(v[nxt[i].t]==0){
					v[nxt[i].t]=1;
					q[r]=nxt[i].t;
					r++;
				}
			
			}
		}v[q[l]]=0;
		l++;
	}
}int ans=0;
void bfs(){
	int l=1,r=2;
	q[l]=s;h[l]=0;
	fa[l]=-1;g[l]=0;
	while(l<r)
	{
		if(h[l]>dis[t]){
			l++;
			continue;
		}
		if(q[l]==t){
			ans=g[l];
			return;
		}
		for(int i=head[q[l]];i;i=nxt[i].nxt){
			if(nxt[i].t!=fa[l]){
				q[r]=nxt[i].t;
				h[r]=h[l]+nxt[i].w;
				fa[r]=q[l];
				g[r]=g[l]+1;
				r++;
			}
		}
		l++;
	}
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	memset(dis,0x3f,sizeof dis);
	n=read(),m=read();
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			a[i][j]=read();
		}
	}for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(a[i][j]==2)continue;
			for(int k=0;k<8;k++){
				int nx=i+dx[k],ny=j+dy[k];
				if(nx<=0||nx>n||ny<=0||ny>m)continue;
				if(a[nx][ny]==2)continue;
				if(a[nx][ny]==0)addedge((i-1)*m+j,(nx-1)*m+ny,1);
				else addedge((i-1)*m+j,(nx-1)*m+ny,0);
				if(a[i][j]==3)s=(i-1)*m+j;
				if(a[i][j]==4)t=(i-1)*m+j;
			}
		}
	}dis[s]=0;
	SPFA();cout<<dis[t]<<' ';
	bfs();cout<<ans<<endl;
	return 0;
}
