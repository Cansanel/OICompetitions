#include<bits/stdc++.h>
using namespace std;
int read(){
	int f=1,s=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'&&ch!='-')ch=getchar();
	if(ch=='-')f=-1,ch=getchar();
	while(ch>='0'&&ch<='9')s=s*10+ch-'0',ch=getchar();
	return s*f;
}struct{
	int x;int y;
}s,t;
int n,m,a[666][666];
int dx[8]={-2,-1,1,2,2,1,-1,-2};
int dy[8]={1,2,2,1,-1,-2,-2,-1};
int f[666][666],ans=2147483647,len=2147483647;
void dfs(int x,int y,int l,int ll){
	if(x==t.x&&y==t.y){
		if(ans==l){
			len=min(len,ll);
		}else{
			if(ans>l){
				ans=l;
				len=ll;
			}
		}
		return ;
	}
	for(int i=0;i<8;i++){
		int nx=x+dx[i],ny=y+dy[i];
		if(nx<=0||nx>n||ny<=0||ny>m)continue;
		if(f[nx][ny]==1||a[nx][ny]==2)continue;
		f[nx][ny]=1;if(a[nx][ny]==0)dfs(nx,ny,l+1,ll+1);
		else dfs(nx,ny,l,ll+1);
		f[nx][ny]=0;
	}
}
int main(){
	n=read(),m=read();
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			a[i][j]=read();
			if(a[i][j]==3)s.x=i,s.y=j;
			if(a[i][j]==4)t.x=i,t.y=j;
		}
	}f[s.x][s.y]=1;
	dfs(s.x,s.y,0,0);
	if(ans==2147483647)cout<<"-1"<<endl;
	else cout<<ans<<' '<<len<<endl;
	return 0;
}
/*	
	4 8
	0 0 0 1 0 0 0 0
	0 0 0 0 0 2 0 1
	0 0 0 0 0 4 0 0
	3 0 0 0 0 0 1 0
	
	
	
	10 5
	0 1 2 0 3 0 0 0 1 0
	1 1 1 2 2 0 2 1 0 0
	0 0 0 0 0 1 2 2 2 1
	1 0 2 1 0 2 2 1 0 0
	0 4 0 0 1 0 0 2 0 0
						*/ 

