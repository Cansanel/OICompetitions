#include<bits/stdc++.h>
using namespace std;
int a[666][666];
int main(){
	freopen("lilypad.in","w",stdout);
	srand(time(0));
	int n=100,m=100;
	cout<<n<<' '<<m<<endl;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			a[i][j]=rand()%3;
		}
	}
	int x=rand()%n+1,y=rand()%m+1;
	a[x][y]=3;
	int x1=rand()%n+1,y1=rand()%m+1;
	while(x1==x&&y1==y)x1=rand()%n+1,y1=rand()%m+1;
	a[x1][y1]=4;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cout<<a[i][j]<<' ';
		}
		cout<<endl;
	}
	return 0;
}

