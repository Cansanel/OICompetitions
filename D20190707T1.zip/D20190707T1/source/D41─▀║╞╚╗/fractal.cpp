#include<bits/stdc++.h>

using namespace std;
const int MAXN = 800 + 10;
char c[MAXN][MAXN];
double P, Q, Sx, Sy;
struct node{
	double x, y;
	node operator + (const node &b){
		node d;
		d.x = x + b.x;
		d.y = y + b.y;
		return d;
	}
	node operator += (const node &b){
		(*this) = (*this) + b;
		return (*this);
	}
	node operator - (const node &b){
		node d;
		d.x = x - b.x;
		d.y = y - b.y;
		return d;
	}
	node operator -= (const node &b){
		(*this) = (*this) - b;
		return (*this);
	}
	node operator * (const node &b){
		node d;
		d.x = x * b.x - y * b.y;
		d.y = x * b.y + y * b.x;
		return d;
	}
	node operator *= (const node &b){
		(*this) = (*this) * b;
		return (*this);
	}
	double mod_lenth(){
		return sqrt(x * x + y * y);
	}
};
node z[101];
inline void Clear(void){
	for(int i = 0; i <= 100; ++ i){
		z[i].x = 0; z[i].y = 0;
	}
}
inline bool check(double x, double y){
	node c; c.x = P; c.y = Q;
	Clear();
	z[0].x = x; z[0].y = y;
	for(int i = 1; i <= 100; ++ i){
		z[i] = (z[i - 1] * z[i - 1]) + c;
		if(z[i].mod_lenth() >= 10)
			return false;
	}
	return true;
}
int yc, xc;
inline void init(void){
	cin >> yc >> xc >> Sy >> Sx;
	cin >> P >> Q;
}

inline void work(void){
	for(int j = 0; j < yc; ++ j){
		for(int i = 0; i < xc; ++ i){
			if(check(Sy + i * 0.005, Sx + j * 0.01) == true)
				c[j][i] = 'a';
			else
				c[j][i] = ' ';
			cout << c[j][i];
		}
		cout << endl;
	}
}

int main(){
	freopen("fractal.in", "r", stdin);
	freopen("fractal.out", "w", stdout);
	init();
	work();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
