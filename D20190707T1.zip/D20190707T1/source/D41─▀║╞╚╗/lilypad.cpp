#include<bits/stdc++.h>

using namespace std;
const int MAXN = 1e5 + 10;
const int MAXM = 2e6 + 10;
const int INF = 0x3f3f3f3f;
#define Index(x, y)  ((x - 1) * m + y)
#define pd(i, j) (i >= 1 && i <= n && j >= 1 && j <= m)
int mp[110][110];
int head[MAXN], to[MAXM], val[MAXM], nxt[MAXM], ind;
void add_edge(int u, int v, int w){
	nxt[ ++ ind] = head[u];
	head[u] = ind;
	to[ind] = v;
	val[ind] = w;
}
int n, m, start, finish;
int fx[8][2] = {{1, 2}, {-1, 2}, {1, -2}, {-1, -2}, {2, 1}, {-2, 1}, {2, -1}, {-2, -1}};
inline void Graph_init(void){
	int nowi, nowj;
	for(int i = 1; i <= n; ++ i){
		for(int j = 1; j <= m; ++ j){
			for(int dir = 0; dir < 8; ++ dir){
				nowi = i + fx[dir][0], nowj = j + fx[dir][1];
				if(pd(nowi, nowj) == true && mp[nowi][nowj] != 2){
					if(mp[nowi][nowj] == 1){
						add_edge(Index(i, j), Index(nowi, nowj), 0);
						//printf("edge    from   (%d, %d)    to  (%d, %d)  val  is   %d\n", i, j, nowi, nowj, 0);
					}
					else{
						add_edge(Index(i, j), Index(nowi, nowj), 1);
						//printf("edge    from   (%d, %d)    to  (%d, %d)  val  is   %d\n", i, j, nowi, nowj, 1);
					}
					
				}
			}
		}
	}
}
inline void init(void){
	cin >> n >> m;
	for(int i = 1; i <= n; ++ i){
		for(int j = 1; j <= m; ++ j){
			cin >> mp[i][j];
			if(mp[i][j] == 3){
				start = Index(i, j); mp[i][j] = 1;
			}
			if(mp[i][j] == 4){
				finish = Index(i, j); mp[i][j] = 1;
			}
		}
	}
	Graph_init();
}
priority_queue<pair<int, int> >q;
int dist[MAXN];
bool vis[MAXN];
int pre[MAXN];

inline void Dijkstra(void){
	memset(dist, INF, sizeof(dist));
	memset(vis, 0, sizeof(vis));
	dist[start] = 0;
	q.push(make_pair(0, start));
	while(q.size()){
		int now = q.top().second; q.pop();
		if(vis[now] == true)
			continue;
		vis[now] = true;
		for(int i = head[now]; i; i = nxt[i]){
			int j = to[i];
			if(dist[j] > dist[now] + val[i]){
				dist[j] = dist[now] + val[i];
				q.push(make_pair(-dist[j], j));
				pre[j] = now;
			}
		}
	}
	
}
int road;
void find_road(int x){
	while(pre[x] != 0){
		++ road;
		x = pre[x];
	}
}
int ans;
inline void work(void){
	Dijkstra();
	find_road(finish);
	if(dist[finish] >= INF)
		cout << "-1 -1";
	else
		cout << dist[finish] << " " << road;
}

int main(){
	freopen("lilypad.in", "r", stdin);
	freopen("lilypad.out", "w", stdout);
	init();
	work();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
