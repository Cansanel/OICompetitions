#include<bits/stdc++.h>

using namespace std;
const int MAXN = 500 + 10;
const int MAXM = 1e5 + 10;
int n, m, cnt;
struct node{
	int x, y, power;
}light[MAXN * MAXM];
int Top;
inline void init(void){
	scanf("%d%d", &n, &m); int now;
	for(int i = 1; i <= n; ++ i){
		for(int j = 1; j <= m; ++ j){
			scanf("%d", &now);
			if(now > 0){
				light[++ cnt].x = i; light[cnt].y = j;
				light[cnt].power = now;
			}
			Top = max(Top, now);
		}
	}
}
int lin[MAXN][MAXM], col[MAXM][MAXN];
void lit_line(int x, int y, int len){
	int f = y - len + 1, t = y + len - 1;
	if(f <= 1) f = 1;
	if(t >= m) t = m;
	lin[x][f] ++; lin[x][t + 1] --;
}

void lit_col(int x, int y, int len){
	int f = x - len + 1, t = y + len - 1;
	if(f <= 1) f = 1;
	if(t >= n) t = n;
	col[y][f] ++; col[y][t + 1] --;
}
inline bool check(int mid){
	memset(lin, 0, sizeof(lin));
	memset(col, 0, sizeof(col));
	for(int i = 1; i <= cnt; ++ i){
		if(light[i].power < mid)
			continue;
		lit_line(light[i].x, light[i].y, mid);
		lit_col(light[i].x, light[i].y, mid);
	}
	for(int i = 1; i <= n; ++ i){
		int now = 0;
		for(int j = 1; j <= m; ++ j){
			now += lin[i][j];
			if(now <= 0)
				return false;
		}
	}
	for(int j = 1; j <= m; ++ j){
		int now = 0;
		for(int i = 1; i <= n; ++ i){
			now += col[j][i];
		}
		if(now <= 0)
			return false;
	}
	return true;
}
int ans;
inline void work(void){
	int chosen = min(Top, max(n, m));
	if((long long)n * m * chosen > (long long )1e10){
		printf("-1"); return ;
	}
	for(int i = 1; i <= chosen; ++ i){
		if(check(i)){
			printf("%d", i);
			return ;
		}
	}
	printf("-1");
}

int main(){
	freopen("lantern.in", "r", stdin);
	freopen("lantern.out", "w", stdout);
	init();
	work();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
