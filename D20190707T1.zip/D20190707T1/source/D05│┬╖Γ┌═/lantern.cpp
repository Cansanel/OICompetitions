#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<iomanip>
#include<algorithm>
using namespace std;
int n,m,a[505][10005],x,y,t;
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	int i,j;
	cin>>n>>m;
	for(i=1;i<=n;i++)
	for(j=1;j<=m;j++)
	cin>>a[i][j];
	do
	{
		y=2100000000;
		for(i=1;i<=n;i++)
		{
			t=0;
			for(j=1;j<=m;j++)
			if(a[i][j]>0&&((t==0&&j<=a[i][j])||(t!=0&&floor((j-t+2)/2)<=a[i][t]&&floor((j-t+2)/2)<=a[i][j]))&&a[i][j]>=x)
			{
				if(t!=0)
				{
					y=min(y,a[i][t]);
					x=max(x,(j-t)/2+1);
					t=j;
				}
				else
				{
					x=max(x,j);
					t=j;
				}
			}
			if(t==0)
			{
				cout<<-1<<endl;
				return 0;
			}
			else
			{
				y=min(y,a[i][t]);
				if(a[i][t]<m+1-t)
				{
					cout<<-1<<endl;
					return 0;
				}
				else
				{
					x=max(x,m+1-t);
				}
			}
		}
		for(j=1;j<=m;j++)
		{
			t=0;
			for(i=1;i<=n;i++)
			if(a[i][j]>0&&((t==0&&i<=a[i][j])||(t!=0&&floor((i-t+2)/2)<=a[t][j]&&floor((i-t+2)/2)<=a[i][j]))&&a[i][j]>=x)
			{
				if(t!=0)
				{
					y=min(y,a[t][j]);
					x=max(x,(i-t)/2+1);
					t=i;
				}
				else
				{
					x=max(x,i);
					t=i;
				}
			}
			if(t==0)
			{
				cout<<-1<<endl;
				return 0;
			}
			else
			{
				y=min(y,a[t][j]);
				if(a[t][j]<n+1-t)
				{
					cout<<-1<<endl;
					return 0;
				}
				else
				{
					x=max(x,n+1-t);
				}
			}
		}
	}while(x>y);
	cout<<x<<endl;
	return 0;
}

