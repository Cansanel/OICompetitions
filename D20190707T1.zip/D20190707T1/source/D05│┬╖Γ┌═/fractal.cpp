#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<iomanip>
#include<algorithm>
using namespace std;
int yc,xc;
double sy,sx,p,q,x,y,xx;
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	int i,j,k;
	bool b;
	cin>>yc>>xc>>sy>>sx>>p>>q;
	for(i=0;i<yc;i++)
	{
		for(j=0;j<xc;j++)
		{
			b=0;
			x=sy+j*0.005;
			y=sx+i*0.01;
			for(k=1;k<=100;k++)
			{
				xx=x*x-y*y+p;
				y=2*x*y+q;
				x=xx;
				if(x*x+y*y>=100)
				{
					b=1;
					break;
				}
			}
			if(b==0)printf("a");
			else printf(" ");
		}
		cout<<endl;
	}
	return 0;
}
/*
400 800 -2 -2 -0.53 0.53
*/

