#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<iomanip>
#include<algorithm>
using namespace std;
int n,m,a[105][105],f[105][105],x,y,z,p,q;
bool b[105][105];
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	int i,j,k,c[2][8];
	c[0][0]=-1;c[1][0]=-2;
	c[0][1]=-2;c[1][1]=-1;
	c[0][2]=-1;c[1][2]=2;
	c[0][3]=1;c[1][3]=-2;
	c[0][4]=2;c[1][4]=-1;
	c[0][5]=-2;c[1][5]=1;
	c[0][6]=1;c[1][6]=2;
	c[0][7]=2;c[1][7]=1;
	cin>>n>>m;
	for(i=1;i<=n;i++)
	for(j=1;j<=m;j++)
	{
		cin>>a[i][j];
		f[i][j]=2100000000;
		if(a[i][j]==3)
		f[i][j]=0;
		if(a[i][j]==4)
		{
			p=i;
			q=j;
		}
	}
	for(k=1;k<=n*m;k++)
	{
		z=2100000000;
		for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
		{
			if(f[i][j]<z&&b[i][j]==0)
			{
				x=i;
				y=j;
				z=f[i][j];
				if(z==0)break;
			}
		}
		b[x][y]=1;
		if(f[x][y]>=f[p][q])break;
		for(i=0;i<=7;i++)
		if(x+c[0][i]>=1&&x+c[0][i]<=n&&y+c[1][i]>=1&&y+c[1][i]<=m&&a[x+c[0][i]][y+c[1][i]]!=2)
		if(a[x+c[0][i]][y+c[1][i]]==0)
		f[x+c[0][i]][y+c[1][i]]=min(f[x+c[0][i]][y+c[1][i]],f[x][y]+10001);
		else
		f[x+c[0][i]][y+c[1][i]]=min(f[x+c[0][i]][y+c[1][i]],f[x][y]+1);
	}
	if(f[p][q]<2000000000)
	cout<<f[p][q]/10000<<' '<<f[p][q]%10000<<endl;
	else cout<<"-1 -1"<<endl;
	return 0;
}

