#include<bits/stdc++.h>
using namespace std;
#define maxn 107
int m,n;
bool vis[maxn][maxn];
int a[maxn][maxn],bx,by,ex,ey,ans=0x7fffffff,step=0x7fffffff;
int dx[8]={-1,1 ,2 ,2,1,-1,-2,-2};
int dy[8]={-2,-2,-1,1,2,2 ,1 ,-1};
template <typename Tp>
void read(Tp &x){
	x=0;char ch=1;int fh;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-'){
		fh=-1;ch=getchar();
	}
	else fh=1;
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	x*=fh;
}
struct node{
	int x,y,add,dep;
	bool operator <(node a)const{
		return add==a.add?dep>a.dep:add>a.add;
	}
};
priority_queue<node>q;
void bfs(){
	q.push((node){bx,by,0,0});vis[bx][by]=0;
	while(!q.empty()){
		int xx=q.top().x,yy=q.top().y,ad=q.top().add,sp=q.top().dep;q.pop();
		if(xx==ex&&yy==ey){
			if(ad<=ans){
				ans=ad;
				step=min(step,sp);
				return;
			}
		}
		for(int i=0;i<8;i++){
			if(dx[i]+xx>=1&&dx[i]+xx<=m&&dy[i]+yy>=1&&dy[i]+yy<=n){
				if(a[dx[i]+xx][dy[i]+yy]==2||!vis[dx[i]+xx][dy[i]+yy]) continue;
				if(a[dx[i]+xx][dy[i]+yy]==0){
					q.push((node){dx[i]+xx,dy[i]+yy,ad+1,sp+1});vis[xx+dx[i]][yy+dy[i]]=0;
				}
				else{
					q.push((node){dx[i]+xx,dy[i]+yy,ad,sp+1});vis[xx+dx[i]][yy+dy[i]]=0;
				}
			}
		}
	}
}

int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	read(m);read(n);
	for(register int i=1;i<=m;i++){
		for(register int j=1;j<=n;j++){
			read(a[i][j]);vis[i][j]=1;
			if(a[i][j]==3) bx=i,by=j;
			if(a[i][j]==4) ex=i,ey=j;
		}
	}
	bfs();
	if(ans==0x7fffffff){
		puts("-1 -1");
	}
	else{
		printf("%d %d\n",ans,step);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

