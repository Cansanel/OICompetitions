#include<bits/stdc++.h>
using namespace std;

#define maxn 503
#define maxm 10003
bool hh[maxn],ll[maxm];
int a[maxn][maxm],n,m,L=1,R,ans=0x7fffffff,mid,s[maxn][maxm],q[maxn][maxm],ma,hhh,lll;
double st;
template <typename Tp>
void read(Tp &x){
	x=0;char ch=1;int fh;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-'){
		fh=-1;ch=getchar();
	}
	else fh=1;
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	x*=fh;
}

bool check(){
	memset(s,0,sizeof(s));memset(q,0,sizeof(q));
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=m;j++){
			if(a[i][j]>=mid){
				s[i][max(1,j-mid+1)]++;
				if(m>=j+mid) s[i][j+mid]--;
//				s[i][min(m,j+mid)]--;
				q[j][max(1,i-mid+1)]++;
				if(n>=i+mid) q[j][i+mid]--;
			}
		}
	}
	for(register int i=1;i<=n;i++){
		int k=0;
		for(register int j=1;j<=m;j++){
			k+=s[i][j];
			if(k<=0) return false;
		}
	}
	for(register int i=1;i<=m;i++){
		int k=0;
		for(register int j=1;j<=n;j++){
			k+=q[i][j];
			if(k<=0) return false;
		}
	}
	return true;
}
void fuck(){
	int lucky=ma/4*3+ma/20,luck=ma/2-ma/20,ans=-1,unluck=ma/4-ma/20;
	bool aaa=0,bbb=0,ccc=0,ddd=0;
	for(mid=luck;mid<=lucky;mid++){
		if((clock()-st)/CLOCKS_PER_SEC>=1.92){
			printf("%d\n",ans);exit(0);
		}
		if(check()){
			ans=mid;aaa=1;break;
		}
	}
	for(mid=1;mid<unluck;mid++){
		if((clock()-st)/CLOCKS_PER_SEC>=1.92){
			printf("%d\n",ans);exit(0);
		}
		if(check()){
			printf("%d\n",mid);bbb=1;exit(0);
		}
	}
	for(mid=unluck;mid<luck;mid++){
		if(bbb) break;
		if((clock()-st)/CLOCKS_PER_SEC>=1.92){
			printf("%d\n",ans);exit(0);
		}
		if(check()){
			ans=mid;break;
		}
	}
	for(mid=lucky+1;mid<=ma;mid++){
		if(aaa||bbb) break;
		if((clock()-st)/CLOCKS_PER_SEC>=1.92){
			printf("%d\n",ans);exit(0);
		}
		if(check()){
			printf("%d\n",mid);exit(0);
		}
	}
}
int main(){
	st=clock();
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	read(n);read(m);lll=m,hhh=n;
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=m;j++){
			read(a[i][j]);
			R=max(R,a[i][j]);
			if(a[i][j]){
				if(!hh[i]) hhh--;
				hh[i]=1;
				if(!ll[j]) lll--;
				ll[j]=1;
			}
		}
	}
	if(hhh||lll){
		puts("-1");return 0;
	}
	ma=min(R,max(m,n));
	if(ma>1000){
		fuck();
		return 0;
	}
	for(mid=1;mid<=ma;mid++){
		if(check()){
			printf("%d\n",mid);return 0;
		}
	}
	puts("-1");
	fclose(stdin);
	fclose(stdout);
	return 0;
}

