#include<bits/stdc++.h>
using namespace std;

int yc,xc;
double Sy,Sx,P,Q;

template <typename Tp>
void read(Tp &x){
	x=0;char ch=1;int fh;
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-'){
		fh=-1;ch=getchar();
	}
	else fh=1;
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	x*=fh;
}

double getlong(double x,double y){
	double k=x*x+y*y;
	double re=sqrt(k);
	return re;
}

bool check(double x,double y){
	double lx=x,ly=y;
	for(int i=1;i<=100;i++){
		x=lx*lx-ly*ly;
		y=lx*ly+lx*ly;
		x=x+P,y=y+Q;
		lx=x,ly=y;
		double l=getlong(x,y);
		if(l>=10.0) return false;
	}
	return true;
}

int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d%d%lf%lf%lf%lf",&yc,&xc,&Sy,&Sx,&P,&Q);
	for(register int j=0;j<yc;j++){
		for(register int i=0;i<xc;i++){
			if(check(Sy+(double)i*0.005,Sx+(double)j*0.01)){
				putchar('a');
			}
			else putchar(' ');
		}
		puts("");
	}
	fclose(stdin);fclose(stdout);
	return 0;
}

