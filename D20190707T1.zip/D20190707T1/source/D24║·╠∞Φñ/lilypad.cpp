#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<deque>
#include<queue>
using namespace std;

int n,m;
int point[105][105];
int d[105][105];
int v[105][105];
struct P
{
	int x,y;
}start,dest;
int bushu[105][105];
int put[105][105];

void bfs()
{
	for(int i=1;i<=102;++i)
		for(int j=1;j<=102;++j)
			{d[i][j]=-1;bushu[i][j]=-1;}
	memset(v,0,sizeof(v));
	deque<P> q;
	q.push_front(start);
	d[start.x][start.y]=0;v[start.x][start.y]=1;//bushu[start.x][start.y]=0;
	while(q.size()>0)
	{
		P xx=q.front();q.pop_front();
		for(int i=-2;i<=2;++i)
		{
			if(i==0) continue;
			for(int j=-2;j<=2;++j)
			{
				if(j==i||j==-i||j==0) continue;
				P yy;
				yy.x=xx.x+i;yy.y=xx.y+j;
				if(yy.x<1||yy.x>m||yy.y<1||yy.y>n) continue;
				if(v[yy.x][yy.y]) continue;
				if(point[yy.x][yy.y]==2) continue;
				if(point[yy.x][yy.y]==0)
				{
					d[yy.x][yy.y]=d[xx.x][xx.y]+1;
					v[yy.x][yy.y]=1;
					//bushu[yy.x][yy.y]=bushu[xx.x][xx.y]+1;
					q.push_back(yy);
				}
				if(point[yy.x][yy.y]==1)
				{
					d[yy.x][yy.y]=d[xx.x][xx.y];
					v[yy.x][yy.y]=1;
					//bushu[yy.x][yy.y]=bushu[xx.x][xx.y]+1;
					q.push_front(yy);
				}
				if(point[yy.x][yy.y]==4)
				{
					d[yy.x][yy.y]=d[xx.x][xx.y];
					v[yy.x][yy.y]=1;
					q.push_front(yy);
					//bushu[yy.x][yy.y]=bushu[xx.x][xx.y]+1;
					//return;
				}
			}
		}
	}
}

void bfs2()
{
	memset(put,0,sizeof(put));
	for(int i=1;i<=102;++i)
		for(int j=1;j<=102;++j)
			bushu[i][j]=-1;
	memset(v,0,sizeof(v));
	queue<P> q;
	q.push(start);v[start.x][start.y]=1;bushu[start.x][start.y]=0;
	while(q.size()>0)
	{
		P xx=q.front();q.pop();
		for(int i=-2;i<=2;++i)
		{
			if(i==0) continue;
			for(int j=-2;j<=2;++j)
			{
				if(j==i||j==-i||j==0) continue;
				P yy;
				yy.x=xx.x+i;yy.y=xx.y+j;
				if(yy.x<1||yy.x>m||yy.y<1||yy.y>n) continue;
				if(v[yy.x][yy.y]) continue;
				if(point[yy.x][yy.y]==2) continue;
				if(point[yy.x][yy.y]==0)
				{
					put[yy.x][yy.y]=put[xx.x][xx.y]+1;
					if(put[yy.x][yy.y]>d[yy.x][yy.y]) continue;
					v[yy.x][yy.y]=1;
					bushu[yy.x][yy.y]=bushu[xx.x][xx.y]+1;
					q.push(yy);
				}
				if(point[yy.x][yy.y]==1)
				{
					put[yy.x][yy.y]=put[xx.x][xx.y];
					if(put[yy.x][yy.y]>d[yy.x][yy.y]) continue;
					v[yy.x][yy.y]=1;
					bushu[yy.x][yy.y]=bushu[xx.x][xx.y]+1;
					q.push(yy);
				}
				if(point[yy.x][yy.y]==4)
				{
					put[yy.x][yy.y]=put[xx.x][xx.y];
					if(put[yy.x][yy.y]>d[yy.x][yy.y]) continue;
					v[yy.x][yy.y]=1;
					bushu[yy.x][yy.y]=bushu[xx.x][xx.y]+1;
					return;
				}
			}
		}
	}
}

int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int i=1;i<=m;++i)
	{
		for(int j=1;j<=n;++j)
		{
			scanf("%d",&point[i][j]);
			if(point[i][j]==3)
			{
				start.x=i;start.y=j;
			}
			if(point[i][j]==4)
			{
				dest.x=i;dest.y=j;
			}
		}
	}
	bfs();
	bfs2();
	printf("%d %d\n",d[dest.x][dest.y],bushu[dest.x][dest.y]);
	return 0;
}
