#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;

int yc,xc;
long double sy,sx,p,q;
char c[805][805];
struct Z
{
	long double real,notreal;
}z[102];

long double length(long double x,long double y)
{
	return sqrt(x*x+y*y);
}

bool calc(long double x,long double y)
{
	z[0].real=x;z[0].notreal=y;
	for(int i=1;i<=100;++i)
	{
		z[i].real=z[i-1].real*z[i-1].real-z[i-1].notreal*z[i-1].notreal+p;
		z[i].notreal=z[i-1].real*2*z[i-1].notreal+q;
		if(length(z[i].real,z[i].notreal)>=10) return false;
	}
	return true;
}

int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx;
	cin>>p>>q;
	for(int j=0;j<yc;++j)
	{
		for(int i=0;i<xc;++i)
		{
			if(calc(sy+(long double)i*0.005,sx+(long double)j*0.01)) c[j][i]='a';
			else c[j][i]=' ';
		}
	}
	for(int i=0;i<yc;++i)
	{
		for(int j=0;j<xc;++j)
		{
			cout<<c[i][j];
		}
		cout<<endl;
	}
	return 0;
}
