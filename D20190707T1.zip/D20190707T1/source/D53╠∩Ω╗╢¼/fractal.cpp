#include <bits/stdc++.h>
using namespace std;

int yc, xc;
double Sy, Sx, P, Q;

struct comp {
	double x, y;
	comp operator + (const comp& a) {
		comp ans;
		ans.x = x + a.x;
		ans.y = y + a.y;
		return ans;
	}
	comp operator - (const comp& a) {
		comp ans;
		ans.x = x - a.x;
		ans.y = y - a.y;
		return ans;
	}
	comp operator * (const comp& a) {
		comp ans;
		ans.x = x * a.x - y * a.y;
		ans.y = x * a.y + y * a.x;
		return ans;
	}
	comp operator = (const comp& a) {
		x = a.x;
		y = a.y;
		return a;
	}
	double Mod() {
		return sqrt(x * x + y * y);
	}
	
};

bool restrain(double x, double y) {
	comp c;
	c.x = P, c.y = Q;
	comp z[101];
	z[0].x = x, z[0].y = y;
	for (register int i = 1; i <= 100; ++i) {
		z[i] = (z[i - 1] * z[i - 1]) + c;
		if (z[i].Mod() >= 10) return false;
	}
	return true;
}


int main() {
	freopen("fractal.in", "r", stdin);
	freopen("fractal.out", "w", stdout);
	cin >> yc >> xc >> Sy >> Sx >> P >> Q;
	for (register int j = 0; j < yc; ++j) {
		for (register int i = 0; i < xc; ++i) {
			if (restrain(Sy + i * 0.005, Sx + j * 0.01)) putchar('a');
			else putchar(' ');
		}
		putchar('\n');
	}
	
	return 0;
}
/*
400 800 -2 -2
-0.53 0.53
*/
