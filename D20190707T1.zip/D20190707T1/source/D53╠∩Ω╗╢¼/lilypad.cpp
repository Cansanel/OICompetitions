#include <bits/stdc++.h>
#define P(x, y) ((x - 1) * N + y)
using namespace std;
const int MAXN = 105;
const int INF = 0x3f3f3f3f;
const int nx[] = {2, 1, -1, -2, -2, -1, 1, 2};
const int ny[] = {1, 2, 2, 1, -1, -2, -2, -1};


int N, M, S, T;
int a[MAXN][MAXN];

int lily[MAXN * MAXN], step[MAXN * MAXN];
bool inq[MAXN * MAXN];

inline void spfa() {
	memset(lily, 0x3f, sizeof(lily));
	memset(step, 0x3f, sizeof(step));
	queue<int> q;
	memset(inq, 0, sizeof(inq));
	q.push(S);
	step[S] = lily[S] = 0;
	inq[S] = 1;
	while (q.size()) {
		int u = q.front();
		int x = (u / N) + 1, y = u % N;
		if (y == 0) y = N, x--;
		q.pop();
		inq[u] = 0;
		for (register int i = 0; i < 8; ++i) {
			int tx = x + nx[i], ty = y + ny[i], w;
			if (tx < 1 || tx > M || ty < 1 || ty > N) continue;
			if (a[tx][ty] == 2) continue;
			if (a[tx][ty] == 0) w = 1;
			else w = 0;
			int v = P(tx, ty);
			if (lily[u] + w < lily[v]) {
				lily[v] = lily[u] + w;
				step[v] = step[u] + 1;
				if (inq[v] == 0) {
					inq[v] = 1;
					q.push(v);
				}
			}
		}
	}
}

int main() {
	freopen("lilypad.in", "r", stdin);
	freopen("lilypad.out", "w", stdout);
	scanf("%d%d", &M, &N);
	for (register int i = 1; i <= M; ++i)
		for (register int j = 1; j <= N; ++j) {
			scanf("%d", &a[i][j]);
			if (a[i][j] == 3) S = P(i, j);
			if (a[i][j] == 4) T = P(i, j);
		}
	spfa();
	if (lily[T] >= INF) puts("-1 -1");
	else printf("%d %d", lily[T], step[T]);
	return 0;
}
/*
4 8
0 0 0 1 0 0 0 0 
0 0 0 0 0 2 0 1
0 0 0 0 0 4 0 0
3 0 0 0 0 0 1 0

5 5
0 0 2 0 4 
0 0 2 0 0
2 0 2 2 0 
0 0 0 0 0
0 3 0 0 0



*/
