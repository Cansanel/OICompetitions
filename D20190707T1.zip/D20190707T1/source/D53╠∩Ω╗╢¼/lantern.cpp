#pragma GCC optimize(2)
#include <bits/stdc++.h>
using namespace std;

int N, M;
int a[51][10001]; // fit 50%

inline bool check(int R) {
	for (register int i = 1; i <= N; ++i) {
		int cnt = -1 * R + 1;
		for (register int j = 1; j <= M; ++j) {
			cnt--;
			if (a[i][j] >= R) cnt = 0; 
			if (cnt == -2 * R + 1) return 0;
		}
		if (cnt <= -1 * R) return 0;
	}
	for (register int j = 1; j <= M; ++j) {
		int cnt = -1 * R + 1;
		for (register int i = 1; i <= N; ++i) {
			cnt--;
			if (a[i][j] >= R) cnt = 0;
			if (cnt == -2 * R + 1) return 0;
		}
		if (cnt <= -1 * R) return 0;
	}
	return 1;
}

int main() {
	freopen("lantern.in", "r", stdin);
	freopen("lantern.out", "w", stdout);
	scanf("%d%d", &N, &M);
	int maxr = 0;
	for (register int i = 1; i <= N; ++i) {
		for (register int j = 1; j <= M; ++j) {
			scanf("%d", &a[i][j]);
			maxr = max(maxr, a[i][j]);
		}
	}
	for (register int i = 1; i <= maxr; ++i) {
		if (check(i)) {
			printf("%d", i);
			return 0;
		}
	}
	puts("-1");
	return 0;
}
