#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	
	fclose(stdin);fclose(stdout);
	return 0;
}
