#include<bits/stdc++.h>
using namespace std;
const int dx[9]={0,1,2,-1,-2,1,2,-1,-2},
		  dy[9]={0,2,1,2,1,-2,-1,-2,-1};
int n,m,num,ans,ans2,ansans,s1,t1,s2,t2,a[105][105];
bool flag;
bool v[105][105]={0};
void dfs(int l,int r,int k,int step)
{
	if(l==s2&&r==t2)
	{
		if(k>=0) flag=true;
		if(step<ans2) ans2=step;
		return;
	}
	for(int i=1;i<=8;i++)
	{
		int x=l+dx[i],y=r+dy[i];
		if(a[x][y]!=2&&v[x][y]==0&&x>0&&x<=m&&y>0&&y<=n)
		{
			if(a[x][y]==0) k--;	
			if(k<0) return;
			v[x][y]=1;
			dfs(x,y,k,step+1);
			v[x][y]=0;
			if(a[x][y]==0) k++;	
		}
	}
}
bool check(int k)
{
	flag=false;
	dfs(s1,t1,k,0);
	if(flag) return true;
	else return false;
}
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int i=1;i<=m;i++)
		for(int j=1;j<=n;j++) 
		{
			scanf("%d",&a[i][j]);
			if(a[i][j]==0) num++;
			if(a[i][j]==3) {s1=i;t1=j;}
			if(a[i][j]==4) {s2=i;t2=j;}
		}
	int l=0,r=num;
	while(l<r)
	{
		ans2=100000000;
		int mid=(l+r)>>1;
		if(check(mid))
		{
			r=mid;
			ans=mid;
			ansans=ans2;
		}
		else
		{
			l=mid+1;
		}
	}
	if(ans==0&&flag==false) printf("-1 -1");
	else printf("%d %d",ans,ansans);
	fclose(stdin);fclose(stdout);
	return 0;
}
