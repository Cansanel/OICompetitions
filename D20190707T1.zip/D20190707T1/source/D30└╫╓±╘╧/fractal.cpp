#include<bits/stdc++.h>
using namespace std;
int yc,xc,sy,sx,P,Q;
struct node
{
	int x,y;
}z[1000];
bool check(int x,int y)
{
	memset(z,0,sizeof(z));
	z[0].x=x; z[0].y=y;
	if(x*x+y*y>=100) return false;
	for(int i=1;i<=100;i++)
	{
		z[i].x=(z[i-1].x*z[i-1].x-z[i-1].y*z[i-1].y)+P;
		z[i].y=(z[i-1].x*z[i-1].y+z[i-1].y*z[i-1].x)+Q;
		if(z[i].x*z[i].x+z[i].y*z[i].y>=100) return false;
	}
	return true;
}
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d%d%d%d",&yc,&xc,&sy,&sx);
	scanf("%d%d",&P,&Q);
	for(int i=0;i<yc;i++)
	{
		for(int j=0;j<xc;j++)
		{
			if(check(sy+i*0.005,sx+j*0.01)) printf("a");
			else printf(" ");
		}
		printf("\n");
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
