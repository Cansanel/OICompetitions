#include <cstdio>
#include <cstring>
#include <queue>
using namespace std;
struct node{
  int step;
  int x;
  int y;
  int lil;
};
queue<node> q0;
queue<node> q1;
int n,m;
int sx,sy,ex,ey;
int dx[]={0,-2,-2,-1,1,2,2,1,-1};
int dy[]={0,-1,1,2,2,1,-1,-2,-2};
int mp[110][110];
bool vis[110][110];

node nodemk(int step,int x,int y,int lil)
{
  node ans;
  ans.x=x;
  ans.y=y;
  ans.step=step;
  ans.lil=lil;
  return ans;
}

node bfs()
{
  q0.push(nodemk(0,sx,sy,0));
  vis[sx][sy]=1;
  node ans;
  ans.x=0;
  ans.y=0;
  ans.lil=0x3f3f3f3f;
  ans.step=0x3f3f3f3f;
  while(!q0.empty()||!q1.empty())
  {
  	while(!q0.empty())
    {
  	  node cur=q0.front();
//  	  printf("%d %d %d\n",cur.x,cur.y,cur.lil);
  	  q0.pop();
  	  for(int i=1;i<=8;i++)
  	  {
  	    int nx=cur.x+dx[i];
  	    int ny=cur.y+dy[i];
  	    if(nx<1||ny<1||nx>n||ny>m||vis[nx][ny]||mp[nx][ny]==2)  continue;
  	    vis[nx][ny]=1;
  	    if(nx==ex&&ny==ey)
  	    {
  	  	  if(ans.lil==cur.lil)  ans.step=min(ans.step,cur.step+1);
  	  	  if(ans.lil>cur.lil)
		  {
		  	ans.lil=cur.lil;
		  	ans.step=cur.step+1;
		  }
//  	  	  printf("record:ans,%d %d\n",ans.lil,ans.step);
  	    }else{
  	      if(mp[nx][ny]==1)  q0.push(nodemk(cur.step+1,nx,ny,cur.lil));
  	      if(mp[nx][ny]==0)  q1.push(nodemk(cur.step+1,nx,ny,cur.lil+1));
  	    }
  	    
  	  }
    }
    while(!q1.empty())
    {
      node cur=q1.front();
//      printf("%d %d %d\n",cur.x,cur.y,cur.lil);
  	  q1.pop();
  	  for(int i=1;i<=8;i++)
  	  {
  	    int nx=cur.x+dx[i];
  	    int ny=cur.y+dy[i];
  	    if(nx<1||ny<1||nx>n||ny>m||vis[nx][ny]||mp[nx][ny]==2)  continue;
  	    vis[nx][ny]=1;
  	    if(nx==ex&&ny==ey)
  	    {
  	  	  if(ans.lil==cur.lil)  ans.step=min(ans.step,cur.step+1);
  	  	  if(ans.lil>cur.lil)
		  {
		  	ans.lil=cur.lil;
		  	ans.step=cur.step+1;
		  }
//  	  	  printf("record:ans,%d %d\n",ans.lil,ans.step);
  	    }else{
  	      if(mp[nx][ny]==1)  q0.push(nodemk(cur.step+1,nx,ny,cur.lil));
  	      if(mp[nx][ny]==0)  q1.push(nodemk(cur.step+1,nx,ny,cur.lil+1));
  	    }
  	  }
  	  break;
    }
  }
  if(ans.lil==0x3f3f3f3f)  return nodemk(-1,0,0,-1);
  else  return ans;
}
int main()
{
  freopen("lilypad.in","r",stdin);
  freopen("lilypad.out","w",stdout);
  scanf("%d %d",&n,&m);
  for(int i=1;i<=n;i++)
  {
  	for(int j=1;j<=m;j++)
  	{
  	  scanf("%d",&mp[i][j]);
  	  if(mp[i][j]==3)
  	  {
  	  	sx=i;
  	  	sy=j;
  	  }
  	  if(mp[i][j]==4)
  	  {
  	  	ex=i;
  	  	ey=j;
  	  }
  	}
  }
//  printf("%d %d %d %d\n",sx,sy,ex,ey);
  node ans=bfs();
  printf("%d %d\n",ans.lil,ans.step);
  return 0;
}
