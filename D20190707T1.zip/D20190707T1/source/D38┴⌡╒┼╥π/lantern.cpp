#include <cstdio>
#include <cstring>
using namespace std;
int n,m;
int len[510][10010];
int min(long long a,long long b)
{
  return a<=b?a:b;
}

int max(int x,int y)
{
  return x>=y?x:y;
}

bool check(int x)
{
  for(int i=1;i<=n;i++)
  {
  	for(int j=1;j<=m;j++)
  	{
  	  bool judge1=0;
  	  bool judge2=0;
  	  for(int k=0;k<x;k++)
  	  {
  	    if(len[i][j+k]>=x)  judge1=1;
  	    if(j-k>0)  if(len[i][j-k]>=x)  judge1=1;
  	    if(len[i+k][j]>=x)  judge2=1;
  	    if(i-k>0)  if(len[i-k][j]>=x)  judge2=1;
  	  }
  	  if(!(judge1&&judge2))
	  return 0;
  	}
  }
  return 1;
}

int main()
{
  freopen("lantern.in","r",stdin);
  freopen("lantern.out","w",stdout);
  scanf("%d %d",&n,&m);
  int maxn=0;
  for(int i=1;i<=n;i++)
  {
  	for(int j=1;j<=m;j++)
  	{
  	  scanf("%d",&len[i][j]);
  	  maxn=max(maxn,len[i][j]);
  	}
  }
  bool judge=0;
  int ans;
  for(int i=1;i<=min(2*m,min(maxn,2*n));i++)
  {
  	if(check(i))
  	{
  	  judge=1;
  	  ans=i;
  	  break;
  	}
  }
  if(!judge)  printf("-1\n");
  else  printf("%d\n",ans);
  return 0;
}
