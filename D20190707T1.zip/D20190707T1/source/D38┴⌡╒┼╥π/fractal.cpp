#include <bits/stdc++.h>
using namespace std;
double xc,yc,sx,sy,p,q;
struct node{
  double x;
  double y;
}z[110];
char c[810][810];
node add(node a,node b)
{
  node ans;
  ans.x=a.x+b.x;
  ans.y=a.y+b.y;
  return ans;
}
node qpow(node z)
{
  node ans;
  ans.x=z.x*z.x-z.y*z.y;
  ans.y=z.x*z.y+z.x*z.y;
  return ans;
}
bool check(double dx,double dy)
{
  memset(z,0,sizeof(z));
  node cx;
  cx.x=p;
  cx.y=q;
  z[0].x=dx;
  z[0].y=dy;
  if(z[0].x*z[0].x+z[0].y*z[0].y>=100)  return 0;
  for(int i=1;i<=100;i++)
  {
  	z[i]=add(qpow(z[i-1]),cx);
  	if(z[i].x*z[i].x+z[i].y*z[i].y>=100)  return 0;
  }
  return 1;
}
int main()
{
  freopen("fractal.in","r",stdin);
  freopen("fractal.out","w",stdout);
  scanf("%lf %lf %lf %lf %lf %lf",&xc,&yc,&sx,&sy,&p,&q);
  for(int i=0;i<xc;i++)
  	for(int j=0;j<yc;j++)
  	  if(check(sx+j*0.005,sy+i*0.01))  c[i][j]='a';
  	  else  c[i][j]=' ';
  for(int i=0;i<xc;i++)
  {
  	for(int j=0;j<yc;j++)  printf("%c",c[i][j]);
  	printf("\n");
  }
  return 0;
}
