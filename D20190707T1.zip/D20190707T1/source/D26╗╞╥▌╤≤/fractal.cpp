#include<bits/stdc++.h>
using namespace std;
template<typename T>inline void read(T &x){
	long long f=1;x=0;char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	x*=f;
}
template<typename T>inline void write(T x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
}
template<typename T>inline void writeln(T x){
	write(x);
	putchar('\n');
}
struct Complex{
	double x,y;
}z[200];
Complex Add(Complex t1,Complex t2){
	Complex res;
	res.x=t1.x+t2.x;
	res.y=t1.y+t2.y;
	return res;
}
Complex Sub(Complex t1,Complex t2){
	Complex res;
	res.x=t1.x-t2.x;
	res.y=t1.y-t2.y;
	return res;
}
Complex Mul(Complex t1,Complex t2){
	Complex res;
	res.x=t1.x*t2.x-t1.y*t2.y;
	res.y=t1.x*t2.y+t1.y*t2.x;
	return res;
}
double Mc(Complex t1){
	return sqrt(t1.x*t1.x+t1.y*t1.y);
}
int yc,xc;
double P,Q,Sy,Sx;
char c[2000][2000];
bool Sl(double X,double Y){
	Complex C=(Complex){P,Q};
	z[0].x=X;z[0].y=Y;
//	if(Mc(z[0])>=10)return 0;
	for(int i=1;i<=100;i++){
		z[i]=Add(Mul(z[i-1],z[i-1]),C);
		if(Mc(z[i])>=10)return 0;
	}
	return 1;
}
void work(){
	for(int j=0;j<yc;j++){
		for(int i=0;i<xc;i++){
			if(Sl(Sy+i*0.005,Sx+j*0.01)){
				c[j][i]='a';
			}else{
				c[j][i]=' ';
			}
		}
	}
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);

	read(yc);read(xc);
	cin>>Sy>>Sx>>P>>Q;
	
	work();
	
	for(int j=0;j<yc;j++){
		for(int i=0;i<xc;i++){
			putchar(c[j][i]);
		}
		putchar('\n');
	}
	return 0;
}
/*
400 800 -2 -2
-0.53 0.53

400 800 -2 -2
-0.53 0.53

800 800 -1.75 -1.75
-1.326 0.01

800 800 -1 -1
-1.326 0.01

*/
