#include<bits/stdc++.h>
using namespace std;
template<typename T>inline void read(T &x){
	long long f=1;x=0;char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	x*=f;
}
template<typename T>inline void write(T x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
}
template<typename T>inline void writeln(T x){
	write(x);
	putchar('\n');
}
const int dir[8][2]={{1,2},{2,1},{-1,2},{-2,1},{1,-2},{2,-1},{-1,-2},{-2,-1}};
struct Info{
	int x,y,step;
}S,T;
int n,m,a[200][200],vis[200][200],flg,ans;
void init(){
	memset(vis,0,sizeof(vis));
}
void bfs1(){
	queue<Info>q;
	q.push(S);
	vis[S.x][S.y]=1;
	while(!q.empty()){
		Info Qtop=q.front();q.pop();
		if(Qtop.x==T.x&&Qtop.y==T.y){
			write(0);putchar(' ');writeln(Qtop.step);
			exit(0);
		}
		int x=Qtop.x,y=Qtop.y;
		for(int i=0;i<8;i++){
			int tx=x+dir[i][0];
			int ty=y+dir[i][1];
			if(tx>=1&&tx<=n&&ty>=1&&ty<=m&&a[tx][ty]==1&&!vis[tx][ty]){
				Info tmp=(Info){tx,ty,Qtop.step+1};
				vis[tx][ty]=1;
				q.push(tmp);
			}
		}
	}
}
void dfs1(int x,int y){
	vis[x][y]=1;
	for(int i=0;i<8;i++){
		int tx=x+dir[i][0];
		int ty=y+dir[i][1];
		if(tx>=1&&tx<=n&&ty>=1&&ty<=m&&a[tx][ty]!=2&&!vis[tx][ty]){
			dfs1(tx,ty);
		}
	}
}
void dfs2(int x,int y,int k){
	if(flg)return;
	if(x==T.x&&y==T.y){
		flg=1;
		return;
	}
	vis[x][y]=1;
	for(int i=0;i<8;i++){
		int tx=x+dir[i][0];
		int ty=y+dir[i][1];
		if(tx>=1&&tx<=n&&ty>=1&&ty<=m&&!vis[tx][ty]){
			if(a[tx][ty]==1){
				dfs2(tx,ty,k);
			}else if(a[tx][ty]==0&&k){
				dfs2(tx,ty,k-1);
			}
		}
	}
	vis[x][y]=0;
}
void dfs3(int x,int y,int k,int step){
	if(x==T.x&&y==T.y){
		ans=min(ans,step);
		return;
	}
	vis[x][y]=1;
	for(int i=0;i<8;i++){
		int tx=x+dir[i][0];
		int ty=y+dir[i][1];
		if(tx>=1&&tx<=n&&ty>=1&&ty<=m&&!vis[tx][ty]){
			if(a[tx][ty]==1){
				dfs3(tx,ty,k,step+1);
			}else if(a[tx][ty]==0&&k){
				dfs3(tx,ty,k-1,step+1);
			}
		}
	}
	vis[x][y]=0;
}
bool check(int k){
	init();
	flg=0;
	dfs2(S.x,S.y,k);
	return flg;
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);

	read(n);read(m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			read(a[i][j]);
			if(a[i][j]==3){
				S.x=i;S.y=j;S.step=0;
				a[i][j]=1;
			}else if(a[i][j]==4){
				T.x=i;T.y=j;T.step=0;
				a[i][j]=1;
			}
		}
	}
	
	init();
	bfs1();
	init();
	dfs1(S.x,S.y);
	if(!vis[T.x][T.y]){
		write(-1);putchar(' ');writeln(-1);
		return 0;
	}
	
	int l=0,r=10000;
	while(l+1<r){
		int mid=(l+r)>>1;
		if(check(mid)){
			r=mid;
		}else{
			l=mid;
		}
	}
	
	write(r);putchar(' ');
	init();
	ans=0x3f3f3f3f;
	dfs3(S.x,S.y,r,0);
	writeln(ans);
	return 0;
}
/*
4 8
0 0 0 1 0 0 0 0
0 0 0 0 0 2 0 1
0 0 0 0 0 4 0 0
3 0 0 0 0 0 1 0

4 8
0 0 0 1 0 0 0 0
0 0 0 0 0 2 0 1
0 0 1 0 1 4 0 0
3 0 0 0 0 0 1 0

3 3
0 0 4
1 3 2
0 0 1

4 3
0 0 4
1 3 2
0 0 0
0 1 1

4 3
0 0 4
0 3 2
0 0 0
0 1 0

*/
