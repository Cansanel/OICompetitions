#include<bits/stdc++.h>
using namespace std;
template<typename T>inline void read(T &x){
	long long f=1;x=0;char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	x*=f;
}
template<typename T>inline void write(T x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+48);
}
template<typename T>inline void writeln(T x){
	write(x);
	putchar('\n');
}
int n,m,a[510][10010],h[510][10010];
void light(int x,int y,int r){
	for(int i=y-r+1;i<=y+r-1;i++){
		if(1<=i&&i<=m)h[x][i]|=1;
	}
	for(int i=x-r+1;i<=x+r-1;i++){
		if(1<=i&&i<=n)h[i][y]|=2;
	}
}
bool check(int x){
	memset(h,0,sizeof(h));
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(a[i][j]>=x)light(i,j,x);
		}
	}
	
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(h[i][j]^3)return 0;
		}
	}
	return 1;
}
bool wj(){
	memset(h,0,sizeof(h));
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			light(i,j,a[i][j]);
		}
	}
	
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(h[i][j]^3)return 1;
		}
	}
	return 0;
}
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	
	int l=0,r=-1;
	read(n);read(m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			read(a[i][j]);
			if(a[i][j])r=max(r,a[i][j]);
		}
	}
	
	if(wj()){
		writeln(-1);
		return 0;
	}
	
	while(l+1<r){
		int mid=(l+r)>>1;
		if(check(mid)){
			r=mid;
		}else{
			l=mid;
		}
	}
	writeln(r);
	return 0;
}
/*
2 2
0 2
3 0

2 2
0 0
3 0

5 5
1 2 3 4 5
5 4 3 2 1
0 0 9 0 0
1 2 3 4 5
5 4 3 2 1

5 5
2 2 2 2 2
2 0 2 0 2
2 2 2 2 2
2 0 2 0 2
2 2 2 2 2

10 10
9 0 0 0 0 0 0 0 0 9
0 0 9 0 0 0 0 9 0 0
0 9 0 0 0 0 0 0 9 0
0 0 0 9 0 0 9 0 0 0
0 0 0 0 9 9 0 0 0 0
0 0 0 0 9 9 0 0 0 0
0 0 0 9 0 0 9 0 0 0
0 9 0 0 0 0 0 0 9 0
0 0 9 0 0 0 0 9 0 0
9 0 0 0 0 0 0 0 0 9

*/
