#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
#define ld long double
#define F(i,j,k) for(int i=j;i<=k;i++)
#define DF(i,j,k) for(int i=j;i>=k;i--)
#define P pair<double,double>
#define M make_pair
#define dui priority_queue
template<typename T>inline void read(T &n){
	T w=1;n=0;char ch=getchar();
	while(!isdigit(ch)&&ch!=EOF){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch)&&ch!=EOF){n=(n<<3)+(n<<1)+(ch&15);ch=getchar();}
	n*=w;
}
template<typename T>inline void write(T x){
	T l=0;
	ull y=0;
	if(!x){putchar(48);return;}
	if(x<0){x=-x;putchar('-');}
	while(x){y=y*10+x%10;x/=10;l++;}
	while(l){putchar(y%10+48);y/=10;l--;}
}
template<typename T>inline void writes(T x){
	write(x);
	putchar(' ');
}
template<typename T>inline void writeln(T x){
	write(x);
	puts("");
}
template<typename T>inline void checkmax(T &a,T b){a=max(a,b);}
template<typename T>inline void checkmin(T &a,T b){a=min(a,b);}
const int dx[9]={0,1,2,1,2,-1,-2,-1,-2},dy[9]={0,2,1,-2,-1,2,1,-2,-1};
int mp[1100][1100],node[1100][1100],dis1[410000],dis2[410000];
int v[410000],to[410000],cnt,head[410000],nxt[410000];
int start,end;
inline void addedge(int x,int y,int w){
	to[++cnt]=y;
	nxt[cnt]=head[x];
	v[cnt]=w;
	head[x]=cnt;
}
inline void SPFA(){
	 queue <int>q;
	 q.push(start);
	 while(!q.empty()){
	 	int x=q.front();q.pop();
	 	for(int i=head[x];i;i=nxt[i])if(dis1[x]+v[i]<dis1[to[i]]||(dis1[x]+v[i]==dis1[to[i]]&&dis2[x]+1<dis2[to[i]])){dis1[to[i]]=dis1[x]+v[i];dis2[to[i]]=dis2[x]+1;q.push(to[i]);}	 
	}
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	int n,m;read(n);read(m);
	F(i,1,n)
		F(j,1,m){
			read(mp[i][j]);
			node[i][j]=(i-1)*m+j;
			if(mp[i][j]==3)start=node[i][j];
			if(mp[i][j]==4)end=node[i][j];
		}
	F(i,1,n)
		F(j,1,m)
			F(k,1,8)
				if(i+dx[k]>0&&i+dx[k]<=n&&j+dy[k]>0&&j+dy[k]<=m&&mp[i+dx[k]][j+dy[k]]!=2){addedge(node[i][j],node[i+dx[k]][j+dy[k]],!mp[i+dx[k]][j+dy[k]]);}
	F(i,1,n*m)dis1[i]=dis2[i]=1000000;
	dis1[start]=dis2[start]=0;
	SPFA();
	if(dis1[end]==1000000)puts("-1 -1");
	else 
	{
		writes(dis1[end]);
		writeln(dis2[end]);
	}
	return 0;
}
