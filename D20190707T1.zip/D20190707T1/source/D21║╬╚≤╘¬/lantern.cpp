#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
#define ld long double
#define F(i,j,k) for(int i=j;i<=k;i++)
#define DF(i,j,k) for(int i=j;i>=k;i--)
#define P pair<double,double>
#define M make_pair
#define dui priority_queue
template<typename T>inline void read(T &n){
	T w=1;n=0;char ch=getchar();
	while(!isdigit(ch)&&ch!=EOF){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch)&&ch!=EOF){n=(n<<3)+(n<<1)+(ch&15);ch=getchar();}
	n*=w;
}
template<typename T>inline void write(T x){
	T l=0;
	ull y=0;
	if(!x){putchar(48);return;}
	if(x<0){x=-x;putchar('-');}
	while(x){y=y*10+x%10;x/=10;l++;}
	while(l){putchar(y%10+48);y/=10;l--;}
}
template<typename T>inline void writes(T x){
	write(x);
	putchar(' ');
}
template<typename T>inline void writeln(T x){
	write(x);
	puts("");
}
template<typename T>inline void checkmax(T &a,T b){a=max(a,b);}
template<typename T>inline void checkmin(T &a,T b){a=min(a,b);}
int a[510][10100],s[10100],n,m;
inline bool check(int x){
	F(i,1,n){
		F(j,1,m)s[j]=0;
		F(j,1,m)if(a[i][j]>=x){s[max(1,j-x+1)]++;s[j+x]--;}
		F(j,1,m){s[j]+=s[j-1];if(s[j]==0)return 0;}
	}
	F(i,1,m){
		F(j,1,n)s[j]=0;
		F(j,1,n)if(a[j][i]>=x){s[max(1,j-x+1)]++;s[j+x]--;}
		F(j,1,n){s[j]+=s[j-1];if(s[j]==0)return 0;}
	}
	return 1;
}
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	read(n);read(m);
	F(i,1,n)
		F(j,1,m)
			read(a[i][j]);
	F(i,1,max(n,m))if(check(i)){writeln(i);return 0;}
	puts("-1");
	return 0;
}

