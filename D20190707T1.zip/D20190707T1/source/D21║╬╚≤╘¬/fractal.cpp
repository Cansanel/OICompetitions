#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
#define double long double
#define F(i,j,k) for(int i=j;i<=k;i++)
#define DF(i,j,k) for(int i=j;i>=k;i--)
#define P pair<double,double>
#define M make_pair
#define dui priority_queue
template<typename T>inline void read(T &n){
	T w=1;n=0;char ch=getchar();
	while(!isdigit(ch)&&ch!=EOF){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch)&&ch!=EOF){n=(n<<3)+(n<<1)+(ch&15);ch=getchar();}
	n*=w;
}
template<typename T>inline void write(T x){
	T l=0;
	ull y=0;
	if(!x){putchar(48);return;}
	if(x<0){x=-x;putchar('-');}
	while(x){y=y*10+x%10;x/=10;l++;}
	while(l){putchar(y%10+48);y/=10;l--;}
}
template<typename T>inline void writes(T x){
	write(x);
	putchar(' ');
}
template<typename T>inline void writeln(T x){
	write(x);
	puts("");
}
template<typename T>inline void checkmax(T &a,T b){a=max(a,b);}
template<typename T>inline void checkmin(T &a,T b){a=min(a,b);}
P c,z[101];
inline P fushujia(P a,P b){return M(a.first+b.first,a.second+b.second);}
inline P fushujian(P a,P b){return M(a.first-b.first,a.second-b.second);}
inline P fushucheng(P a,P b){return M(a.first*b.first-a.second*b.second,a.first*b.second+a.second*b.first);}
inline double mochang(P a){if(a.second==0)return abs(a.first);else return sqrt(a.first*a.first+a.second*a.second);}
inline bool shoulian(P a){
	z[0]=a;if(mochang(z[0])>=10)return 1;
	F(i,1,100){z[i]=fushujia(fushucheng(z[i-1],z[i-1]),c);if(mochang(z[i])>=10)return 1;}
	return 0;
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	int yc,xc;read(yc);read(xc);
	double sy,sx;cin>>sy>>sx>>c.first>>c.second;
	F(j,0,yc-1){
		F(i,0,xc-1)
			if(shoulian(M(sy+0.005*i,sx+0.01*j)))putchar(' ');
			else putchar('a');
		puts("");
	}
	return 0;
}
