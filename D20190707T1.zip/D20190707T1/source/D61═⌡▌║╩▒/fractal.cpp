#include <bits/stdc++.h>

using namespace std;

int read (){
	int ret=0;char c=getchar ();
	while (c>'9'||c<'0')c=getchar();
	while (c<='9'&&c>='0')ret=ret*10+c-'0',c=getchar();
	return ret;
}

int yc,xc;
double sy,sx,p,q,zx[105],zy[105];

double mod2 (int i){
	return (zx[i]*zx[i])+(zy[i]*zy[i]);
}

bool check(double x,double y){
	zx[0]=x;
	zy[0]=y;
	if (mod2(0)>=100.0)return false;
	for (int i=1;i<=100;i++){
		zx[i]=zx[i-1]*zx[i-1]-zy[i-1]*zy[i-1]+p;
		zy[i]=(zx[i-1]*zy[i-1])*2+q;
		if (mod2(i)>=100.0)return false;
		
	}
	return true;
}

int main (){
	freopen ("fractal.in","r",stdin);
	freopen ("fractal.out","w",stdout);
	yc=read();
	xc=read();
	cin >>sy>>sx;
	cin >>p>>q;
	for (int j=0;j<yc;j++){
		for (int i=0;i<xc;i++){
			if (check(sy+i*0.005,sx+j*0.01))putchar('a');
			else putchar(' ');
		}
		putchar('\n');
	}
	return 0;
}
