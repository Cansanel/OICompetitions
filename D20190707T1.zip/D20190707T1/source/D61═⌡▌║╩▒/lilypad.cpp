#include <bits/stdc++.h>
#define maxN 10005

using namespace std;

struct node {
	int idx,dist;
};

bool operator <(const node &a,const node &b ){
	return a.dist>b.dist;
}

int read (){
	int ret=0;char c=getchar ();
	while (c>'9'||c<'0')c=getchar();
	while (c<='9'&&c>='0')ret=ret*10+c-'0',c=getchar();
	return ret;
}

int m,n,g[105][105],a[105][105],b[105][105],v[8*maxN],w[8*maxN],nxt[8*maxN],head[maxN],s,t,d[maxN],dep[maxN],tot;
int di[10][2]={{1,2},{2,1},{-1,2},{2,-1},{1,-2},{-2,1},{-1,-2},{-2,-1}};
bool book [maxN],flag,vis[maxN];

int getnum(int x,int y){
	return (x-1)*m+y;
}

bool check(int x,int y){
	if (g[x][y]==0)return 1;
	else return 0;
}

void add (int x,int y,int z){
	v[++tot]=y;
	w[tot]=z;
	nxt[tot]=head[x];
	head[x]=tot;
}

bool checkout (int x,int y){
	return  (x<=0||y<=0||x>n||y>m);
}

void makeg (){
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			int x=getnum(i,j);
			vis[x]=1;
			if (g[i][j]==2)continue;
			for (int k=0;k<8;k++){
				int y=getnum(i+di[k][0],j+di[k][1]);
				if (vis[y]||g[i+di[k][0]][j+di[k][1]]==2||checkout(i+di[k][0],j+di[k][1]))continue;
				add (x,y,check(i+di[k][0],j+di[k][1]));
				add (y,x,check(i,j));
			}
		}
	}
}

void dijkstra (){
	memset (d,127,sizeof(d));
	d[s]=0;
	dep[s]=0;
	priority_queue<node> q;
	node tmp;
	tmp.idx=s,tmp.dist=0;
	q.push(tmp);
	while (!q.empty()){
		int x=q.top().idx;
		if (book[x]||d[x]<q.top().dist)continue;
		book[x]=1;
		q.pop();
		if (x==t){
			flag=1;
			cout<<d[t]<<' '<<dep[t];
			break;
		}
		for (int i=head[x];i;i=nxt[i]){
			int y=v[i];
//			if (y==t){
//				cout<<x<<endl;
//			}
			if (book[y])continue;
			if (d[y]>d[x]+w[i]){
				d[y]=d[x]+w[i];
				dep[y]=dep[x]+1;
				tmp.idx=y;
				tmp.dist=d[y];
				q.push(tmp);
			}
			if (d[y]==d[x]+w[i]||dep[y]>dep[x]+1){
				dep[y]=dep[x]+1;
			}
		}
	}
}

int main (){
	freopen ("lilypad.in","r",stdin);
	freopen ("lilypad.out","w",stdout);
	n=read(),m=read();
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			g[i][j]=read();
			if (g[i][j]==3)s=getnum(i,j);
			if (g[i][j]==4)t=getnum(i,j);
		}
	}
	makeg();
	dijkstra();
	if (flag==0)cout<<"-1 -1";
	return 0;
}

