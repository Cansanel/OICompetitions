#include <bits/stdc++.h>

using namespace std;

struct lantern {
	int x,y,level;
}l[505*10005];

int read (){
	int ret=0;char c=getchar ();
	while (c>'9'||c<'0')c=getchar();
	while (c<='9'&&c>='0')ret=ret*10+c-'0',c=getchar();
	return ret;
}

int n,m,g[505][10005],tot;
int minn[505][10005][2];
const int inf = 0x3f3f3f3f;
//
//bool check(int cur){
//	memset (light,0,sizeof (light));
//	for (int i=1;i<=tot;i++){
//		if (l[i].level<cur)continue;
//		int x=l[i].x,y=l[i].y;
//		light[max(1,x-cur+1)][y][0]++,light[min(n,x+cur-1)+1][y][0]--;
//		light[x][max(1,y-cur+1)][1]++,light[x][min(m,y+cur-1)+1][1]--;
//	}
//	cout<<cur<<':'<<endl;
//	for (int i=1;i<=n;i++){
//		for (int j=1;j<=m;j++){
//			cout<<light[i][j][1]<<' ';
//		}
//		cout<<endl;
//	}
//	for (int i=1;i<=n;i++){
//		int cur=0;
//		for (int j=1;j<=m;j++){
//			cur+=light[i][j][1];
//			if (cur==0)return false;
//		}
//	}
//
//	
//	for (int j=1;j<=m;j++){
//		int cur=0;
//		for (int i=1;i<=n;i++){
//			cur+=light[i][j][0];
//			if (cur==0)return false;
//		}
//	}
//	
//	return true;
//}

void baoli(){
	int ans =0;
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			minn[i][j][0]=minn[i][j][1]=inf;
		}
	}
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			for (int k=1;k<=m;k++){
				if (g[i][k]>abs(j-k))minn[i][j][0]=min(minn[i][j][0],abs(j-k)+1);
			}
			for (int k=1;k<=n;k++){
				if (g[k][j]>abs(i-k))minn[i][j][1]=min(minn[i][j][1],abs(i-k)+1);
			}
			
		}
	}
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			ans=max(ans,max(minn[i][j][0],minn[i][j][1]));
		}
	}
	if (ans==inf)cout<<-1;
	else cout<<ans;
}

int main (){
	freopen ("lantern.in","r",stdin);
	freopen ("lantern.out","w",stdout);
	n=read(),m=read();
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			g[i][j]=read();
//			if (g[i][j]>0)l [++tot].x=i,l [tot].y=j,l [tot].level=g[i][j];
		}
	}
	baoli();
	return 0;
}

