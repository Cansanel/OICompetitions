#include<bits/stdc++.h>
using namespace std;
int n,m,yc,xc;
double sy,sx,p,q;
struct node
{
	double x,y;
}a[200010];
char c[1000][1000];
bool check(double x,double y)
{
	a[0].x=x;a[0].y=y;
	for (int i=1;i<=100;i++)
	{
		a[i].x=a[i-1].x*a[i-1].x-a[i-1].y*a[i-1].y;
		a[i].y=a[i-1].x*a[i-1].y+a[i-1].y*a[i-1].x;
		a[i].x+=p;
		a[i].y+=q;
		double k=sqrt(a[i].x*a[i].x+a[i].y*a[i].y);
		if (k>=10) return true;
	}
	return false;
}
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx;
	cin>>p>>q;
	for (int j=0;j<yc;j++)
	{
		for (int i=0;i<xc;i++)
		{
			double x=sy+i*0.005,y=sx+j*0.01;
			if (check(x,y)) c[j][i]=' ';
			else c[j][i]='a';
		}
	}
	for (int i=0;i<yc;i++)
	{
		for (int j=0;j<xc;j++)
		cout<<c[i][j];
		cout<<endl;
	}
}
