#include<bits/stdc++.h>
using namespace std;
int n,m,Map[120][120],xx,yy,xt,yt,v[200010],tot,d[200010];
int dx[]={2,2,-2,-2,1,1,-1,-1};
int dy[]={1,-1,1,-1,2,-2,2,-2};
priority_queue<pair<int,int> >q;
int f(int x,int y)
{
	return (x-1)*m+y;
}
vector<int>a[200010],b[200010];
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
		{
			cin>>Map[i][j];
			if (Map[i][j]==3) xx=i,yy=j;
			if (Map[i][j]==4) xt=i,yt=j;
		}
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
			for (int k=0;k<8;k++)
			{
				int tx=i+dx[k];
				int ty=j+dy[k];
				if (tx>0&&tx<=n&&ty>0&&ty<=m&&Map[tx][ty]!=2&&Map[i][j]!=2)
				{
					a[f(i,j)].push_back(f(tx,ty));
					if (Map[tx][ty]!=0) b[f(i,j)].push_back(1);
					else b[f(i,j)].push_back(13000);
				}
			}
	for (int i=1;i<=n*m;i++) d[i]=214748364;
	memset(v,0,sizeof(v));
	d[f(xx,yy)]=0;
	q.push(make_pair(0,f(xx,yy)));
	while(q.size())
	{
		int x=q.top().second;q.pop();
		if (v[x]) continue;
		v[x]=1;
		for (int i=0;i<a[x].size();i++)
		{
			int y=a[x][i],z=b[x][i];
			if (d[y]>d[x]+z)
			{
				d[y]=d[x]+z;
				q.push(make_pair(-d[y],y));
			}
		}
	}
	int ans=d[f(xt,yt)];
	if (ans==214748364) cout<<"-1"<<endl;
	else cout<<ans/13000<<" "<<ans/13000+ans%13000<<endl;
}
