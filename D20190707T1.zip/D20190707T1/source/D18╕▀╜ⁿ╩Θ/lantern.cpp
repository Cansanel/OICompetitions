#include<bits/stdc++.h>
using namespace std;
int n,m,tot,ans,f1[10010],f2[10010],f[10010],v1[510][10010],v2[510][10010],p,sum;
int a[510][10010];
priority_queue<pair<int,int> >q;
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	cin>>n>>m;
	if (m>1000)
	{
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
			cin>>a[i][j];
	for (int i=1;i<=n;i++)
	{
		tot=0;
		memset(f1,0,sizeof(f1));
		while(q.size()) q.pop();
		for (int j=1;j<=m;j++)
		{
			if (a[i][j]) 
			{
				q.push(make_pair(j,a[i][j]));
				f1[j]=1;
			}
			else
			{
				while(q.size()) 
				{
					if (j-q.top().first+1<=q.top().second) break;
					q.pop();
				}
				if (q.empty()) f1[j]=214748364;
				else f1[j]=j-q.top().first+1;
			}
		}
		memset(f2,0,sizeof(f2));
		while(q.size()) q.pop();
		for (int j=m;j>=1;j--)
		{
			if (a[i][j]) 
			{
				q.push(make_pair(-j,a[i][j]));
				f2[j]=1;
			}
			else
			{
				while(q.size()) 
				{
					if (1-j-q.top().first<=q.top().second) break;
					q.pop();
				}
				if (q.empty()) f2[j]=214748364;
				else f2[j]=1-j-q.top().first;
			}
		}
		for (int j=1;j<=m;j++) f[j]=min(f1[j],f2[j]);
		for (int j=1;j<=m;j++) ans=max(ans,f[j]);
	}
	for (int j=1;j<=m;j++)
	{
		tot=0;
		memset(f1,0,sizeof(f1));
		while(q.size()) q.pop();
		for (int i=1;i<=n;i++)
		{
			if (a[i][j]) 
			{
				q.push(make_pair(i,a[i][j]));
				f1[i]=1;
			}
			else
			{
				while(q.size()) 
				{
					if (i-q.top().first+1<=q.top().second) break;
					q.pop();
				}
				if (q.empty()) f1[i]=214748364;
				else f1[i]=i-q.top().first+1;
			}
		}
		memset(f2,0,sizeof(f2));
		while(q.size()) q.pop();
		for (int i=n;i>=1;i--)
		{
			if (a[i][j]) 
			{
				q.push(make_pair(-i,a[i][j]));
				f2[i]=1;
			}
			else
			{
				while(q.size()) 
				{
					if (1-i-q.top().first<=q.top().second) break;
					q.pop();
				}
				if (q.empty()) f2[i]=214748364;
				else f2[i]=1-i-q.top().first;
			}
		}
		for (int i=1;i<=n;i++) f[i]=min(f1[i],f2[i]);
		for (int i=1;i<=n;i++) ans=max(ans,f[i]);
	}
	if (ans==214748364) cout<<"-1"<<endl;
	else cout<<ans<<endl;
	}
	else
	{
			for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
		{
			cin>>a[i][j];
			sum=max(sum,a[i][j]);
		}
			p=false;
		for (int k=1;k<=sum;k++)
		{
			memset(v1,1,sizeof(v1));
			memset(v2,1,sizeof(v2));
			for (int i=1;i<=n;i++)
				for (int j=1;j<=m;j++)
				{
					if (a[i][j]>=k)
					{
						for (int ii=max(1,i-k+1);ii<=min(n,i+k-1);ii++) v2[ii][j]=0;
						for (int jj=max(1,j-k+1);jj<=min(m,j+k-1);jj++) v1[i][jj]=0;
					}
				}
			bool flag=true;
			for (int i=1;i<=n;i++)
				for (int j=1;j<=m;j++)
					if (v1[i][j]||v2[i][j])
					{
						flag=false;
						break;
					}
			if (flag) 
			{
				cout<<k<<endl;
				p=true;
				break;
			}
		}
		if (!p) cout<<"-1"<<endl;
	}
}
