#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define rep(i,j,k) for (int i=j;i<=k;i++)
#define dep(i,j,k) for (int i=j;i>=k;i--)
#define M(a,b) memset(a,b,sizeof(a));
using namespace std;
int n,m,gra[55][1005],maxr;
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,n)     
		rep(j,1,m) scanf("%d",&gra[i][j]);
	if (n<=10 && m<=10)
		rep(h,1,10){
			int temp[55][1005],t2[55][1005][2];
			M(temp,0);M(t2,0);
			rep(i,1,n)
				rep(j,1,m){
					if (gra[i][j]==0) temp[i][j]=0;
					if (gra[i][j]<h) temp[i][j]=0;
					if (gra[i][j]>=h) temp[i][j]=h;
				}
			rep(i,1,n)
				rep(j,1,m)
					if (temp[i][j]>0){
						rep(k,i-h+1,i+h-1) t2[k][j][0]++;
						rep(k,j-h+1,j+h-1) t2[i][k][1]++;
					}
			bool flag=true;
			rep(i,1,n) {
				if (!flag) break;
				rep(j,1,m)
					if (t2[i][j][0]==0 || t2[i][j][1]==0){
						flag=false;
						break;
					}
			}
			if (flag){
				printf("%d",h);
				return 0;
			}
		}
	printf("-1");
	return 0;
}
