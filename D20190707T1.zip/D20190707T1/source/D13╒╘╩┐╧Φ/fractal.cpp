#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#define rep(i,j,k) for (int i=j;i<=k;i++)
#define dep(i,j,k) for (int i=j;i>=k;i--)
using namespace std;
struct node{
	double x,y;
};
int yc,xc;
double Sy,Sx,P,Q;
node add(node a,node b){
	node c;
	c.x=a.x+b.x;c.y=a.y+b.y;
	return c;
}
node del(node a,node b){
	node c;
	c.x=a.x-b.x;c.y=a.y-b.y;
	return c;
}
node mul(node a,node b){
	node c;
	c.x=a.x*b.x-a.y*b.y;c.y=a.x*b.y+a.y*b.x;
	return c;
}
bool sl(double a,double b){
	node c;
	c.x=P,c.y=Q;
	node z[100];
	memset(z,0,sizeof(z));
	z[0].x=a,z[0].y=b;
	rep(i,1,100){
		z[i]=add(c,mul(z[i-1],z[i-1]));
		if (sqrt(z[i].x*z[i].x+z[i].y*z[i].y)>=10) return false;
	}
	return true;
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d%d%lf%lf",&yc,&xc,&Sy,&Sx);
	scanf("%lf%lf",&P,&Q);
	rep(j,0,yc-1){
		rep(i,0,xc-1)
			if(sl(Sy+(double)i*0.005,Sx+(double)j*0.01)) putchar('a');
			else putchar(' ');
		printf("\n");
	}
	return 0;
}

