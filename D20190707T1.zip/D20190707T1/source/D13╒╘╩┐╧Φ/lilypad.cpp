#include<cstdio>
#include<cstring>
#include<algorithm>
#define rep(i,j,k) for (int i=j;i<=k;i++)
#define dep(i,j,k) for (int i=j;i>=k;i--)
#define M(a,b) memset(a,b,sizeof(a))
using namespace std;
struct node{
	int x,y;
}que[1000005];
int dx[]={1,1,-1,-1,2,2,-2,-2};
int dy[]={-2,2,-2,2,-1,1,-1,1};
int n,m,map[105][105],sx,sy,tx,ty,l,r;
int leaf[105][105],step[105][105];
bool vis[105][105];
bool unover(int x,int y){
	if (x<=0 || x>n || y<=0 || y>m || map[x][y]==2) return false;
	return true;
}
void add(int x,int y,int le,int st){
	if (unover(x,y)){
		if (map[x][y]==0) le++;
		if (le>leaf[x][y]) return;
		if (le==leaf[x][y] && st>step[x][y]) return;
		leaf[x][y]=le,step[x][y]=st;
		if (!vis[x][y]){
			que[++r].x=x,que[r].y=y;
			vis[x][y]=true;
		}
	}
	return;
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,n)
		rep(j,1,m){
			scanf("%d",&map[i][j]);
			if (map[i][j]==3) sx=i,sy=j;
			if (map[i][j]==4) tx=i,ty=j;
		} 
	M(leaf,127);M(step,127);
	add(sx,sy,0,0);
	while(l<=r){
		l++;
		int nowx=que[l].x,nowy=que[l].y;
		rep(i,0,7) add(nowx+dx[i],nowy+dy[i],leaf[nowx][nowy],step[nowx][nowy]+1);
		vis[nowx][nowy]=false;
	}
	if (leaf[tx][ty]<2e9) printf("%d %d",leaf[tx][ty],step[tx][ty]);
	else printf("-1 -1");
	return 0;
}
