#include<bits/stdc++.h>
#define rep(i,j,k) for((i)=(j);(i)<=(k);++i)
#define per(i,j,k) for((i)=(j);(i)>=(k);--i)
#define mem(a) memset((a),0,sizeof(a))
#define x1 xx1
#define y1 yy1
#define mk make_pair
#define fi first
#define se second
#define sqr(x) ((x)*(x))
typedef long long ll;
using namespace std;
inline void cmin(int &x,int y){if(y<x)x=y;}
inline void cmax(int &x,int y){if(y>x)x=y;}
typedef pair<double,double> PI;
PI z[105];
int yc,xc,i,j; double sy,sx,p,q;
PI operator +(PI a,PI b){return mk(a.fi+b.fi,a.se+b.se);}
PI operator -(PI a,PI b){return mk(a.fi-b.fi,a.se-b.se);}
PI operator *(PI a,PI b){return mk(a.fi*b.fi-a.se*b.se,a.fi*b.se+a.se*b.fi);}
double len(PI a){return sqrt(sqr(a.fi)+sqr(a.se));}
int inline read(){
	char ch=getchar();int z=0,f=1;
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){z=z*10+ch-'0';ch=getchar();}
	return z*f;
}
bool bound(PI d){
	PI c = mk(p,q); z[0] = d; int i;
	if(len(z[0]) >= 10) return 0;
	rep(i,1,100){
		z[i] = (z[i-1] * z[i-1]) + c;
		if(len(z[i]) >= 10) return 0;
	}
	return 1;
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	yc=read();xc=read();scanf("%lf%lf",&sy,&sx);
	scanf("%lf%lf",&p,&q);
	rep(j,0,yc-1){
		rep(i,0,xc-1)
			if(bound(mk(sy + i * 0.005,sx + j * 0.01))) putchar('a');
			else putchar(' ');
		putchar('\n');
	}
	return 0;
}
