#include<bits/stdc++.h>
#define rep(i,j,k) for((i)=(j);(i)<=(k);++i)
using namespace std;
const int dx[8] = {-2,-1,1,2,2,1,-1,-2};
const int dy[8] = {1,2,2,1,-1,-2,-2,-1};
const int N = 150; const int inf = 1000000007;
int m,n,x,y,tx,ty,a[N][N],inq[N][N],f[N][N],g[N][N],q[5100000][2],i,j,head,tail,Sx,Sy,Tx,Ty,c1;
int inline read(){
	char ch=getchar();int z=0,f=1;
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){z=z*10+ch-'0';ch=getchar();}
	return z*f;
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	m=read();n=read();
	rep(i,1,m)
		rep(j,1,n){
			a[i][j]=read();
			if(a[i][j]==3){Sx=i;Sy=j;}
			if(a[i][j]==4){Tx=i;Ty=j;}
		}
	rep(i,1,m) rep(j,1,n) f[i][j] = inf; f[Sx][Sy] = 0;
	q[head=tail=0][0] = Sx; q[0][1] = Sy; inq[Sx][Sy] = 1;
	while(head <= tail){
		x = q[head][0]; y = q[head][1];
		rep(i,0,7){
			tx = x + dx[i]; ty = y + dy[i];
			if(tx>0&&ty>0&&tx<=m&&ty<=n&&a[tx][ty]!=2){
				c1 = (a[tx][ty] == 0);
				if(f[x][y]+c1<f[tx][ty]||f[x][y]+c1==f[tx][ty]&&g[x][y]+1<g[tx][ty]){
					f[tx][ty] = f[x][y] + c1;
					g[tx][ty] = g[x][y] + 1;
					if(!inq[tx][ty]){inq[tx][ty]=1; q[++tail][0]=tx; q[tail][1]=ty;}
				}
			}
		}
		inq[x][y] = 0; ++head;
	}
	if(f[Tx][Ty] >= inf) puts("-1 -1"); else printf("%d %d\n",f[Tx][Ty],g[Tx][Ty]);
	return 0;
}
