#include<bits/stdc++.h>
int n, m, ans, maxn, g[505][10005];
bool check(int r) {
	for (int i = 1; i <= n; i++) {
		int j = 1;
		while (j <= m) {
			int p = -1;
			for (int k = std::min(m, j + r - 1); k >= j; k--)
				if (g[i][k] >= r) {
					p = k;
					break;
				}
			if (p == -1) return false;
			j = p + r;
			while (j <= m) {
				p = -1;
				for (int k = j; k >= j - r + 1; k--)
					if (g[i][k] >= r) {
						p = k;
						break;
					}
				if (p == -1) break;
				j = p + r;
			}
		}
	} 
	for (int j = 1; j <= m; j++) {
		int i = 1;
		while (i <= n) {
			int p = -1;
			for (int k = std::min(n, i + r - 1); k >= i; k--)
				if (g[k][j] >= r) {
					p = k;
					break;
				}
			if (p == -1) return false;
			i = p + r;
			while (i <= n) {
				p = -1;
				for (int k = i; k >= i - r + 1; k--)
					if (g[k][j] >= r) {
						p = k;
						break;
					}
				if (p == -1) break;
				i = p + r;
			}
		}
	}
	return true;
}

int main() {
	freopen("lantern.in", "r", stdin);
	freopen("lantern.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++) {
			scanf("%d", &g[i][j]);
			maxn = std::max(maxn, g[i][j]);
		}
	ans = -1;
	for (int i = 1; i <= std::min(std::max(n, m), maxn); i++)
		if (check(i)) {
			ans = i;
			break;
		}
	printf("%d\n", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
