#include<bits/stdc++.h>
using namespace std;
int yc,xc;
double x[5001],y[5001],sy,sx,p,q;
bool flag;
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx>>p>>q;
	for(int i=0;i<=xc-1;i++)
	{
		for(int j=0;j<=xc-1;j++)
		{
			x[0]=sx+j*0.005;
			y[0]=sy+i*0.01;
			flag=false;
			for(int k=1;k<=100;k++)
			{
				if(flag)	break;
				x[k]=x[k-1]*x[k-1]-y[k-1]*y[k-1]+p;
				y[k]=2*x[k-1]*y[k-1]+q;
				if(x[k]*x[k]+y[k]*y[k]>=100)	flag=true;
			}
			flag==1?putchar(' '):putchar('a');
		}
		cout<<endl;
	}
	return 0;
}
