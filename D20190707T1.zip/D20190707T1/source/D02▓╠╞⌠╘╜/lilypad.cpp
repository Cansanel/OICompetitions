#include<bits/stdc++.h>
using namespace std;
const int INF=0x3f3f3f;
int n,m,a[105][105],dp[105][105],minn=INF,flag[105][105];
int sx,sy,ex,ey;

int dx[8]={1,1,2,2,-1,-1,-2,-2};
int dy[8]={2,-2,1,-1,2,-2,1,-1};

int ddddd(int x,int y)
{
	for(int i=0;i<8;i++)
	{
		int xx=x+dx[i];
		int yy=y+dy[i];
		if((a[xx][yy]==1||a[xx][yy]==4)&&dp[xx][yy]>dp[x][y]&&xx>0&&xx<=n&&yy>0&&yy<=m)
		{
			dp[xx][yy]=dp[x][y];
			ddddd(xx,yy);
		}
		if(a[xx][yy]==0&&(dp[xx][yy]>dp[x][y]+1)&&xx>0&&xx<=n&&yy>0&&yy<=m)	
		{
			dp[xx][yy]=dp[x][y]+1;
			ddddd(xx,yy);
		}
	}
}

int ddd(int x,int y,int step,int timess)
{
	for(int i=0;i<8;i++)
	{
		int xx=x+dx[i];
		int yy=y+dy[i];
		if(xx==ex&&yy==ey)
			minn=min(minn,step+1);	
		if((a[xx][yy]==1||a[xx][yy]==4)&&xx>0&&xx<=n&&yy>0&&yy<=m&&flag[xx][yy]==false)
		{
			flag[xx][yy]=true;
			ddd(xx,yy,step+1,timess);
			flag[xx][yy]=false;
		}
			
		if(a[xx][yy]==0&&xx>0&&xx<=n&&yy>0&&yy<=m&&timess<dp[ex][ey]&&flag[xx][yy]==false)	
		{
			flag[xx][yy]=true;
			ddd(xx,yy,step+1,timess+1);
			flag[xx][yy]=false;
		}
			
	}
}

int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	cin>>n>>m;
	memset(a,INF,sizeof(a));
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
			if(a[i][j]==3)
			{
				sx=i;
				sy=j;
			}
			if(a[i][j]==4)
			{
				ex=i;
				ey=j;
			}
		}
	}
	memset(dp,INF,sizeof(dp));
	dp[sx][sy]=0;
	ddddd(sx,sy);
	if(dp[ex][ey]<INF)	cout<<dp[ex][ey]<<" ";
	else
	{
		cout<<-1<<" "<<-1<<endl;
		return 0;
	}
	ddd(sx,sy,0,0);
	cout<<minn<<endl;
	return 0;
}
