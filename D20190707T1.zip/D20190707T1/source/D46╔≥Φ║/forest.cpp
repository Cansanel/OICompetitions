#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int read(){
	int f=1,r=0;
	char ch=getchar();
	while (!isdigit(ch)&&ch!='-') ch=getchar();
	if (ch=='-') f=-1,ch=getchar();
	while (isdigit(ch)) r=r*10+ch-'0',ch=getchar();
	return r*f;
}
int nxt[100005],head[100005],to[100005],tot,visit[100005],ans1,d[100005],a[100005],n,x[100005],b[100005][2],ans[100005];
void add(int u,int v,int flag){
	nxt[++tot]=head[u];
	head[u]=tot;
	to[tot]=v;
	if (flag==0) add(v,u,1);
}
void dp(int u){
	visit[u]=1;
	for (int i=head[u];i;i=nxt[i]){
		int v=to[i];
		if (visit[v]) continue;
		dp(v);
		ans1=max(ans1,d[u]+d[v]+a[v]);
		d[u]=max(d[u],d[v]+a[v]);
	}
}
signed main(){
	freopen("forest.in","r",stdin);
	freopen("forest.out","w",stdout);
	cin>>n;
	for (int i=1;i<=n;i++) cin>>a[i];
	for (int i=1;i<n;i++) cin>>b[i][0]>>b[i][1];
	for (int i=1;i<n;i++) cin>>x[n-i];
	for (int i=1;i<=n;i++) {
		ans[i]=1;
		memset(d,0,sizeof(d));
		memset(visit,0,sizeof(visit));
		for (int j=1;j<=n;j++){
		ans1=0;
		if (visit[j]) continue;
		dp(j);
		ans[i]=ans[i]*(ans1+a[j])%mod;
		}
		if (i!=n) add(b[x[i]][0],b[x[i]][1],0);
	}
	for (int i=n;i>=1;i--) cout<<ans[i]<<endl;
	return 0;
}

