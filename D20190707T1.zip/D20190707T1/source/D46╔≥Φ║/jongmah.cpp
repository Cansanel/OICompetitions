#include<bits/stdc++.h>
using namespace std;
int read(){
	int f=1,r=0;
	char ch=getchar();
	while (!isdigit(ch)&&ch!='-') ch=getchar();
	if (ch=='-') f=-1,ch=getchar();
	while (isdigit(ch)) r=r*10+ch-'0',ch=getchar();
	return r*f;
}
int ans,ans1,n,m,a[100005],b[100005],ls[100005],ls1[100005],ls2,ls3,ls4,ls5,sizels;
void dfs(){
	ans1=max(ans,ans1);
	int sum=0;
	for (int i=1;i<=m;i++) sum+=(a[i]>0);
	if (sum<3){
		sum=0;
		for (int i=1;i<=m;i++) sum+=(a[i]>=3);
		if (sum==0) return ;
	}
	sort(b+1,b+n+1);
	if (b[3]==INT_MAX) return ;
	for (int i=1;i<=n&&b[i]!=INT_MAX;i++) {
		if (a[b[i]]<0) continue;
		int r=0;
		while (a[b[i]+1]>0&&a[b[i]+2]>0&&a[b[i]]>0) {
			ls1[++sizels]=b[i];
			b[i]=INT_MAX;
			ls[sizels]=i;
			int x=i;
			while (b[x]!=ls1[sizels]+1) x++;
			ls1[++sizels]=b[x];
			b[x]=INT_MAX;
			ls[sizels]=x;
			while (b[x]!=ls1[sizels]+1) x++;
			ls1[++sizels]=b[x];
			b[x]=INT_MAX;
			ls[sizels]=x;
			a[ls1[sizels-2]+1]--;
			a[ls1[sizels-2]+2]--;
			a[ls1[sizels-2]]--;
			ans++;
			r++;
			dfs();
		}
		b[ls[sizels]]=ls1[sizels];
		sizels--;
		b[ls[sizels]]=ls1[sizels];
		sizels--;
		b[ls[sizels]]=ls1[sizels];
		sizels--;
		ans-=r;
		a[b[i]+1]+=r;
		a[b[i]+2]+=r;
		a[b[i]]+=r;
		r=0;
		while (a[b[i]]>=3){
			ls3=b[i];
			ls4=b[i+1];
			ls5=b[i+2];
			b[i]=b[i+1]=b[i+2]=INT_MAX;
			a[ls3]-=3;
			ans++;
			r++;
			dfs();
		}
		b[i]=ls3;
		sizels--;
		b[i+1]=ls4;
		sizels--;
		b[i+2]=ls5;
		sizels--;
		ans-=r;
		a[b[i]]+=3*r;
	}
	return ;
}
int main(){
	freopen("jongmah.in","r",stdin);
	freopen("jongmah.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=n;i++) cin>>b[i],a[b[i]]++;
	int spe=1;
	for (int i=1;i<=m;i++) if (a[i]>=3) spe=0;
	if (spe){
		int ans=0;
		sort(b+1,b+n+1);
		for (int i=1;i<=n;i++) if (b[i]!=-99999&&a[b[i]+1]&&a[b[i]+2]) {
			int x=i;
			while (b[x]!=b[i]+1) x++;
			b[x]=-99999;
			while (b[x]!=b[i]+2) x++;
			b[x]=-99999;
			a[b[i]+1]--;
			a[b[i]+2]--;
			a[b[i]]--;
			ans++;
		} 
		cout<<ans<<endl;
		return 0;
	}
	sort(b+1,b+n+1);
	dfs();
	cout<<ans1<<endl;
	return 0;
}
/*
25 5
1 1 1 1  2 2 2 2   3 3 3 3 3 3 3  4 4 4 4 4   5 5 5 5 5
*/
