#include<bits/stdc++.h>
#define int long long
using namespace std;
struct node{
	int x,y;
}num[1000005];
int cmp(node d,node e){
	return d.x-d.y>e.x-e.y;
}
int read(){
	int f=1,r=0;
	char ch=getchar();
	while (!isdigit(ch)&&ch!='-') ch=getchar();
	if (ch=='-') f=-1,ch=getchar();
	while (isdigit(ch)) r=r*10+ch-'0',ch=getchar();
	return r*f;
}
int n,ans;
signed main(){
	freopen("queue.in","r",stdin);
	freopen("queue.out","w",stdout);
	cin>>n;
	for (int i=1;i<=n;i++) cin>>num[i].x>>num[i].y;
	sort(num+1,num+n+1,cmp);
	for (int i=1;i<=n;i++) ans+=num[i].y*(n-1)+(num[i].x-num[i].y)*(i-1);
	cout<<ans<<endl;
	return 0;
}
