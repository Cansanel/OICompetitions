#include<bits/stdc++.h>
using namespace std;
long long n,m,a[501][10001],l,r,mid,ans=1e9+10,sum,maxx;
bool ok[501][10001],ok1[501][10001];
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++){
		cin>>a[i][j];maxx=max(a[i][j],maxx);
	}
	l=1;r=max(n,m);if(r>maxx) r=maxx;
	while(l<=r){
		mid=(l+r)/2;sum=0;
		for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) ok[i][j]=ok1[i][j]=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(a[i][j]>=mid){
					for(int k=i-mid-1;k<=i+mid-1;k++){
						if(k<1||k>n) continue;
						ok[k][j]=1;
					}
					for(int k=j-mid-1;k<=mid+j-1;k++){
						if(k<1||k>m) continue;
						ok1[i][k]=1;
					}
				}
			}
		}
		for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++) if(ok[i][j]==1&&ok1[i][j]==1) sum++;
		if(sum<n*m) l=mid+1;
		else r=mid-1;
		if(sum>=n*m) ans=min(ans,mid);
	}
	if(ans==1e9+10) cout<<-1;
	else cout<<ans;
}
