#include<bits/stdc++.h>
using namespace std;
int n,m,a[110][110],f1[110][110],f2[110][110],sx,sy,zx,zy;
bool ok[110][110];
int dx[8]={1,-1,1,-1,2,-2,2,-2};
int dy[8]={2,2,-2,-2,1,1,-1,-1};
void dfs(int x,int y,int w,int step){
	if(w>f1[y][x]) return;
	if(w==f1[y][x]&&step>f2[y][x]) return;
	if(w<f1[y][x]){
		f1[y][x]=w;f2[y][x]=step;
	}
	if(x==zx&&y==zy)return;
	for(int i=0;i<8;i++){
		if(x+dx[i]<1||x+dx[i]>m||y+dy[i]<1||y+dy[i]>n||ok[y+dy[i]][x+dx[i]]==1||a[y+dy[i]][x+dx[i]]==2) continue;
		if(a[y+dy[i]][x+dx[i]]==0){
			ok[y+dy[i]][x+dx[i]]=1;
			dfs(x+dx[i],y+dy[i],w+1,step+1);
			ok[y+dy[i]][x+dx[i]]=0;
		} 
		else{
			ok[y+dy[i]][x+dx[i]]=1;
			dfs(x+dx[i],y+dy[i],w,step+1);
			ok[y+dy[i]][x+dx[i]]=0;
		}
	}
}
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			f1[i][j]=f2[i][j]=9999999;cin>>a[i][j];
			if(a[i][j]==3){
				sx=j;sy=i;
			}
			if(a[i][j]==4){
				zx=j;zy=i;
			}
		}
	}
	ok[sy][sx]=1;
	dfs(sx,sy,0,0);
	if(f1[zy][zx]==9999999&&f2[zy][zx]==9999999) cout<<-1<<" "<<-1;
	else cout<<f1[zy][zx]<<" "<<f2[zy][zx];
}
