#include<bits/stdc++.h>
using namespace std;
struct rec{double x,y;}z[110];
char c[1010][1010];
double yc,xc,sy,sx,p,q;
bool check(double a,double b){
	z[0].x=a;z[0].y=b;
	if(sqrt(a*a+b*b)>=10) return 0;
	for(int i=1;i<=100;i++){
		z[i].x=z[i-1].x*z[i-1].x-z[i-1].y*z[i-1].y;
		z[i].y=z[i-1].x*z[i-1].y+z[i-1].y*z[i-1].x;
		z[i].x+=p;z[i].y+=q;
		if(sqrt(z[i].x*z[i].x+z[i].y*z[i].y)>=10) return 0;
	}
	return 1;
}
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx>>p>>q;
	for(int i=0;i<yc;i++){
		for(int j=0;j<xc;j++){
			if(check(sy+j*0.005,sx+i*0.01)) c[i][j]='a';
			else c[i][j]=' ';
		}
	}
	for(int i=0;i<yc;i++){
		for(int j=0;j<xc;j++){
			putchar(c[i][j]);
		}
		printf("\n");
	}
}
