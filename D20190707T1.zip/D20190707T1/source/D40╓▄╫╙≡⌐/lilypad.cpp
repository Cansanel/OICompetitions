#include<iostream>
#include<cstdio>
#include<queue>
using namespace std;
int g[111][111],m,n;
bool v[111][111];
int dx[8]={1,2,2,1,-1,-2,-2,-1},
	dy[8]={2,1,-1,-2,-2,-1,1,2};
struct point{
	int x,y,need,step;
	friend bool operator < (const point a,const point b) {
		if(a.need>b.need) return true;
		else if(a.need==b.need&&a.step>b.step) return true;
		return false;
	}
}start,end;
priority_queue <point> q;
inline bool check(point p)
{
	return p.x>0&&p.y>0&&p.x<=n&&p.y<=m&&g[p.x][p.y]!=2&&!v[p.x][p.y];
}
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			cin>>g[i][j];
			if(g[i][j]==3)
			{
				start.x=i;
				start.y=j;
				v[i][j]=1;
			}
			if(g[i][j]==4)
			{
				end.x=i;
				end.y=j;
			}
		}
	q.push(start);
	while(!q.empty())
	{
		point p=q.top();
		q.pop();
		for(int i=0;i<8;i++)
		{
			point t;
			t.x=p.x+dx[i];
			t.y=p.y+dy[i];
			if(check(t))
			{
				v[t.x][t.y]=1;
				t.step=p.step+1;
				if(g[t.x][t.y]==0) t.need=p.need+1;
				else t.need=p.need;
				q.push(t);
				if(t.x==end.x&&t.y==end.y)
				{
					cout<<t.need<<" "<<t.step;
					return 0;
				}
			}
		}
	}
	cout<<"-1 -1";
	return 0;
}
