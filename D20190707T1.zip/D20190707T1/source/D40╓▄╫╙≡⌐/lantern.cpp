#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,m,l,r,mid;
int a[505][10005];
bool b[505][10005],c[505][10005];
inline void bright(int x,int y,int k)
{
	for(int i=x-k+1;i<=x+k-1;i++) if(i>0) b[i][y]=1;
	for(int j=y-k+1;j<=y+k-1;j++) if(j>0) c[x][j]=1;
}
inline bool work(int k)
{
	memset(b,0,sizeof(b));
	memset(c,0,sizeof(c));
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		if(a[i][j]>=k) bright(i,j,k);
	}
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		if(!b[i][j]||!c[i][j]) return false;
	}
	return true;
}
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		cin>>a[i][j];
		r=max(r,a[i][j]);
	}
	while(r>l)
	{
		mid=(l+r)>>1;
		if(work(mid)) r=mid;
		else l=mid+1;
	}
	if(work(l)) cout<<l;
	else cout<<-1;
	return 0;
}
