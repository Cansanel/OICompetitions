#include<iostream>
#include<cmath>
#include<cstdio>
using namespace std;
int yc,xc;
double p,q,sy,sx;
struct point{
	double x,y;
}z[101],c;
char cc[1000][1000];
inline point mul(point z1,point z2)
{
	point t;
	t.x=z1.x*z2.x-z1.y*z2.y;
	t.y=z1.x*z2.y+z1.y*z2.x;
	return t;
}
inline point myplus(point z1,point z2)
{
	point t;
	t.x=z1.x+z2.x;
	t.y=z1.y+z2.y;
	return t;
}
inline double mo2(point zz)
{
	return zz.x*zz.x+zz.y*zz.y;
}
inline bool shoulian(double x,double y)
{
	z[0].x=x;z[0].y=y;
	for(register int i=1;i<=100;i++)
	{
		z[i]=myplus(mul(z[i-1],z[i-1]),c);
		if(mo2(z[i])>=100.0) return false;
	}
	return true;
}
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx>>p>>q;
	c.x=p;c.y=q;
	for(register int j=0;j<=yc;j++)
	{
		for(register int i=0;i<=xc;i++)
		{
			if(shoulian(sy+i*0.005,sx+j*0.01)) cc[j][i]='a';
			else cc[j][i]=' ';
		}
	}
	for(register int j=0;j<=yc;j++)
	{
		for(register int i=0;i<=xc;i++) putchar(cc[j][i]);
		putchar('\n');
	}
	return 0;
}
