#include<bits/stdc++.h>
#define MAX 1e9+7
using namespace std;
int a[101][101];
int jl[101][101];//��Ҷ 
int cs[101][101];//����
queue< pair< int , int > > q;
int fx[8]={1,2,2,1,-1,-2,-2,-1};
int fy[8]={2,1,-1,-2,-2,-1,1,2};
inline void read(int &X)
{
    X=0;int w=0; char ch=0;
    while(!isdigit(ch)) {w|=ch=='-';ch=getchar();}
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    X=w?-X:X;
}
inline void writen(int x)
{
     if(x<0) putchar('-'),x=-x;
     if(x>9) writen(x/10);
     putchar(x%10+'0');
}
inline void write(int x)
{
   writen(x);
   putchar(' ');
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	int m,n;
	read(m);
	read(n);
	int x,y,endx,endy;
	for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=n;j++)
		{
			read(a[i][j]);
			if(a[i][j]==3){
				x=i;y=j;
				jl[i][j]=0;
				cs[i][j]=0;
				a[i][j]=1;
			}
			else{
				jl[i][j]=MAX;
				cs[i][j]=MAX;
			} 
			if(a[i][j]==4){
				endx=i;
				endy=j;
				a[i][j]=1;
			}
			
		}
	}
	int nx,ny,j,c;
	q.push(make_pair(x,y));
	pair<int,int>s; 
	while(!q.empty()){
		for(int i=0;i<=7;i++){
			s=q.front();
			nx=s.first+fx[i],ny=s.second+fy[i];
			if(nx>0&&ny>0&&nx<=m&&ny<=n){
				if(a[nx][ny]==0){
					c=cs[s.first][s.second]+1;
					j=jl[s.first][s.second]+1;
			}
				if(a[nx][ny]==1){
				c=cs[s.first][s.second]+1;
				j=jl[s.first][s.second];
			}
				if(j<jl[nx][ny]||j==jl[nx][ny]&&c<cs[nx][ny]){
					q.push(make_pair(nx,ny));
					jl[nx][ny]=j;
					cs[nx][ny]=c;
				}
			}
			
		}
		q.pop();
	}
	if(jl[endx][endy]==MAX){
		cout<<-1<<' '<<-1;
		return 0;
}
	cout<<jl[endx][endy]<<' ';
	cout<<cs[endx][endy];
	return 0;
}


