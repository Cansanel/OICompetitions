#include<bits/stdc++.h>
#define db long double
using namespace std;
char c[1001][1001];db yc,xc,sy,sx;
struct fushu{
	db x;
	db y;
}z[101],shu;
fushu cheng(fushu A,fushu B){
	fushu ans;
	ans.x=A.x*B.x-A.y*B.y;
	ans.y=A.x*B.y+A.y*B.x;
	return ans;
}
fushu add(fushu A,fushu B){
	 fushu C;
	 C.x = A.x+B.x;C.y = A.y+B.y;
	 return C;
}
db mochang(fushu A){
	db ans=sqrt(A.x*A.x+A.y*A.y);
	return ans;
}
bool shoulian(db x,db y){
	memset(z,0,sizeof(z));
	z[0].x=x;
	z[0].y=y;
	int m=mochang(z[0]);
	if(m>=10) return false;
	for(int i=1;i<=100;i++){
		z[i]=add(cheng(z[i-1],z[i-1]),shu);
		db m=mochang(z[i]);
		if(m>=10) return false;
	}
	return true;
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx>>shu.x>>shu.y;
	for(int j=0;j<yc;j++){
		for(int i=0;i<xc;i++){
			c[j][i]=shoulian(sy+i*0.005,sx+j*0.01)?'a':' ';
			putchar(c[j][i]);
		}
		puts("");
	}
	return 0;
}


