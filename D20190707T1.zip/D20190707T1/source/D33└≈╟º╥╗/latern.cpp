#include<bits/stdc++.h>
using namespace std;
int n;
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	cout<<"-1";
	return 0;
}
