#include<bits/stdc++.h>
#pragma GCC optimize(2) 
#define up(l,r,i) for(int i=l;i<=r;i++)
#define lw(r,l,i) for(int i=r;i>=l;i--)
using namespace std;
typedef long long LL;
const int SIZE =100000;
char bef1[SIZE+3],*p1=bef1,*p2=bef1;
char readc(){
	if(p1==p2) p1=bef1,p2=bef1+fread(bef1,1,SIZE,stdin);
	return p1==p2?EOF:*p1++;
}
int qread(){
	int ret,c,w=1;
	while((c=readc())> '9'||c< '0')
	w=(c=='-'?-1:1); ret=c-'0';
	while((c=readc())>='0'&&c<='9')
	ret=ret*10+c-'0';
	return ret*w;
}
char bef2[SIZE+3],*p3=bef2,*p4=bef2+SIZE;
void flush(){
	fwrite(bef2,1,p3-bef2,stdout);
	p3=bef2;
}
char writec(char c){
	if(p3==p4) flush();
	*p3++=c;
}
void qwrite(int x){
	if(x<0) writec('-'),x=-x;
	if(x>9) qwrite(x/10);
	writec(x%10+'0');
}
const int MAXN =100 +3;
int mmp[MAXN][MAXN],s1,s2,e1,e2;
struct state{
	int x,y,mnh,mns;
	bool operator <(state t) const{
		return mnh==t.mnh?mns<t.mns:mnh<t.mnh;
	}
	bool operator >(state t) const{
		return mnh==t.mnh?mns>t.mns:mnh>t.mnh;
	}
	state(int nx,int ny,int nh,int ns){
		x=nx,y=ny,mnh=nh,mns=ns;
	}
};
bool vis[MAXN][MAXN];
int m,n;
const int dir[8][2]={{2,1},{-2,-1},{-2,1},{2,-1},{1,2},{-1,-2},{-1,2},{1,-2}};
bool bfs(){
	priority_queue <state,vector<state>,greater<state> > pq;
	pq.push(state(s1,s2,0,0));
	while(!pq.empty()){
		state t=pq.top();pq.pop();
		int x=t.x,y=t.y,h=t.mnh,s=t.mns;
		if(vis[x][y]) continue; vis[x][y]=true;
		if(x==e1&&y==e2){
			qwrite(h),writec(' '),qwrite(s),writec('\n');
			flush(),exit(0);
		}
		up(0,7,i){
			int nx=x+dir[i][0],ny=y+dir[i][1],nh=h,ns=s+1;
			if(nx<1||nx>m||ny<1||ny>n||mmp[nx][ny]==2) continue;
			if(mmp[nx][ny]==0) nh++;
			pq.push(state(nx,ny,nh,ns));
		}
	}
	return false;
}

int main(){
	
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	m=qread(),n=qread();
	up(1,m,i) up(1,n,j){
		mmp[i][j]=qread();
		if(mmp[i][j]==3) s1=i,s2=j,mmp[i][j]=1;
		if(mmp[i][j]==4) e1=i,e2=j,mmp[i][j]=1;
	}
	if(!bfs())qwrite(-1),writec(' '),qwrite(-1),writec('\n');
	flush();
	return 0;
}
/*
	�������������ԣ������������֮��
	Too young,too simple.
*/ 

/*
4 8
0 0 0 1 0 0 0 0
0 0 0 0 0 2 0 1
0 0 0 0 0 4 0 0
3 0 0 0 0 0 1 0

*/
