#include<bits/stdc++.h>
#pragma GCC optimize(2) 
#define up(l,r,i) for(int i=l;i<=r;i++)
#define lw(r,l,i) for(int i=r;i>=l;i--)
using namespace std;
typedef long long LL;
const int SIZE =100000;
char bef1[SIZE+3],*p1=bef1,*p2=bef1;
char readc(){
	if(p1==p2) p1=bef1,p2=bef1+fread(bef1,1,SIZE,stdin);
	return p1==p2?EOF:*p1++;
}
int qread(){
	int ret,c,w=1;
	while((c=readc())> '9'||c< '0')
	w=(c=='-'?-1:1); ret=c-'0';
	while((c=readc())>='0'&&c<='9')
	ret=ret*10+c-'0';
	return ret*w;
}
char bef2[SIZE+3],*p3=bef2,*p4=bef2+SIZE;
void flush(){
	fwrite(bef2,1,p3-bef2,stdout);
	p3=bef2;
}
char writec(char c){
	if(p3==p4) flush();
	*p3++=c;
}
void qwrite(int x){
	if(x<0) writec('-'),x=-x;
	if(x>9) qwrite(x/10);
	writec(x%10+'0');
}
const int MAXN =800 +3;
int yc,xc,c[MAXN][MAXN];
double Sy,Sx,P,Q;
bool check(double a,double b){
	double z[101][2];
	z[0][0]=a,z[0][1]=b;
	up(1,100,i){
		z[i][0]=z[i-1][0]*z[i-1][0]-z[i-1][1]*z[i-1][1]+P,
		z[i][1]=z[i-1][0]*z[i-1][1]+z[i-1][0]*z[i-1][1]+Q;
		if(z[i][0]*z[i][0]+z[i][1]*z[i][1]>=100) return false;
	}
	return true;
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d%d%lf%lf%lf%lf",&yc,&xc,&Sy,&Sx,&P,&Q);
	up(0,yc-1,j) up(0,xc-1,i){
		c[j][i]=(check((double)Sy+i*0.005,(double)Sx+j*0.01)?'a':' ');
	}
	up(1,yc,j){
		up(1,xc,i) writec(c[j-1][i-1]);
		writec('\n');
	}
	flush();
	return 0;
}
/*
	�������������ԣ������������֮��
	Too young,too simple.
*/ 
