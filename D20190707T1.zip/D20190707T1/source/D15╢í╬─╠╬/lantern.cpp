#include<bits/stdc++.h>
#pragma GCC optimize(2) 
#define up(l,r,i) for(int i=l;i<=r;i++)
#define lw(r,l,i) for(int i=r;i>=l;i--)
using namespace std;
typedef long long LL;
const int SIZE =100000;
char bef1[SIZE+3],*p1=bef1,*p2=bef1;
char readc(){
	if(p1==p2) p1=bef1,p2=bef1+fread(bef1,1,SIZE,stdin);
	return p1==p2?EOF:*p1++;
}
int qread(){
	int ret,c,w=1;
	while((c=readc())> '9'||c< '0')
	w=(c=='-'?-1:1); ret=c-'0';
	while((c=readc())>='0'&&c<='9')
	ret=ret*10+c-'0';
	return ret*w;
}
char bef2[SIZE+3],*p3=bef2,*p4=bef2+SIZE;

const int MAXN =500+3,MAXM=10000 +3;
int n,m,mmp[MAXN][MAXM];
struct Node{
	int front,nxt,R;
	
}P[MAXN][MAXM];
void del(int t,int x){
	P[t][P[t][x].front].nxt=P[t][x].nxt;
	P[t][P[t][x].nxt].front=P[t][x].front;
}	
int dis(int t,int x){
	return max((x-P[t][x].nxt+1)/2,(x-P[t][x].front+1)/2);
}
void init(){
	up(1,n,i){
		P[i][0].nxt=1,P[i][m+1].nxt=m+1;
		up(1,m,j) P[i][j].front=j-1,P[i][j].nxt=j+1;
	}
}
int cnt[MAXM];
bool vis[MAXN][MAXM],stop;
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	n=qread(),m=qread(),init();
	up(1,n,i) up(1,m,j) mmp[i][j]=qread(),cnt[j]++;
	up(1,n,i) up(1,m,j) P[i][j].R=mmp[i][j];
	for(int t,lvl=1;lvl<=10086;lvl++){
		t=0;
		up(1,n,i) for(int h=P[i][0].nxt;h!=m+1;h=P[i][h].nxt){
			if(P[i][h].R<lvl) del(i,h),cnt[h]--;
			if(cnt[h]==0) {
				puts("-1");
				exit(0);
			}
		}
		if(lvl<=n){
			memset(vis,0,sizeof(vis));
			up(1,n,i){
				up(1,m,j) if(mmp[i][j]>=lvl)
				up(max(1,i-lvl+1),min(n,i+lvl-1),k) vis[k][j]=true;
			}
			up(1,n,i) up(1,m,j) if(!vis[i][j]) goto end;
		}
		up(1,n,i){
			for(int h=P[i][0].nxt;h!=m+1;h=P[i][h].nxt) t=max(t,dis(i,h));
			stop=false;for(int h=P[i][0].nxt;h!=m+1;h=P[i][h].nxt) if(h<=lvl) stop=true,h=m+1;
			if(!stop) goto end;
			stop=false;for(int h=P[i][0].nxt;h!=m+1;h=P[i][h].nxt) if(m-h+1<=lvl) stop=true,h=m+1;
			if(!stop) goto end;
		}
		if(t<=lvl){
			printf("%d\n",lvl);
			exit(0);
		} else lvl=max(lvl,t);
		end:;
	}
	printf("-1\n");
	return 0;
}
/*
	�������������ԣ������������֮��
	Too young,too simple.
	�������ӽ����ǲ��еġ� 
*/ 
/*
2 2
0 2
3 0
*/
