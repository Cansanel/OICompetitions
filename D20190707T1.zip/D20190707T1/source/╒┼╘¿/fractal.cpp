#include<bits/stdc++.h>
using namespace std;

int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cout << 'a'  << endl;
	return 0;
}

