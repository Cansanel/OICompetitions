#include<bits/stdc++.h>
using namespace std;

int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	cout << "-1" << endl;
	return 0;
}
