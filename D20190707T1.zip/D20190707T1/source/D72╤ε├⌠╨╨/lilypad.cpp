#include<bits/stdc++.h>
using namespace std;
int n,m,mp[101][101],dx[8]={1,2,2,1,-1,-2,-2,-1},dy[8]={-2,-1,1,2,2,1,-1,-2},l,r,dis[101][101],stp[101][101],ans1,ans2;
pair<int,int>s,t;
struct node{
	pair<int,int>p;
	int tim;
}tmp,tt;
queue<node>q;
void bfs1(){
	memset(dis,0x3f3f3f3f,sizeof(dis));
	dis[s.first][s.second]=0;
	tmp.p=s,tmp.tim=0;
	q.push(tmp);
	while(!q.empty()){
		tmp=q.front();q.pop();
		//printf("(%d,%d):%d\n",tmp.p.first,tmp.p.second,tmp.tim);
		for(int i=0;i<8;i++){
			tt=tmp;tt.p.first+=dx[i],tt.p.second+=dy[i];
			if(mp[tt.p.first][tt.p.second]==2||tt.p.first>n||tt.p.first<1||tt.p.second>m||tt.p.second<1)continue;
			tt.tim+=!mp[tt.p.first][tt.p.second];
			if(dis[tt.p.first][tt.p.second]>tt.tim)dis[tt.p.first][tt.p.second]=tt.tim,q.push(tt);
		}
	}
}
void bfs2(){
	memset(stp,0x3f3f3f3f,sizeof(stp));
	stp[s.first][s.second]=0;
	tmp.p=s,tmp.tim=0;
	q.push(tmp);
	while(!q.empty()){
		tmp=q.front();q.pop();
//		printf("(%d,%d,%d):%d\n",tmp.p.first,tmp.p.second,tmp.tim,dis[tmp.p.first][tmp.p.second]);
		for(int i=0;i<8;i++){
			tt=tmp;tt.p.first+=dx[i],tt.p.second+=dy[i],tt.tim++;
//			printf("S:(%d,%d,%d):%d\n",tt.p.first,tt.p.second,tt.tim,dis[tt.p.first][tt.p.second]);
			if(mp[tt.p.first][tt.p.second]==2||dis[tt.p.first][tt.p.second]>ans1||tt.p.first>n||tt.p.first<1||tt.p.second>m||tt.p.second<1)continue;
			if(stp[tt.p.first][tt.p.second]>tt.tim)stp[tt.p.first][tt.p.second]=tt.tim,q.push(tt);
		}
	}
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)for(int j=1;j<=m;j++){
		scanf("%d",&mp[i][j]);
		if(mp[i][j]==3)mp[i][j]=1,s=make_pair(i,j);
		if(mp[i][j]==4)mp[i][j]=1,t=make_pair(i,j);
	}
	/*r=n*m;
	while(l<r){
		int mid=(l+r)>>1;
		if(che(mid))r=mid;
		else l=mid+1;
	}*/
	bfs1();
	if(dis[t.first][t.second]==0x3f3f3f3f){puts("-1 -1");return 0;}
	ans1=dis[t.first][t.second];
	bfs2();
	//puts("");for(int i=1;i<=n;i++){for(int j=1;j<=m;j++)printf(dis[i][j]==0x3f3f3f3f?"%d ":"%d          ",dis[i][j]);puts("");}
	//puts("");for(int i=1;i<=n;i++){for(int j=1;j<=m;j++)printf(stp[i][j]==0x3f3f3f3f?"%d ":"%d          ",stp[i][j]);puts("");}
	printf("%d %d\n",ans1,stp[t.first][t.second]);
	return 0;
}
/*
4 8
0 0 0 1 0 0 0 0
0 2 0 0 0 2 0 1
0 0 2 0 0 4 0 0
3 0 0 0 0 0 1 0
-1 -1

6 6
3 0 0 1 0 2
0 0 1 0 2 1
1 0 0 2 0 0
0 0 2 0 0 0
0 2 0 0 0 0
2 0 0 0 0 4
2 4

6 6
3 0 0 1 0 2
0 0 1 0 2 1
1 0 0 2 2 2
0 0 2 2 0 0
0 2 2 2 0 0
2 2 2 0 0 4
-1 -1

6 6
3 0 0 1 0 2
0 0 1 0 2 1
1 0 0 2 2 2
0 0 2 2 0 0
0 2 2 2 0 0
2 2 2 0 0 4
3 4
*/
