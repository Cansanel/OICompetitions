#include<bits/stdc++.h>
using namespace std;
int yc,xc;
double p,q,sy,sx;
struct node{
	double x,y;
	friend node operator +(node a,node b){
		a.x+=b.x,a.y+=b.y;
		return a;
	}
	friend node operator -(node a,node b){
		a.x-=b.x,a.y-=b.y;
		return a;
	}
	friend node operator *(node a,node b){
		node c;
		c.x=a.x*b.x-a.y*b.y,c.y=a.x*b.y+a.y*b.x;
		return c;
	}
}s,t;
inline double mod(node a){
	return sqrt(a.x*a.x+a.y*a.y);
}
inline bool in(node a){
	node z[2];
	z[0]=a;
	for(register int i=1;i<=100;i++){
		z[i&1]=z[!(i&1)]*z[!(i&1)]+t;
		if(mod(z[i&1])>=10)return false;
	}
	return true;
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d%d%lf%lf",&yc,&xc,&sy,&sx);
	scanf("%lf%lf",&p,&q),t.x=p,t.y=q;
	for(register int i=1;i<=yc;i++){
		for(register int j=1;j<=xc;j++){
			s.x=sy+j*0.005,s.y=sx+i*0.01;
			putchar(in(s)?'a':' ');
		}
		puts("");
	}
	return 0;
}
