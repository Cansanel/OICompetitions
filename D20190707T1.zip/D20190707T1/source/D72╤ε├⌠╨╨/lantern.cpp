#include<bits/stdc++.h>
using namespace std;
int n,m,mp[501][10001],tot,r;
struct node{
	int x,y,lev;
}lt[5000001];
bool che(int mid){
	for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)mp[i][j]=0;
	for(int i=1;i<=tot;i++){
		if(lt[i].lev<mid)continue;
		int lim=min(n,lt[i].x+mid-1);
		for(int j=max(1,lt[i].x-mid+1);j<=lim;j++)if(mp[j][lt[i].y]==0||mp[j][lt[i].y]==2)mp[j][lt[i].y]++/*,printf("%d %d:1 ",j,lt[i].y);puts("")*/;
		lim=min(m,lt[i].y+mid-1);
		for(int j=max(1,lt[i].y-mid+1);j<=lim;j++)if(mp[lt[i].x][j]==0||mp[lt[i].x][j]==1)mp[lt[i].x][j]+=2/*,printf("%d %d:2 ",j,lt[i].y);puts("")*/;
	}
	for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)if(mp[i][j]!=3)return false;
	return true;
}
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)for(int j=1;j<=m;j++){
		scanf("%d",&mp[i][j]);
		if(mp[i][j])++tot,lt[tot].x=i,lt[tot].y=j,lt[tot].lev=mp[i][j],r=max(r,mp[i][j]);
	}
	for(int i=1;i<=r;i++)if(che(i)){printf("%d\n",i);return 0;}
	puts("-1");
	return 0;
}
/*
6 6
2 0 2 2 2 2
2 2 2 2 2 0
0 2 2 2 2 2 
2 2 2 2 2 0
2 2 2 2 0 2
2 2 2 2 2 2
*/
