#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;
int n,m,a[505][10005],L,R;
struct Data { int x,pos; };
Data lt[5000005]; int cnt;
inline bool cmp1(const Data &a,const Data &b) { return a.x<b.x; }
int Q[10005],head,tail,tmp[10005];
inline void procR(int id)
{
	cnt=0;
	for(int i=1;i<=m;i++) if(a[id][i]>0) lt[cnt++]=(Data){max(1,i-a[id][i]+1),i};
	sort(lt,lt+cnt,cmp1);
	int p=0; head=tail=1;
	memset(tmp,-1,(m+1)<<4);
	for(int i=1;i<=m;i++)
	{
		while(head<tail&&Q[head]<i) head++;
		while(p<cnt&&lt[p].x<=i)
		{
			int x=lt[p].pos;
			while(head<tail&&x<=Q[tail-1]) tail--;
			Q[tail++]=x;
			p++;
		}
		if(head==tail) continue;
		tmp[i]=Q[head]-i+2;
	}
	cnt=0;
	for(int i=1;i<=m;i++) if(a[id][i]>0) lt[cnt++]=(Data){m-min(m,i+a[id][i]-1)+1,m-i+1};
	sort(lt,lt+cnt,cmp1);
//	for(int i=0;i<cnt;i++) printf("(%d,%d)\n",lt[i].x,lt[i].pos);
	p=0; head=tail=1;
	for(int i=1;i<=m;i++)
	{
		while(head<tail&&Q[head]<i) head++;
		while(p<cnt&&lt[p].x<=(m-i+1))
		{
			int x=lt[p].pos;
			while(head<tail&&x<=Q[tail-1]) tail--;
			Q[tail++]=x;
			p++;
		}
		if(head==tail)
		{
			if(tmp[i]==-1) { puts("-1"); exit(0); }
			continue;
		}
		L=max(L,min(tmp[i],Q[head]-(m-i+1)+2));
	}
}
inline void procC(int id)
{
	cnt=0;
	for(int i=1;i<=n;i++) if(a[i][id]>0) lt[cnt++]=(Data){max(1,i-a[i][id]+1),i};
	sort(lt,lt+cnt,cmp1);
	int p=0; head=tail=1;
	memset(tmp,-1,(n+1)<<4);
	for(int i=1;i<=n;i++)
	{
		while(head<tail&&Q[head]<i) head++;
		while(p<cnt&&lt[p].x<=i)
		{
			int x=lt[p].pos;
			while(head<tail&&x<=Q[tail-1]) tail--;
			Q[tail++]=x;
			p++;
		}
		if(head==tail) continue;
		tmp[i]=Q[head]-i+2;
	}
	cnt=0;
	for(int i=1;i<=n;i++) if(a[i][id]>0) lt[cnt++]=(Data){n-min(n,i+a[i][id]-1)+1,n-i+1};
	sort(lt,lt+cnt,cmp1);
	p=0; head=tail=1;
	for(int i=1;i<=n;i++)
	{
		while(head<tail&&Q[head]<i) head++;
		while(p<cnt&&lt[p].x<=(n-i+1))
		{
			int x=lt[p].pos;
			while(head<tail&&x<=Q[tail-1]) tail--;
			Q[tail++]=x;
			p++;
		}
		if(head==tail)
		{
			if(tmp[i]==-1) { puts("-1"); exit(0); }
			continue;
		}
		L=max(L,min(tmp[i],Q[head]-(n-i+1)+2));
	}
}
inline void procRx(int id)
{
	cnt=0;
	for(int i=1;i<=m;i++) if(a[id][i]>0) lt[cnt++]=(Data){max(1,i-a[id][i]+1),i};
	sort(lt,lt+cnt,cmp1);
	int p=0; head=tail=1;
	for(int i=1;i<=m;i++)
	{
		while(head<tail&&Q[head]<i) head++;
		while(p<cnt&&lt[p].x<=i)
		{
			int x=lt[p].pos;
			while(head<tail&&x>=Q[tail-1]) tail--;
			Q[tail++]=x;
			p++;
		}
		tmp[i]=Q[head]-i+2;
	}
	cnt=0;
	for(int i=1;i<=m;i++) if(a[id][i]>0) lt[cnt++]=(Data){m-min(m,i+a[id][i]-1)+1,m-i+1};
	sort(lt,lt+cnt,cmp1);
//	for(int i=0;i<cnt;i++) printf("(%d,%d)\n",lt[i].x,lt[i].pos);
	p=0; head=tail=1;
	for(int i=1;i<=m;i++)
	{
		while(head<tail&&Q[head]<i) head++;
		while(p<cnt&&lt[p].x<=(m-i+1))
		{
			int x=lt[p].pos;
			while(head<tail&&x>=Q[tail-1]) tail--;
			Q[tail++]=x;
			p++;
		}
		R=min(R,max(tmp[i],Q[head]-(m-i+1)+2));
	}
}
inline void procCx(int id)
{
	cnt=0;
	for(int i=1;i<=n;i++) if(a[i][id]>0) lt[cnt++]=(Data){max(1,i-a[i][id]+1),i};
	sort(lt,lt+cnt,cmp1);
	int p=0; head=tail=1;
	for(int i=1;i<=n;i++)
	{
		while(head<tail&&Q[head]<i) head++;
		while(p<cnt&&lt[p].x<=i)
		{
			int x=lt[p].pos;
			while(head<tail&&x>=Q[tail-1]) tail--;
			Q[tail++]=x;
			p++;
		}
		tmp[i]=Q[head]-i+2;
	}
	cnt=0;
	for(int i=1;i<=n;i++) if(a[i][id]>0) lt[cnt++]=(Data){n-min(n,i+a[i][id]-1)+1,n-i+1};
	sort(lt,lt+cnt,cmp1);
	p=0; head=tail=1;
	for(int i=1;i<=n;i++)
	{
		while(head<tail&&Q[head]<i) head++;
		while(p<cnt&&lt[p].x<=(n-i+1))
		{
			int x=lt[p].pos;
			while(head<tail&&x>=Q[tail-1]) tail--;
			Q[tail++]=x;
			p++;
		}
		R=min(L,max(tmp[i],Q[head]-(n-i+1)+2));
	}
}
namespace BaoLi
{
	int cnt1[55][1005],cnt2[55][1005];
	inline bool ok(int R)
	{
		memset(cnt1,0,sizeof(cnt1));
		memset(cnt2,0,sizeof(cnt2));
		for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) if(a[i][j]>=R)
		{
			for(int k=max(1,i-R+1);k<=min(n,i+R-1);k++) cnt1[k][j]++;
			for(int k=max(1,j-R+1);k<=min(m,j+R-1);k++) cnt2[i][k]++;
		}
		for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) if(cnt1[i][j]<1||cnt2[i][j]<1) return 0;
		return 1;
	}
}
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) { scanf("%d",&a[i][j]); R=max(R,a[i][j]); }
	if(n<=50&&m<=1000)
	{
		for(int i=1;i<=R;i++) if(BaoLi::ok(i)) { printf("%d\n",i); return 0; }
		puts("-1");
	}
	else
	{
		for(int i=1;i<=n;i++) procR(i);
		for(int i=1;i<=m;i++) procC(i);
		for(int i=1;i<=n;i++) procRx(i);
		for(int i=1;i<=m;i++) procCx(i);
		if(L>R) puts("-1");
		else printf("%d\n",L);
	}
	return 0;
}
