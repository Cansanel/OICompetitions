#include<cstdio>
#include<cstring>
#include<algorithm>
#include<deque>
#include<queue>
#include<cassert>
using namespace std;
const int maxn=105;
int MR,MC,SR,SC,ER,EC,mp[maxn][maxn],d[maxn][maxn],vis[maxn][maxn],tothe,totst;
struct Node { int r,c; };
const int dr[]={-2,-2,-1,+1,+2,+2,+1,-1};
const int dc[]={-1,+1,+2,+2,+1,-1,-2,-2};
inline bool InMap(int r,int c) { return 1<=r&&r<=MR&&1<=c&&c<=MC; }
int GetHe()
{
	memset(d,0x3f,sizeof(d));
	d[SR][SC]=0;
	deque<Node> Q;
	Q.push_back((Node){SR,SC});
	while(Q.size())
	{
		Node u=Q.front(); Q.pop_front();
		if(vis[u.r][u.c]) continue;
		vis[u.r][u.c]=true;
		if(u.r==ER&&u.c==EC) return d[u.r][u.c];
		for(int i=0;i<8;i++)
		{
			Node nxt=(Node){u.r+dr[i],u.c+dc[i]};
			if(!InMap(nxt.r,nxt.c)) continue;
			if(vis[nxt.r][nxt.c]) continue;
			if(mp[nxt.r][nxt.c]==2) continue;
			if(mp[nxt.r][nxt.c]!=0) { d[nxt.r][nxt.c]=d[u.r][u.c]; Q.push_front((Node){nxt.r,nxt.c}); }
			else if(d[u.r][u.c]+1<d[nxt.r][nxt.c]) { d[nxt.r][nxt.c]=d[u.r][u.c]+1; Q.push_back((Node){nxt.r,nxt.c}); }
		}
	}
	return -1;
}
int GetStep()
{
	memset(vis,-1,sizeof(vis));
	queue<Node> Q;
	vis[SR][SC]=0;
	Q.push((Node){SR,SC});
	while(Q.size())
	{
		Node u=Q.front(); Q.pop();
		for(int i=0;i<8;i++)
		{
			Node nxt=(Node){u.r+dr[i],u.c+dc[i]};
			if(!InMap(nxt.r,nxt.c)) continue;
			if(vis[nxt.r][nxt.c]!=-1) continue;
			int nd=(mp[nxt.r][nxt.c]!=0?0:1);
			if(d[u.r][u.c]+nd!=d[nxt.r][nxt.c]) continue;
			vis[nxt.r][nxt.c]=vis[u.r][u.c]+1;
//			printf("vis[%d][%d]=%d\n",nxt.r,nxt.c,vis[nxt.r][nxt.c]);
			if(nxt.r==ER&&nxt.c==EC) return vis[nxt.r][nxt.c];
			Q.push((Node){nxt.r,nxt.c});
		}
	}
	return -1;
}
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	scanf("%d%d",&MR,&MC);
	for(int i=1;i<=MR;i++) for(int j=1;j<=MC;j++)
	{
		scanf("%d",&mp[i][j]);
		if(mp[i][j]==3) SR=i,SC=j;
		if(mp[i][j]==4) ER=i,EC=j;
	}
	tothe=GetHe();
	if(tothe==-1) { puts("-1 -1"); return 0; }
	totst=GetStep();
	printf("%d %d\n",tothe,totst);
	return 0;
}
