#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
const int maxn=805;
typedef long long LL;
typedef long double LD;
char c[maxn][maxn];
int yc,xc,Sy,Sx;
double P,Q;
struct Cpl
{
	LD x,y;
	inline Cpl():x(0),y(0) { }
	inline Cpl(const LD &_x,const LD &_y):x(_x),y(_y) { }
};
inline Cpl operator + (const Cpl &a,const Cpl &b) { return Cpl(a.x+b.x,a.y+b.y); }
inline Cpl operator * (const Cpl &a,const Cpl &b) { return Cpl(a.x*b.x-a.y*b.y,a.x*b.y+a.y*b.x); }
Cpl d;
inline double Len(const Cpl &a) { return sqrt(a.x*a.x+a.y*a.y); }
inline bool SL(LD x,LD y)
{
	Cpl z(x,y);
	for(int i=1;i<=100;i++)
	{
		z=z*z+d;
		if(Len(z)>=10) return false;
	}
	return true;
}
//#include<ctime>
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d%d%d%d",&yc,&xc,&Sy,&Sx);
	scanf("%lf%lf",&P,&Q);
	d=Cpl(P,Q);
	for(int j=0;j<yc;j++)
		for(int i=0;i<xc;i++)
			c[j][i]=(SL(Sy+(LD)i*0.005,Sx+(LD)j*0.01)?'a':' ');
	for(int i=0;i<yc;i++)
	{
		for(int j=0;j<xc;j++) putchar(c[i][j]);
		putchar('\n');
	}
//	fprintf(stderr,"%d\n",clock());
	return 0;
}
