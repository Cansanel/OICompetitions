#include<cstdio>
#include<cctype>
#include<cstring>
#include<algorithm>

int c1[1010][1010], c2[1010][1010], a[1010][1010];
int n, m, ans;

inline int read() {
	int x = 0, f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
	return x * f;
}

bool check(int x) {
	memset(c1, 0, sizeof c1);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			if (a[i][j] >= x) {
				++c1[i][std::max(1, j - x + 1)];
				if (j + x - 1 < m) --c1[i][j + x - 1];
				
				++c2[std::max(1, i - x + 1)][j];
				if (i + x - 1 < n) --c2[i + x - 1][j];
			}
	int s;
	for (int i = 1; i <= n; ++i) {
		s = 0;
		for (int j = 1; j <= m; ++j) {
			s += c1[i][j];
			if (s <= 0) return 0; 
		}
	}
	for (int j = 1; j <= m; ++j) {
		s = 0;
		for (int i = 1; i <= n; ++i) {
			s += c2[i][j];
			if (s <= 0) return 0;
		}
	}
	return 1;
}

int main() {
	freopen("lantern.in", "r", stdin);
	freopen("lantern.out", "w", stdout);
	n = read(); m = read();
	for (int i = 1; i <= n; ++i)	
		for (int j = 1; j <= m; ++j) 
			a[i][j] = read();
	for (int i = 2; i <= m; ++i)
		if (check(i)) {ans = i; break;}
	printf("%d\n", ans);
	return 0;
}
