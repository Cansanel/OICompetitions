#include<cstdio>
#include<ctime>
#include<algorithm>
#define INF 0x7fffffff

const int dx[8] = {-2, -2, -1, 1, 2, 2, 1, -1};
const int dy[8] = {-1, 1, 2, 2, 1, -1, -2, -2};

int a[110][110], n, m, sx, sy, ex, ey, vis[110][110], ans = INF, ans_step = INF, start;
bool time_out = 0;

void dfs(int x, int y, int cnt, int step) {
	if (time_out) return ;
	if (clock() - start > 1400) {time_out = 1; return ;}
	if (cnt > ans) return ;
	if (cnt == ans && step >= ans_step) return ;
	if (x == ex && y == ey) {
		if (cnt < ans) ans = cnt, ans_step = step;
		if (cnt == ans) ans_step = std::min(step, ans_step);
		return ;
	}
	for (int dir = 0; dir < 8; ++dir) {
		int tx = x + dx[dir], ty = y + dy[dir];
		if (tx <= 0 || tx > n || ty <= 0 || ty > m || vis[tx][ty] || a[tx][ty] == 2) continue;
		vis[tx][ty] = 1;
		if (a[tx][ty] == 1) dfs(tx, ty, cnt, step + 1);
		else dfs(tx, ty, cnt + 1, step + 1);
		vis[tx][ty] = 0;
	}
}

int main() {
	freopen("lilypad.in", "r", stdin);
	freopen("lilypad.out", "w", stdout);
	scanf("%d %d", &n, &m);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j) {
			scanf("%d", &a[i][j]);
			if (a[i][j] == 3) sx = i, sy = j;
			if (a[i][j] == 4) ex = i, ey = j;
		}
	int start = clock();
	dfs(sx, sy, 0, 0);
	if (ans == INF) printf("-1 -1\n");
	else printf("%d %d\n", ans - 1, ans_step);
	return 0;
}
