#include<cstdio>
#include<algorithm>
#include<cmath>

int yc, xc;
double sy, sx, p, q;
char c[1010][1010];

struct complex {
	double x, y;
	complex operator + (const complex &rhs) const {return (complex) {x + rhs.x, y + rhs.y};}
	complex operator - (const complex &rhs) const {return (complex) {x - rhs.x, y - rhs.y};}
	complex operator * (const complex &rhs) const {return (complex) {x * rhs.x - y * rhs.y, x * rhs.y + y * rhs.x};}
	double calc_mod() {return sqrt(x * x + y * y);}
};

bool converge(double x, double y) {
	complex c = (complex) {p, q}, z[101] = {(complex) {x, y}};
	for (int i = 1; i <= 100; ++i) {
		z[i] = (z[i - 1] * z[i - 1]) + c;
		if (z[i].calc_mod() >= 10) return 0;
	}
	return 1;
}

int main() {
	freopen("fractal.in", "r", stdin);
	freopen("fractal.out", "w", stdout);
	scanf("%d %d %lf %lf", &yc, &xc, &sy, &sx);	
	scanf("%lf %lf", &p, &q);
	for (int j = 0; j <= yc; ++j)
		for (int i = 0; i <= xc; ++i) {
			if (converge(sy + i * 0.005, sx + j * 0.01)) c[j][i] = 'a'; else c[j][i] = ' ';
		}
	for (int i = 1; i <= yc; ++i) {
		for (int j = 1; j <= xc; ++j) putchar(c[i - 1][j - 1]);
		putchar('\n');
	}
	return 0;
}
