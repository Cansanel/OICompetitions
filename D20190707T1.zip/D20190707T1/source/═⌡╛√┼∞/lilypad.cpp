#include<bits/stdc++.h>
#define MAXN 110
#define P pair <int , int>
#define mp make_pair

using namespace std;

const int dirx[8] = {1 , -1 , 1 , -1 , 2 , -2 , 2 , -2};
const int diry[8] = {2 , 2 , -2 , -2 , 1 , -1 , -1 , 1};

int n , m;
int a[MAXN][MAXN];
int sx , sy , tx , ty;
queue < P > q;
int dis[MAXN][MAXN] , hy[MAXN][MAXN];
bool h[MAXN][MAXN];
int ans , ansmin;

template <typename T> inline void read(T &x) {
	x = 0; T f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}

template <typename T> inline void chkmax(T &x , T y) {x = x > y ? x : y ; }
template <typename T> inline void chkmin(T &x , T y) {x = x < y ? x : y ; }

int main(){

	freopen("lilypad.in" , "r" , stdin);
	freopen("lilypad.out" , "w" , stdout);

	read(n); read(m);
	memset(hy , 127 , sizeof(hy));
	memset(dis , 127 , sizeof(dis));
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			read(a[i][j]);
			if (a[i][j] == 3) {
				a[i][j] = 1;
				sx = i; sy = j;
			}
			if (a[i][j] == 4) {
				a[i][j] = 1;
				tx = i; ty = j;
			}
		}
	}
	
	q.push(mp(sx , sy));
	h[sx][sy] = 1;
	dis[sx][sy] = hy[sx][sy] = 0;
	ans = INT_MAX; 
	while(!q.empty()) {
		int dx = q.front().first , dy = q.front().second;
		q.pop(); h[dx][dy] = 0;
		if (dx == tx && dy == ty) {
			if (hy[tx][ty] <= ans) {
				if (ans == hy[tx][ty]) chkmin(ansmin , dis[tx][ty]);
				else {
					ans = hy[tx][ty]; ansmin = dis[tx][ty];
				}
			}
		}
		for (int i = 0; i < 8; i++) {
			int px = dx + dirx[i] , py = dy + diry[i];
			if (px > 0 && px <= n && py > 0 && py <= m && a[px][py] != 2) {
				if (a[px][py] == 0 && hy[dx][dy] + 1 > hy[px][py]) continue;
				if (a[px][py] == 0 && hy[dx][dy] + 1 == hy[px][py] && dis[px][py] <= dis[dx][dy] + 1) continue;
				if (a[px][py] == 1 && hy[dx][dy] > hy[px][py]) continue;
				if (a[px][py] == 1 && hy[dx][dy] == hy[px][py] && dis[px][py] <= dis[dx][dy] + 1) continue;
				if (a[px][py] == 0) hy[px][py] = hy[dx][dy] + 1;
				else hy[px][py] = hy[dx][dy];
				dis[px][py] = dis[dx][dy] + 1;
				if (!h[px][py]) {
					q.push(mp(px , py));
					h[px][py] = 1;
				} 
			}
		}
	}
	
	if (ans == ansmin && ans == 0) {
		cout << "-1 -1" << endl;
	}
	else cout << ans << " " << ansmin << endl;

	return 0;
}


