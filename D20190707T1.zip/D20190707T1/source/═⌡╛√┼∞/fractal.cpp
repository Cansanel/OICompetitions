#include<bits/stdc++.h>

using namespace std;

int yc , xc;
double sy , sx , p , q;
char ch[810][810];

struct node{
	double x , y;
} z[110];

template <typename T> inline void read(T &x) {
	x = 0; T f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}

template <typename T> inline void chkmax(T &x , T y) {x = x > y ? x : y ; }
template <typename T> inline void chkmin(T &x , T y) {x = x < y ? x : y ; }

inline node calc(node a , node b) {
	node c;
	c.x = a.x * b.x - a.y * b.y;
	c.y = a.x * b.y + a.y * b.x;
	return c;
}

inline node pl(node a , node b) {
	node c;
	c.x = a.x + b.x;
	c.y = a.y + b.y;
	return c;
}

inline double mc(node a) {
	return sqrt(a.x * a.x + a.y * a.y);
}

inline bool sl (node a) {
	z[0].x = a.x;
	z[0].y = a.y; 
	if (mc(z[0]) >= 10.0) return 0;
	node s = {p , q};
	for (int i = 1; i <= 100; i++) {
		z[i] = calc(z[i - 1] , z[i - 1]);
		z[i] = pl(z[i] , s);
		if (mc(z[i]) >= 10.0) return 0;
	}
	return 1;
}

int main(){

	freopen("fractal.in" , "r" , stdin);
	freopen("fractal.out" , "w" , stdout);

	cin >> yc >> xc;
	cin >> sy >> sx;
	cin >> p >> q;
	
	for (int j = 0; j < yc; j++) {
		for (int i = 0; i < xc; i++) {
			node h = {sy + i * 0.005 , sx + j * 0.01};
			if (sl(h)) putchar('1');
			else putchar(' ');
		}
		putchar('\n');
	}

	return 0;
}


