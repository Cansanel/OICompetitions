#include<bits/stdc++.h>
#define MAXN 510
#define MAXM 10010

using namespace std;

int n , m;
int a[MAXN][MAXM];
vector <int> vh[MAXM] , vl[MAXM];
int cf[MAXM];

template <typename T> inline void read(T &x) {
	x = 0; T f = 1; char c = getchar();
	for (; !isdigit(c); c = getchar()) if (c == '-') f = -1;
	for (; isdigit(c); c = getchar()) x = (x << 3) + (x << 1) + (c ^ 48);
	x *= f;
}

template <typename T> inline void chkmax(T &x , T y) {x = x > y ? x : y ; }
template <typename T> inline void chkmin(T &x , T y) {x = x < y ? x : y ; }

//struct SegmentTree{
//	int tree[MAXN << 2];
//	int la[MAXN << 2];
//	
//	inline void update(int index) {
//		tree[index] = tree[index << 1] + tree[idnex << 1 | 1];
//	}
//	
//	inline void down(int index , int l , int r) {
//		int mid = (l + r) >> 1;
//		int t = la[index];
//		tree[index << 1] += (mid - l + 1) * t;
//		la[index << 1] += t;
//		tree[index << 1 | 1] += (r - mid) * t;
//		la[index << 1 | 1] += t;
//		la[index] = 0;
//	}
//	
//	inline modify(int index , int l , int r , int x , int y) {
//		if (l > r) return;
//		if (x <=l && r <= y) {
//			tree[index] += r - l + 1;
//			la[index]++;
//			return;
//		}
//		down(index , l , r);
//		int mid = (l + r) >> 1;
//		if (mid >= x && x >= l) {
//			modify(index << 1 , l , mid , x , y);
//		}
//		if (mid < y & y <= r) {
//			modify(index << 1 | 1 , mid + 1 , r , x , y);
//		}
//		update(index);
//	}
//	
//	inline void query(int index , int l , int r) {
//		if (l > ans) return;
//		if (tree[index] == (r - l + 1) * (n + m)) {
//			chkmin(ans , l);
//		}
//		int mid = (l + r) >> 1;
//		query(index << 1 , l , mid);
//		query(index << 1 | 1 , mid + 1 , r);
//	}
//};

int main(){

	freopen("lantern.out" , "w" , stdout);
	cout << "-1" < endl;

	return 0;
}


