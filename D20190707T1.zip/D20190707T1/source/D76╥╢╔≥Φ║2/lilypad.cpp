#include<bits/stdc++.h>
using namespace std;
int a[110][110];
int n, m;
struct AK{
	int x;
	int y;
	int fz;
	int bs;
};
queue<AK> q;
AK t;
int h[110][110];
int spfa[110][110];
inline void pushin(AK t, int x, int y)
{
	t.x += x;t.y += y;
	if(t.x <= n && t.y <= m && t.x >= 1 && t.y >= 1)
	{
		if(a[t.x][t.y] != 2)
		{
			t.bs ++;
			if(a[t.x][t.y] == 0) t.fz++;
			if(t.fz < spfa[t.x][t.y])
			{
				spfa[t.x][t.y] = t.fz;
				h[t.x][t.y] = t.bs;
				q.push(t);
			}
			else if(t.fz = spfa[t.x][t.y] && t.bs < h[t.x][t.y])
			{
				h[t.x][t.y] = t.bs;
				q.push(t);
			}
		}
	}
}
int main()
{
	freopen("lilypad.in", "r", stdin);
	freopen("lilypad.out", "w", stdout);
	cin >> n >> m;
	int i, j;
	int ans_x, ans_y;
	for(i = 1;i <= n;i++)
	{
		for(j = 1;j <= m;j++)
		{
			scanf("%d", &a[i][j]);
			if(a[i][j] == 3)
			{
				t.x = i;
				t.y = j;
			}
			if(a[i][j] == 4)
			{
				ans_x = i;
				ans_y = j;
			}
		}
	}
	t.fz = 0;
	t.bs = 0;
	q.push(t);
	memset(h, 63, sizeof(h));
	memset(spfa, 63, sizeof(spfa));
	h[t.x][t.y] = 0;
	spfa[t.x][t.y] = 0;
	while(!q.empty())
	{
		t = q.front();
		pushin(t, 2, 1);
		pushin(t, 2, -1);
		pushin(t, -2, 1);
		pushin(t, -2, -1);
		pushin(t, 1, 2);
		pushin(t, -1, 2);
		pushin(t, 1, -2);
		pushin(t, -1, -2);
		q.pop();
	}
	if(spfa[ans_x][ans_y] <= 100000000)
	{
		cout << spfa[ans_x][ans_y] << " " << h[ans_x][ans_y];
	}
	else cout << -1 << " " << -1;
	return 0;
}

