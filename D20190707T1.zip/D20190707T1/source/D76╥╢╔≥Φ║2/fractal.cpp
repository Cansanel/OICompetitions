#include<bits/stdc++.h>
using namespace std;
int yc, xc;
double Sy, Sx;
double p, q;
char ans[810][810];
struct complex_zjh{
	double x;
	double y;
	
	inline complex_zjh jia(complex_zjh a, complex_zjh b)
	{
		complex_zjh co;
		co.x = a.x + b.x;
		co.y = a.y + b.y;
		return co;
	} 
	
	inline complex_zjh jian(complex_zjh a, complex_zjh b)
	{
		complex_zjh co;
		co.x = a.x - b.x;
		co.y = a.y - b.y;
		return co;
	} 
	
	inline complex_zjh cheng(complex_zjh a, complex_zjh b)
	{
		complex_zjh co;
		co.x = a.x *b.x -a.y *b.y;
		co.y = a.x *b.y +a.y *b.x;
		return co;
	}
	
	inline double orz(complex_zjh a)
	{
		double bj = 0.00;
		if(a.y == bj)
		{
			if(a.x < bj) return a.x *-1;
			else return a.x;
		}
		else 
		{
			return sqrt(a.x *a.x +a.y *a.y);
		}
	}
};
complex_zjh c;
complex_zjh test[110];
inline bool fuck(complex_zjh ass)
{
	int i;
	if(ass.orz(ass) >= 10.00)return 0;
	test[0] = ass;
	for(i = 1;i <= 100;i++)
	{
		test[i] =ass.jia(ass.cheng(test[i -1], test[i -1]), c);
		if(ass.orz(test[i]) >= 10.00)return 0;
	}
	return 1;
}
int main()
{
	freopen("fractal.in", "r", stdin);
	freopen("fractal.out", "w", stdout);
	cin >> yc >> xc;
	cin >> Sy >> Sx >> p >> q;
	int i, j;
	c.x = p;
	c.y = q;
	for(i = 0;i < yc;i++)
	{
		for(j = 0;j < xc;j++)
		{
			double x, y;
			x = i;
			y = j;
			complex_zjh t;
			t.x = Sy +y *0.005;
			t.y = Sx +x *0.01;
			if(fuck(t))ans[i][j] = 'a';
			else ans[i][j] = ' ';
		}
	}
	for(i = 0;i < yc;i++)
	{
		for(j = 0;j < xc;j++)
		{
			cout << ans[i][j];
		}
		cout << endl;
	}
	return 0;
}

