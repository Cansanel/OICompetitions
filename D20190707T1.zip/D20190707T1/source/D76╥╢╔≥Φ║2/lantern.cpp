#include<bits/stdc++.h>
using namespace std;
/*
int a[510][10010];
vector<int> ve[510];
vector<int> vf[10010];
bool he[510][10010];
bool hf[510][10010];
struct AK{
	int n;
	int light;
};
bool operator < (AK x, AK y)
{
	if(x.light < y.light)return 1;
	return 0;
}
priority_queue<AK> qe[510];
priority_queue<AK> qf[10010];
*/
int main()
{
	freopen("lantern.in", "r", stdin);
	freopen("lantern.out", "w", stdout);
	/*
	int n, m;
	cin >> n >>m;
	int i, j;
	for(i = 1;i <= n;i++)
	{
		for(j = 1;j <= m;j++)
		{
			scanf("%d", &a[i][j]);
			if(a[i][j] != 0)
			{
				he[i][j] = 1;
				hf[i][j] = 1;
				ve[i].push_back(j);
				vf[j].push_back(i);
				AK t;
				t.light = a[i][j];
				t.n = j;
				qe[i].push(t);
				t.n = i;
				qf[j].push(t);
			}
		}
	}
	
	for(i = 1;i <= n;i++)
	{
		
		while(!qe[i].empty())
		{
			bool k = 1;
			int last;
			int maxi;
			for(j = 0;j < ve[i].size();j++)
			{
				if(he[i][ve[i][j]] != 0)
				{
					if(k == 1)
					{
						maxi = ve[i][j];
						k = 0;
						last = ve[i][j];
					}
					else 
					{
						maxi = max(maxi, (ve[i][j] - last +1));
					}
				}
			}
			he[i][qe[i].top().n] = 0;
			if(maxi <= qe[i].top().light)
			{
				for(j = maxi;j <= qe[i].top().light;j++)
				{
					
				}
			}
			qe[i].pop();
		}
	}
	for(i = 1;i <= m;i++)
	*/
	cout << -1;
	return 0;
}

