#include<cstdio>
#define cy(tmp,x,y) for(int tmp=x;tmp<=y;++tmp)
using namespace std;
int xc,yc,flag;
double sx,sy,p,q,x[107],y[107];
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d%d%lf%lf%lf%lf",&xc,&yc,&sx,&sy,&p,&q);
	cy(i,0,xc-1){
		cy(j,0,yc-1){
			x[0]=sx+j*0.005;
			y[0]=sy+i*0.01;
			flag=0;
			if(x[0]*x[0]+y[0]*y[0]>=100) flag=1;
			cy(k,1,100){
				if(flag==1) break;
				x[k]=x[k-1]*x[k-1]-y[k-1]*y[k-1]+p;
				y[k]=2*x[k-1]*y[k-1]+q;
				if(x[k]*x[k]+y[k]*y[k]>=100) flag=1;
			}
			flag==1?putchar(' '):putchar('a');
		}
		printf("\n");
	}
	return 0;
}
