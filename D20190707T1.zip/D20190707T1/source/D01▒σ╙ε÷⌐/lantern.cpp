#include<cstdio>
#include<algorithm>
#define cy(tmp,x,y) for(int tmp=x;tmp<=y;++tmp)
using namespace std;
int n,m,tot,flag,l,r,mid,sum,vis[507][10007],map[507][10007];
struct node{
	int x,y,k;
}q[5000007];
bool cmp(node x,node y){
	return x.k<y.k;
}
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	scanf("%d%d",&n,&m);
	cy(i,1,n)
		cy(j,1,m){
			scanf("%d",&map[i][j]);
			if(map[i][j]>0){
				q[++tot].x=i;
				q[tot].y=j;
				q[tot].k=map[i][j];
			}
		}
	sort(q+1,q+tot+1,cmp);
	l=1;r=tot;flag=0;
	while(l<r){
		mid=(l+r)>>1;
		cy(i,1,n)
			cy(j,1,m) vis[i][j]=0;
		sum=0;
		cy(i,mid,tot){
			cy(j,q[i].x-q[mid].k+1,q[i].x+q[mid].k-1)
				if(vis[j][q[i].y]==0){
					vis[j][q[i].y]=1;
					sum++;
				}
			cy(j,q[i].y-q[mid].k+1,q[i].y+q[mid].k-1)
				if(vis[q[i].x][j]==0){
					vis[q[i].x][j]=1;
					sum++;
				}
		}
		if(sum==n*m) r=mid,flag=1;
		else l=mid+1;
	}
	if(!flag) printf("-1");
	else printf("%d",q[mid].k);
	return 0;
}
