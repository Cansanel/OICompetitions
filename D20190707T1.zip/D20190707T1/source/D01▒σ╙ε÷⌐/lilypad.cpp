#include<cstdio>
#define cy(tmp,x,y) for(int tmp=x;tmp<=y;++tmp)
using namespace std;
int m,n,ux,uy,vx,vy,h,t,tmp,p[8],q[8],x[100007],y[100007],vis[107][107],sum[107][107],map[107][107];
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	scanf("%d%d",&m,&n);
	cy(i,1,m)
		cy(j,1,n){
			scanf("%d",&map[i][j]);
			if(map[i][j]==3) ux=i,uy=j;
			if(map[i][j]==4) vx=i,vy=j;
		}
	x[1]=ux;y[1]=uy;h=0;t=1;
	cy(i,1,m)
		cy(j,1,n) vis[i][j]=1e9;
	vis[ux][uy]=0;
	p[1]=-1;q[1]=2;p[2]=-2;q[2]=1;p[3]=-2;q[3]=-1;p[4]=-1;q[4]=-2;
	p[5]=1;q[5]=-2;p[6]=2;q[6]=-1;p[7]=2;q[7]=1;p[8]=1;q[8]=2;
	while(h!=t){
		h++;
		cy(i,1,8)
			if(map[x[h]+p[i]][y[h]+q[i]]!=2&&x[h]+p[i]>=1&&x[h]+p[i]<=m&&y[h]+q[i]>=1&&y[h]+q[i]<=n){
				tmp=vis[x[h]][y[h]];
				if(map[x[h]+p[i]][y[h]+q[i]]==0) tmp++;
				if(tmp<vis[x[h]+p[i]][y[h]+q[i]]){
					vis[x[h]+p[i]][y[h]+q[i]]=tmp;
					x[++t]=x[h]+p[i];
					y[t]=y[h]+q[i];
				}
			}
	}
	if(vis[vx][vy]==1e9) printf("-1 -1\n");
	else{
		printf("%d ",vis[vx][vy]);
		sum[vx][vy]=1;
		map[vx][vx]=1;
		h=0;t=1;x[1]=vx;y[1]=vy;
		while(h!=t){
			h++;
			tmp=vis[x[h]][y[h]];
			if(map[x[h]][y[h]]==0) tmp--;
			cy(i,1,8)
				if(map[x[h]+p[i]][y[h]+q[i]]!=2&&x[h]+p[i]>=1&&x[h]+p[i]<=m&&y[h]+q[i]>=1&&y[h]+q[i]<=n)
					if(vis[x[h]+p[i]][y[h]+q[i]]==tmp&&sum[x[h]+p[i]][y[h]+q[i]]==0){
						sum[x[h]+p[i]][y[h]+q[i]]=sum[x[h]][y[h]]+1;
						x[++t]=x[h]+p[i];
						y[t]=y[h]+q[i];
					}
			if(sum[ux][uy]!=0) break;
		}
		printf("%d",sum[ux][uy]-1);
	}
	return 0;
}
