#include<bits/stdc++.h>
using namespace std;
const int gx[8]={1,1,-1,-1,2,2,-2,-2};
const int gy[8]={2,-2,2,-2,1,-1,1,-1};
struct node{
	int x,y;
}s,t;
int n,m,a[105][105];
int h[105][105],dep[105][105];
void bfs(){
	queue<node> q;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			dep[i][j]=h[i][j]=9;
	dep[s.x][s.y]=0;
	h[s.x][s.y]=0;
	q.push(s);
	while(!q.empty())
	{
		int x=q.front().x,y=q.front().y;
//		cout<<x<<"*"<<y<<endl;
//		for(int i=1;i<=n;i++)
//		{
//			for(int j=1;j<=m;j++)
//				cout<<h[i][j]<<" ";
//			cout<<"   ";
//			for(int j=1;j<=m;j++)
//				cout<<dep[i][j]<<" ";
//			cout<<endl;
//		}
		q.pop();
		for(int i=0;i<8;i++)
		{
			if (1<=x+gx[i]&&x+gx[i]<=n&&1<=y+gy[i]&&y+gy[i]<=m)
			if (a[x+gx[i]][y+gy[i]]!=2)
			{
				if (a[x+gx[i]][y+gy[i]]==1||a[x+gx[i]][y+gy[i]]==4)
				{
					if (h[x][y]<h[x+gx[i]][y+gy[i]])
					{
						h[x+gx[i]][y+gy[i]]=h[x][y];
						dep[x+gx[i]][y+gy[i]]=dep[x][y]+1;
						node t;
						t.x=x+gx[i];
						t.y=y+gy[i];
						q.push(t);
					}
					else
					if (h[x][y]==h[x+gx[i]][y+gy[i]])
					{
						if (h[x][y]<h[x+gx[i]][y+gy[i]]-1)
						{
							dep[x+gx[i]][y+gy[i]]=dep[x][y]+1;	
							node t;
							t.x=x+gx[i];
							t.y=y+gy[i];
							q.push(t);
						}
					}
				}
				else
				{
					if (h[x][y]+1<h[x+gx[i]][y+gy[i]])
					{
						h[x+gx[i]][y+gy[i]]=h[x][y]+1;
						dep[x+gx[i]][y+gy[i]]=dep[x][y]+1;
						node z;
						z.x=x+gx[i];
						z.y=y+gy[i];
						q.push(z);
					}
					else
					if (h[x][y]+1==h[x+gx[i]][y+gy[i]])
					{
						if (h[x][y]<h[x+gx[i]][y+gy[i]]-1)
						{
							dep[x+gx[i]][y+gy[i]]=dep[x][y]+1;	
							node z;
							z.x=x+gx[i];
							z.y=y+gy[i];
							q.push(z);
						}
					}
				}
			}
		}
	}
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
			if (a[i][j]==3){s.x=i;s.y=j;}
			if (a[i][j]==4){t.x=i;t.y=j;}
		}
	bfs();
	cout<<h[t.x][t.y]<<" "<<dep[t.x][t.y]<<endl; 
	return 0;
}
/*
4 8
0 0 0 1 0 0 0 0
0 0 0 0 0 2 0 1
0 0 0 0 0 4 0 0
3 0 0 0 0 0 1 0
*/
