#include<bits/stdc++.h>
using namespace std;
int n,m,a[505][10005],b[505][10005],ma;
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)	
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
			ma=max(a[i][j],ma);
		}
	for(int i=1;i<=ma;i++)
	{
		for(int j=1;j<=n;j++)	
			for(int k=1;k<=m;k++)
				if (a[j][k]<i) b[j][k]=0;
				else b[j][k]=i;
		int f=0;
		for(int j=1;j<=n;j++)
		{
			int s=0;
			for(int k=1;k<=m;k++)
			{
				if (b[j][k]==0) s++;
				else 
				if (s>i*2-2)
				{
					f=1;
					break;
				}
				else s=0;
			}
			if (f==1) break;
		}
		if (f==1) continue;
		for(int j=1;j<=m;j++)
		{
			int s=0;
			for(int k=1;k<=n;k++)
			{
				if (b[k][j]==0) s++;
				else 
				if (s>i*2-2)
				{
					f=1;
					break;
				}
				else s=0;
			}
			if (f==1) break;
		}
		if (f==1) continue;
		else
		{
			cout<<i<<endl;
			break;
		}
	}
	return 0;
}

