#include<bits/stdc++.h>
using namespace std;
char c[805][805];
double yc,xc,sy,sx,p,q;
bool pd(double x,double y){
	pair<double,double> z[101];
	z[0]=make_pair(x,y);
	for(int i=1;i<=100;i++)
	{
		z[i].first=z[i-1].first*z[i-1].first-z[i-1].second*z[i-1].second+p;
		z[i].second=z[i-1].first*z[i-1].second+z[i-1].second*z[i-1].first+q;
		if (sqrt(z[i].first*z[i].first+z[i].second*z[i].second)>=10) return 0;
	}
	return 1;
} 
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout); 
	cin>>yc>>xc>>sy>>sx>>p>>q;
	for(int j=0;j<yc;j++)
		for(int i=0;i<xc;i++)
		{
			if (pd(sy+i*0.005,sx+j*0.01)) c[j][i]='a';
			else c[j][i]=' ';
		} 
	for(int j=0;j<yc;j++)
	{
		for(int i=0;i<xc;i++)
			putchar(c[j][i]);
		cout<<endl;
	}
	return 0;
}
