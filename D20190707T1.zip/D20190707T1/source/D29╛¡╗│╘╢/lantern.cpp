#include<bits/stdc++.h>
#define N 501
#define M 10001
using namespace std;
void read(int &x){
	x=0;int b=1;
	char c;
	while(c=getchar(),!isdigit(c))
	    if(c=='-') b=-1;
	x=c-'0';
	while(c=getchar(),isdigit(c)) x=x*10+c-'0';
	x*=b;
	return;
}
void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>=10) write(x/10);
	putchar(x%10+'0');
	return;
}
int n,m,Map[N][M],vis[N][M];
int d[5][2];
struct rec{
	int x,y,lv;
};
rec lit[5000001];
int tot=0;
bool check(int p){
	memset(vis,0,sizeof(vis));
	int sum=0;
	for(register int i=1;i<=tot;++i)
	    if(lit[i].lv<p) continue;
	    else{
	    	int x=lit[i].x,y=lit[i].y;
	    	if(vis[x][y]!=3) ++sum,vis[x][y]=3;
			for(register int k=1;k<=4;++k)
				for(register int j=1;j<=p-1&&x+d[k][0]*j<=n&&x+d[k][0]*j>=1&&y+d[k][1]*j<=m&&y+d[k][1]*j>=1;++j){
					if(vis[x+d[k][0]*j][y+d[k][1]*j]==3) continue;
					if(vis[x+d[k][0]*j][y+d[k][1]*j]==1&&(k==1||k==3)){
						sum+=1,vis[x+d[k][0]*j][y+d[k][1]*j]=3;
						continue;
					}
					if(vis[x+d[k][0]*j][y+d[k][1]*j]==2&&(k==2||k==4)){
						sum+=1,vis[x+d[k][0]*j][y+d[k][1]*j]=3;
						continue;
					}
					if(vis[x+d[k][0]*j][y+d[k][1]*j]==0)
					    (k==2||k==4)?vis[x+d[k][0]*j][y+d[k][1]*j]=1:vis[x+d[k][0]*j][y+d[k][1]*j]=2;
				}
		}
	if(sum==n*m) return 1;
	else return 0;
}
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	d[1][0]=1,d[1][1]=0;
	d[2][0]=0,d[2][1]=1;
	d[3][0]=-1,d[3][1]=0;
	d[4][0]=0,d[4][1]=-1;
	read(n),read(m);
	int l=2147483647,r=0;
	for(register int i=1;i<=n;++i)
	    for(register int j=1;j<=m;++j){
	        read(Map[i][j]);
			Map[i][j]!=0?l=min(l,Map[i][j]),r=max(r,Map[i][j]):0;
			Map[i][j]!=0?lit[++tot].x=i,lit[tot].y=j,lit[tot].lv=Map[i][j]:0;
	    }
	int ans=-1,mid;
	while(l<=r){
		mid=(l+r)/2;
		if(check(mid)) ans=mid,r=mid-1;
		else l=mid+1;
	}
	write(ans);putchar('\n');
	return 0;
}

