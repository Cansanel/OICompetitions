#include<bits/stdc++.h>
#define N 101
#define ink 2147483647
using namespace std;
void read(int &x){
	x=0;int b=1;
	char c;
	while(c=getchar(),!isdigit(c))
	    if(c=='-') b=-1;
	x=c-'0';
	while(c=getchar(),isdigit(c)) x=x*10+c-'0';
	x*=b;
	return;
}
void write(int x){
	if(x<0) putchar('-'),x=-x;
	if(x>=10) write(x/10);
	putchar(x%10+'0');
	return;
}
int m,n,Map[N][N],sx,sy,ex,ey;
int deep,step;
bool vis[N][N];
int d[9][2];
struct rec{
	int x;int y;int p;int stp;
};
queue<rec> q;
void bfs(){
	while(q.size()) q.pop();
	rec tmp;tmp.x=sx,tmp.y=sy,tmp.p=0,tmp.stp=0;
	q.push(tmp);
	vis[sx][sy]=1;
	while(q.size()){
		int x=q.front().x,y=q.front().y,p=q.front().p,stp=q.front().stp;
		q.pop();
		if(x==ex&&y==ey){
			step=stp;
			return;
		}
		for(register int i=1;i<=8;++i)
		    if(x+d[i][0]>=1&&x+d[i][0]<=n&&y+d[i][1]>=1&&y+d[i][1]<=m&&Map[x+d[i][0]][y+d[i][1]]!=2)
		    	if(vis[x+d[i][0]][y+d[i][1]]>(Map[x+d[i][0]][y+d[i][1]]==0?p+1:p)||vis[x+d[i][0]][y+d[i][1]]==0){
		    		
		    		rec tmp;
		    		tmp.x=x+d[i][0];tmp.y=y+d[i][1];
		    		tmp.p=p;tmp.stp=stp+1;
		    		if(Map[x+d[i][0]][y+d[i][1]]==0)
		    		    if(p+1>deep) continue;
		    		    else ++tmp.p;
		    		vis[x+d[i][0]][y+d[i][1]]=tmp.p;
		    		q.push(tmp);
			  	}
	}
	return;
} 
bool check(int x){
	deep=x,step=ink;
	memset(vis,0,sizeof(vis));
	bfs();
	if(step!=ink) return 1;
	else return 0;
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	d[1][0]=1;d[1][1]=2;
	d[2][0]=2;d[2][1]=1;
	d[3][0]=-1;d[3][1]=2;
	d[4][0]=-2;d[4][1]=1;
	d[5][0]=1;d[5][1]=-2;
	d[6][0]=2;d[6][1]=-1;
	d[7][0]=-1,d[7][1]=-2;
	d[8][0]=-2,d[8][0]=-1;
	read(n),read(m);
	for(register int i=1;i<=n;++i) for(register int j=1;j<=m;++j){
		read(Map[i][j]);
		Map[i][j]==3?sx=i,sy=j:0;
		Map[i][j]==4?ex=i,ey=j:0;
	}
	vis[sx][sy]=1;
	int l=0,r=n*m,ans,mid;
	while(l<=r){
		mid=(l+r)/2;
		if(check(mid)) ans=mid,r=mid-1;
		else l=mid+1;
	} 
	write(ans),putchar(' '),write(step),putchar('\n');
	return 0;
}

