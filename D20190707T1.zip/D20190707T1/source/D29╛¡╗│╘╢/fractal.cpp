#include<bits/stdc++.h>
#define N 801
using namespace std;
int yc,xc;
double sy,sx,p,q;
struct rec{
	double x,y;
};
rec add(rec x,rec y){
	rec z;
	z.x=x.x+y.x;
	z.y=x.y+y.y;
	return z;
}
rec mul(rec x,rec y){
	rec z;
	z.x=x.x*y.x-x.y*y.y;
	z.y=x.x*y.y+x.y*y.x;
	return z;
}
double len(rec x){
	return sqrt(x.x*x.x+x.y*x.y);
}
bool work(double x,double y){
	rec c;c.x=p,c.y=q;
	rec z[101];z[0].x=x,z[0].y=y;
	if(len(z[0])>=10) return 0;
	for(register int i=1;i<=100;++i){
		z[i]=add(mul(z[i-1],z[i-1]),c);
		if(len(z[i])>=10) return 0;
	}
	return 1;
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx;
	cin>>p>>q;
	for(register int j=1;j<=yc;++j){
		for(register int i=1;i<=xc;++i)
		   if(work(sy+i*0.005,sx+j*0.01)) cout<<'a';
		   else cout<<' ';
		cout<<endl;
	}
	return 0;
}

