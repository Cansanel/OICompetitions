#include<cstdio>
#include<cstring>
#include<algorithm>
#define max(x,y) (x>y?x:y)
#define min(x,y) (x<y?x:y)
int n,m,maxr=0,tmp,tot=0,val,flag=0;
int mp[503][10003];
struct lantern
{
int x,y,r;
}a[5000001];
inline int read()
{
int x=0;char ch=getchar();
while(ch>'9'||ch<'0')ch=getchar();
while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+ch-48,ch=getchar();
return x;
}
bool cmp(lantern a,lantern b)
{return a.r>b.r;}
void check()
{
printf("val:%d mp:\n",val);
for(int i=0;i<=n+1;++i)
{
for(int j=0;j<=m+1;++j)
printf("%-4d",mp[i][j]);
printf("\n");
}
}
int main()
{
freopen("lantern.in","r",stdin);
freopen("lantern.out","w",stdout);
n=read(),m=read();
for(int i=1;i<=n;++i)
for(int j=1;j<=m;++j)
{
tmp=read();
if(tmp)
a[++tot].x=i,a[tot].y=j,a[tot].r=tmp,maxr=(maxr,tmp);
}
if(tot<min(n/2,m/2)){puts("-1");fclose(stdin);fclose(stdout);return 0;}
std::sort(a+1,a+1+tot,cmp);
for(val=1;val<=maxr;++val)
	{
	std::memset(mp,0,sizeof(mp));
	for(int i=1;i<=tot;++i)
		{
		if(a[i].r<val)break;
		mp[max(a[i].x-val+1,0)][a[i].y]=1;
		mp[min(a[i].x+val,n+1)][a[i].y]=-1;
		mp[a[i].x][max(a[i].y-val+1,0)]=1;
		mp[a[i].x][min(a[i].y+val,m+1)]=-1;
		}
		
	//if(val>=5)check();	
	
	flag=1;
	for(int i=1;i<=n;++i)
		{
		tmp=mp[i][0];
		for(int j=1;j<=m;++j)
			{
			tmp+=mp[i][j];
			
			//if(val>=5)printf("val:%d i:%d j:%d tmp:%d\n",val,i,j,tmp);
			
			if(tmp<=0){flag=0;break;}
			}
		if(!flag)break;
		}
	if(!flag)continue;
	for(int j=1;j<=m;++j)
		{
		tmp=mp[0][j];
		for(int i=1;i<=n;++i)
			{
			tmp+=mp[i][j];
			
			//if(val>=5)printf("val:%d i:%d j:%d tmp:%d\n",val,i,j,tmp);
			
			if(tmp<=0){flag=0;break;}
			}
		if(!flag)break;
		}
	if(flag)break;
	}
if(!flag)puts("-1");else printf("%d\n",val);
fclose(stdin);
fclose(stdout);
return 0;
}
