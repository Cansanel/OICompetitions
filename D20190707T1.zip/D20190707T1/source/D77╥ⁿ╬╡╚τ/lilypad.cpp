#include<cstdio>
#include<cstring>
#include<queue>
#include<cstdlib>
using namespace std;
#define inf 0x3f3f3f3f
#define pii pair<int,int>
int dx[9]={0,1,2,-1,-2,1,2,-1,-2};
int dy[9]={0,2,1,-2,-1,-2,-1,2,1};
int n,m,sx,sy,ex,ey;
int a[101][101];
int dist[101][101];
struct queue
{
int x,y,len;
}qq[20001];int l,r;
bool vis[101][101];
pii t;
priority_queue<pii,vector<pii >,greater<pii > >q;
char ch;
void check()
{
puts("\n\ndist:");
for(int i=1;i<=n;++i)
{
for(int j=1;j<=m;++j)
dist[i][j]==inf?printf("- "):printf("%d ",dist[i][j]);
putchar('\n');
}
}
int main()
{
freopen("lilypad.in","r",stdin);
freopen("lilypad.out","w",stdout);
scanf("%d%d",&n,&m);
memset(a,-1,sizeof(a));
for(int i=1;i<=n;++i)
for(int j=1;j<=m;++j)
{
do{ch=getchar();}while(ch>'4'||ch<'0');
a[i][j]=ch-48;
if(a[i][j]==3)sx=i,sy=j,a[i][j]=0;
else if(a[i][j]==2)a[i][j]=-2;
else if(a[i][j]==4)ex=i,ey=j,a[i][j]=0;
else if(a[i][j]==1)a[i][j]=0;
else if(a[i][j]==0)a[i][j]=1;
}
memset(dist,inf,sizeof(dist));
t=make_pair(0,sx*10000+sy);
dist[sx][sy]=0;vis[sx][sy]=1;
q.push(t);
while(!q.empty())
	{
	int xx=q.top().second/10000;int yy=q.top().second%1000;
	if(dist[xx][yy]!=q.top().first)
	{q.pop();continue;}q.pop();
	for(int i=1;i<=8;++i)
		{
		int tx=xx+dx[i],ty=yy+dy[i];
		if(dist[tx][ty]>dist[xx][yy]+a[tx][ty])
			{
			dist[tx][ty]=dist[xx][yy]+a[tx][ty];
			if(a[tx][ty]>=0&&!vis[tx][ty])
				{
				t=make_pair(dist[tx][ty],tx*10000+ty);
				q.push(t);
				vis[tx][ty]=1;
				}
			}
		
		}
	}
printf("%d ",dist[ex][ey]);
memset(vis,0,sizeof(vis));
l=r=1;qq[l].x=ex;qq[r].y=ey;qq[l].len=0;vis[ex][ey]=1;
while(l<=r)
	{
	if(qq[l].x==sx&&qq[l].y==sy)
	{printf("%d\n",qq[l].len);break;}
	for(int i=1;i<=8;++i)
	{
	int tx=qq[l].x+dx[i],ty=qq[l].y+dy[i];
	if(dist[tx][ty]+a[qq[l].x][qq[l].y]==dist[qq[l].x][qq[l].y]
		&&!vis[tx][ty])
		{
		vis[tx][ty]=1;
		qq[++r].x=tx;qq[r].y=ty;
		qq[r].len=qq[l].len+1;
		}
	}
	++l;
	}
fclose(stdin);
fclose(stdout);
return 0;
}
