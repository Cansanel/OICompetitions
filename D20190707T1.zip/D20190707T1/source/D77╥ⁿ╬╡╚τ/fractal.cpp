#include<cstdio>
#include<iostream>
using namespace std;
int yc,xc;
double sy,sx,p,q;
struct a_bi
{
double p,q;
};
a_bi z[101];
a_bi c;
char ch[801][801];
double len;
inline bool check()
{
for(int i=1;i<=100;++i)
	{
	z[i].p=z[i-1].p*z[i-1].p-z[i-1].q*z[i-1].q+p;
	z[i].q=2*z[i-1].q*z[i-1].p+q;
	if(z[i].p*z[i].p+z[i].q*z[i].q>=99.9999)return 0;
	}
return 1;
}
int main()
{
freopen("fractal.in","r",stdin);
freopen("fractal.out","w",stdout);
scanf("%d%d%lf%lf",&yc,&xc,&sy,&sx);
scanf("%lf%lf",&p,&q);
for(int j=0;j<yc;++j)
for(int i=0;i<xc;++i)
{
z[0].p=sy+(double)i*0.005,z[0].q=sx+(double)j*0.01;
if(check())ch[j][i]='a';else ch[j][i]=' ';
}
for(register int j=0;j<yc;++j)
{
for(register int i=0;i<xc;++i)
putchar(ch[j][i]);cout<<endl;
}
fclose(stdin);
fclose(stdout);
return 0;
}
