#include<iostream>
#include<cstdio>
#include<cmath>
const int MAXN = 810;
struct cplx{long double x,y;};
cplx p,z[101];
char c[MAXN][MAXN];
bool flg;
int i,j,xc,yc;
long double sy,sx;
cplx operator + (cplx a,cplx b){
	cplx res;
	res.x=a.x+b.x;
	res.y=a.y+b.y;
	return res;
}
cplx operator - (cplx a,cplx b){
	b.x=-b.x;
	b.y=-b.y;
	return a+b;
}
cplx operator * (cplx a,cplx b){
	cplx res;
	res.x=a.x*b.x-a.y*b.y;
	res.y=a.x*b.y+a.y*b.x;
	return res;
}
cplx read(){
	cplx res;
	std::cin>>res.x>>res.y;
	return res;
}
cplx mkc(long double a,long double b){
	cplx r;
	r.x=a; r.y=b;
	return r;
}
long double calc(cplx a){
	return sqrt(a.x*a.x+a.y*a.y);
}
bool chk(cplx P,cplx C){
	z[0]=P; flg=1;
	for(register int i=1;i<101 && flg;i++){
		z[i]=z[i-1]*z[i-1]+C;
		if (calc(z[i])>=10) flg=0;	
	}
	return flg;	
}
void gen(){
	for(j=0;j<yc;j++)
		for(i=0;i<xc;i++)
			if (chk(mkc(sy+i*0.005,sx+j*0.01),p))
				c[j][i]='a';
			else
				c[j][i]=' ';
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	std::cin>>yc>>xc>>sy>>sx;
	p=read();
	gen();
	for(i=0;i<yc;i++){
		for(j=0;j<xc;j++)
			putchar(c[i][j]);
		putchar('\n');
	}
	return 0;
} 
