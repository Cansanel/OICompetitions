#include<cstring>
#include<utility>
#include<cstdio>
#include<queue>
const int dx[] = {1,-1,2,2,1,-1,-2,-2};
const int dy[] = {-2,-2,1,-1,2,2,1,-1};
const int MAXN = 110;
int ed,u[MAXN*MAXN*8],v[MAXN*MAXN*8],w[MAXN*MAXN*8],fst[MAXN*MAXN],nxt[MAXN*MAXN*8];
int n,m,ans,px,py,ex,ey,a[MAXN][MAXN],dis[MAXN*MAXN];
bool vis[MAXN][MAXN];
int min(int x,int y){
	return x>y?y:x;
}
void addedge(int x,int y,int z){
	u[++ed]=x; v[ed]=y; w[ed]=z;
	nxt[ed]=fst[u[ed]];
	fst[u[ed]]=ed;
}
void dijkstra(){
	std::priority_queue <std::pair<int,int> > q;
	memset(dis,0x7f7f7f7f,sizeof dis);
	dis[(px-1)*n+py]=0;
	q.push(std::make_pair(0,(px-1)*n+py));
	while(!q.empty()){
		int nownode=q.top().second;
		q.pop();
		for(register int i=fst[nownode];i!=-1;i=nxt[i])
			if (dis[v[i]]>dis[nownode]+w[i]){
				dis[v[i]]=dis[nownode]+w[i];
				q.push(std::make_pair(-dis[v[i]],v[i]));
			}
	}
}
void dfs(int dep,int x,int y,int c,int maxc){
	if (c>maxc) return;
	if (x==ex && y==ey){
		ans=min(ans,dep);
		return;
	}
	vis[x][y]=1;
	for(register int i=0;i<8;i++){
		int tx=x+dx[i],ty=y+dy[i];
		if (tx>0 && ty>0 && tx<=m && ty<=n && !vis[tx][ty] && a[tx][ty]!=2){
			dfs(dep+1,tx,ty,c+(a[tx][ty]==0),maxc);
		}
	}
	vis[x][y]=0;
}
int main(){
	freopen("lilypad.out","w",stdout);
	freopen("lilypad.in","r",stdin);
	memset(fst,255,sizeof fst);
	ans=2147483647;
	scanf("%d%d",&m,&n);
	for(register int i=1;i<=m;i++)
		for(register int j=1;j<=n;j++){
			scanf("%d",&a[i][j]);
			if (a[i][j]==3){
				px=i; py=j;
			}
			if (a[i][j]==4){
				ex=i; ey=j;
			}
		}
	for(register int i=1;i<=m;i++)
		for(register int j=1;j<=n;j++)
			for(register int k=0;k<8;k++){
				int x=i+dx[k],y=j+dy[k];
				if (x>0 && y>0 && x<=m && y<=n && a[x][y]!=2)
					addedge((i-1)*n+j,(x-1)*n+y,a[x][y]==0);
			}
	dijkstra();
	dfs(0,px,py,0,dis[(ex-1)*n+ey]);
	printf("%d %d",dis[(ex-1)*n+ey],ans);
	return 0;
}
