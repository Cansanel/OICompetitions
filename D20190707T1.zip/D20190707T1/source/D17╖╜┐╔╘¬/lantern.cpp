#include<algorithm>
#include<cstdio>
const int MAXN = 501;
const int MAXM = 10001;
struct light{ int x,y,r; };
light lights[MAXN*MAXM];
int n,m,left,right,mid,lightcnt,vis[MAXN][MAXM];
struct segt{ int L,R,C; };
segt sgt[MAXN][MAXM*8];
int CT;
void buildtree(int adr,int idx,int l,int r){
	sgt[adr][idx].L=l;
	sgt[adr][idx].R=r;
	if (l==r) return;
	buildtree(adr,idx<<1,l,(l+r)>>1);
	buildtree(adr,(idx<<1)+1,((l+r)>>1)+1,r);
}
int iscover(int adr,int idx,int l,int r){
	if (sgt[adr][idx].R<l || sgt[adr][idx].L>r) return CT;
	if (sgt[adr][idx].L>=l && sgt[adr][idx].R<=r) return sgt[adr][idx].C;
	return sgt[adr][idx].C = (iscover(adr,idx<<1,l,r)==CT && iscover(adr,(idx<<1)+1,l,r)==CT)?CT:sgt[adr][idx].C;
}
void cover(int adr,int idx,int l,int r){
	if (sgt[adr][idx].R<l || sgt[adr][idx].L>r) return;
	if (sgt[adr][idx].L>=l && sgt[adr][idx].R<=r){
		sgt[adr][idx].C=CT;
		return;
	}
	cover(adr,idx<<1,l,r);
	cover(adr,(idx<<1)+1,l,r);
	sgt[adr][idx].C = (sgt[adr][idx<<1].C==CT && sgt[adr][(idx<<1)+1].C==CT)?CT:sgt[adr][idx].C;
}
inline int read(){
	int x=0; char c=0;
	while(c<'0' || c>'9') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	return x;
}
inline bool cmp(light x,light y){
	return x.r<y.r;
}
inline int max(int x,int y){
	return x>y?x:y;
}
inline int min(int x,int y){
	return x<y?x:y;
}
inline bool chk(int R){
	CT++; // Clear the segment tree
	int Left=1,Right=lightcnt,Mid,cntx=0,cnty=0,tmp=n*m;
	while(Left<Right){
		Mid = (Left + Right) >> 1;
		if (lights[Mid].r >= R) Right = Mid;
			else Left = Mid + 1;
	}
	for(register int i=Left;i<=lightcnt;i++){
		cover(lights[i].x,1,max(1,lights[i].y-R+1),min(m,lights[i].y+R-1));
		if (cnty<tmp)
			for(register int j=max(1,lights[i].x-R+1);j<=min(n,lights[i].x+R-1) && cnty<tmp;j++)
				if (vis[j][lights[i].y]!=CT){
					vis[j][lights[i].y]=CT;
					cnty++;
				}
	}
	for(register int i=1;i<=n;i++)
		if (iscover(i,1,1,m)==CT) cntx++;
	return cntx>=n && cnty>=tmp;
}
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	n=read(); m=read();
	for(register int i=1;i<=n;i++)
		buildtree(i,1,1,m);
	for(register int i=1;i<=n;i++)
		for(register int j=1;j<=m;j++){
			int x=read();
			if (x){
				lights[++lightcnt].x=i;
				lights[lightcnt  ].y=j;
				lights[lightcnt  ].r=x;
				right=max(right,x);
			}
		}
	std::sort(lights+1,lights+lightcnt+1,cmp);
	while(left!=right){
		mid = (left + right + 1) >> 1;
		if (chk(mid)) left = mid;
			else right = mid - 1;
	}
	printf("%d",left?left:-1);
	return 0;
}
