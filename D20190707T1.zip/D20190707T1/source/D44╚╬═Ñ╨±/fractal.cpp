#include <bits/stdc++.h>
using namespace std;
const int maxn = 810;
int n, m;
double sx, sy, p, q;
struct comp{
	double a, b;
	comp(double a = 0, double b = 0) : a(a), b(b) {}
}z[110], c;
comp operator + (comp x, comp y) { return comp(x.a + y.a, x.b + y.b);  }
comp operator - (comp x, comp y) { return comp(x.a - y.a, x.b - y.b);  }
comp operator * (comp x, comp y) { return comp(x.a * y.a - x.b * y.b, x.a * y.b + x.b * y.a); }
double Len(comp x) { return sqrt(x.a * x.a + x.b * x.b); }
bool check(double x, double y) {
	z[0] = comp(x, y);
	if(Len(z[0]) >= 10) return false;
	for(int i = 1; i <= 100; i++) {
		z[i] = (z[i-1] * z[i-1]) + c;
		if(Len(z[i]) >= 10) return false;
	}
	return true;
}
int main() {
	freopen("fractal.in", "r", stdin);
	freopen("fractal.out", "w", stdout);
	scanf("%d%d%lf%lf", &n, &m, &sx, &sy);
	scanf("%lf%lf", &p, &q);
	c = comp(p, q);
	for(int i = 0; i < n; i++) {
		for(int j = 0; j < m; j++) {
			if(check(sx + 0.005 * j, sy + 0.01 * i)) printf("a");
			else printf(" ");
		}
		printf("\n");
	}
	return 0;
}
