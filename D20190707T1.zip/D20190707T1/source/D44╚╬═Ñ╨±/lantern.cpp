#include <bits/stdc++.h>
using namespace std;
const int maxn = 510, maxm = 10010;
int read() {
	int res = 0, f = 1; char c = getchar();
	while(c != '-' && (c < '0' || c > '9')) c = getchar(); if(c == '-') f = -1, c = getchar();
	while(c >= '0' && c <= '9') res = (res << 3) + (res << 1) + c - '0', c = getchar(); return res * f;
}
int n, m, r[maxn][maxm], c1[maxn][maxm], mx, c2[maxn][maxm];
int main() {
	freopen("lantern.in", "r", stdin);
	freopen("lantern.out", "w", stdout);
	n = read(); m = read();
	for(int i = 1; i <= n; i++)
		for(int j = 1; j <= m; j++) r[i][j] = read(), mx = max(mx, r[i][j]);
	for(int x = 1; x <= mx; x++) {
		for(int i = 1; i <= n; i++) for(int j = 1; j <= m; j++) c1[i][j] = c2[i][j] = 0;
		for(int i = 1; i <= n; i++) {
			for(int j = 1; j <= m; j++) {
				if(!r[i][j]) continue;
				if(x > r[i][j]) continue;
				int l = i - x + 1, r = i + x - 1;
				l = max(l, 1); r = min(r, n);
				c1[l][j]++; c1[r + 1][j]--;
				l = j - x + 1; r = j + x - 1;
				l = max(l, 1); r = min(r, m);
				c2[i][l]++; c2[i][r + 1]--;
			}
		}
		bool tag = 1;
		for(int i = 1; i <= n; i++) {
			for(int j = 1; j <= m; j++) {
				c1[i][j] += c1[i-1][j];
				c2[i][j] += c2[i][j-1];
				if(!c1[i][j] || !c2[i][j]) tag = 0;
			}
		}
		if(tag) { printf("%d\n", x); return 0; }
	}
	printf("-1\n");
	return 0;
}
