#include <bits/stdc++.h>
using namespace std;
const int maxn = 110, inf = 0x3f3f3f3f;
int read() {
	int res = 0, f = 1; char c = getchar();
	while(c != '-' && (c < '0' || c > '9')) c = getchar(); if(c == '-') f = -1, c = getchar();
	while(c >= '0' && c <= '9') res = (res << 3) + (res << 1) + c - '0', c = getchar(); return res * f;
}
int n, m, a[maxn][maxn], s, t, dx[8] = {-2, -1, 1, 2, 2, 1, -1, -2}, dy[8] = {1, 2, 2, 1, -1, -2, -2, -1};
int head[maxn * maxn], ver[maxn * maxn * 16], Next[maxn * maxn * 16], tot, w[maxn * maxn];
int v[maxn * maxn], d[maxn * maxn];
void add(int x, int y) {
	ver[++tot] = y, Next[tot] = head[x], head[x] = tot;
}
queue<int> q;
void spfa() {
	memset(d, 0x3f, sizeof(d));
	q.push(s); v[s] = 1; d[s] = w[s];
	while(q.size()) {
		int x = q.front(); q.pop();
		v[x] = 0;
		for(int i = head[x]; i; i = Next[i]) {
			if(d[ver[i]] > d[x] + w[ver[i]]) {
				d[ver[i]] = d[x] + w[ver[i]];
				if(!v[ver[i]]) q.push(ver[i]), v[ver[i]] = 1;
			}
		}
	}
}
int main() {
	freopen("lilypad.in", "r", stdin);
	freopen("lilypad.out", "w", stdout);
	n = read(); m = read();
	for(int i = 0; i < n; i++)
		for(int j = 0; j < m; j++) {
			a[i][j] = read();
			if(a[i][j] == 3) s = i * m + j, w[i * m + j] = 0;
			else if(a[i][j] == 4) t = i * m + j, w[i * m + j] = 1;
			else if(a[i][j] == 2) w[i * m + j] = inf;
			else w[i * m + j] = (1 - a[i][j]) * m * n + 1;
			for(int k = 0; k < 8; k++) {
				int nx = i + dx[k], ny = j + dy[k];
				if(nx < 0 || nx >= n || ny < 0 || ny >= m) continue;
				add(i * m + j, nx * m + ny);
			}
		}
	spfa();
	if(d[t] >= inf) printf("-1 -1\n");
	else printf("%d %d\n", d[t] / (m * n), d[t] % (m * n));
	return 0;
}
