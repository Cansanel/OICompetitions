#include<bits/stdc++.h>
#define LL long long
using namespace std;
int yc,xc;
double Sy,Sx,P,Q;
struct Xjh{
	double x,y;
}C;
Xjh operator *(Xjh A,Xjh B){
	Xjh C;
	C.x=A.x*B.x-A.y*B.y;
	C.y=A.x*B.y+A.y*B.x;
	return C;
}
Xjh operator +(Xjh A,Xjh B){
	Xjh C;
	C.x=A.x+B.x;
	C.y=A.y+B.y;
	return C;
}
Xjh operator -(Xjh A,Xjh B){
	Xjh C;
	C.x=A.x-B.x;
	C.y=A.y-B.y;
	return C;
}
double S(Xjh A){
	return sqrt(A.x*A.x+A.y*A.y);
}
Xjh Z[111];
bool Check(double x,double y){
	Z[0].x=x;
	Z[0].y=y;
	for(int i=1;i<=100;++i){
		Z[i]=(Z[i-1]*Z[i-1])+C;
		if(S(Z[i])>=10)return false;
	}
	return true;
}
char c[1001][1001];
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	scanf("%d%d%lf%lf%lf%lf",&yc,&xc,&Sy,&Sx,&P,&Q);
	C.x=P;
	C.y=Q;
	for(int i=0;i<xc;++i)
		for(int j=0;j<yc;++j)
			if(Check(Sy+i*0.005,Sx+j*0.01))
				c[j][i]='a';
			else
				c[j][i]=' ';
	for(int i=0;i<yc;++i,puts(""))
		for(int j=0;j<xc;++j)
			putchar(c[i][j]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
400 800 
-2 -2 
-0.53 0.53 
*/
/*
800 800
-1.75 -1.75
-1.326 0.01
*/
/*
800 800
-1.75 -1.75
-0.75 0.01
*/
