#include<bits/stdc++.h>
#define LL long long
using namespace std;
int N,M,Map[501][10001],l,r,Mid,Ans=-1;
int PD[501][10001];
void Modify(int x,int y,int k){
	for(int i=max(1,x-k+1);i<=min(N,x+k-1);++i)
		PD[i][y]|=1;
	for(int i=max(1,y-k+1);i<=min(M,y+k-1);++i)
		PD[x][i]|=2;
}
bool Check(int Level){
	for(int i=1;i<=N;++i)
		for(int j=1;j<=M;++j)
			PD[i][j]=0;
	for(int i=1;i<=N;++i)
		for(int j=1;j<=M;++j)
			if(Map[i][j]>=Level)
				Modify(i,j,Level);
	for(int i=1;i<=N;++i)
		for(int j=1;j<=M;++j)
			if(PD[i][j]^3)
				return false;
	return true;
}
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	scanf("%d%d",&N,&M);
	for(int i=1;i<=N;++i)
		for(int j=1;j<=M;++j)
			scanf("%d",&Map[i][j]),r=max(r,Map[i][j]);
	r=min(r,10001);
	while(l<=r){
		Mid=(l+r)>>1;
		if(Check(Mid))
			Ans=Mid,r=Mid-1;
		else
			l=Mid+1;
	}
	printf("%d\n",Ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
10 10
9 0 0 0 0 0 0 0 0 9
0 0 9 0 0 0 0 9 0 0
0 9 0 0 0 0 0 0 9 0
0 0 0 9 0 0 9 0 0 0
0 0 0 0 9 9 0 0 0 0
0 0 0 0 9 9 0 0 0 0
0 0 0 9 0 0 9 0 0 0
0 9 0 0 0 0 0 0 9 0
0 0 9 0 0 0 0 9 0 0
9 0 0 0 0 0 0 0 0 9
*/
/*
2 2
0 2
3 0
*/
