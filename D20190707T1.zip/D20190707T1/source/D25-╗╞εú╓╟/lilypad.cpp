#include<bits/stdc++.h>
#define LL long long
using namespace std;
struct Xjh{
	int x,y,s,d;
};
queue<Xjh>Q;
int M,N,Map[110][110],Up,sx,sy,ex,ey;
int Vis[101][101];
int dx[]={1,2,-1,-2,1,2,-1,-2};
int dy[]={2,-1,2,-1,-2,1,-2,1};
int Check(int Energy){
	memset(Vis,-1,sizeof(Vis));
	while(!Q.empty())Q.pop();
	Xjh u;
	u.x=sx;
	u.y=sy;
	u.s=0;
	u.d=Energy;
	Vis[u.x][u.y]=u.d;
	Q.push(u);
	while(!Q.empty()){
		u=Q.front();
		Q.pop();
//		printf("%d %d %d %d\n",u.x,u.y,u.s,u.d);
		if(u.x==ex&&u.y==ey)
			return u.s;
		for(int k=0;k<8;++k){
			int nx=u.x+dx[k];
			int ny=u.y+dy[k];
			if(nx<1||ny<1||nx>M||ny>N)continue;
			if(Map[nx][ny]==2)continue;
			if(Map[nx][ny]==1&&Vis[nx][ny]<u.d){
				Vis[nx][ny]=u.d;
				Xjh v;
				v.x=nx;
				v.y=ny;
				v.s=u.s+1;
				v.d=u.d;
				Q.push(v);
			}
			if(Map[nx][ny]==0&&Vis[nx][ny]<u.d-1&&u.d>0){
				Vis[nx][ny]=u.d-1;
				Xjh v;
				v.x=nx;
				v.y=ny;
				v.s=u.s+1;
				v.d=u.d-1;
				Q.push(v);
			}
		}
	}
	return -1;
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	scanf("%d%d",&M,&N);
	for(int i=1;i<=M;++i)
		for(int j=1;j<=N;++j){
			scanf("%d",&Map[i][j]);
			Up+=(Map[i][j]==0);
			if(Map[i][j]==3)
				Map[i][j]=1,sx=i,sy=j;
			if(Map[i][j]==4)
				Map[i][j]=1,ex=i,ey=j;
		}
	int Mid,Ans=-1,l=0,r=Up;
	while(l<=r){
		Mid=(l+r)>>1;
		if(Check(Mid)!=-1){
			Ans=Mid;
			r=Mid-1;
		}
		else
			l=Mid+1;
	}
	if(Ans==-1)
		puts("-1 -1");
	else
		printf("%d %d\n",Ans,Check(Ans));
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
4 8
0 0 0 1 0 0 0 0
0 0 0 0 0 2 0 1
0 0 0 0 0 4 0 0
3 0 0 0 0 0 1 0
*/
/*
3 3
0 0 4
1 3 2
0 0 1
*/
/*
4 3
0 0 4
1 3 2
0 0 0
0 1 1 
*/
/*
4 3
0 0 4
0 3 2
0 0 0
0 1 0
*/
