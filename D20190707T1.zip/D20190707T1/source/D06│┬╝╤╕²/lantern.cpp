#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn = 1005;
const int INF = 2147483647;
int n,m,cur,tot,init,l,r;
struct node
{
	int x,y,val;
};
bool col[maxn][55],row[55][maxn];
node lan[50050];
bool pd = false;
bool cmp(node x, node y)
{
	return x.val < y.val;
}
bool check(int x)
{
	int il = 0;
	int ir = tot;
	memset(col,0,sizeof(col));
	memset(row,0,sizeof(row));
	/*for(int i = 1;i <= n;i++)
	{
		for(int j = 1;j <= m;j++)row[i][j] = 0;
	}
	for(int j = 1;j <= m;j++)
	{
		for(int i = 1;i <= n;i++)col[j][i] = 0;
	}*/
	while(il < ir - 1)
	{
		int imid = (il + ir)>>1;
		if(lan[imid].val >= x)
		{
			ir = imid;
		}
		else il = imid;
	}
	for(int i = ir;i <= tot;i++)
	{
		for(ll j = max(lan[i].y - x + 1,1);j <= min(lan[i].y + x - 1,m);j++)row[lan[i].x][j] = 1;
		for(ll j = max(lan[i].x - x + 1,1);j <= min(lan[i].x + x - 1,n);j++)col[lan[i].y][j] = 1;
		//row[lan[i].x].x = min(row[lan[i].x].x,max(lan[i].y - x + 1,1));
		//row[lan[i].x].y = max(row[lan[i].x].y,min(lan[i].y + x - 1,m));
		//col[lan[i].y].x = min(col[lan[i].y].x,max(lan[i].x - x + 1,1));
		//col[lan[i].y].y = max(col[lan[i].y].y,min(lan[i].x + x - 1,n));
	}
	for(int i = 1;i <= n;i++)
	{
		for(int j = 1;j <= m;j++)if(!row[i][j])return false;
	//	if(row[i].x != 1 || row[i].y != m)return false;
	}
	for(int j = 1;j <= m;j++)
	{
		for(int i = 1;i <= n;i++)if(!col[j][i])return false;
		//if(col[j].x != 1 || col[j].y != n)return false;
	}
	return true;
}
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	cin>>n>>m;
	r = -1;
	for(int i = 1; i <= n;i++)
	{
		for(int j = 1;j <= m;j++)
		{
			cin>>cur;
			if(cur != 0)
			{
				pd = true;
				lan[++tot].x = i;
				lan[tot].y = j;
				lan[tot].val = cur;
				r = max(cur,r);
			}
		}
	}
	if(!pd)
	{
		cout<<"-1";
		return 0;
	}
	sort(lan + 1,lan + tot + 1,cmp);
	l = 0;
	r++;
	init = r;
	while(l < r - 1)
	{
		int mid = (l + r)>>1;
		if(check(mid))
		{
			r = mid;
		}
		else l = mid;
	}
	if(r == init)
	{
		cout<<"-1";
	}
	else
	{
		cout<<r;
	}
	return 0;
}
/*
3 4
1 1 1 1
1 0 0 1 
1 1 1 1 
*/
