#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll maxn = 850;
struct node
{
	double x,y;
};
node cur,con,icur;
char a[maxn][maxn];
ll xc,yc;
double sx,sy,p,q;
bool cal(node cur)
{
	double sum = sqrt(cur.x * cur.x + cur.y * cur.y);
	if(sum >= double(10))return true;
	return false;
}
bool check(node cur)
{
	for(int i = 1;i <= 100;i++)
	{
		icur.x = con.x + cur.x * cur.x - cur.y * cur.y;
		icur.y = con.y + cur.x * cur.y * (double)(2.0);
		if(cal(icur))return false;
		cur = icur;
	}
	return true;
}
int main()
{
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx;
	cin>>p>>q;
	con.x = p;
	con.y = q;
	for(int j = 0;j < yc;j++)
	{
		for(int i = 0;i < xc;i++)
		{
			cur.x = sy + 0.005 * (double)(i);
			cur.y = sx + 0.01 * (double)(j);
			if(check(cur))a[j][i] = 'a';
			else a[j][i] = ' ';
		}
	}
	for(int j = 0;j < yc;j++)
	{
		for(int i = 0;i < xc;i++)
		{
			cout<<a[j][i];
		}
		cout<<"\n";
	}
}
