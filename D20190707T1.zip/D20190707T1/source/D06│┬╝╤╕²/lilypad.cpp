#include <bits/stdc++.h>
using namespace std;
#define P pair<ll,pair<ll,ll> >
typedef long long ll;
const ll maxn = 105;
const ll INF = 2147483647;
struct node
{
	ll to,val;
};
node cur;
vector<node> e[10500];
P icur;
node item;
priority_queue<P,vector<P>,greater<P> >q;
ll n,m,tem,st,ed,a[maxn][maxn],dis[10500],step[10500];
bool vis[10500];
ll dx[10] = {2,1,-1,-2,-2,-1,1,2};
ll dy[10] = {1,2,2,1,-1,-2,-2,-1};
void init(ll x,ll y)
{
	ll num = (x - 1) * m + y;
	for(int i = 0;i < 8;i++)
	{
		ll curx = x + dx[i];
		ll cury = y + dy[i];
		if(curx < 1||curx > n||cury < 1||cury > m)continue;
		ll inum = (curx - 1) * m + cury;
		if(a[curx][cury] == 1||a[curx][cury] == 3||a[curx][cury] == 4)
		{
			cur.val = 0;
			cur.to = inum;
			e[num].push_back(cur);
		}
		else if(a[curx][cury] == 0)
		{
			cur.val = 1;
			cur.to = inum;
			e[num].push_back(cur);
		}
	}
	return;
}
void dijkstra()
{
	for(int i= 1;i < 10500;i++)
	{
		dis[i] = INF;
		step[i] = INF;
	}
	dis[st] = 0;
	step[st] = 0;
	q.push(make_pair(dis[st],make_pair(step[st],st)));
	while(!q.empty())
	{
		icur = q.top();
		q.pop();
		tem = icur.second.second;
		if(!vis[tem])
		{
			vis[tem] = 1;
			for(int i = 0;i < e[tem].size();i++)
			{
				item = e[tem][i];
				if(dis[item.to] >= dis[tem] + item.val)
				{
					dis[item.to] = dis[tem] + item.val;
					step[item.to] = min(step[item.to],icur.second.first + 1);
					q.push(make_pair(dis[item.to],make_pair(icur.second.first + 1,item.to)));
				}
			}
		}
	}
}
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	cin>>n>>m;
	for(int i = 1;i <= n;i++)
	{
		for(int j = 1; j <= m;j++)
		{
			cin>>a[i][j];
			if(a[i][j] == 3)
			{
				st = (i - 1) * m + j;
			}
			if(a[i][j] == 4)
			{
				ed = (i - 1) * m + j;
			}
		}
	}
	for(int i = 1;i <= n;i++)
	{
		for(int j = 1;j <= m;j++)
		{
			init(i,j);
		}
	}
	dijkstra();
	if(dis[ed] == INF)
	{
		cout<<"-1 -1";
	}
	else
	{
		cout<<dis[ed]<<" "<<step[ed];
	}
	return 0;
}
/*
4 8
0 0 0 1 0 0 0 0
0 0 0 0 0 2 0 1
0 0 0 0 0 4 0 0
3 0 0 0 0 0 1 0
*/
/*
4 4
0 1 0 0
0 4 0 1
3 0 0 0 
0 0 0 0
*/
