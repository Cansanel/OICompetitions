#include<bits/stdc++.h>
using namespace std;
const int dx[8]={1,1,-1,-1,2,2,-2,-2};
const int dy[8]={2,-2,2,-2,1,-1,1,-1};
int a[105][105];
int n,m;
int ans1,ans2;
inline void read(int &x)
{
	char ch=getchar();
	int p=0;
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) p=p*10+ch-48,ch=getchar();
	x=p;
}
int zdi,zdj;
bool vis[105][105];
int did[105][105];
int does[105][105];
bool flag=0;
void dfs(int i,int j,int now,int bs)
{
	if(a[i][j]==2||i<=0||i>n||j<=0||j>m||now>did[i][j]||(now==did[i][j]&&bs>=does[i][j])||vis[i][j]) return;
	if(a[i][j]==0) now++;
	vis[i][j]=1;
	did[i][j]=now;
	does[i][j]=bs;
	if(i==zdi&&j==zdj)
		{
			if(now<ans1)ans2=bs;
			if(now==ans1)ans2=min(bs,ans2);
			ans1=min(ans1,now);
			vis[i][j]=0;
			return;
		}
	for(int b=0;b<8;b++)
		{
			dfs(i+dx[b],j+dy[b],now,bs+1);
		}
	vis[i][j]=0;
}
int qsi,qsj;
int main()
{
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	read(n);
	read(m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			{
				read(a[i][j]);
				if(a[i][j]==3) qsi=i,qsj=j,a[i][j]=1;
				if(a[i][j]==4) zdi=i,zdj=j,a[i][j]=1;
			}
	memset(did,0x7f,sizeof(did));
	ans1=INT_MAX;
	ans2=ans1;
	dfs(qsi,qsj,0,0);
	if(ans1==INT_MAX) cout<<-1<<" "<<-1<<endl;
	else cout<<ans1<<" "<<ans2<<endl;
	return 0;
}

