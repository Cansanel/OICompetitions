#include<bits/stdc++.h>
using namespace std;
struct node{
	double x,y;
};
node operator*(node a,node b)
{
	node k;
	k.x=a.x*b.x-a.y*b.y;
	k.y=a.x*b.y+a.y*b.x;
	return k;
}
node operator+(node a,node b)
{
	node k;
	k.x=a.x+b.x;
	k.y=a.y+b.y;
	return k;
}
node operator-(node a,node b)
{
	node k;
	k.x=a.x-b.x;
	k.y=a.y-b.y;
	return k;
}
double mc(node a)
{
	return sqrt(a.x*a.x+a.y*a.y);
}
node c;
node sz[105];
bool sl(node a)
{
	node d;
	d.x=a.x;
	d.y=a.y;
	sz[0]=d;
	if(mc(sz[0])>=10) return 0;
	for(int i=1;i<=100;i++)
		{
			sz[i]=(sz[i-1]*sz[i-1])+c;
			if(mc(sz[i])>=10) return 0;
//			cout<<mc(sz[i])<<" "<<sz[i].x<<" "<<sz[i].y<<endl;
//			system("pause");
		}
	return 1;
}
int main()
{
	freopen("fractal.in","r",stdout);
	freopen("fractal.out","w",stdout);
	int x,y;
	double a,b;
	double p,q;
	cin>>y>>x>>b>>a>>p>>q;
	c.x=p;
	c.y=q;
	for(int j=0;j<y;j++)
	{
		for(int i=0;i<x;i++)
			{
				node p;
				p.x=b+i*0.005;
				p.y=a+j*0.01;
				if(sl(p)) putchar('a');
				else putchar(' ');
			}
		putchar('\n');
	}
		
	return 0;
}
