#include<bits/stdc++.h>
using namespace std;
inline void read(int &x)
{
	char ch=getchar();
	int p=0;
	while(!isdigit(ch)) ch=getchar();
	while(isdigit(ch)) p=p*10+ch-48,ch=getchar();
	x=p;
}
int a[505][10005];
int cfh[505][10005];
int cfl[505][10005];
int n,m;
bool check(int x)
{
	memset(cfh,0,sizeof(cfh));
	memset(cfl,0,sizeof(cfl));
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			{
				if(a[i][j]<x) continue;
				cfh[i][max(0,j-x)]++;
				cfh[i][min(m+1,j+x-1)]--;
				cfl[max(0,i-x)][j]++;
				cfl[min(n+1,i+x-1)][j]--;
			}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			{
				cfh[i][j]=cfh[i][j-1]+cfh[i][j];
			}
	for(int j=1;j<=m;j++)
		for(int i=1;i<=n;i++)
			{
				cfh[i][j]=cfh[i-1][j]+cfh[i][j];
				if(!cfh[i][j]&&!cfl[i][j]) return 0;
			}
	return 1;
}
int main()
{
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	read(n);
	read(m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			read(a[i][j]);
		}
	if(m<=10000)
		{
			for(int i=0;i<=max(n,m);i++)
			{
				if(check(i))
				{
					cout<<i<<endl;
					return 0;
				}
			}
			cout<<-1<<endl;
			return 0;
		}
	cout<<-1<<endl;
	return 0;
}

