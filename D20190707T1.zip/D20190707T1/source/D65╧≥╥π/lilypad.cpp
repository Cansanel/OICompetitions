#include<bits/stdc++.h>
using namespace std;
const int dir[8][2]={{1,2},{1,-2},{-1,2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-1}};
const int INF=0x3f3f3f3f;
struct node{
	int to,nxt,val;
}edge[80010];
struct node2{
	int v,use,step;
};
bool operator <(const node2 &x,const node2 &y){
	if(x.use>y.use)return 1;
	if(x.use==y.use&&x.step>y.step)return 1;
	return 0;
}
struct node3{
	int use,step;
}dis[10010];
int n,m,head[10010],tot,a[110][110],num[110][110],sx,sy,ex,ey,vis[10010],tmp;
priority_queue<node2>q;
void add(int from,int to,int d){
	edge[++tot]=(node){to,head[from],d};
	head[from]=tot;
}
void dij(int s){
	dis[s].use=dis[s].step=0;
	for(int i=head[s];i;i=edge[i].nxt){
		int u=s,v=edge[i].to,va=edge[i].val;
		dis[v].use=dis[u].use+va;
		dis[v].step=dis[u].step+1;
		q.push((node2){v,dis[v].use,dis[v].step});
	}
	vis[s]=1;
	while(!q.empty()){
		int u=q.top().v;
		q.pop();
		if(vis[u])continue;
		vis[u]=1;
		for(int i=head[u];i;i=edge[i].nxt){
			int v=edge[i].to,va=edge[i].val;
			if(dis[u].use+va<dis[v].use||(dis[u].use+va==dis[v].use&&dis[u].step+1<dis[v].step)){
				dis[v].use=dis[u].use+va;
				dis[v].step=dis[u].step+1;
				q.push((node2){v,dis[v].use,dis[v].step});
			}
		}
	}
}
int main(){
	freopen("lilypad.in","r",stdin);
	freopen("lilypad.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>a[i][j];
			if(a[i][j]==3){
				sx=i;
				sy=j;
			}
			if(a[i][j]==4){
				ex=i;
				ey=j;
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			num[i][j]=++tmp;
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			for(int k=0;k<8;k++){
				int tx=i+dir[k][0],ty=j+dir[k][1];
				if(tx>0&&tx<=n&&ty>0&&ty<=m&&a[tx][ty]!=2){
					if(a[tx][ty]!=0){
						add(num[i][j],num[tx][ty],0);
					}else{
						add(num[i][j],num[tx][ty],1);
					}
				}
			}
		}
	}
	for(int i=1;i<=tmp;i++){
		dis[i].use=dis[i].step=INF;
	}
	dij(num[sx][sy]);
	if(dis[num[ex][ey]].use==INF){
		cout<<"-1 -1"<<endl;
		return 0;
	}
	cout<<dis[num[ex][ey]].use<<" "<<dis[num[ex][ey]].step<<endl;
	return 0;
}

