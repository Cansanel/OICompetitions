#include<bits/stdc++.h>
using namespace std;
struct node{
	double x,y;
}z[110];
int yc,xc;
double sy,sx,p,q;
char c[810][810];
double mo(double a,double b){
	return sqrt(a*a+b*b);
}
node times(node a,node b){
	node k;
	k.x=(a.x*b.x)-(a.y*b.y);
	k.y=(a.x*b.y)+(a.y*b.x);
	return k;
}
bool check(double a,double b){
	z[0].x=a;
	z[0].y=b;
	if(mo(a,b)>=10){
		return 0;
	}
	for(int i=1;i<=100;i++){
		z[i]=times(z[i-1],z[i-1]);
		z[i].x+=p;
		z[i].y+=q;
		if(mo(z[i].x,z[i].y)>=10){
			return 0;
		}
	}
	return 1;
}
int main(){
	freopen("fractal.in","r",stdin);
	freopen("fractal.out","w",stdout);
	cin>>yc>>xc>>sy>>sx>>p>>q;
	for(int j=0;j<yc;j++){
		for(int i=0;i<xc;i++){
			if(check(sy+0.005*i,sx+0.01*j)){
				c[j][i]='a';
			}else{
				c[j][i]=' ';
			}
		}
	}
	for(int j=0;j<yc;j++){
		for(int i=0;i<xc;i++){
			putchar(c[j][i]);
		}
		cout<<endl;
	}
	return 0;
}

