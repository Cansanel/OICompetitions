#include<bits/stdc++.h>
using namespace std;
int n,m,h[510][10010],l[510][10010];
inline int rd(){
	char ch=getchar();
	int x=0;
	while(ch<'0'||ch>'9'){
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x;
}
int main(){
	freopen("lantern.in","r",stdin);
	freopen("lantern.out","w",stdout);
	n=rd();m=rd();
	memset(h,0x7f,sizeof(h));
	memset(l,0x7f,sizeof(l));
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			int x=rd();
			if(x!=0){
				for(int k=max(1,j-x+1);k<=min(m,j+x-1);k++){
					h[i][k]=min(h[i][k],abs(j-k)+1);
				}
				for(int k=max(1,i-x+1);k<=min(n,i+x-1);k++){
					l[k][j]=min(l[k][j],abs(i-k)+1);
				}
			}
		}
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(l[i][j]==0x7f7f7f7f||h[i][j]==0x7f7f7f7f){
				cout<<"-1"<<endl;
				return 0;
			}else{
				ans=max(ans,l[i][j]);
				ans=max(ans,h[i][j]);
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}

